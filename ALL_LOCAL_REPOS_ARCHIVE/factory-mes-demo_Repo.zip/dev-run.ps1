# Start the Node server and the .NET acquisition client in separate consoles
param(
  [int]$Port = 4317
)

$env:PORT = $Port

Write-Output "Starting Node server on port $Port..."
Start-Process -NoNewWindow -FilePath pwsh -ArgumentList "-NoProfile","-Command","node src/server.js" -WindowStyle Normal

Start-Sleep -Seconds 1

Write-Output "Starting .NET acquisition client..."
Start-Process -NoNewWindow -FilePath pwsh -ArgumentList "-NoProfile","-Command","dotnet run --project dotnet/AcquisitionService.csproj" -WindowStyle Normal

Write-Output "Both processes started. Use Ctrl+C in each console or stop them from Task Manager."
