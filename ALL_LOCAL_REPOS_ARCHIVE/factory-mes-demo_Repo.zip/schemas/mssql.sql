-- Microsoft SQL Server schema for the Factory MES Demo.
-- Use this as the production database shape when replacing the JSON demo store.

CREATE TABLE ProductionOrders (
    OrderNo NVARCHAR(40) NOT NULL PRIMARY KEY,
    ProductCode NVARCHAR(40) NOT NULL,
    Color NVARCHAR(30) NOT NULL,
    Quantity INT NOT NULL,
    Completed INT NOT NULL DEFAULT 0,
    Rejected INT NOT NULL DEFAULT 0,
    Status NVARCHAR(30) NOT NULL,
    DueDate DATETIME2 NULL,
    CreatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
    UpdatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
);

CREATE TABLE Machines (
    MachineId NVARCHAR(60) NOT NULL PRIMARY KEY,
    ShopId NVARCHAR(40) NOT NULL,
    ShopName NVARCHAR(80) NOT NULL,
    StationCode NVARCHAR(20) NOT NULL,
    Controller NVARCHAR(80) NOT NULL,
    ProtocolName NVARCHAR(40) NOT NULL,
    HmiPanel NVARCHAR(60) NULL,
    IsActive BIT NOT NULL DEFAULT 1
);

CREATE TABLE PlcTagSamples (
    SampleId BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    MachineId NVARCHAR(60) NOT NULL,
    TagName NVARCHAR(120) NOT NULL,
    TagValue NVARCHAR(200) NOT NULL,
    Quality NVARCHAR(30) NOT NULL,
    ProtocolName NVARCHAR(40) NOT NULL,
    CapturedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_PlcTagSamples_Machines FOREIGN KEY (MachineId) REFERENCES Machines(MachineId)
);

CREATE INDEX IX_PlcTagSamples_Machine_Time
ON PlcTagSamples (MachineId, CapturedAt DESC);

CREATE TABLE TraceabilityEvents (
    TraceId BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    VIN NVARCHAR(40) NOT NULL,
    OrderNo NVARCHAR(40) NOT NULL,
    Model NVARCHAR(40) NOT NULL,
    Color NVARCHAR(30) NOT NULL,
    StationCode NVARCHAR(20) NOT NULL,
    LineName NVARCHAR(80) NOT NULL,
    Controller NVARCHAR(80) NOT NULL,
    ProtocolName NVARCHAR(40) NOT NULL,
    Result NVARCHAR(10) NOT NULL,
    CycleTimeSec DECIMAL(10,2) NULL,
    EnergyKw DECIMAL(10,2) NULL,
    OperatorId NVARCHAR(40) NULL,
    ShiftCode NVARCHAR(10) NULL,
    CapturedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_TraceabilityEvents_ProductionOrders FOREIGN KEY (OrderNo) REFERENCES ProductionOrders(OrderNo)
);

CREATE INDEX IX_TraceabilityEvents_VIN_Time
ON TraceabilityEvents (VIN, CapturedAt DESC);

CREATE TABLE DowntimeEvents (
    DowntimeId BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    MachineId NVARCHAR(60) NULL,
    ShopName NVARCHAR(80) NOT NULL,
    FaultCode NVARCHAR(80) NOT NULL,
    Category NVARCHAR(40) NOT NULL,
    DurationSeconds INT NOT NULL,
    StartedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
    ClosedAt DATETIME2 NULL
);

CREATE TABLE QualityEvents (
    QualityId BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    VIN NVARCHAR(40) NULL,
    ShopName NVARCHAR(80) NOT NULL,
    Result NVARCHAR(10) NOT NULL,
    DefectCode NVARCHAR(80) NULL,
    Disposition NVARCHAR(80) NULL,
    CapturedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
);

CREATE TABLE OeeSnapshots (
    SnapshotId BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    ShopId NVARCHAR(40) NULL,
    Availability DECIMAL(8,5) NOT NULL,
    Performance DECIMAL(8,5) NOT NULL,
    Quality DECIMAL(8,5) NOT NULL,
    OeeValue DECIMAL(8,5) NOT NULL,
    GoodCount INT NOT NULL,
    RejectCount INT NOT NULL,
    CapturedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
);

CREATE TABLE ErpTransactions (
    TransactionId BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    OrderNo NVARCHAR(40) NOT NULL,
    TransactionType NVARCHAR(40) NOT NULL,
    Payload NVARCHAR(MAX) NOT NULL,
    Status NVARCHAR(30) NOT NULL,
    CreatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
);

CREATE TABLE ProtocolEndpoints (
    EndpointId INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    ProtocolName NVARCHAR(40) NOT NULL,
    EndpointAddress NVARCHAR(200) NOT NULL,
    ShopName NVARCHAR(80) NULL,
    Purpose NVARCHAR(200) NOT NULL,
    IsEnabled BIT NOT NULL DEFAULT 1
);
