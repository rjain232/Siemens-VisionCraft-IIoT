"use strict";

let machineData = [];

const receiveMachineData = (req, res, body) => {
  const { machineId, temperature, timestamp } = body || {};

  if (!machineId || typeof temperature === "undefined") {
    res.writeHead(400, { "content-type": "application/json; charset=utf-8" });
    res.end(JSON.stringify({ error: "machineId and temperature are required" }));
    return;
  }

  machineData.push({ machineId, temperature, timestamp: timestamp || new Date().toISOString() });

  if (machineData.length > 100) {
    machineData.shift();
  }

  res.writeHead(201, { "content-type": "application/json; charset=utf-8" });
  res.end(JSON.stringify({ message: "Data successfully received by backend" }));
};

const getMachineData = (req, res) => {
  res.writeHead(200, { "content-type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(machineData));
};

module.exports = { receiveMachineData, getMachineData };
