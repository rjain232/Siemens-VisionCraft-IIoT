const { useEffect, useState } = React;
const root = ReactDOM.createRoot(document.getElementById("root"));

function percent(value) {
  return `${Math.round((Number(value) || 0) * 100)}%`;
}

function statusClass(status) {
  return String(status || "info").toLowerCase();
}

function fmtTime(iso) {
  if (!iso) return "None";
  return new Date(iso).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

function App() {
  const [activeView, setActiveView] = useState("plant");
  const [data, setData] = useState(null);
  const [machineTelemetry, setMachineTelemetry] = useState([]);
  const [traceFilter, setTraceFilter] = useState("");
  const [connection, setConnection] = useState("Connecting");

  useEffect(() => {
    let ignore = false;
    let pollTimer = null;

    async function loadInitialState() {
      try {
        const [stateResponse, telemetryResponse] = await Promise.all([
          fetch("/api/state"),
          fetch("/api/machines/data").catch(() => null)
        ]);
        if (ignore) return;
        const nextData = await stateResponse.json();
        const nextTelemetry = telemetryResponse ? await telemetryResponse.json() : [];
        setData(nextData);
        setMachineTelemetry(nextTelemetry);
      } catch (error) {
        if (!ignore) setConnection("Offline");
      }
    }

    loadInitialState();

    const feed = new EventSource("/events");
    feed.onopen = () => setConnection("Live");
    feed.onmessage = (message) => {
      try {
        setData(JSON.parse(message.data));
      } catch (error) {
        // ignore malformed updates
      }
    };
    feed.onerror = () => setConnection("Reconnecting");

    const refreshTelemetry = async () => {
      try {
        const response = await fetch("/api/machines/data");
        if (response.ok) {
          setMachineTelemetry(await response.json());
        }
      } catch (error) {
        // ignore polling failures
      }
    };

    refreshTelemetry();
    pollTimer = window.setInterval(refreshTelemetry, 5000);

    return () => {
      ignore = true;
      feed.close();
      if (pollTimer) window.clearInterval(pollTimer);
    };
  }, []);

  const releaseOrder = async (event) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const payload = {
      productCode: form.get("productCode"),
      color: form.get("color"),
      quantity: Number(form.get("quantity"))
    };
    await fetch("/api/orders", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(payload)
    });
  };

  const metrics = data
    ? [
        {
          label: "Active Order",
          value: data.mes.orderNo,
          detail: `${data.mes.productCode} / ${data.mes.color}`
        },
        {
          label: "MES OEE",
          value: percent(data.mes.oee.value),
          detail: `A ${percent(data.mes.oee.availability)} / P ${percent(data.mes.oee.performance)} / Q ${percent(data.mes.oee.quality)}`
        },
        {
          label: "WIP",
          value: data.mes.wipCount,
          detail: `${data.mes.completedQty}/${data.mes.plannedQty} finished for order`
        },
        {
          label: "Alerts",
          value: data.mes.activeAlerts,
          detail: `${data.automation.masterPlc.status} master PLC`
        }
      ]
    : [];

  const renderPlantView = () => {
    if (!data) return <div className="empty">Loading plant data</div>;
    const layers = data.plant.architectureLayers || [];
    return (
      <div className="dashboard-grid">
        <section className="panel">
          <div className="panel-header">
            <h2 className="panel-title">Shop Floor</h2>
            <span className={`status ${statusClass(data.automation.masterPlc.status)}`}>{data.automation.masterPlc.status}</span>
          </div>
          <div className="panel-body">
            <div className="shop-grid">
              {data.shops.map((shop) => (
                <article className="shop-card" key={shop.name}>
                  <div className="shop-top">
                    <div>
                      <h3 className="shop-name">{shop.name}</h3>
                      <div className="field-label">{shop.stationCode} / {shop.controller}</div>
                    </div>
                    <span className={`status ${statusClass(shop.status)}`}>{shop.status}</span>
                  </div>
                  <p className="shop-role">{shop.role}</p>
                  <div className="kv-grid">
                    <div className="kv"><span className="field-label">Actual</span><strong>{shop.actual}/{shop.targetPerShift}</strong></div>
                    <div className="kv"><span className="field-label">Good / Reject</span><strong>{shop.good} / {shop.reject}</strong></div>
                    <div className="kv"><span className="field-label">Cycle</span><strong>{shop.cycleTimeSec}s</strong></div>
                    <div className="kv"><span className="field-label">Protocol</span><strong>{shop.protocolName}</strong></div>
                    <div className="kv"><span className="field-label">Last VIN</span><strong>{shop.lastVin || "None"}</strong></div>
                    <div className="kv"><span className="field-label">Result</span><strong>{shop.lastResult}</strong></div>
                  </div>
                  <div className="progress" aria-label="Cycle progress">
                    <span style={{ width: `${Math.min(100, shop.cycleProgressPercent)}%` }} />
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <aside className="stack">
          <section className="panel">
            <div className="panel-header">
              <h2 className="panel-title">Master PLC</h2>
              <span className="small-pill">{data.automation.masterPlc.id}</span>
            </div>
            <div className="panel-body">
              <div className="kv-grid">
                <div className="kv"><span className="field-label">Controller</span><strong>{data.automation.masterPlc.controller}</strong></div>
                <div className="kv"><span className="field-label">Line PLCs</span><strong>{data.automation.masterPlc.connectedLinePlcs}</strong></div>
                <div className="kv"><span className="field-label">Status</span><strong>{data.automation.masterPlc.status}</strong></div>
                <div className="kv"><span className="field-label">Updated</span><strong>{fmtTime(data.generatedAt)}</strong></div>
              </div>
            </div>
          </section>

          <section className="panel">
            <div className="panel-header">
              <h2 className="panel-title">Plant Profile</h2>
              <span className="small-pill">{data.plant.companyProfile?.partner || "Industrial Automation"}</span>
            </div>
            <div className="panel-body">
              <div className="kv-grid">
                <div className="kv"><span className="field-label">Scope</span><strong>{data.plant.companyProfile?.scope || ""}</strong></div>
                <div className="kv"><span className="field-label">Communication</span><strong>{(data.plant.communicationStack || []).join(" • ")}</strong></div>
                <div className="kv"><span className="field-label">Frontend / Backend</span><strong>{data.plant.softwareStack?.frontend || ""} / {data.plant.softwareStack?.backend || ""}</strong></div>
                <div className="kv"><span className="field-label">Database / Acquisition</span><strong>{data.plant.softwareStack?.database || ""} / {data.plant.softwareStack?.acquisition || ""}</strong></div>
              </div>
            </div>
          </section>

          <section className="panel">
            <div className="panel-header">
              <h2 className="panel-title">IIoT Telemetry</h2>
              <span className="small-pill">{machineTelemetry.length} samples</span>
            </div>
            <div className="panel-body">
              {machineTelemetry.length ? (
                <div className="telemetry-list">
                  {machineTelemetry.slice(-5).reverse().map((reading, index) => (
                    <div className="telemetry-item" key={`${reading.machineId || "machine"}-${index}`}>
                      <div className="telemetry-meta">
                        <strong>{reading.machineId || "Machine"}</strong>
                        <span>{reading.timestamp ? fmtTime(reading.timestamp) : "Unknown"}</span>
                      </div>
                      <div className="telemetry-temp">{Number(reading.temperature).toFixed(1)}°C</div>
                    </div>
                  ))}
                </div>
              ) : <div className="empty">Waiting for machine telemetry…</div>}
            </div>
          </section>

          <section className="panel">
            <div className="panel-header">
              <h2 className="panel-title">Automation Pyramid</h2>
              <span className="small-pill">{data.plant.architecture}</span>
            </div>
            <div className="panel-body">
              <div className="architecture-flow">
                {layers.map((layer, index) => (
                  <div className="architecture-stage" key={layer.name}>
                    <div className="architecture-node">
                      <div className="layer-order">{index + 1}</div>
                      <div className="layer-content">
                        <strong>{layer.name}</strong>
                        <div className="layer-role">{layer.role}</div>
                        <div className="layer-connectors">{layer.connectors.map((connector) => <span className="small-pill" key={connector}>{connector}</span>)}</div>
                      </div>
                    </div>
                    {index < layers.length - 1 ? <div className="architecture-arrow" aria-hidden="true">↓</div> : null}
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="panel">
            <div className="panel-header">
              <h2 className="panel-title">Network Topology</h2>
              <span className="small-pill">Ethernet • TCP/IP • PROFINET</span>
            </div>
            <div className="panel-body">
              <div className="network-flow">
                <div className="network-node network-node-primary"><strong>MES Server</strong><span>Reporting / Traceability / Order Control</span></div>
                <div className="network-connector"><div className="network-arrow" aria-hidden="true">→</div><div className="network-labels"><span className="protocol-chip protocol-ethernet">Ethernet</span><span className="protocol-chip protocol-tcp">TCP/IP</span></div></div>
                <div className="network-node network-node-control"><strong>SCADA / HMI</strong><span>Operator stations • Historian • Alarm view</span></div>
                <div className="network-connector"><div className="network-arrow" aria-hidden="true">→</div><div className="network-labels"><span className="protocol-chip protocol-ethernet">Ethernet</span><span className="protocol-chip protocol-ethernet">OPC UA</span></div></div>
                <div className="network-node network-node-control"><strong>Master PLC / Gateway</strong><span>{data.automation.masterPlc.id} • {data.automation.masterPlc.controller}</span></div>
                <div className="network-connector"><div className="network-arrow" aria-hidden="true">→</div><div className="network-labels"><span className="protocol-chip protocol-profinet">PROFINET</span><span className="protocol-chip protocol-ethernet">EtherNet/IP</span></div></div>
                <div className="network-node network-node-plc"><strong>Line PLCs</strong><span>{data.automation.linePlcs.slice(0, 4).map((plc) => plc.id).join(" • ")}</span></div>
                <div className="network-connector"><div className="network-arrow" aria-hidden="true">→</div><div className="network-labels"><span className="protocol-chip protocol-profinet">PROFINET</span><span className="protocol-chip protocol-modbus">Modbus</span></div></div>
                <div className="network-node network-node-field"><strong>Drives / Sensors</strong><span>{data.shops.slice(0, 4).map((shop) => shop.name).join(" • ")}</span></div>
              </div>
            </div>
          </section>

          <section className="panel">
            <div className="panel-header">
              <h2 className="panel-title">Vehicle Flow</h2>
            </div>
            <div className="panel-body">
              <div className="flow">
                {data.shops.map((shop) => (
                  <div className="flow-step" key={shop.name}>
                    <strong>{shop.name}</strong>
                    <span>{shop.status} / {shop.protocolName}</span>
                  </div>
                ))}
              </div>
            </div>
          </section>
        </aside>
      </div>
    );
  };

  const renderScadaView = () => {
    if (!data) return <div className="empty">Loading plant data</div>;
    return (
      <div className="dashboard-grid">
        <section className="panel">
          <div className="panel-header">
            <h2 className="panel-title">SCADA Trends</h2>
            <span className="small-pill">{data.scada.trends.length} samples</span>
          </div>
          <div className="panel-body">
            <canvas id="trend-canvas" className="trend-canvas" width="900" height="260" />
          </div>
        </section>
        <aside className="panel">
          <div className="panel-header">
            <h2 className="panel-title">Alarm Queue</h2>
          </div>
          <div className="panel-body">
            <div className="event-list">
              {data.scada.alarms.length ? data.scada.alarms.map((event) => (
                <article className="event" key={`${event.lineName || event.type}-${event.timestamp}`}>
                  <div className="shop-top">
                    <strong>{event.lineName || event.type}</strong>
                    <span className={`status ${statusClass(event.severity)}`}>{event.severity}</span>
                  </div>
                  <div className="metric-detail">{fmtTime(event.timestamp)} / {event.message || ""}</div>
                </article>
              )) : <div className="empty">No active alarms</div>}
            </div>
          </div>
        </aside>
      </div>
    );
  };

  const renderMesView = () => {
    if (!data) return <div className="empty">Loading plant data</div>;
    const mes = data.mes;
    return (
      <div className="stack">
        <section className="panel">
          <div className="panel-header">
            <h2 className="panel-title">MES Execution</h2>
            <span className="small-pill">{mes.orderNo}</span>
          </div>
          <div className="panel-body">
            <div className="oee-grid">
              <div className="oee-tile"><span className="field-label">Availability</span><strong>{percent(mes.oee.availability)}</strong><div className="progress"><span style={{ width: `${Math.min(100, Math.round(mes.oee.availability * 100))}%` }} /></div></div>
              <div className="oee-tile"><span className="field-label">Performance</span><strong>{percent(mes.oee.performance)}</strong><div className="progress"><span style={{ width: `${Math.min(100, Math.round(mes.oee.performance * 100))}%` }} /></div></div>
              <div className="oee-tile"><span className="field-label">Quality</span><strong>{percent(mes.oee.quality)}</strong><div className="progress"><span style={{ width: `${Math.min(100, Math.round(mes.oee.quality * 100))}%` }} /></div></div>
              <div className="oee-tile"><span className="field-label">OEE</span><strong>{percent(mes.oee.value)}</strong><div className="progress"><span style={{ width: `${Math.min(100, Math.round(mes.oee.value * 100))}%` }} /></div></div>
            </div>
          </div>
        </section>
        <section className="panel">
          <div className="panel-header">
            <h2 className="panel-title">Line PLC Results</h2>
          </div>
          <div className="panel-body table-wrap">
            <table>
              <thead>
                <tr><th>Shop</th><th>PLC</th><th>HMI</th><th>Status</th><th>VIN</th><th>Good</th><th>Reject</th><th>OEE</th></tr>
              </thead>
              <tbody>
                {data.automation.linePlcs.map((plc, index) => {
                  const shop = data.shops[index];
                  return (
                    <tr key={plc.id}>
                      <td>{shop.name}</td>
                      <td>{plc.id}</td>
                      <td>{plc.hmiPanel}</td>
                      <td><span className={`status ${statusClass(plc.status)}`}>{plc.status}</span></td>
                      <td>{plc.lastVin || "None"}</td>
                      <td>{shop.good}</td>
                      <td>{shop.reject}</td>
                      <td>{percent(shop.oee.value)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </section>
      </div>
    );
  };

  const renderErpView = () => {
    if (!data) return <div className="empty">Loading plant data</div>;
    const order = data.erp.activeOrder;
    return (
      <div className="stack">
        <section className="panel">
          <div className="panel-header">
            <h2 className="panel-title">SAP / ERP Order</h2>
            <span className="status running">{order.status}</span>
          </div>
          <div className="panel-body">
            <div className="split">
              <div className="kv-grid">
                <div className="kv"><span className="field-label">Order</span><strong>{order.orderNo}</strong></div>
                <div className="kv"><span className="field-label">Product</span><strong>{order.productCode}</strong></div>
                <div className="kv"><span className="field-label">Color</span><strong>{order.color}</strong></div>
                <div className="kv"><span className="field-label">Quantity</span><strong>{order.completed}/{order.quantity}</strong></div>
              </div>
              <form className="form-grid" onSubmit={releaseOrder}>
                <label className="form-field">
                  <span className="field-label">Product</span>
                  <select name="productCode">
                    <option>SUV-X1</option>
                    <option>SEDAN-A2</option>
                    <option>HATCH-C3</option>
                    <option>EV-E4</option>
                  </select>
                </label>
                <label className="form-field">
                  <span className="field-label">Color</span>
                  <select name="color">
                    <option>White</option>
                    <option>Silver</option>
                    <option>Blue</option>
                    <option>Red</option>
                    <option>Black</option>
                  </select>
                </label>
                <label className="form-field">
                  <span className="field-label">Qty</span>
                  <input name="quantity" min="10" max="500" type="number" defaultValue="120" />
                </label>
                <button className="primary-button" type="submit">Release</button>
              </form>
            </div>
          </div>
        </section>
        <section className="panel">
          <div className="panel-header">
            <h2 className="panel-title">Inventory and Dispatch</h2>
            <span className="small-pill">{data.erp.finishedGoods} finished</span>
          </div>
          <div className="panel-body split">
            <div className="pill-row">
              {Object.entries(data.erp.inventory).map(([key, value]) => <span className="small-pill" key={key}>{key}: {value}</span>)}
            </div>
            <div className="table-wrap">
              <table>
                <thead><tr><th>VIN</th><th>Model</th><th>Color</th><th>Order</th></tr></thead>
                <tbody>
                  {data.erp.dispatchQueue.length ? data.erp.dispatchQueue.map((item) => (
                    <tr key={item.vin}>
                      <td>{item.vin}</td>
                      <td>{item.model}</td>
                      <td>{item.color}</td>
                      <td>{item.orderNo}</td>
                    </tr>
                  )) : <tr><td colSpan="4">No vehicles dispatched yet</td></tr>}
                </tbody>
              </table>
            </div>
          </div>
        </section>
      </div>
    );
  };

  const renderProtocolsView = () => {
    if (!data) return <div className="empty">Loading plant data</div>;
    return (
      <div className="dashboard-grid">
        <section className="panel">
          <div className="panel-header">
            <h2 className="panel-title">Industrial Protocols</h2>
            <span className="small-pill">{data.protocols.catalog.length} mapped</span>
          </div>
          <div className="panel-body table-wrap">
            <table>
              <thead><tr><th>Name</th><th>Family</th><th>Use</th><th>Port/Transport</th></tr></thead>
              <tbody>
                {data.protocols.catalog.map((item) => (
                  <tr key={item.name}>
                    <td>{item.name}</td>
                    <td>{item.family}</td>
                    <td>{item.typicalUse}</td>
                    <td>{item.defaultPort}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
        <aside className="panel">
          <div className="panel-header">
            <h2 className="panel-title">Latest Packets</h2>
          </div>
          <div className="panel-body packet-list">
            {data.protocols.latestPackets.map((packet) => (
              <article className="packet" key={`${packet.protocolName}-${packet.endpoint || packet.topic || packet.historianPath}`}>
                <strong>{packet.protocolName}</strong>
                <div className="field-label">{packet.quality} / {packet.endpoint || packet.topic || packet.historianPath}</div>
                <code>{JSON.stringify(packet, null, 2)}</code>
              </article>
            ))}
          </div>
        </aside>
      </div>
    );
  };

  const renderTraceabilityView = () => {
    if (!data) return <div className="empty">Loading plant data</div>;
    const records = data.traceability.recentRecords.filter((record) => {
      if (!traceFilter) return true;
      return String(record.vin || "").toLowerCase().includes(traceFilter.toLowerCase());
    });
    return (
      <div className="stack">
        <section className="panel">
          <div className="panel-header">
            <h2 className="panel-title">In Process Vehicles</h2>
            <input value={traceFilter} onChange={(event) => setTraceFilter(event.target.value)} placeholder="VIN filter" />
          </div>
          <div className="panel-body">
            <div className="shop-grid">
              {data.traceability.inProcess.length ? data.traceability.inProcess.map((vehicle) => (
                <article className="shop-card" key={vehicle.vin}>
                  <div className="shop-top">
                    <h3 className="shop-name">{vehicle.vin}</h3>
                    <span className={`status ${statusClass(vehicle.status)}`}>{vehicle.status}</span>
                  </div>
                  <div className="kv-grid">
                    <div className="kv"><span className="field-label">Shop</span><strong>{vehicle.currentShop}</strong></div>
                    <div className="kv"><span className="field-label">Model</span><strong>{vehicle.model}</strong></div>
                    <div className="kv"><span className="field-label">Color</span><strong>{vehicle.color}</strong></div>
                    <div className="kv"><span className="field-label">Order</span><strong>{vehicle.orderNo}</strong></div>
                  </div>
                </article>
              )) : <div className="empty">No WIP vehicles yet</div>}
            </div>
          </div>
        </section>
        <section className="panel">
          <div className="panel-header">
            <h2 className="panel-title">Trace Records</h2>
            <span className="small-pill">{records.length} visible</span>
          </div>
          <div className="panel-body table-wrap">
            <table>
              <thead><tr><th>Time</th><th>VIN</th><th>Station</th><th>Result</th><th>Protocol</th><th>Cycle</th><th>Operator</th></tr></thead>
              <tbody>
                {records.length ? records.map((record) => (
                  <tr key={`${record.vin}-${record.timestamp}`}>
                    <td>{fmtTime(record.timestamp)}</td>
                    <td>{record.vin}</td>
                    <td>{record.lineName}</td>
                    <td><span className={`status ${record.result === "OK" ? "running" : "warning"}`}>{record.result}</span></td>
                    <td>{record.protocol}</td>
                    <td>{record.cycleTimeSec}s</td>
                    <td>{record.operatorId}</td>
                  </tr>
                )) : <tr><td colSpan="7">No matching trace records</td></tr>}
              </tbody>
            </table>
          </div>
        </section>
      </div>
    );
  };

  const renderIndustrialNetworkView = () => {
    if (!data) return <div className="empty">Loading plant data</div>;
    return (
      <div className="stack">
        <section className="panel">
          <div className="panel-header">
            <h2 className="panel-title">Industrial Network</h2>
            <span className="small-pill">Plant control and field communication</span>
          </div>
          <div className="panel-body">
            <div className="network-flow network-flow-large">
              <div className="network-node network-node-primary"><strong>MES Server</strong><span>Reporting / traceability / production monitoring</span></div>
              <div className="network-connector"><div className="network-arrow" aria-hidden="true">→</div><div className="network-labels"><span className="protocol-chip protocol-ethernet">Ethernet</span><span className="protocol-chip protocol-tcp">TCP/IP</span></div></div>
              <div className="network-node network-node-control"><strong>SCADA / HMI</strong><span>Operator workstations • alarms • trends</span></div>
              <div className="network-connector"><div className="network-arrow" aria-hidden="true">→</div><div className="network-labels"><span className="protocol-chip protocol-ethernet">Ethernet</span><span className="protocol-chip protocol-ethernet">OPC UA</span></div></div>
              <div className="network-node network-node-control"><strong>Master PLC / Gateway</strong><span>{data.automation.masterPlc.id} • {data.automation.masterPlc.controller}</span></div>
              <div className="network-connector"><div className="network-arrow" aria-hidden="true">→</div><div className="network-labels"><span className="protocol-chip protocol-profinet">PROFINET</span><span className="protocol-chip protocol-ethernet">EtherNet/IP</span></div></div>
              <div className="network-node network-node-plc"><strong>Line PLCs</strong><span>{data.automation.linePlcs.slice(0, 5).map((plc) => plc.id).join(" • ")}</span></div>
              <div className="network-connector"><div className="network-arrow" aria-hidden="true">→</div><div className="network-labels"><span className="protocol-chip protocol-profinet">PROFINET</span><span className="protocol-chip protocol-modbus">Modbus</span></div></div>
              <div className="network-node network-node-field"><strong>Drives / Sensors</strong><span>{data.shops.slice(0, 5).map((shop) => shop.name).join(" • ")}</span></div>
            </div>
          </div>
        </section>
        <section className="panel">
          <div className="panel-header">
            <h2 className="panel-title">Protocol Legend</h2>
          </div>
          <div className="panel-body">
            <div className="pill-row">
              <span className="protocol-chip protocol-ethernet">Ethernet</span>
              <span className="protocol-chip protocol-tcp">TCP/IP</span>
              <span className="protocol-chip protocol-profinet">PROFINET</span>
              <span className="protocol-chip protocol-ethernet">EtherNet/IP</span>
              <span className="protocol-chip protocol-modbus">Modbus TCP/IP</span>
              <span className="protocol-chip protocol-ethernet">MQTT</span>
              <span className="protocol-chip protocol-ethernet">OPC UA</span>
            </div>
            <div className="legend-note">This path represents the control and information flow from MES and SCADA/HMI down to the field devices via Ethernet-based automation networks.</div>
          </div>
        </section>
      </div>
    );
  };

  const renderView = () => {
    if (!data) return <div className="empty">Loading plant data</div>;
    switch (activeView) {
      case "scada": return renderScadaView();
      case "mes": return renderMesView();
      case "erp": return renderErpView();
      case "protocols": return renderProtocolsView();
      case "industrial-network": return renderIndustrialNetworkView();
      case "traceability": return renderTraceabilityView();
      case "plant":
      default: return renderPlantView();
    }
  };

  return (
    <div className="app-shell">
      <header className="topbar">
        <div>
          <p className="eyebrow">Heimdall Automotive Plant</p>
          <h1>Digital Factory Command Center</h1>
        </div>
        <div className={`connection-pill ${connection === "Live" ? "live" : "offline"}`}>{connection}</div>
      </header>

      <nav className="tabs" aria-label="Dashboard views">
        {[
          { key: "plant", label: "Plant" },
          { key: "scada", label: "SCADA" },
          { key: "mes", label: "MES" },
          { key: "erp", label: "ERP" },
          { key: "protocols", label: "Protocols" },
          { key: "industrial-network", label: "Industrial Network" },
          { key: "traceability", label: "Trace" }
        ].map((tab) => (
          <button
            key={tab.key}
            className={`tab ${activeView === tab.key ? "active" : ""}`}
            type="button"
            onClick={() => setActiveView(tab.key)}
          >
            {tab.label}
          </button>
        ))}
      </nav>

      <section className="metric-strip">
        {metrics.length ? metrics.map((item) => (
          <article className="metric" key={item.label}>
            <div className="metric-label">{item.label}</div>
            <div className="metric-value">{item.value}</div>
            <div className="metric-detail">{item.detail}</div>
          </article>
        )) : <div className="empty">Loading plant data</div>}
      </section>

      <main className="view-root">{renderView()}</main>
    </div>
  );
}

root.render(<App />);
