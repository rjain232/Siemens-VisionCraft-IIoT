"use strict";

const state = {
  activeView: "plant",
  data: null,
  machineTelemetry: [],
  traceFilter: ""
};

const viewRoot = document.getElementById("view-root");
const metricStrip = document.getElementById("metric-strip");
const connectionPill = document.getElementById("connection-pill");

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function percent(value) {
  return `${Math.round((Number(value) || 0) * 100)}%`;
}

function statusClass(status) {
  return String(status || "info").toLowerCase();
}

function fmtTime(iso) {
  if (!iso) return "None";
  return new Date(iso).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

function setConnection(status) {
  connectionPill.textContent = status;
  connectionPill.className = `connection-pill ${status === "Live" ? "live" : "offline"}`;
}

function renderMetrics(data) {
  const mes = data.mes;
  metricStrip.innerHTML = [
    {
      label: "Active Order",
      value: mes.orderNo,
      detail: `${mes.productCode} / ${mes.color}`
    },
    {
      label: "MES OEE",
      value: percent(mes.oee.value),
      detail: `A ${percent(mes.oee.availability)} / P ${percent(mes.oee.performance)} / Q ${percent(mes.oee.quality)}`
    },
    {
      label: "WIP",
      value: mes.wipCount,
      detail: `${mes.completedQty}/${mes.plannedQty} finished for order`
    },
    {
      label: "Alerts",
      value: mes.activeAlerts,
      detail: `${data.automation.masterPlc.status} master PLC`
    }
  ].map((item) => `
    <article class="metric">
      <div class="metric-label">${escapeHtml(item.label)}</div>
      <div class="metric-value">${escapeHtml(item.value)}</div>
      <div class="metric-detail">${escapeHtml(item.detail)}</div>
    </article>
  `).join("");
}

function renderPlant(data) {
  const layers = data.plant.architectureLayers || [];
  viewRoot.innerHTML = `
    <div class="dashboard-grid">
      <section class="panel">
        <div class="panel-header">
          <h2 class="panel-title">Shop Floor</h2>
          <span class="status ${statusClass(data.automation.masterPlc.status)}">${escapeHtml(data.automation.masterPlc.status)}</span>
        </div>
        <div class="panel-body">
          <div class="shop-grid">
            ${data.shops.map(renderShopCard).join("")}
          </div>
        </div>
      </section>

      <aside class="stack">
        <section class="panel">
          <div class="panel-header">
            <h2 class="panel-title">Master PLC</h2>
            <span class="small-pill">${escapeHtml(data.automation.masterPlc.id)}</span>
          </div>
          <div class="panel-body">
            <div class="kv-grid">
              <div class="kv"><span class="field-label">Controller</span><strong>${escapeHtml(data.automation.masterPlc.controller)}</strong></div>
              <div class="kv"><span class="field-label">Line PLCs</span><strong>${data.automation.masterPlc.connectedLinePlcs}</strong></div>
              <div class="kv"><span class="field-label">Status</span><strong>${escapeHtml(data.automation.masterPlc.status)}</strong></div>
              <div class="kv"><span class="field-label">Updated</span><strong>${fmtTime(data.generatedAt)}</strong></div>
            </div>
          </div>
        </section>

        <section class="panel">
          <div class="panel-header">
            <h2 class="panel-title">Plant Profile</h2>
            <span class="small-pill">${escapeHtml(data.plant.companyProfile?.partner || "Industrial Automation")}</span>
          </div>
          <div class="panel-body">
            <div class="kv-grid">
              <div class="kv"><span class="field-label">Scope</span><strong>${escapeHtml(data.plant.companyProfile?.scope || "")}</strong></div>
              <div class="kv"><span class="field-label">Communication</span><strong>${escapeHtml((data.plant.communicationStack || []).join(" • "))}</strong></div>
              <div class="kv"><span class="field-label">Frontend / Backend</span><strong>${escapeHtml(data.plant.softwareStack?.frontend || "")} / ${escapeHtml(data.plant.softwareStack?.backend || "")}</strong></div>
              <div class="kv"><span class="field-label">Database / Acquisition</span><strong>${escapeHtml(data.plant.softwareStack?.database || "")} / ${escapeHtml(data.plant.softwareStack?.acquisition || "")}</strong></div>
            </div>
          </div>
        </section>

        <section class="panel">
          <div class="panel-header">
            <h2 class="panel-title">IIoT Telemetry</h2>
            <span class="small-pill">${(state.machineTelemetry || []).length} samples</span>
          </div>
          <div class="panel-body">
            ${(state.machineTelemetry || []).length ? `
              <div class="telemetry-list">
                ${state.machineTelemetry.slice(-5).reverse().map((reading) => `
                  <div class="telemetry-item">
                    <div class="telemetry-meta">
                      <strong>${escapeHtml(reading.machineId || "Machine")}</strong>
                      <span>${escapeHtml(reading.timestamp ? fmtTime(reading.timestamp) : "Unknown")}</span>
                    </div>
                    <div class="telemetry-temp">${Number(reading.temperature).toFixed(1)}°C</div>
                  </div>
                `).join("")}
              </div>
            ` : `<div class="empty">Waiting for machine telemetry…</div>`}
          </div>
        </section>

        <section class="panel">
          <div class="panel-header">
            <h2 class="panel-title">Automation Pyramid</h2>
            <span class="small-pill">${escapeHtml(data.plant.architecture)}</span>
          </div>
          <div class="panel-body">
            <div class="architecture-flow">
              ${layers.map((layer, index) => `
                <div class="architecture-stage">
                  <div class="architecture-node">
                    <div class="layer-order">${index + 1}</div>
                    <div class="layer-content">
                      <strong>${escapeHtml(layer.name)}</strong>
                      <div class="layer-role">${escapeHtml(layer.role)}</div>
                      <div class="layer-connectors">${layer.connectors.map((connector) => `<span class="small-pill">${escapeHtml(connector)}</span>`).join("")}</div>
                    </div>
                  </div>
                  ${index < layers.length - 1 ? '<div class="architecture-arrow" aria-hidden="true">↓</div>' : ""}
                </div>
              `).join("")}
            </div>
          </div>
        </section>

        <section class="panel">
          <div class="panel-header">
            <h2 class="panel-title">Network Topology</h2>
            <span class="small-pill">Ethernet • TCP/IP • PROFINET</span>
          </div>
          <div class="panel-body">
            <div class="network-flow">
              <div class="network-node network-node-primary">
                <strong>MES Server</strong>
                <span>Reporting / Traceability / Order Control</span>
              </div>
              <div class="network-connector">
                <div class="network-arrow" aria-hidden="true">→</div>
                <div class="network-labels">
                  <span class="protocol-chip protocol-ethernet">Ethernet</span>
                  <span class="protocol-chip protocol-tcp">TCP/IP</span>
                </div>
              </div>
              <div class="network-node network-node-control">
                <strong>SCADA / HMI</strong>
                <span>Operator stations • Historian • Alarm view</span>
              </div>
              <div class="network-connector">
                <div class="network-arrow" aria-hidden="true">→</div>
                <div class="network-labels">
                  <span class="protocol-chip protocol-ethernet">Ethernet</span>
                  <span class="protocol-chip protocol-ethernet">OPC UA</span>
                </div>
              </div>
              <div class="network-node network-node-control">
                <strong>Master PLC / Gateway</strong>
                <span>${escapeHtml(data.automation.masterPlc.id)} • ${escapeHtml(data.automation.masterPlc.controller)}</span>
              </div>
              <div class="network-connector">
                <div class="network-arrow" aria-hidden="true">→</div>
                <div class="network-labels">
                  <span class="protocol-chip protocol-profinet">PROFINET</span>
                  <span class="protocol-chip protocol-ethernet">EtherNet/IP</span>
                </div>
              </div>
              <div class="network-node network-node-plc">
                <strong>Line PLCs</strong>
                <span>${data.automation.linePlcs.slice(0, 4).map((plc) => escapeHtml(plc.id)).join(" • ")}</span>
              </div>
              <div class="network-connector">
                <div class="network-arrow" aria-hidden="true">→</div>
                <div class="network-labels">
                  <span class="protocol-chip protocol-profinet">PROFINET</span>
                  <span class="protocol-chip protocol-modbus">Modbus</span>
                </div>
              </div>
              <div class="network-node network-node-field">
                <strong>Drives / Sensors</strong>
                <span>${data.shops.slice(0, 4).map((shop) => escapeHtml(shop.name)).join(" • ")}</span>
              </div>
            </div>
          </div>
        </section>

        <section class="panel">
          <div class="panel-header">
            <h2 class="panel-title">Vehicle Flow</h2>
          </div>
          <div class="panel-body">
            <div class="flow">
              ${data.shops.map((shop) => `
                <div class="flow-step">
                  <strong>${escapeHtml(shop.name)}</strong>
                  <span>${escapeHtml(shop.status)} / ${escapeHtml(shop.protocolName)}</span>
                </div>
              `).join("")}
            </div>
          </div>
        </section>
      </aside>
    </div>
  `;
}

function renderShopCard(shop) {
  return `
    <article class="shop-card">
      <div class="shop-top">
        <div>
          <h3 class="shop-name">${escapeHtml(shop.name)}</h3>
          <div class="field-label">${escapeHtml(shop.stationCode)} / ${escapeHtml(shop.controller)}</div>
        </div>
        <span class="status ${statusClass(shop.status)}">${escapeHtml(shop.status)}</span>
      </div>
      <p class="shop-role">${escapeHtml(shop.role)}</p>
      <div class="kv-grid">
        <div class="kv"><span class="field-label">Actual</span><strong>${shop.actual}/${shop.targetPerShift}</strong></div>
        <div class="kv"><span class="field-label">Good / Reject</span><strong>${shop.good} / ${shop.reject}</strong></div>
        <div class="kv"><span class="field-label">Cycle</span><strong>${shop.cycleTimeSec}s</strong></div>
        <div class="kv"><span class="field-label">Protocol</span><strong>${escapeHtml(shop.protocolName)}</strong></div>
        <div class="kv"><span class="field-label">Last VIN</span><strong>${escapeHtml(shop.lastVin || "None")}</strong></div>
        <div class="kv"><span class="field-label">Result</span><strong>${escapeHtml(shop.lastResult)}</strong></div>
      </div>
      <div class="progress" aria-label="Cycle progress">
        <span style="width: ${Math.min(100, shop.cycleProgressPercent)}%"></span>
      </div>
    </article>
  `;
}

function renderIndustrialNetwork(data) {
  viewRoot.innerHTML = `
    <div class="stack">
      <section class="panel">
        <div class="panel-header">
          <h2 class="panel-title">Industrial Network</h2>
          <span class="small-pill">Plant control and field communication</span>
        </div>
        <div class="panel-body">
          <div class="network-flow network-flow-large">
            <div class="network-node network-node-primary">
              <strong>MES Server</strong>
              <span>Reporting / traceability / production monitoring</span>
            </div>
            <div class="network-connector">
              <div class="network-arrow" aria-hidden="true">→</div>
              <div class="network-labels">
                <span class="protocol-chip protocol-ethernet">Ethernet</span>
                <span class="protocol-chip protocol-tcp">TCP/IP</span>
              </div>
            </div>
            <div class="network-node network-node-control">
              <strong>SCADA / HMI</strong>
              <span>Operator workstations • alarms • trends</span>
            </div>
            <div class="network-connector">
              <div class="network-arrow" aria-hidden="true">→</div>
              <div class="network-labels">
                <span class="protocol-chip protocol-ethernet">Ethernet</span>
                <span class="protocol-chip protocol-ethernet">OPC UA</span>
              </div>
            </div>
            <div class="network-node network-node-control">
              <strong>Master PLC / Gateway</strong>
              <span>${escapeHtml(data.automation.masterPlc.id)} • ${escapeHtml(data.automation.masterPlc.controller)}</span>
            </div>
            <div class="network-connector">
              <div class="network-arrow" aria-hidden="true">→</div>
              <div class="network-labels">
                <span class="protocol-chip protocol-profinet">PROFINET</span>
                <span class="protocol-chip protocol-ethernet">EtherNet/IP</span>
              </div>
            </div>
            <div class="network-node network-node-plc">
              <strong>Line PLCs</strong>
              <span>${data.automation.linePlcs.slice(0, 5).map((plc) => escapeHtml(plc.id)).join(" • ")}</span>
            </div>
            <div class="network-connector">
              <div class="network-arrow" aria-hidden="true">→</div>
              <div class="network-labels">
                <span class="protocol-chip protocol-profinet">PROFINET</span>
                <span class="protocol-chip protocol-modbus">Modbus</span>
              </div>
            </div>
            <div class="network-node network-node-field">
              <strong>Drives / Sensors</strong>
              <span>${data.shops.slice(0, 5).map((shop) => escapeHtml(shop.name)).join(" • ")}</span>
            </div>
          </div>
        </div>
      </section>

      <section class="panel">
        <div class="panel-header">
          <h2 class="panel-title">Protocol Legend</h2>
        </div>
        <div class="panel-body">
          <div class="pill-row">
            <span class="protocol-chip protocol-ethernet">Ethernet</span>
            <span class="protocol-chip protocol-tcp">TCP/IP</span>
            <span class="protocol-chip protocol-profinet">PROFINET</span>
            <span class="protocol-chip protocol-ethernet">EtherNet/IP</span>
            <span class="protocol-chip protocol-modbus">Modbus TCP/IP</span>
            <span class="protocol-chip protocol-ethernet">MQTT</span>
            <span class="protocol-chip protocol-ethernet">OPC UA</span>
          </div>
          <div class="legend-note">This path represents the control and information flow from MES and SCADA/HMI down to the field devices via Ethernet-based automation networks.</div>
        </div>
      </section>
    </div>
  `;
}

function renderScada(data) {
  viewRoot.innerHTML = `
    <div class="dashboard-grid">
      <section class="panel">
        <div class="panel-header">
          <h2 class="panel-title">SCADA Trends</h2>
          <span class="small-pill">${data.scada.trends.length} samples</span>
        </div>
        <div class="panel-body">
          <canvas id="trend-canvas" class="trend-canvas" width="900" height="260"></canvas>
        </div>
      </section>

      <aside class="panel">
        <div class="panel-header">
          <h2 class="panel-title">Alarm Queue</h2>
        </div>
        <div class="panel-body">
          <div class="event-list">
            ${data.scada.alarms.length ? data.scada.alarms.map(renderEvent).join("") : `<div class="empty">No active alarms</div>`}
          </div>
        </div>
      </aside>
    </div>
  `;
  drawTrend(data.scada.trends);
}

function drawTrend(samples) {
  const canvas = document.getElementById("trend-canvas");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  const width = canvas.width;
  const height = canvas.height;
  ctx.clearRect(0, 0, width, height);
  ctx.fillStyle = "#fbfdff";
  ctx.fillRect(0, 0, width, height);
  ctx.strokeStyle = "#d8e1ea";
  ctx.lineWidth = 1;
  for (let i = 0; i <= 4; i += 1) {
    const y = 24 + i * ((height - 48) / 4);
    ctx.beginPath();
    ctx.moveTo(32, y);
    ctx.lineTo(width - 20, y);
    ctx.stroke();
  }
  if (!samples.length) return;
  const points = samples.map((sample, index) => ({
    x: 32 + index * ((width - 56) / Math.max(1, samples.length - 1)),
    y: height - 28 - sample.value * (height - 58)
  }));
  ctx.strokeStyle = "#12975d";
  ctx.lineWidth = 4;
  ctx.beginPath();
  points.forEach((point, index) => {
    if (index === 0) ctx.moveTo(point.x, point.y);
    else ctx.lineTo(point.x, point.y);
  });
  ctx.stroke();
  ctx.fillStyle = "#1f2933";
  ctx.font = "13px Arial";
  ctx.fillText("OEE", 32, 18);
  ctx.fillText("100%", width - 58, 30);
  ctx.fillText("0%", width - 48, height - 18);
}

function renderMes(data) {
  const mes = data.mes;
  viewRoot.innerHTML = `
    <div class="stack">
      <section class="panel">
        <div class="panel-header">
          <h2 class="panel-title">MES Execution</h2>
          <span class="small-pill">${escapeHtml(mes.orderNo)}</span>
        </div>
        <div class="panel-body">
          <div class="oee-grid">
            ${renderOeeTile("Availability", mes.oee.availability)}
            ${renderOeeTile("Performance", mes.oee.performance)}
            ${renderOeeTile("Quality", mes.oee.quality)}
            ${renderOeeTile("OEE", mes.oee.value)}
          </div>
        </div>
      </section>

      <section class="panel">
        <div class="panel-header">
          <h2 class="panel-title">Line PLC Results</h2>
        </div>
        <div class="panel-body table-wrap">
          <table>
            <thead>
              <tr>
                <th>Shop</th><th>PLC</th><th>HMI</th><th>Status</th><th>VIN</th><th>Good</th><th>Reject</th><th>OEE</th>
              </tr>
            </thead>
            <tbody>
              ${data.automation.linePlcs.map((plc, index) => {
                const shop = data.shops[index];
                return `
                  <tr>
                    <td>${escapeHtml(shop.name)}</td>
                    <td>${escapeHtml(plc.id)}</td>
                    <td>${escapeHtml(plc.hmiPanel)}</td>
                    <td><span class="status ${statusClass(plc.status)}">${escapeHtml(plc.status)}</span></td>
                    <td>${escapeHtml(plc.lastVin || "None")}</td>
                    <td>${shop.good}</td>
                    <td>${shop.reject}</td>
                    <td>${percent(shop.oee.value)}</td>
                  </tr>
                `;
              }).join("")}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  `;
}

function renderOeeTile(label, value) {
  return `
    <div class="oee-tile">
      <span class="field-label">${escapeHtml(label)}</span>
      <strong>${percent(value)}</strong>
      <div class="progress"><span style="width: ${Math.min(100, Math.round(value * 100))}%"></span></div>
    </div>
  `;
}

function renderErp(data) {
  const order = data.erp.activeOrder;
  viewRoot.innerHTML = `
    <div class="stack">
      <section class="panel">
        <div class="panel-header">
          <h2 class="panel-title">SAP / ERP Order</h2>
          <span class="status running">${escapeHtml(order.status)}</span>
        </div>
        <div class="panel-body">
          <div class="split">
            <div class="kv-grid">
              <div class="kv"><span class="field-label">Order</span><strong>${escapeHtml(order.orderNo)}</strong></div>
              <div class="kv"><span class="field-label">Product</span><strong>${escapeHtml(order.productCode)}</strong></div>
              <div class="kv"><span class="field-label">Color</span><strong>${escapeHtml(order.color)}</strong></div>
              <div class="kv"><span class="field-label">Quantity</span><strong>${order.completed}/${order.quantity}</strong></div>
            </div>
            <form class="form-grid" id="order-form">
              <label class="form-field">
                <span class="field-label">Product</span>
                <select name="productCode">
                  <option>SUV-X1</option>
                  <option>SEDAN-A2</option>
                  <option>HATCH-C3</option>
                  <option>EV-E4</option>
                </select>
              </label>
              <label class="form-field">
                <span class="field-label">Color</span>
                <select name="color">
                  <option>White</option>
                  <option>Silver</option>
                  <option>Blue</option>
                  <option>Red</option>
                  <option>Black</option>
                </select>
              </label>
              <label class="form-field">
                <span class="field-label">Qty</span>
                <input name="quantity" min="10" max="500" type="number" value="120">
              </label>
              <button class="primary-button" type="submit">Release</button>
            </form>
          </div>
        </div>
      </section>

      <section class="panel">
        <div class="panel-header">
          <h2 class="panel-title">Inventory and Dispatch</h2>
          <span class="small-pill">${data.erp.finishedGoods} finished</span>
        </div>
        <div class="panel-body split">
          <div class="pill-row">
            ${Object.entries(data.erp.inventory).map(([key, value]) => `
              <span class="small-pill">${escapeHtml(key)}: ${escapeHtml(value)}</span>
            `).join("")}
          </div>
          <div class="table-wrap">
            <table>
              <thead><tr><th>VIN</th><th>Model</th><th>Color</th><th>Order</th></tr></thead>
              <tbody>
                ${data.erp.dispatchQueue.length ? data.erp.dispatchQueue.map((item) => `
                  <tr><td>${escapeHtml(item.vin)}</td><td>${escapeHtml(item.model)}</td><td>${escapeHtml(item.color)}</td><td>${escapeHtml(item.orderNo)}</td></tr>
                `).join("") : `<tr><td colspan="4">No vehicles dispatched yet</td></tr>`}
              </tbody>
            </table>
          </div>
        </div>
      </section>
    </div>
  `;
  document.getElementById("order-form").addEventListener("submit", releaseOrder);
}

async function releaseOrder(event) {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const payload = {
    productCode: form.get("productCode"),
    color: form.get("color"),
    quantity: Number(form.get("quantity"))
  };
  await fetch("/api/orders", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(payload)
  });
}

function renderProtocols(data) {
  viewRoot.innerHTML = `
    <div class="dashboard-grid">
      <section class="panel">
        <div class="panel-header">
          <h2 class="panel-title">Industrial Protocols</h2>
          <span class="small-pill">${data.protocols.catalog.length} mapped</span>
        </div>
        <div class="panel-body table-wrap">
          <table>
            <thead><tr><th>Name</th><th>Family</th><th>Use</th><th>Port/Transport</th></tr></thead>
            <tbody>
              ${data.protocols.catalog.map((item) => `
                <tr>
                  <td>${escapeHtml(item.name)}</td>
                  <td>${escapeHtml(item.family)}</td>
                  <td>${escapeHtml(item.typicalUse)}</td>
                  <td>${escapeHtml(item.defaultPort)}</td>
                </tr>
              `).join("")}
            </tbody>
          </table>
        </div>
      </section>
      <aside class="panel">
        <div class="panel-header">
          <h2 class="panel-title">Latest Packets</h2>
        </div>
        <div class="panel-body packet-list">
          ${data.protocols.latestPackets.map((packet) => `
            <article class="packet">
              <strong>${escapeHtml(packet.protocolName)}</strong>
              <div class="field-label">${escapeHtml(packet.quality)} / ${escapeHtml(packet.endpoint || packet.topic || packet.historianPath)}</div>
              <code>${escapeHtml(JSON.stringify(packet, null, 2))}</code>
            </article>
          `).join("")}
        </div>
      </aside>
    </div>
  `;
}

function renderTraceability(data) {
  const records = data.traceability.recentRecords.filter((record) => {
    if (!state.traceFilter) return true;
    return String(record.vin || "").toLowerCase().includes(state.traceFilter.toLowerCase());
  });
  viewRoot.innerHTML = `
    <div class="stack">
      <section class="panel">
        <div class="panel-header">
          <h2 class="panel-title">In Process Vehicles</h2>
          <input id="trace-filter" value="${escapeHtml(state.traceFilter)}" placeholder="VIN filter">
        </div>
        <div class="panel-body">
          <div class="shop-grid">
            ${data.traceability.inProcess.length ? data.traceability.inProcess.map((vehicle) => `
              <article class="shop-card">
                <div class="shop-top">
                  <h3 class="shop-name">${escapeHtml(vehicle.vin)}</h3>
                  <span class="status ${statusClass(vehicle.status)}">${escapeHtml(vehicle.status)}</span>
                </div>
                <div class="kv-grid">
                  <div class="kv"><span class="field-label">Shop</span><strong>${escapeHtml(vehicle.currentShop)}</strong></div>
                  <div class="kv"><span class="field-label">Model</span><strong>${escapeHtml(vehicle.model)}</strong></div>
                  <div class="kv"><span class="field-label">Color</span><strong>${escapeHtml(vehicle.color)}</strong></div>
                  <div class="kv"><span class="field-label">Order</span><strong>${escapeHtml(vehicle.orderNo)}</strong></div>
                </div>
              </article>
            `).join("") : `<div class="empty">No WIP vehicles yet</div>`}
          </div>
        </div>
      </section>
      <section class="panel">
        <div class="panel-header">
          <h2 class="panel-title">Trace Records</h2>
          <span class="small-pill">${records.length} visible</span>
        </div>
        <div class="panel-body table-wrap">
          <table>
            <thead>
              <tr><th>Time</th><th>VIN</th><th>Station</th><th>Result</th><th>Protocol</th><th>Cycle</th><th>Operator</th></tr>
            </thead>
            <tbody>
              ${records.length ? records.map((record) => `
                <tr>
                  <td>${fmtTime(record.timestamp)}</td>
                  <td>${escapeHtml(record.vin)}</td>
                  <td>${escapeHtml(record.lineName)}</td>
                  <td><span class="status ${record.result === "OK" ? "running" : "warning"}">${escapeHtml(record.result)}</span></td>
                  <td>${escapeHtml(record.protocol)}</td>
                  <td>${escapeHtml(record.cycleTimeSec)}s</td>
                  <td>${escapeHtml(record.operatorId)}</td>
                </tr>
              `).join("") : `<tr><td colspan="7">No matching trace records</td></tr>`}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  `;
  document.getElementById("trace-filter").addEventListener("input", (event) => {
    state.traceFilter = event.target.value;
    render();
  });
}

function renderEvent(event) {
  return `
    <article class="event">
      <div class="shop-top">
        <strong>${escapeHtml(event.lineName || event.type)}</strong>
        <span class="status ${statusClass(event.severity)}">${escapeHtml(event.severity)}</span>
      </div>
      <div class="metric-detail">${fmtTime(event.timestamp)} / ${escapeHtml(event.message || "")}</div>
    </article>
  `;
}

function render() {
  const data = state.data;
  if (!data) {
    viewRoot.innerHTML = `<div class="empty">Loading plant data</div>`;
    return;
  }
  renderMetrics(data);
  if (state.activeView === "plant") renderPlant(data);
  if (state.activeView === "scada") renderScada(data);
  if (state.activeView === "mes") renderMes(data);
  if (state.activeView === "erp") renderErp(data);
  if (state.activeView === "protocols") renderProtocols(data);
  if (state.activeView === "industrial-network") renderIndustrialNetwork(data);
  if (state.activeView === "traceability") renderTraceability(data);
}

document.querySelectorAll(".tab").forEach((button) => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach((tab) => tab.classList.remove("active"));
    button.classList.add("active");
    state.activeView = button.dataset.view;
    render();
  });
});

async function loadInitialState() {
  const [stateResponse, telemetryResponse] = await Promise.all([
    fetch("/api/state"),
    fetch("/api/machines/data").catch(() => null)
  ]);
  state.data = await stateResponse.json();
  state.machineTelemetry = telemetryResponse ? await telemetryResponse.json() : [];
  render();
}

function startTelemetryPolling() {
  const refresh = async () => {
    try {
      const response = await fetch("/api/machines/data");
      if (response.ok) {
        state.machineTelemetry = await response.json();
        render();
      }
    } catch (error) {
      // swallow polling errors and keep the existing dashboard visible
    }
  };

  refresh();
  window.setInterval(refresh, 5000);
}

function startLiveFeed() {
  const feed = new EventSource("/events");
  feed.onopen = () => setConnection("Live");
  feed.onmessage = (message) => {
    state.data = JSON.parse(message.data);
    render();
  };
  feed.onerror = () => {
    setConnection("Reconnecting");
  };
}

loadInitialState()
  .then(() => {
    startLiveFeed();
    startTelemetryPolling();
  })
  .catch(() => {
    setConnection("Offline");
    viewRoot.innerHTML = `<div class="empty">Server not reachable</div>`;
  });
