using System.Net.Http.Json;
using System.Text.Json;

var baseUrl = Environment.GetEnvironmentVariable("FACTORY_API_URL") ?? "http://localhost:4317";
using var client = new HttpClient
{
    BaseAddress = new Uri(baseUrl)
};

Console.WriteLine($"Data acquisition service connected to {baseUrl}");
Console.WriteLine("Polling /api/state every 2 seconds. Press Ctrl+C to stop.");

while (true)
{
    try
    {
        var state = await client.GetFromJsonAsync<FactoryState>("/api/state");
        if (state is null)
        {
            Console.WriteLine("No plant state returned.");
        }
        else
        {
            foreach (var shop in state.Shops)
            {
                var sample = new TagSample(
                    shop.Id,
                    shop.Name,
                    shop.ProtocolName,
                    shop.Status,
                    shop.LastVin,
                    shop.Good,
                    shop.Reject,
                    DateTimeOffset.UtcNow);

                Console.WriteLine(JsonSerializer.Serialize(sample));
            }
        }
    }
    catch (Exception ex)
    {
        Console.WriteLine($"Acquisition error: {ex.Message}");
    }

    await Task.Delay(TimeSpan.FromSeconds(2));
}

public sealed record FactoryState(IReadOnlyList<ShopState> Shops);

public sealed record ShopState(
    string Id,
    string Name,
    string ProtocolName,
    string Status,
    string? LastVin,
    int Good,
    int Reject);

public sealed record TagSample(
    string ShopId,
    string ShopName,
    string Protocol,
    string MachineStatus,
    string? LastVin,
    int GoodCount,
    int RejectCount,
    DateTimeOffset CapturedAt);
