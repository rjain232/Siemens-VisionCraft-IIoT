"use strict";

const { receiveMachineData, getMachineData } = require("../controllers/machineController");

function machineRouter(req, res, body) {
  const pathname = new URL(req.url, `http://${req.headers.host || "localhost"}`).pathname;

  if (req.method === "POST" && pathname === "/api/machines/data") {
    receiveMachineData(req, res, body);
    return true;
  }

  if (req.method === "GET" && pathname === "/api/machines/data") {
    getMachineData(req, res);
    return true;
  }

  return false;
}

module.exports = machineRouter;
