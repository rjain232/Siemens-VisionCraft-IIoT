# Factory MES Demo

A runnable project based on the handwritten industrial notes:

```text
Sensors -> PLC / HMI / SCADA -> MES -> SAP / ERP
```

It simulates an automotive plant aligned to the notes you shared, including Siemens-style PLC/HMI/SCADA automation, MES reporting, SAP/ERP order release, and industrial protocols such as PROFINET, EtherNet/IP, PROFIBUS, Modbus TCP/IP, MQTT, and OPC UA.

It simulates an automotive plant:

```text
Press Shop -> Body Shop -> Paint Shop -> Engine and Transmission -> TCF Shop -> Test Track -> Stock Yard
```

The demo architecture now follows:

```text
SAP / ERP (Business Planning)
  -> MES Server (Reporting / Production / Traceability)
  -> Master PLC / Gateway
  -> Line PLCs
  -> Drives / Servo Drives / VFD / Sensors
```

## What Is Included

- Node.js backend with no external packages.
- Live browser dashboard for Plant, SCADA, MES, ERP, Protocols, and Traceability.
- Simulated master PLC and line PLC hierarchy.
- Simulated HMI/operator messages.
- SCADA alarms and OEE trend.
- MES production order execution, WIP, quality, traceability, and OEE.
- ERP/SAP-style order release, inventory, and dispatch queue.
- Mock protocol adapters for PROFINET, EtherNet/IP, PROFIBUS, Modbus TCP/IP, MQTT, OPC-UA, OPC-DA, and OPC-HDA.
- Microsoft SQL Server and MySQL schema files.
- .NET/C# data-acquisition sample that polls the Node API.

## Run

From this folder:

```powershell
node src/server.js
```

Open:

```text
http://localhost:4317
```

If port 4317 is busy:

```powershell
$env:PORT=4320
node src/server.js
```

### Docker (optional)

Build and run the Node demo in a container (Node only):

```bash
docker build -t factory-mes-demo:latest .
docker run -p 4317:4317 -e PORT=4317 --rm factory-mes-demo:latest
```

The container runs the same `node src/server.js` server and exposes port `4317`.

## Project Map

```text
factory-mes-demo/
  src/
    server.js       HTTP server, APIs, static files, live event stream
    simulator.js    PLC, SCADA, MES, ERP, WIP, OEE, traceability simulation
    protocols.js    Mock industrial protocol adapters
    store.js        JSON-backed demo data store
  public/
    index.html      Dashboard shell
    styles.css      Industrial dashboard styling
    app.js          Browser dashboard logic
  schemas/
    mssql.sql       SQL Server schema
    mysql.sql       MySQL schema
  dotnet/
    Program.cs      C# data acquisition worker sample
```

## Main APIs

```text
GET  /api/state
GET  /api/events
GET  /api/traceability
POST /api/orders
GET  /events
```

`/events` is a Server-Sent Events stream used by the dashboard for live updates.

## How The Layers Map

```text
Level 4: ERP / SAP
  Production order, inventory, dispatch

Level 3: MES
  OEE, traceability, WIP, quality, order execution

Level 2: SCADA / HMI
  Alarms, live status, trends, operator messages

Level 1: PLC / drives / controllers
  Master PLC, line PLCs, status, cycles, counts

Level 0: sensors / actuators
  Simulated part-present, safety, energy, temperature, air pressure
```

## Production Upgrade Path

Replace the mock adapters in `src/protocols.js` with real connectors:

- Siemens: S7/PROFINET gateway, OPC-UA server, or Siemens Industrial Edge.
- Rockwell: EtherNet/IP connector or FactoryTalk gateway.
- Legacy systems: OPC-DA/HDA bridge or historian connector.
- IIoT: MQTT broker with TLS and topic governance.
- SQL: use `schemas/mssql.sql` or `schemas/mysql.sql`.
- ERP: replace the demo order API with SAP integration through IDoc, BAPI, OData, or middleware.

The demo intentionally keeps the runnable path dependency-free so it can start with only Node.js.
