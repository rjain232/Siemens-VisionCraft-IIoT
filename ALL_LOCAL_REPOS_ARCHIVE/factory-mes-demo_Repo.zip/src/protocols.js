"use strict";

const protocolCatalog = [
  {
    id: "profinet",
    name: "PROFINET",
    family: "Industrial Ethernet",
    typicalUse: "Siemens PLCs, remote IO, drives, HMIs, robot interfaces",
    defaultPort: "Real-time Ethernet",
    layerFocus: "Layer 2 plus application profile",
    exampleAddress: "PNIO/Plant1/BodyShop/S7-1500"
  },
  {
    id: "ethernet-ip",
    name: "EtherNet/IP",
    family: "Industrial Ethernet",
    typicalUse: "Rockwell/Allen-Bradley controllers, drives, robots, IO",
    defaultPort: "TCP/UDP 44818",
    layerFocus: "Application protocol over TCP/UDP/IP",
    exampleAddress: "EIP/10.20.30.40/Assembly/LinePLC"
  },
  {
    id: "profibus",
    name: "PROFIBUS",
    family: "Fieldbus",
    typicalUse: "Legacy Siemens IO, drives, process instruments",
    defaultPort: "RS-485 bus",
    layerFocus: "Physical and data-link fieldbus",
    exampleAddress: "PB-DP/3/PaintOvenRemoteIO"
  },
  {
    id: "modbus-tcp",
    name: "Modbus TCP/IP",
    family: "Open industrial protocol",
    typicalUse: "Meters, drives, utility devices, simple third-party controllers",
    defaultPort: "TCP 502",
    layerFocus: "Application protocol over TCP/IP",
    exampleAddress: "MBTCP/10.20.30.55:502/HoldingRegister40001"
  },
  {
    id: "mqtt",
    name: "MQTT",
    family: "IIoT publish/subscribe",
    typicalUse: "Gateway-to-MES, gateway-to-cloud, event streaming",
    defaultPort: "TCP 1883 or TLS 8883",
    layerFocus: "Application messaging over TCP",
    exampleAddress: "factory/bodyshop/line1/status"
  },
  {
    id: "opc-ua",
    name: "OPC-UA",
    family: "Industrial interoperability",
    typicalUse: "SCADA/MES integration, structured tag models, secure subscriptions",
    defaultPort: "TCP 4840",
    layerFocus: "Application data model and secure session",
    exampleAddress: "opc.tcp://localhost:4840/Objects/Plant/Line1"
  },
  {
    id: "opc-da",
    name: "OPC-DA",
    family: "Legacy OPC",
    typicalUse: "Older Windows SCADA and real-time tag servers",
    defaultPort: "Microsoft COM/DCOM",
    layerFocus: "Windows COM/DCOM application layer",
    exampleAddress: "OPCDA://LegacyServer/Plant.Line1.Speed"
  },
  {
    id: "opc-hda",
    name: "OPC-HDA",
    family: "Legacy OPC history",
    typicalUse: "Historical process data from plant historians",
    defaultPort: "Microsoft COM/DCOM",
    layerFocus: "Historical query interface",
    exampleAddress: "OPCHDA://Historian/Line1.CycleTime"
  }
];

function round(value, decimals = 2) {
  const factor = 10 ** decimals;
  return Math.round(value * factor) / factor;
}

function qualityFromStatus(status) {
  if (status === "Fault") return "Bad";
  if (status === "Blocked" || status === "Starved") return "Uncertain";
  return "Good";
}

class ProtocolAdapter {
  constructor(definition) {
    this.definition = definition;
  }

  readLineTags(line, tick) {
    const statusCode = {
      Running: 1,
      Idle: 2,
      Fault: 3,
      Blocked: 4,
      Starved: 5,
      Maintenance: 6
    }[line.status] || 0;

    const values = {
      "plc.status": line.status,
      "plc.statusCode": statusCode,
      "plc.cycleTimeSec": round(line.cycleTimeSec, 1),
      "plc.goodCount": line.good,
      "plc.rejectCount": line.reject,
      "plc.wip": line.wip,
      "hmi.currentModel": line.currentModel,
      "hmi.operatorMessage": line.operatorMessage,
      "drive.speedPercent": round(line.driveSpeedPercent, 1),
      "sensor.partPresent": line.wip > 0,
      "sensor.safetyOk": line.status !== "Fault",
      "scada.energyKw": round(line.energyKw, 1),
      "scada.temperatureC": round(line.temperatureC, 1),
      "scada.airPressureBar": round(line.airPressureBar, 2),
      "mes.stationResult": line.lastResult,
      "mes.lastVin": line.lastVin || "None"
    };

    if (this.definition.id === "modbus-tcp") {
      return {
        protocolId: this.definition.id,
        protocolName: this.definition.name,
        endpoint: this.definition.exampleAddress,
        quality: qualityFromStatus(line.status),
        timestamp: new Date().toISOString(),
        registers: {
          40001: statusCode,
          40002: Math.round(line.driveSpeedPercent * 10),
          40003: line.good,
          40004: line.reject,
          40005: Math.round(line.energyKw * 10)
        }
      };
    }

    if (this.definition.id === "mqtt") {
      return {
        protocolId: this.definition.id,
        protocolName: this.definition.name,
        topic: `factory/${line.id}/telemetry`,
        qos: 1,
        quality: qualityFromStatus(line.status),
        timestamp: new Date().toISOString(),
        payload: values
      };
    }

    if (this.definition.id === "opc-hda") {
      return {
        protocolId: this.definition.id,
        protocolName: this.definition.name,
        historianPath: `${this.definition.exampleAddress}/${line.id}`,
        quality: "Good",
        timestamp: new Date().toISOString(),
        queryWindow: "last_15_minutes",
        samples: [
          { tag: "cycleTimeSec.avg", value: round(line.cycleTimeSec + Math.sin(tick / 7), 2) },
          { tag: "energyKw.avg", value: round(line.energyKw + Math.cos(tick / 5), 2) },
          { tag: "rejectCount.sum", value: line.reject }
        ]
      };
    }

    return {
      protocolId: this.definition.id,
      protocolName: this.definition.name,
      endpoint: this.definition.exampleAddress,
      quality: qualityFromStatus(line.status),
      timestamp: new Date().toISOString(),
      tags: values
    };
  }

  writeCommand(command) {
    return {
      protocolId: this.definition.id,
      accepted: true,
      command,
      timestamp: new Date().toISOString(),
      note: "Demo adapter acknowledged the command. Replace this with a vendor SDK call in production."
    };
  }
}

function createAdapters() {
  return Object.fromEntries(protocolCatalog.map((definition) => [
    definition.id,
    new ProtocolAdapter(definition)
  ]));
}

module.exports = {
  protocolCatalog,
  createAdapters
};
