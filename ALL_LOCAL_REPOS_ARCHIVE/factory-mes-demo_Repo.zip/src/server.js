"use strict";

const http = require("http");
const fs = require("fs");
const path = require("path");
const { URL } = require("url");
const { PlantStore } = require("./store");
const { FactorySimulator } = require("./simulator");

const rootDir = path.resolve(__dirname, "..");
const publicDir = path.join(rootDir, "public");
const port = Number(process.env.PORT || 4317);
const iiotBaseUrl = process.env.IIOT_BACKEND_URL || "http://127.0.0.1:5000";
const store = new PlantStore(path.join(rootDir, "data", "factory-log.json"));
const simulator = new FactorySimulator(store);
const sseClients = new Set();

const mimeTypes = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".ico": "image/x-icon"
};

function sendJson(res, status, payload) {
  const body = JSON.stringify(payload, null, 2);
  res.writeHead(status, {
    "content-type": "application/json; charset=utf-8",
    "cache-control": "no-store"
  });
  res.end(body);
}

function proxyToIiot(req, res, body) {
  const targetUrl = new URL(req.url, iiotBaseUrl);
  const options = {
    hostname: targetUrl.hostname,
    port: targetUrl.port || 80,
    path: `${targetUrl.pathname}${targetUrl.search}`,
    method: req.method,
    headers: { ...req.headers }
  };
  delete options.headers.host;

  if (body !== undefined) {
    const payload = typeof body === "string" ? body : JSON.stringify(body);
    options.headers["content-length"] = Buffer.byteLength(payload);
  }

  const proxyReq = http.request(options, (proxyRes) => {
    res.writeHead(proxyRes.statusCode || 502, proxyRes.headers);
    proxyRes.pipe(res);
  });

  proxyReq.on("error", (error) => {
    sendJson(res, 502, { error: `Unable to reach IIoT backend: ${error.message}` });
  });

  if (body !== undefined) {
    const payload = typeof body === "string" ? body : JSON.stringify(body);
    proxyReq.write(payload);
  }
  proxyReq.end();
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = "";
    req.on("data", (chunk) => {
      body += chunk;
      if (body.length > 1_000_000) {
        reject(new Error("Request body too large"));
        req.destroy();
      }
    });
    req.on("end", () => {
      if (!body) {
        resolve({});
        return;
      }
      try {
        resolve(JSON.parse(body));
      } catch (error) {
        reject(new Error(`Invalid JSON: ${error.message}`));
      }
    });
    req.on("error", reject);
  });
}

function serveStatic(req, res, pathname) {
  const requested = pathname === "/" ? "/index.html" : pathname;
  const normalized = path.normalize(requested).replace(/^(\.\.[/\\])+/, "");
  const filePath = path.join(publicDir, normalized);

  if (!filePath.startsWith(publicDir)) {
    sendJson(res, 403, { error: "Forbidden" });
    return;
  }

  fs.readFile(filePath, (error, content) => {
    if (error) {
      sendJson(res, 404, { error: "Not found" });
      return;
    }
    const ext = path.extname(filePath).toLowerCase();
    res.writeHead(200, {
      "content-type": mimeTypes[ext] || "application/octet-stream",
      "cache-control": "no-store"
    });
    res.end(content);
  });
}

function handleSse(req, res) {
  res.writeHead(200, {
    "content-type": "text/event-stream",
    "cache-control": "no-cache, no-transform",
    connection: "keep-alive",
    "x-accel-buffering": "no"
  });
  res.write(`data: ${JSON.stringify(simulator.getState())}\n\n`);
  sseClients.add(res);
  req.on("close", () => {
    sseClients.delete(res);
  });
}

function broadcast(state) {
  const payload = `data: ${JSON.stringify(state)}\n\n`;
  sseClients.forEach((client) => {
    client.write(payload);
  });
}

async function router(req, res) {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const pathname = url.pathname;

  try {
    if (req.method === "GET" && pathname === "/api/state") {
      sendJson(res, 200, simulator.getState());
      return;
    }

    if (req.method === "GET" && pathname === "/api/machines/data") {
      proxyToIiot(req, res);
      return;
    }

    if (req.method === "POST" && pathname === "/api/machines/data") {
      const body = await readBody(req);
      proxyToIiot(req, res, body);
      return;
    }

    if (req.method === "GET" && pathname === "/api/events") {
      sendJson(res, 200, {
        events: store.getEvents(url.searchParams.get("limit") || 100)
      });
      return;
    }

    if (req.method === "GET" && pathname === "/api/traceability") {
      sendJson(res, 200, {
        records: store.getTraceability(url.searchParams.get("vin"))
      });
      return;
    }

    if (req.method === "POST" && pathname === "/api/orders") {
      const body = await readBody(req);
      const order = simulator.createManualOrder(body);
      sendJson(res, 201, { order });
      return;
    }

    if (req.method === "GET" && pathname === "/events") {
      handleSse(req, res);
      return;
    }

    if (req.method === "GET") {
      serveStatic(req, res, pathname);
      return;
    }

    sendJson(res, 405, { error: "Method not allowed" });
  } catch (error) {
    sendJson(res, 500, { error: error.message });
  }
}

const server = http.createServer(router);
simulator.on("snapshot", broadcast);
simulator.start();

server.listen(port, () => {
  console.log(`Factory MES demo running at http://localhost:${port}`);
  console.log("Press Ctrl+C to stop the server.");
});

process.on("SIGINT", () => {
  simulator.stop();
  server.close(() => process.exit(0));
});

process.on("SIGTERM", () => {
  simulator.stop();
  server.close(() => process.exit(0));
});
