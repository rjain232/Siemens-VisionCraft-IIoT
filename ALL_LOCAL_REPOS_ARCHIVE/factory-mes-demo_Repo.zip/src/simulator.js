"use strict";

const EventEmitter = require("events");
const { createAdapters, protocolCatalog } = require("./protocols");

const shopDefinitions = [
  {
    id: "press",
    name: "Press Shop",
    stationCode: "PRS",
    role: "Stamp sheet metal into panels",
    controller: "Siemens S7-1500",
    protocolId: "profinet",
    baseCycleTimeSec: 6,
    targetPerShift: 430,
    faultRate: 0.025
  },
  {
    id: "body",
    name: "Body Shop",
    stationCode: "BDY",
    role: "Weld panels into vehicle body",
    controller: "Siemens S7-1500",
    protocolId: "profinet",
    baseCycleTimeSec: 8,
    targetPerShift: 410,
    faultRate: 0.03
  },
  {
    id: "paint",
    name: "Paint Shop",
    stationCode: "PNT",
    role: "Pretreat, paint, and cure body",
    controller: "Legacy Siemens S7-400",
    protocolId: "profibus",
    baseCycleTimeSec: 11,
    targetPerShift: 380,
    faultRate: 0.02
  },
  {
    id: "engine",
    name: "Engine and Transmission",
    stationCode: "ENG",
    role: "Assemble and validate powertrain",
    controller: "Rockwell CompactLogix",
    protocolId: "ethernet-ip",
    baseCycleTimeSec: 9,
    targetPerShift: 390,
    faultRate: 0.02
  },
  {
    id: "tcf",
    name: "TCF Shop",
    stationCode: "TCF",
    role: "Trim, chassis, final assembly",
    controller: "Mixed PLC line with torque tools",
    protocolId: "opc-ua",
    baseCycleTimeSec: 10,
    targetPerShift: 370,
    faultRate: 0.035
  },
  {
    id: "test",
    name: "Test Track",
    stationCode: "TST",
    role: "Road test, brake test, diagnostics",
    controller: "Industrial PC gateway",
    protocolId: "mqtt",
    baseCycleTimeSec: 13,
    targetPerShift: 350,
    faultRate: 0.015
  },
  {
    id: "stock",
    name: "Stock Yard",
    stationCode: "STK",
    role: "Finished goods and dispatch staging",
    controller: "Warehouse gateway",
    protocolId: "modbus-tcp",
    baseCycleTimeSec: 7,
    targetPerShift: 350,
    faultRate: 0.01
  }
];

const models = ["SUV-X1", "SEDAN-A2", "HATCH-C3", "EV-E4"];
const colors = ["White", "Silver", "Blue", "Red", "Black"];
const faultCodes = [
  "E101_PART_NOT_PRESENT",
  "E204_ROBOT_TIMEOUT",
  "E302_AIR_PRESSURE_LOW",
  "E411_BARCODE_READ_FAIL",
  "E509_DRIVE_WARNING",
  "E612_QUALITY_HOLD"
];

function round(value, decimals = 2) {
  const factor = 10 ** decimals;
  return Math.round(value * factor) / factor;
}

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

function pick(items) {
  return items[Math.floor(Math.random() * items.length)];
}

function makeOrder(sequence) {
  return {
    orderNo: `SAP-4500${String(sequence).padStart(4, "0")}`,
    productCode: pick(models),
    color: pick(colors),
    quantity: 80 + Math.floor(Math.random() * 80),
    completed: 0,
    rejected: 0,
    status: "Released",
    dueDate: new Date(Date.now() + 36 * 60 * 60 * 1000).toISOString()
  };
}

class FactorySimulator extends EventEmitter {
  constructor(store) {
    super();
    this.store = store;
    this.adapters = createAdapters();
    this.tickCount = 0;
    this.orderSequence = 1;
    this.nextVin = 100001;
    this.timer = null;
    this.wip = [];
    this.finished = [];
    this.oeeTrend = [];
    this.activeOrder = makeOrder(this.orderSequence);
    this.lines = shopDefinitions.map((definition, index) => this.createLine(definition, index));
    this.erp = {
      finishedGoods: 0,
      dispatchQueue: [],
      materialStock: {
        steelCoils: 42,
        paintLiters: 2400,
        engineKits: 160,
        tireSets: 185
      }
    };
    this.store.upsertOrder(this.activeOrder);
    this.store.appendEvent({
      type: "erp_order_release",
      severity: "info",
      message: `${this.activeOrder.orderNo} released from ERP to MES`,
      orderNo: this.activeOrder.orderNo
    });
  }

  createLine(definition, index) {
    return {
      ...definition,
      index,
      linePlc: `${definition.stationCode}-LINE-PLC-${index + 1}`,
      hmiPanel: `${definition.stationCode}-HMI-01`,
      status: "Idle",
      faultCode: null,
      faultCountdown: 0,
      cycleProgressSec: 0,
      actual: 0,
      good: 0,
      reject: 0,
      wip: 0,
      currentModel: this.activeOrder.productCode,
      lastVin: null,
      lastResult: "None",
      operatorMessage: "Waiting for production release",
      runningSeconds: 0,
      plannedSeconds: 0,
      energyKw: 40 + index * 8,
      temperatureC: 26 + index,
      airPressureBar: 6,
      driveSpeedPercent: 0,
      oee: {
        availability: 0,
        performance: 0,
        quality: 1,
        value: 0
      }
    };
  }

  start(intervalMs = 1000) {
    if (this.timer) return;
    this.tick();
    this.timer = setInterval(() => this.tick(), intervalMs);
  }

  stop() {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
    this.store.flush();
  }

  createManualOrder(input = {}) {
    this.orderSequence += 1;
    this.activeOrder = {
      ...makeOrder(this.orderSequence),
      ...input,
      completed: 0,
      rejected: 0,
      status: "Released"
    };
    this.lines.forEach((line) => {
      line.currentModel = this.activeOrder.productCode;
    });
    this.store.upsertOrder(this.activeOrder);
    this.store.appendEvent({
      type: "erp_order_release",
      severity: "info",
      message: `${this.activeOrder.orderNo} manually released to MES`,
      orderNo: this.activeOrder.orderNo
    });
    return this.activeOrder;
  }

  tick() {
    this.tickCount += 1;
    this.releaseReworkVehicles();
    this.lines.forEach((line) => this.updateLine(line));
    this.updateOeeTrend();
    this.emit("snapshot", this.getState());
  }

  releaseReworkVehicles() {
    this.wip.forEach((vehicle) => {
      if (vehicle.status === "Rework" && vehicle.reworkUntil <= this.tickCount) {
        vehicle.status = "InProcess";
        this.store.appendEvent({
          type: "quality_rework_complete",
          severity: "info",
          message: `${vehicle.vin} released from rework`,
          vin: vehicle.vin
        });
      }
    });
  }

  updateLine(line) {
    const hasInput = this.hasInputForLine(line.index);
    line.plannedSeconds += 1;
    line.wip = this.countWipForLine(line.index);
    line.currentModel = this.activeOrder.productCode;

    if (line.faultCountdown > 0) {
      line.faultCountdown -= 1;
      line.status = "Fault";
      line.operatorMessage = `Fault active: ${line.faultCode}`;
    } else if (!hasInput) {
      line.status = "Starved";
      line.faultCode = null;
      line.cycleProgressSec = 0;
      line.operatorMessage = "Waiting for part from previous shop";
    } else if (Math.random() < line.faultRate) {
      this.raiseFault(line);
    } else if (Math.random() < 0.035) {
      line.status = "Blocked";
      line.faultCode = null;
      line.operatorMessage = "Downstream buffer full";
    } else {
      line.status = "Running";
      line.faultCode = null;
      line.operatorMessage = `Running ${line.currentModel} order ${this.activeOrder.orderNo}`;
    }

    this.updateTelemetry(line);

    if (line.status === "Running") {
      line.runningSeconds += 1;
      line.cycleProgressSec += 1;
      if (line.cycleProgressSec >= line.baseCycleTimeSec) {
        line.cycleProgressSec = 0;
        this.completeCycle(line);
      }
    }

    this.updateLineOee(line);
  }

  hasInputForLine(index) {
    if (index === 0) {
      return this.activeOrder.completed < this.activeOrder.quantity;
    }
    return this.wip.some((vehicle) => vehicle.stageIndex === index - 1 && vehicle.status === "InProcess");
  }

  countWipForLine(index) {
    if (index === 0) return 1;
    return this.wip.filter((vehicle) => vehicle.stageIndex === index - 1 || vehicle.stageIndex === index).length;
  }

  raiseFault(line) {
    line.status = "Fault";
    line.faultCode = pick(faultCodes);
    line.faultCountdown = 3 + Math.floor(Math.random() * 7);
    line.operatorMessage = `Fault active: ${line.faultCode}`;
    this.store.appendEvent({
      type: "scada_alarm",
      severity: line.faultCode.includes("QUALITY") ? "warning" : "critical",
      lineId: line.id,
      lineName: line.name,
      message: `${line.name} stopped with ${line.faultCode}`,
      faultCode: line.faultCode
    });
    this.store.appendDowntime({
      lineId: line.id,
      lineName: line.name,
      faultCode: line.faultCode,
      durationSeconds: line.faultCountdown,
      category: "Unplanned"
    });
  }

  updateTelemetry(line) {
    const phase = this.tickCount / (line.index + 3);
    line.driveSpeedPercent = line.status === "Running"
      ? clamp(74 + Math.sin(phase) * 12 + Math.random() * 4, 55, 98)
      : line.status === "Blocked"
        ? 18
        : 0;
    line.energyKw = clamp(35 + line.index * 9 + line.driveSpeedPercent * 0.45 + Math.sin(phase) * 3, 15, 130);
    line.temperatureC = clamp(27 + line.index * 1.4 + Math.sin(phase / 2) * 2, 20, 46);
    line.airPressureBar = clamp(6.1 + Math.cos(phase / 3) * 0.25, 5.2, 6.5);
    line.cycleTimeSec = round(line.baseCycleTimeSec + Math.sin(phase) * 0.8 + Math.random() * 0.5, 1);
  }

  completeCycle(line) {
    const rejected = Math.random() < (line.id === "paint" ? 0.08 : 0.035);
    line.actual += 1;
    line.lastResult = rejected ? "NOK" : "OK";

    if (rejected) {
      line.reject += 1;
      this.activeOrder.rejected += 1;
    } else {
      line.good += 1;
    }

    const vehicle = this.moveVehicleThroughShop(line, rejected);
    if (vehicle) {
      line.lastVin = vehicle.vin;
    }

    this.store.appendEvent({
      type: rejected ? "quality_result" : "cycle_complete",
      severity: rejected ? "warning" : "info",
      lineId: line.id,
      lineName: line.name,
      vin: vehicle ? vehicle.vin : null,
      result: line.lastResult,
      message: `${line.name} completed cycle ${line.actual} with result ${line.lastResult}`
    });
  }

  moveVehicleThroughShop(line, rejected) {
    let vehicle;
    if (line.index === 0) {
      if (rejected) {
        this.store.appendQuality({
          lineId: line.id,
          lineName: line.name,
          result: "NOK",
          defectCode: "PANEL_FORMING_DEFECT",
          disposition: "Scrap before VIN creation"
        });
        return null;
      }

      vehicle = {
        vin: `VIN${this.nextVin++}`,
        orderNo: this.activeOrder.orderNo,
        model: this.activeOrder.productCode,
        color: this.activeOrder.color,
        stageIndex: 0,
        status: "InProcess",
        history: []
      };
      this.wip.push(vehicle);
    } else {
      vehicle = this.wip.find((item) => item.stageIndex === line.index - 1 && item.status === "InProcess");
      if (!vehicle) return null;
      if (rejected) {
        vehicle.status = "Rework";
        vehicle.reworkUntil = this.tickCount + 8 + Math.floor(Math.random() * 8);
        this.store.appendQuality({
          vin: vehicle.vin,
          lineId: line.id,
          lineName: line.name,
          result: "NOK",
          defectCode: line.id === "paint" ? "PAINT_SURFACE_DEFECT" : "STATION_CHECK_FAILED",
          disposition: "Route to rework"
        });
      } else {
        vehicle.stageIndex = line.index;
      }
    }

    const traceRecord = {
      vin: vehicle.vin,
      orderNo: vehicle.orderNo,
      model: vehicle.model,
      color: vehicle.color,
      stationCode: line.stationCode,
      lineName: line.name,
      controller: line.controller,
      protocol: this.adapters[line.protocolId].definition.name,
      result: rejected ? "NOK" : "OK",
      cycleTimeSec: line.cycleTimeSec,
      energyKw: round(line.energyKw, 1),
      operatorId: `OP-${100 + line.index}`,
      shift: "A"
    };
    vehicle.history.unshift(traceRecord);
    this.store.appendTrace(traceRecord);

    if (!rejected && line.index === this.lines.length - 1) {
      vehicle.status = "Finished";
      this.finished.unshift({
        ...vehicle,
        finishedAt: new Date().toISOString()
      });
      this.finished = this.finished.slice(0, 40);
      this.wip = this.wip.filter((item) => item.vin !== vehicle.vin);
      this.activeOrder.completed += 1;
      this.erp.finishedGoods += 1;
      this.erp.dispatchQueue = this.finished.slice(0, 8).map((item) => ({
        vin: item.vin,
        model: item.model,
        color: item.color,
        orderNo: item.orderNo
      }));
      this.consumeMaterials();
      this.store.upsertOrder(this.activeOrder);
    }

    if (this.activeOrder.completed >= this.activeOrder.quantity) {
      this.closeAndReleaseNextOrder();
    }

    return vehicle;
  }

  consumeMaterials() {
    this.erp.materialStock.steelCoils = round(this.erp.materialStock.steelCoils - 0.02, 2);
    this.erp.materialStock.paintLiters = round(this.erp.materialStock.paintLiters - 4.5, 1);
    this.erp.materialStock.engineKits = Math.max(0, this.erp.materialStock.engineKits - 1);
    this.erp.materialStock.tireSets = Math.max(0, this.erp.materialStock.tireSets - 1);
  }

  closeAndReleaseNextOrder() {
    this.activeOrder.status = "Complete";
    this.store.upsertOrder(this.activeOrder);
    this.store.appendEvent({
      type: "erp_order_complete",
      severity: "info",
      message: `${this.activeOrder.orderNo} completed and confirmed back to ERP`,
      orderNo: this.activeOrder.orderNo
    });
    this.orderSequence += 1;
    this.activeOrder = makeOrder(this.orderSequence);
    this.store.upsertOrder(this.activeOrder);
    this.store.appendEvent({
      type: "erp_order_release",
      severity: "info",
      message: `${this.activeOrder.orderNo} released from ERP to MES`,
      orderNo: this.activeOrder.orderNo
    });
  }

  updateLineOee(line) {
    const totalProduced = line.good + line.reject;
    const idealOutput = Math.max(1, line.runningSeconds / line.baseCycleTimeSec);
    const availability = line.plannedSeconds ? line.runningSeconds / line.plannedSeconds : 0;
    const performance = clamp(totalProduced / idealOutput, 0, 1.15);
    const quality = totalProduced ? line.good / totalProduced : 1;
    line.oee = {
      availability: round(availability, 3),
      performance: round(Math.min(performance, 1), 3),
      quality: round(quality, 3),
      value: round(availability * Math.min(performance, 1) * quality, 3)
    };
  }

  updateOeeTrend() {
    const mes = this.getMesMetrics();
    this.oeeTrend.push({
      timestamp: new Date().toISOString(),
      value: mes.oee.value,
      good: mes.goodCount,
      reject: mes.rejectCount
    });
    this.oeeTrend = this.oeeTrend.slice(-60);
  }

  getMesMetrics() {
    const totals = this.lines.reduce((acc, line) => {
      acc.good += line.good;
      acc.reject += line.reject;
      acc.actual += line.actual;
      acc.availability += line.oee.availability;
      acc.performance += line.oee.performance;
      acc.quality += line.oee.quality;
      acc.oee += line.oee.value;
      return acc;
    }, {
      good: 0,
      reject: 0,
      actual: 0,
      availability: 0,
      performance: 0,
      quality: 0,
      oee: 0
    });

    const count = this.lines.length;
    return {
      orderNo: this.activeOrder.orderNo,
      productCode: this.activeOrder.productCode,
      color: this.activeOrder.color,
      plannedQty: this.activeOrder.quantity,
      completedQty: this.activeOrder.completed,
      goodCount: totals.good,
      rejectCount: totals.reject,
      wipCount: this.wip.length,
      finishedGoods: this.erp.finishedGoods,
      oee: {
        availability: round(totals.availability / count, 3),
        performance: round(totals.performance / count, 3),
        quality: round(totals.quality / count, 3),
        value: round(totals.oee / count, 3)
      },
      activeAlerts: this.store.getEvents(20).filter((event) => event.severity === "critical" || event.severity === "warning").length
    };
  }

  getProtocolPackets() {
    return protocolCatalog.map((definition, index) => {
      const line = this.lines[index % this.lines.length];
      return this.adapters[definition.id].readLineTags(line, this.tickCount);
    });
  }

  getState() {
    const protocolPackets = this.getProtocolPackets();
    const linePlcs = this.lines.map((line) => ({
      id: line.linePlc,
      shop: line.name,
      status: line.status,
      protocol: this.adapters[line.protocolId].definition.name,
      controller: line.controller,
      hmiPanel: line.hmiPanel,
      faultCode: line.faultCode,
      lastVin: line.lastVin,
      lastResult: line.lastResult
    }));

    return {
      generatedAt: new Date().toISOString(),
      tick: this.tickCount,
      plant: {
        name: "Heimdall Automotive Plant",
        architecture: "ISA-95 Automation Pyramid: SAP / ERP -> MES -> SCADA / HMI -> PLC / Drives -> Sensors",
        architectureLayers: [
          {
            name: "SAP / ERP",
            role: "Business planning and order control",
            connectors: ["REST API", "SQL"]
          },
          {
            name: "MES",
            role: "Reporting, monitoring, and production control",
            connectors: ["OPC UA", "MQTT"]
          },
          {
            name: "SCADA / HMI",
            role: "Operator supervision and alarms",
            connectors: ["Ethernet", "TCP/IP"]
          },
          {
            name: "PLC / Drives / Servo Drives",
            role: "Automation execution on the shop floor",
            connectors: ["PROFINET", "EtherNet/IP", "Modbus TCP/IP"]
          },
          {
            name: "Sensors / Actuators",
            role: "Field devices, I/O, and machine feedback",
            connectors: ["I/O"]
          }
        ],
        companyProfile: {
          partner: "Siemens India Channel Partner",
          scope: "PLC • HMI • Drives • Servo Drives • SCADA • Automation Services"
        },
        communicationStack: ["Ethernet", "TCP/IP", "PROFINET", "MQTT", "OPC UA"],
        softwareStack: {
          frontend: "ReactJS",
          backend: "Node.js",
          database: "MS SQL / MySQL",
          acquisition: ".NET Core (C#)"
        },
        shops: shopDefinitions.map((shop) => shop.name)
      },
      automation: {
        masterPlc: {
          id: "MASTER-PLC-01",
          controller: "Siemens S7-1500",
          status: this.lines.some((line) => line.status === "Fault") ? "Attention" : "Healthy",
          connectedLinePlcs: linePlcs.length
        },
        linePlcs
      },
      shops: this.lines.map((line) => ({
        id: line.id,
        name: line.name,
        stationCode: line.stationCode,
        role: line.role,
        controller: line.controller,
        protocolId: line.protocolId,
        protocolName: this.adapters[line.protocolId].definition.name,
        status: line.status,
        targetPerShift: line.targetPerShift,
        actual: line.actual,
        good: line.good,
        reject: line.reject,
        wip: line.wip,
        cycleProgressPercent: round((line.cycleProgressSec / line.baseCycleTimeSec) * 100, 1),
        cycleTimeSec: line.cycleTimeSec,
        driveSpeedPercent: round(line.driveSpeedPercent, 1),
        energyKw: round(line.energyKw, 1),
        temperatureC: round(line.temperatureC, 1),
        airPressureBar: round(line.airPressureBar, 2),
        faultCode: line.faultCode,
        currentModel: line.currentModel,
        lastVin: line.lastVin,
        lastResult: line.lastResult,
        operatorMessage: line.operatorMessage,
        oee: line.oee
      })),
      scada: {
        alarms: this.store.getEvents(50).filter((event) => event.type === "scada_alarm" || event.type === "quality_result").slice(0, 12),
        trends: this.oeeTrend
      },
      mes: this.getMesMetrics(),
      erp: {
        activeOrder: this.activeOrder,
        inventory: this.erp.materialStock,
        finishedGoods: this.erp.finishedGoods,
        dispatchQueue: this.erp.dispatchQueue
      },
      protocols: {
        catalog: protocolCatalog,
        latestPackets: protocolPackets
      },
      traceability: {
        inProcess: this.wip.slice(0, 20).map((vehicle) => ({
          vin: vehicle.vin,
          orderNo: vehicle.orderNo,
          model: vehicle.model,
          color: vehicle.color,
          currentShop: this.lines[vehicle.stageIndex] ? this.lines[vehicle.stageIndex].name : "Unknown",
          status: vehicle.status
        })),
        recentRecords: this.store.getTraceability().slice(0, 20)
      },
      events: this.store.getEvents(30)
    };
  }
}

module.exports = {
  FactorySimulator,
  shopDefinitions
};
