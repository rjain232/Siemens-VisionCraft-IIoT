"use strict";

const fs = require("fs");
const path = require("path");

class PlantStore {
  constructor(filePath) {
    this.filePath = filePath;
    this.data = {
      events: [],
      traceability: [],
      orders: [],
      downtime: [],
      quality: []
    };
    this.pendingWrites = 0;
    this.load();
  }

  load() {
    try {
      if (fs.existsSync(this.filePath)) {
        const parsed = JSON.parse(fs.readFileSync(this.filePath, "utf8"));
        this.data = {
          ...this.data,
          ...parsed
        };
      }
    } catch (error) {
      this.appendEvent({
        type: "store_warning",
        severity: "warning",
        message: `Could not load store file: ${error.message}`
      });
    }
  }

  appendEvent(event) {
    const entry = {
      id: `evt-${Date.now()}-${Math.floor(Math.random() * 100000)}`,
      timestamp: new Date().toISOString(),
      severity: "info",
      ...event
    };
    this.data.events.unshift(entry);
    this.data.events = this.data.events.slice(0, 500);
    this.scheduleFlush();
    return entry;
  }

  appendTrace(record) {
    const entry = {
      id: `trace-${Date.now()}-${Math.floor(Math.random() * 100000)}`,
      timestamp: new Date().toISOString(),
      ...record
    };
    this.data.traceability.unshift(entry);
    this.data.traceability = this.data.traceability.slice(0, 1000);
    this.scheduleFlush();
    return entry;
  }

  appendDowntime(record) {
    const entry = {
      id: `dt-${Date.now()}-${Math.floor(Math.random() * 100000)}`,
      timestamp: new Date().toISOString(),
      ...record
    };
    this.data.downtime.unshift(entry);
    this.data.downtime = this.data.downtime.slice(0, 300);
    this.scheduleFlush();
    return entry;
  }

  appendQuality(record) {
    const entry = {
      id: `qa-${Date.now()}-${Math.floor(Math.random() * 100000)}`,
      timestamp: new Date().toISOString(),
      ...record
    };
    this.data.quality.unshift(entry);
    this.data.quality = this.data.quality.slice(0, 300);
    this.scheduleFlush();
    return entry;
  }

  upsertOrder(order) {
    const existingIndex = this.data.orders.findIndex((item) => item.orderNo === order.orderNo);
    if (existingIndex >= 0) {
      this.data.orders[existingIndex] = {
        ...this.data.orders[existingIndex],
        ...order,
        updatedAt: new Date().toISOString()
      };
    } else {
      this.data.orders.unshift({
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        ...order
      });
    }
    this.data.orders = this.data.orders.slice(0, 50);
    this.scheduleFlush();
  }

  getEvents(limit = 100) {
    return this.data.events.slice(0, Number(limit) || 100);
  }

  getTraceability(vin) {
    if (!vin) return this.data.traceability.slice(0, 100);
    return this.data.traceability.filter((item) => item.vin === vin);
  }

  scheduleFlush() {
    this.pendingWrites += 1;
    if (this.pendingWrites >= 10) {
      this.flush();
    }
  }

  flush() {
    this.pendingWrites = 0;
    fs.mkdirSync(path.dirname(this.filePath), { recursive: true });
    fs.writeFileSync(this.filePath, JSON.stringify(this.data, null, 2));
  }
}

module.exports = {
  PlantStore
};
