"use strict";

console.log("Starting PLC Simulator...");

setInterval(async () => {
  const currentTemp = (Math.random() * (85 - 70) + 70).toFixed(1);
  const payload = {
    machineId: "M1-Extruder",
    temperature: parseFloat(currentTemp),
    timestamp: new Date().toISOString()
  };

  try {
    const response = await fetch("http://127.0.0.1:5000/api/machines/data", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(payload)
    });
    const body = await response.json();
    console.log(`[PLC] Pushed: ${payload.temperature}°C (${body.message})`);
  } catch (error) {
    console.error("[PLC] Error: Cannot connect to backend. Is server.js running?");
  }
}, 2000);
