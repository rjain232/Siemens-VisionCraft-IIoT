# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: jsw_smoke.spec.js >> JSW Smoke Tests >> Successful login and navigation to Dashboard
- Location: tests\jsw_smoke.spec.js:5:3

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('text="Production Overview"')
Expected: visible
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" locator('text="Production Overview"') with timeout 10000ms
  - waiting for locator('text="Production Overview"')

```

```yaml
- banner:
  - button
  - link "JSW Logo":
    - /url: /
    - img "JSW Logo"
  - button
  - img "Net+Ve Logo"
- complementary:
  - button
  - navigation:
    - paragraph: Dashboard
    - list:
      - listitem:
        - link "Overview":
          - /url: /dashboard
          - text: Overview
          - button
    - paragraph: Production
    - list:
      - listitem:
        - link "OEE":
          - /url: /oee
          - text: OEE
          - button
      - listitem:
        - link "Robot Monitoring":
          - /url: /robot-monitoring
          - text: Robot Monitoring
          - button
      - listitem:
        - link "Production Control":
          - /url: /production-control
          - text: Production Control
          - button
      - listitem:
        - link "Maintenance":
          - /url: /maintenance
          - text: Maintenance
          - button
    - paragraph: Configuration
    - list:
      - listitem:
        - link "Process Configurator":
          - /url: /process-configurator
          - text: Process Configurator
          - button
      - listitem:
        - link "Third Party Report":
          - /url: /third-party-report
          - text: Third Party Report
          - button
    - paragraph: Operations
    - list:
      - listitem:
        - link "Part Marriage":
          - /url: /part-marriage
          - text: Part Marriage
          - button
    - paragraph: Reports
    - list:
      - listitem:
        - link "Share Reports":
          - /url: /share-reports
          - text: Share Reports
          - button
    - paragraph: Help
    - list:
      - listitem:
        - link "About":
          - /url: /about
          - text: About
          - button
      - listitem:
        - link "Help":
          - /url: /help
          - text: Help
          - button
  - text: P
  - paragraph: Priyanka
  - paragraph: user
  - button "Logout"
- main:
  - text: Dashboard / Overview
  - heading "Production Overview Dashboard" [level=1]
  - text: Updated 4:54:24 PM
  - button "Refresh":
    - img
    - text: Refresh
  - text: Live
  - button "Today":
    - img
    - text: Today
    - img
  - img
  - text: Avg. Production 1,267 / 1,440 88% of target
  - img
  - text: Fri, 2 Oct 2026
  - img
  - text: 04:54:31 PM IST Shift B
  - main:
    - img
    - heading "Overall Equipment Effectiveness" [level=2]
    - text: Overall OEE 0%
    - paragraph: Available vs Downtime
    - text: No time data available
    - paragraph: APQ Average
    - paragraph: Availability
    - img
    - text: 0%
    - paragraph: Performance
    - img
    - text: 0%
    - paragraph: Quality
    - img
    - text: 0%
    - img
    - heading "SHOP FLOOR - MASTER SUMMARY" [level=2]
    - text: Good ≥80% · 0 Low 70–79% · 2 Critical <70% · 0 2 lines
    - img
    - text: ACTUAL 1,267
    - img
    - text: PLAN 1,440
    - img
    - text: TARGET 1,440
    - img
    - text: SHOP JPH 49
    - img
    - text: Shop OEE 0%
    - img
    - heading "LINES" [level=2]
    - text: Good ≥80% · 0 Low 70–79% · 2 Critical <70% · 0
    - img
    - text: MB2 Low Actual 1288 Plan 1440 Target 1440
    - button "JPH 51 | 46":
      - img
      - text: JPH 51 | 46
      - img
    - text: OEE 0%
    - img
    - img
    - text: FE Low Actual 1246 Plan 1440 Target 1440
    - button "JPH 51 | 59":
      - img
      - text: JPH 51 | 59
      - img
    - text: OEE 0%
    - img
- contentinfo:
  - img "Schaeffler"
  - paragraph: © 2026 All rights reserved.
  - text: v0.0.2
```

# Test source

```ts
  1  | const { test, expect } = require('@playwright/test');
  2  | const { LoginPage } = require('../pages/LoginPage');
  3  | 
  4  | test.describe('JSW Smoke Tests', () => {
  5  |   test('Successful login and navigation to Dashboard', async ({ page }) => {
  6  |     const loginPage = new LoginPage(page);
  7  | 
  8  |     // 1. Navigate to the app
  9  |     await loginPage.goto();
  10 | 
  11 |     // 2. Perform Login (Replace with actual dev credentials if needed)
  12 |     // Note: If you have a mock or skip login mechanism in dev, adjust accordingly.
  13 |     await loginPage.login('uphadpiy@schaeffler.com', 'priyanka@123');
  14 | 
  15 |     // 3. Verify successful redirection to Dashboard
  16 |     // Assuming the URL changes or a specific dashboard element appears
  17 |     await expect(page).toHaveURL(/.*dashboard/);
> 18 |     await expect(page.locator('text="Production Overview"')).toBeVisible({ timeout: 10000 });
     |                                                              ^ Error: expect(locator).toBeVisible() failed
  19 |   });
  20 | 
  21 |   test('Detailed Production Count Report loads without crashing', async ({ page }) => {
  22 |     const loginPage = new LoginPage(page);
  23 |     await loginPage.goto();
  24 |     await loginPage.login('uphadpiy@schaeffler.com', 'priyanka@123');
  25 | 
  26 |     // Navigate to the report
  27 |     await page.goto('/production/detailed-production');
  28 | 
  29 |     // Verify the page doesn't show the "Connection Refused / Reload App" error boundary
  30 |     const errorBoundaryMsg = page.locator('text="The app lost its connection"');
  31 |     await expect(errorBoundaryMsg).not.toBeVisible();
  32 | 
  33 |     // Verify a chart or table container exists
  34 |     const filtersPane = page.locator('.bg-white', { hasText: 'Area' });
  35 |     await expect(filtersPane.first()).toBeVisible({ timeout: 15000 });
  36 |   });
  37 | });
  38 | 
  39 | 
```