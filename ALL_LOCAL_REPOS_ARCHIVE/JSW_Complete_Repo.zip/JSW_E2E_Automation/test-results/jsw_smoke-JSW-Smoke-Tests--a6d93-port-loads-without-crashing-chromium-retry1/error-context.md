# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: jsw_smoke.spec.js >> JSW Smoke Tests >> Detailed Production Count Report loads without crashing
- Location: tests\jsw_smoke.spec.js:21:3

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('.bg-white').filter({ hasText: 'Area' }).first()
Expected: visible
Timeout: 15000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" locator('.bg-white').filter({ hasText: 'Area' }).first() with timeout 15000ms
  - waiting for locator('.bg-white').filter({ hasText: 'Area' }).first()

```

# Test source

```ts
  1  | const { test, expect } = require('@playwright/test');
  2  | const { LoginPage } = require('../pages/LoginPage');
  3  | 
  4  | test.describe('JSW Smoke Tests', () => {
  5  |   test('Successful login and navigation to Dashboard', async ({ page }) => {
  6  |     const loginPage = new LoginPage(page);
  7  | 
  8  |     // 1. Navigate to the app
  9  |     await loginPage.goto();
  10 | 
  11 |     // 2. Perform Login (Replace with actual dev credentials if needed)
  12 |     // Note: If you have a mock or skip login mechanism in dev, adjust accordingly.
  13 |     await loginPage.login('uphadpiy@schaeffler.com', 'priyanka@123');
  14 | 
  15 |     // 3. Verify successful redirection to Dashboard
  16 |     // Assuming the URL changes or a specific dashboard element appears
  17 |     await expect(page).toHaveURL(/.*dashboard/);
  18 |     await expect(page.locator('text="Production Overview"')).toBeVisible({ timeout: 10000 });
  19 |   });
  20 | 
  21 |   test('Detailed Production Count Report loads without crashing', async ({ page }) => {
  22 |     const loginPage = new LoginPage(page);
  23 |     await loginPage.goto();
  24 |     await loginPage.login('uphadpiy@schaeffler.com', 'priyanka@123');
  25 | 
  26 |     // Navigate to the report
  27 |     await page.goto('/production/detailed-production');
  28 | 
  29 |     // Verify the page doesn't show the "Connection Refused / Reload App" error boundary
  30 |     const errorBoundaryMsg = page.locator('text="The app lost its connection"');
  31 |     await expect(errorBoundaryMsg).not.toBeVisible();
  32 | 
  33 |     // Verify a chart or table container exists
  34 |     const filtersPane = page.locator('.bg-white', { hasText: 'Area' });
> 35 |     await expect(filtersPane.first()).toBeVisible({ timeout: 15000 });
     |                                       ^ Error: expect(locator).toBeVisible() failed
  36 |   });
  37 | });
  38 | 
  39 | 
```