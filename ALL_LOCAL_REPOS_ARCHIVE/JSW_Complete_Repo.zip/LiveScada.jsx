import React, { useEffect, useState } from 'react';
import ReactApexChart from 'react-apexcharts';

const LiveScada = () => {
    const [dataPoints, setDataPoints] = useState([]);

    useEffect(() => {
        // Connect to our new backend WebSocket
        const ws = new WebSocket('ws://localhost:5051/ws/telemetry');

        ws.onmessage = (event) => {
            const payload = JSON.parse(event.data);
            if (payload.motorTemp > 0) {
                setDataPoints(prev => {
                    // Keep the last 20 data points for the live chart
                    const newData = [...prev, { x: new Date().getTime(), y: payload.motorTemp }];
                    return newData.slice(-20);
                });
            }
        };

        return () => ws.close();
    }, []);

    const chartOptions = {
        chart: { type: 'line', animations: { enabled: true, easing: 'linear', dynamicAnimation: { speed: 1000 } }, toolbar: { show: false }, zoom: { enabled: false } },
        stroke: { curve: 'smooth', width: 3, colors: ['#ff0000'] },
        xaxis: { type: 'datetime', range: 20000 },
        yaxis: { max: 100, min: 50, title: { text: "Motor Temp (°C)" } },
        title: { text: "Live Robot Telemetry (R-01)", align: 'left' }
    };

    return (
        <div style={{ padding: '20px', backgroundColor: '#fff', borderRadius: '8px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)', marginTop: '20px' }}>
            <h2>⚡ SGrids / Solvyn Digital Twin Clone</h2>
            <ReactApexChart options={chartOptions} series={[{ name: 'Temperature', data: dataPoints }]} type="line" height={350} />
        </div>
    );
};

export default LiveScada;
