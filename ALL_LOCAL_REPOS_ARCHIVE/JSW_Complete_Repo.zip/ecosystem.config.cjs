module.exports = {
  apps: [
    {
      name: "jsw-backend",
      cwd: "C:/Users/SDS/OneDrive - dacpl.in/Desktop/JSW/JSW_Backend",
      script: "src/server.js",
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: "1G",
      env: {
        NODE_ENV: "production",
        PORT: 5050,
      },
    },
    {
      name: "jsw-frontend",
      cwd: "C:/Users/SDS/OneDrive - dacpl.in/Desktop/JSW/JSW_UI",
      script: "serve-static.js",
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: "500M",
      env: {
        PORT: 3000,
        BACKEND_URL: "http://localhost:5050",
        NODE_ENV: "production",
      },
    },
  ],
};
