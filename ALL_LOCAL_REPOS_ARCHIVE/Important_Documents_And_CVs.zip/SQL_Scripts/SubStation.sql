SELECT tbl_Tran_CT_SubStation.Id, tbl_Tran_CT_SubStation.Sub_StationID, tbl_Mast_SubStation.SubStationName, tbl_Tran_CT_SubStation.StartTime, tbl_Tran_CT_SubStation.EndTime, tbl_Tran_CT_SubStation.CycleTime, datediff(second, tbl_Tran_CT_SubStation.StartTime, tbl_Tran_CT_SubStation.EndTime) as ActalCT,tbl_Tran_CT_SubStation.Biwno, 
             tbl_Tran_CT_SubStation.Emergency , tbl_Tran_CT_SubStation.Tip_Change , tbl_Tran_CT_SubStation.Tip_Dress , tbl_Tran_CT_SubStation.OperatorLoading_Starving_Time , tbl_Tran_CT_SubStation.Block_Time , tbl_Tran_CT_SubStation.Manual , tbl_Tran_CT_SubStation.Part_Present_Fault
              , tbl_Tran_CT_SubStation.RollMoveTime , tbl_Tran_CT_SubStation.LifterTime , tbl_Tran_CT_SubStation.TurnTabletime , tbl_Tran_CT_SubStation.ClampTime , tbl_Tran_CT_SubStation.DeclampTime , tbl_Tran_CT_SubStation.Marriage_Miss_Match , tbl_Tran_CT_SubStation.DropTime
              , tbl_Tran_CT_SubStation.WeldTime , tbl_Tran_CT_SubStation.PickTime , tbl_Tran_CT_SubStation.SealingTime , tbl_Tran_CT_SubStation.Safety_Gate , tbl_Tran_CT_SubStation.Miscleniuos , tbl_Tran_CT_SubStation.MaterialCall , tbl_Tran_CT_SubStation.Others
FROM   tbl_Tran_CT_SubStation INNER JOIN
             tbl_Mast_SubStation ON tbl_Tran_CT_SubStation.Sub_StationID = tbl_Mast_SubStation.SubStationId
WHERE StartTime >= CAST(GETDATE() AS DATE)
  AND StartTime < DATEADD(DAY, 1, CAST(GETDATE() AS DATE))
  
--ORDER BY tbl_Tran_CT_SubStation.Biwno DESC