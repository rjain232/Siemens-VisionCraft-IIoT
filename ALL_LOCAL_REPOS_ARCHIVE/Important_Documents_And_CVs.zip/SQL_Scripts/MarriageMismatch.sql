select * from [dbo].[tbl_tran_MarrigeMismatch]
WHERE TimeStamp >= CAST(GETDATE() AS DATE)
  AND TimeStamp < DATEADD(DAY, 1, CAST(GETDATE() AS DATE))
  order by ID DESC
