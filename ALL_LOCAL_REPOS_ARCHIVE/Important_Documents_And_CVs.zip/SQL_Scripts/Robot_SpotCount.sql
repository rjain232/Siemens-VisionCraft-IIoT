SELECT distinct tbl_Tran_rbt_SpotCount.ID, tbl_Tran_rbt_SpotCount.RobotID, tbl_Mast_Robot.Robot_Name, tbl_Tran_rbt_SpotCount.GunID, tbl_Tran_rbt_SpotCount.Biwno, tbl_Tran_rbt_SpotCount.Varraint, tbl_Tran_rbt_SpotCount.SubVarraint, tbl_Tran_rbt_SpotCount.Target, 
             tbl_Tran_rbt_SpotCount.Actual, tbl_Tran_rbt_SpotCount.Timestamp
FROM   tbl_Tran_rbt_SpotCount INNER JOIN
             tbl_Mast_Robot ON tbl_Tran_rbt_SpotCount.RobotID = tbl_Mast_Robot.RobotId
WHERE (tbl_Tran_rbt_SpotCount.Timestamp >= CAST(GETDATE() AS DATE)) AND (tbl_Tran_rbt_SpotCount.Timestamp < DATEADD(DAY, 1, CAST(GETDATE() AS DATE)))
--and tbl_Tran_rbt_SpotCount.RobotID=4
ORDER BY tbl_Tran_rbt_SpotCount.Timestamp desc