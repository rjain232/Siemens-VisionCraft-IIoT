SELECT TOP (1000) tbl_Tran_Losses.ID, tbl_Tran_Losses.SubStationID, tbl_Mast_SubStation.SubStationName, tbl_Tran_Losses.Shift, tbl_Tran_Losses.Emergency, tbl_Tran_Losses.Tip_Change, tbl_Tran_Losses.Tip_Dress, tbl_Tran_Losses.OperatorLoading_Starving_Time, tbl_Tran_Losses.Block_Time, tbl_Tran_Losses.Manual, 
             tbl_Tran_Losses.Part_Present_Fault, tbl_Tran_Losses.RollMoveTime, tbl_Tran_Losses.LifterMoveTime, tbl_Tran_Losses.TurnTableMoveTime, tbl_Tran_Losses.ClampTime, tbl_Tran_Losses.DeclampTime, tbl_Tran_Losses.Marriage_Miss_Match, tbl_Tran_Losses.DropTime, 
             tbl_Tran_Losses.WeldTime, tbl_Tran_Losses.PickTime, tbl_Tran_Losses.SealingTime, tbl_Tran_Losses.Safety_Gate, tbl_Tran_Losses.Miscellaneous, tbl_Tran_Losses.MaterialCall, tbl_Tran_Losses.Others, tbl_Tran_Losses.NoOfOccurance, tbl_Tran_Losses.Total, 
             tbl_Tran_Losses.Timestamp
FROM   tbl_Tran_Losses INNER JOIN
             tbl_Mast_SubStation ON tbl_Tran_Losses.SubStationID = tbl_Mast_SubStation.SubStationId
WHERE (tbl_Tran_Losses.Timestamp >= CAST(GETDATE() AS DATE)) AND (tbl_Tran_Losses.Timestamp < DATEADD(DAY, 1, CAST(GETDATE() AS DATE))) AND (tbl_Tran_Losses.SubStationID = 1)