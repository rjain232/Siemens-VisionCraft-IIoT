SELECT Id, LineID, StartTime, EndTime, CycleTime,DATEDIFF(second, StartTime, EndTime) AS ActalCT, Biwno, VarriantCode, SubVarraintcode, TimeStamp
FROM   tbl_Tran_CT_Line
WHERE (StartTime >= CAST(GETDATE() AS DATE)) AND (StartTime < DATEADD(DAY, 1, CAST(GETDATE() AS DATE)))
ORDER BY Id DESC