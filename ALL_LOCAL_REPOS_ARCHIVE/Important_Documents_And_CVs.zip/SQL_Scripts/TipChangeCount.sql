select * from [dbo].[tbl_Tran_rbt_TipChangeCount] 
WHERE Timstamp >= CAST(GETDATE() AS DATE)
  AND Timstamp < DATEADD(DAY, 1, CAST(GETDATE() AS DATE))
  order by ID Desc