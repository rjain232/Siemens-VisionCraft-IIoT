SELECT tbl_Tran_rbt_Status.ID, tbl_Tran_rbt_Status.RobotID, tbl_Mast_Robot.Robot_Name, tbl_Tran_rbt_Status.HealthStatus, tbl_Tran_rbt_Status.BatteryStatus, tbl_Tran_rbt_Status.Timestamp
FROM   tbl_Tran_rbt_Status INNER JOIN
             tbl_Mast_Robot ON tbl_Tran_rbt_Status.RobotID = tbl_Mast_Robot.RobotId
WHERE (tbl_Tran_rbt_Status.Timestamp >= CAST(GETDATE() AS DATE)) AND (tbl_Tran_rbt_Status.Timestamp < DATEADD(DAY, 1, CAST(GETDATE() AS DATE)))
ORDER BY tbl_Tran_rbt_Status.ID DESC