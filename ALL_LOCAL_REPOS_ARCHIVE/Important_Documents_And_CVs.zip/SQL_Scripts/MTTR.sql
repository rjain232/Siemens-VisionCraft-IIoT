SELECT tbl_Tran_MTTR_MTBF.ID, tbl_Tran_MTTR_MTBF.SubStationID, tbl_Mast_SubStation.SubStationName, tbl_Tran_MTTR_MTBF.Shift, tbl_Tran_MTTR_MTBF.MTTR, tbl_Tran_MTTR_MTBF.MTBF, tbl_Tran_MTTR_MTBF.NoOfFailure, tbl_Tran_MTTR_MTBF.NetAvail_OperTime, tbl_Tran_MTTR_MTBF.BreakDownTime, 
             tbl_Tran_MTTR_MTBF.Timestamp
FROM   tbl_Tran_MTTR_MTBF INNER JOIN
             tbl_Mast_SubStation ON tbl_Tran_MTTR_MTBF.SubStationID = tbl_Mast_SubStation.SubStationId
WHERE (tbl_Tran_MTTR_MTBF.Timestamp >= CAST(GETDATE() AS DATE)) AND (tbl_Tran_MTTR_MTBF.Timestamp < DATEADD(DAY, 1, CAST(GETDATE() AS DATE)))
ORDER BY tbl_Tran_MTTR_MTBF.Timestamp DESC