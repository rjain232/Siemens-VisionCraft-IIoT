SELECT TOP (1000) [Id]
      ,[LineID]
      ,[Buffer_Count]
      ,[Min_Threshold]
      ,[Max_Threshold]
      ,[Target]
      ,[Status]
      ,[TimeStamp]
  FROM [DB_Reporting_JSW].[dbo].[tbl_Tran_LineBuffer]
  WHERE [TimeStamp] >= CAST(GETDATE() AS DATE)
  AND [TimeStamp] < DATEADD(DAY, 1, CAST(GETDATE() AS DATE))
  order by ID Desc
