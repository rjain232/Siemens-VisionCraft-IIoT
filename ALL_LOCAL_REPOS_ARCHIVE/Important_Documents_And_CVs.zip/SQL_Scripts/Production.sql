SELECT tbl_Tran_Production.Id, tbl_Tran_Production.LineID, tbl_Tran_Production.HourID,
             tbl_Mast_Hour.StartHour, tbl_Mast_Hour.EndHour, tbl_Tran_Production.PlanProd, tbl_Tran_Production.Target, tbl_Tran_Production.Actual, tbl_Tran_Production.J5_Target, tbl_Tran_Production.J5_Actual, tbl_Tran_Production.V23_Target, 
             tbl_Tran_Production.V23_Actual, tbl_Tran_Production.Timestamp, tbl_Tran_Production.LogDateTime, tbl_Tran_Production.J5_Remark, tbl_Tran_Production.J5_UpdatedOn, tbl_Tran_Production.V23_UpdatedOn, tbl_Tran_Production.V23_Remark, tbl_Tran_Production.JPH_J5_V23
FROM   tbl_Tran_Production INNER JOIN
             tbl_Mast_Hour ON tbl_Tran_Production.HourID = tbl_Mast_Hour.HourId
WHERE (tbl_Tran_Production.Timestamp >= CAST(GETDATE() AS DATE)) AND (tbl_Tran_Production.Timestamp < DATEADD(DAY, 1, CAST(GETDATE() AS DATE)))
ORDER BY tbl_Tran_Production.Id