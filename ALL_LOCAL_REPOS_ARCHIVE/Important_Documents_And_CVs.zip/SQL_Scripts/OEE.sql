SELECT tbl_Tran_OEE.ID, tbl_Tran_OEE.SubStationID, tbl_Mast_SubStation.SubStationName, tbl_Tran_OEE.Shift, tbl_Tran_OEE.Availability, tbl_Tran_OEE.Performance, tbl_Tran_OEE.Quality, tbl_Tran_OEE.OEE, tbl_Tran_OEE.NetAvail_OperTime, tbl_Tran_OEE.BreakDownTime, tbl_Tran_OEE.PerformanceLossTime, 
             tbl_Tran_OEE.Timestamp
FROM   tbl_Tran_OEE INNER JOIN
             tbl_Mast_SubStation ON tbl_Tran_OEE.SubStationID = tbl_Mast_SubStation.SubStationId
WHERE (tbl_Tran_OEE.Timestamp >= CAST(GETDATE() AS DATE)) AND (tbl_Tran_OEE.Timestamp < DATEADD(DAY, 1, CAST(GETDATE() AS DATE)))
ORDER BY tbl_Tran_OEE.ID DESC