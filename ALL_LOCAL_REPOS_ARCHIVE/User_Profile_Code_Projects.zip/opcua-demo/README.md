# OPC UA Client & Simulator Demo (Node.js & Python)

This project contains working OPC UA client examples in both **Node.js** and **Python**, designed to connect to:
- Public internet test endpoints (e.g. Sterfive demo)
- A local offline mock server (included)
- Real Siemens S7-1200 / S7-1500 PLCs configured in TIA Portal

---

## Directory Structure

```text
opcua-demo/
├── node/
│   ├── client.js          # Node.js OPC UA client (read, browse, subscribe)
│   ├── mock_server.js     # Local mock Siemens PLC server (Node.js)
│   ├── package.json
│   └── node_modules/
├── python/
│   ├── client.py          # Python asyncua client (read, browse, subscribe)
│   ├── mock_server.py     # Local mock Siemens PLC server (Python)
│   └── requirements.txt
└── README.md
```

---

## 1. Node.js Client (`node-opcua`)

### Run with Public Test Server:
```bash
cd C:\Users\SDS\opcua-demo\node
node client.js
```

### Run with Custom URL or Siemens PLC:
```bash
node client.js "opc.tcp://192.168.1.10:4840" 'ns=3;s="DB_Motor"."MotorSpeed"'
```

---

## 2. Python Client (`asyncua`)

### Setup dependencies:
```bash
cd C:\Users\SDS\opcua-demo\python
pip install -r requirements.txt
```

### Run with Public Test Server:
```bash
python client.py
```

### Run Specific Actions:
- **Browse tags**:
  ```bash
  python client.py --action browse
  ```
- **Read single tag**:
  ```bash
  python client.py --action read --nodeid "ns=0;i=2258"
  ```
- **Live Subscription**:
  ```bash
  python client.py --action subscribe --duration 10
  ```

---

## 3. Local Offline Mock Server (No PLC or Internet Required)

If you have no internet access or are working behind a strict corporate firewall:

1. In one terminal, start the local mock server (choose either Node.js or Python):
   - **Node.js**:
     ```bash
     cd C:\Users\SDS\opcua-demo\node
     node mock_server.js
     ```
   - **Python**:
     ```bash
     cd C:\Users\SDS\opcua-demo\python
     python mock_server.py
     ```

2. In a second terminal, run either the Node or Python client against it:
   - **Node.js**:
     ```bash
     cd C:\Users\SDS\opcua-demo\node
     node client.js "opc.tcp://127.0.0.1:4840/UA/SiemensMockServer" 'ns=2;s="DB_Motor"."MotorSpeed"'
     ```
   - **Python**:
     ```bash
     cd C:\Users\SDS\opcua-demo\python
     python client.py --url "opc.tcp://127.0.0.1:4840/UA/SiemensMockServer" --nodeid 'ns=2;s="DB_Motor"."MotorSpeed"'
     ```

---

## 4. Connecting to Siemens TIA Portal S7-1200 / S7-1500

1. **TIA Portal Configuration**:
   - In CPU properties, enable **OPC UA Server**.
   - In your Data Block (DB) properties, ensure **"Optimized block access" is unchecked**, OR the specific tag has **"Accessible from HMI/OPC UA"** checked.
2. **Finding the NodeId**:
   - Do not guess the NodeId. Use **UaExpert** (free tool from Unified Automation) to browse your PLC's address space.
   - S7-1500 DB tags follow this syntax:
     ```text
     ns=3;s="DB_Motor"."MotorSpeed"
     ```
3. **Endpoint URL**:
   ```text
   opc.tcp://<PLC_IP_ADDRESS>:4840
   ```
