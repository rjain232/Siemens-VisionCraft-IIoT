/**
 * Multi-Model Industrial OPC UA Simulation Server using node-opcua.
 * 
 * Simulates:
 *  1. Boiler & Alarms (OPC Labs style)
 *  2. HVAC / AirConditioner (Peakboard/Unified Automation style - Power spikes when Temp > SetPoint)
 *  3. CNC Machine & Robotics (umati style - Spindle, Axes, Tool)
 *  4. Continuous Raw Signals (Prosys style - Sine, Sawtooth, Random)
 *  5. Siemens S7-1500 DB Tags ("DB_Motor"."MotorSpeed", "DB_Production"."PartCount")
 */

const { OPCUAServer, Variant, DataType, StatusCodes } = require("node-opcua");

async function main() {
  const server = new OPCUAServer({
    port: 4840,
    resourcePath: "/UA/SiemensMockServer",
    buildInfo: {
      productName: "Industrial Multi-PLC Simulation Server",
      buildNumber: "2.0.0"
    }
  });

  await server.initialize();

  const addressSpace = server.engine.addressSpace;
  const ns = addressSpace.registerNamespace("http://industrial.simulation/opcua");
  const objectsFolder = addressSpace.rootFolder.objects;

  // ==========================================
  // 1. BOILER & ALARMS MODEL (OPC Labs style)
  // ==========================================
  const boilerFolder = ns.addObject({ organizedBy: objectsFolder, browseName: "Boiler_1" });
  let boilerPressure = 100.0;
  let boilerTemp = 180.0;
  let boilerAlarm = false;

  ns.addVariable({
    componentOf: boilerFolder,
    nodeId: `ns=${ns.index};s=Boiler_1.Pressure`,
    browseName: "Pressure",
    dataType: "Double",
    value: { get: () => new Variant({ dataType: DataType.Double, value: boilerPressure }) }
  });
  ns.addVariable({
    componentOf: boilerFolder,
    nodeId: `ns=${ns.index};s=Boiler_1.Temperature`,
    browseName: "Temperature",
    dataType: "Double",
    value: { get: () => new Variant({ dataType: DataType.Double, value: boilerTemp }) }
  });
  ns.addVariable({
    componentOf: boilerFolder,
    nodeId: `ns=${ns.index};s=Boiler_1.HighPressureAlarm`,
    browseName: "HighPressureAlarm",
    dataType: "Boolean",
    value: { get: () => new Variant({ dataType: DataType.Boolean, value: boilerAlarm }) }
  });

  // ==========================================
  // 2. HVAC AIR CONDITIONER (Peakboard style)
  // Compressor turns on & power spikes when Temp > SetPoint
  // ==========================================
  const hvacFolder = ns.addObject({ organizedBy: objectsFolder, browseName: "AirConditioner_1" });
  let hvacTemp = 24.5;
  let hvacSetPoint = 22.0;
  let hvacState = "Cooling";
  let hvacPower = 2200.0; // Watts

  ns.addVariable({
    componentOf: hvacFolder,
    nodeId: `ns=${ns.index};s=AirConditioner_1.State`,
    browseName: "State",
    dataType: "String",
    value: { get: () => new Variant({ dataType: DataType.String, value: hvacState }) }
  });
  ns.addVariable({
    componentOf: hvacFolder,
    nodeId: `ns=${ns.index};s=AirConditioner_1.Temperature`,
    browseName: "Temperature",
    dataType: "Double",
    value: { get: () => new Variant({ dataType: DataType.Double, value: hvacTemp }) }
  });
  const setPointVar = ns.addVariable({
    componentOf: hvacFolder,
    nodeId: `ns=${ns.index};s=AirConditioner_1.TemperatureSetPoint`,
    browseName: "TemperatureSetPoint",
    dataType: "Double",
    value: {
      get: () => new Variant({ dataType: DataType.Double, value: hvacSetPoint }),
      set: (variant) => {
        hvacSetPoint = parseFloat(variant.value);
        return StatusCodes.Good;
      }
    }
  });
  ns.addVariable({
    componentOf: hvacFolder,
    nodeId: `ns=${ns.index};s=AirConditioner_1.PowerConsumption`,
    browseName: "PowerConsumption",
    dataType: "Double",
    value: { get: () => new Variant({ dataType: DataType.Double, value: hvacPower }) }
  });

  // ==========================================
  // 3. CNC MACHINE & ROBOTICS (umati style)
  // ==========================================
  const cncFolder = ns.addObject({ organizedBy: objectsFolder, browseName: "CNC_Machine_1" });
  let spindleSpeed = 3500.0;
  let feedRate = 450.0;
  let toolNumber = 4;
  let axisX = 120.45;
  let axisY = 85.12;
  let axisZ = -14.20;

  ns.addVariable({
    componentOf: cncFolder,
    nodeId: `ns=${ns.index};s=CNC_Machine_1.SpindleSpeed`,
    browseName: "SpindleSpeed",
    dataType: "Double",
    value: { get: () => new Variant({ dataType: DataType.Double, value: spindleSpeed }) }
  });
  ns.addVariable({
    componentOf: cncFolder,
    nodeId: `ns=${ns.index};s=CNC_Machine_1.FeedRate`,
    browseName: "FeedRate",
    dataType: "Double",
    value: { get: () => new Variant({ dataType: DataType.Double, value: feedRate }) }
  });
  ns.addVariable({
    componentOf: cncFolder,
    nodeId: `ns=${ns.index};s=CNC_Machine_1.ToolNumber`,
    browseName: "ToolNumber",
    dataType: "Int32",
    value: { get: () => new Variant({ dataType: DataType.Int32, value: toolNumber }) }
  });
  ns.addVariable({
    componentOf: cncFolder,
    nodeId: `ns=${ns.index};s=CNC_Machine_1.AxisX`,
    browseName: "AxisX",
    dataType: "Double",
    value: { get: () => new Variant({ dataType: DataType.Double, value: axisX }) }
  });

  // ==========================================
  // 4. CONTINUOUS SIGNALS (Prosys style)
  // ==========================================
  const signalsFolder = ns.addObject({ organizedBy: objectsFolder, browseName: "Signals" });
  let sineVal = 0.0;
  let sawtoothVal = 0.0;
  let randomNoise = 0.0;

  ns.addVariable({
    componentOf: signalsFolder,
    nodeId: `ns=${ns.index};s=Signals.SineWave`,
    browseName: "SineWave",
    dataType: "Double",
    value: { get: () => new Variant({ dataType: DataType.Double, value: sineVal }) }
  });
  ns.addVariable({
    componentOf: signalsFolder,
    nodeId: `ns=${ns.index};s=Signals.SawTooth`,
    browseName: "SawTooth",
    dataType: "Double",
    value: { get: () => new Variant({ dataType: DataType.Double, value: sawtoothVal }) }
  });
  ns.addVariable({
    componentOf: signalsFolder,
    nodeId: `ns=${ns.index};s=Signals.RandomNoise`,
    browseName: "RandomNoise",
    dataType: "Double",
    value: { get: () => new Variant({ dataType: DataType.Double, value: randomNoise }) }
  });

  // ==========================================
  // 5. SIEMENS S7-1500 DB TAGS
  // ==========================================
  const siemensFolder = ns.addObject({ organizedBy: objectsFolder, browseName: "DataBlocksGlobal" });
  let motorSpeed = 1200.0;
  let partCount = 0;

  ns.addVariable({
    componentOf: siemensFolder,
    nodeId: `ns=${ns.index};s="DB_Motor"."MotorSpeed"`,
    browseName: "MotorSpeed",
    dataType: "Double",
    value: { get: () => new Variant({ dataType: DataType.Double, value: motorSpeed }) }
  });
  ns.addVariable({
    componentOf: siemensFolder,
    nodeId: `ns=${ns.index};s="DB_Production"."PartCount"`,
    browseName: "PartCount",
    dataType: "Int32",
    value: { get: () => new Variant({ dataType: DataType.Int32, value: partCount }) }
  });

  // ==========================================
  // REAL-TIME PROCESS SIMULATION LOOP (1000ms)
  // ==========================================
  let step = 0;
  setInterval(() => {
    step += 0.1;

    // 1. Boiler Simulation
    boilerPressure = +(100 + 8 * Math.sin(step)).toFixed(2);
    boilerTemp = +(180 + 5 * Math.cos(step)).toFixed(2);
    boilerAlarm = boilerPressure > 106.0;

    // 2. HVAC Simulation (Compressor cycles)
    hvacTemp = +(hvacTemp + (Math.random() * 0.4 - 0.2)).toFixed(2);
    if (hvacTemp > hvacSetPoint) {
      hvacState = "Cooling";
      hvacPower = +(2100 + Math.random() * 200).toFixed(1); // 2.1kW - 2.3kW compressor load
      hvacTemp = +(hvacTemp - 0.15).toFixed(2);
    } else {
      hvacState = "Idle / Fan";
      hvacPower = +(120 + Math.random() * 20).toFixed(1); // 120W fan only
      hvacTemp = +(hvacTemp + 0.1).toFixed(2);
    }

    // 3. CNC Machining Cycle
    spindleSpeed = +(3500 + Math.random() * 50 - 25).toFixed(1);
    feedRate = +(450 + Math.random() * 20 - 10).toFixed(1);
    axisX = +(120 + Math.sin(step) * 40).toFixed(2);

    // 4. Raw Signals
    sineVal = +(Math.sin(step) * 100).toFixed(3);
    sawtoothVal = +((step * 10) % 100).toFixed(2);
    randomNoise = +(Math.random() * 50).toFixed(3);

    // 5. Siemens Tags
    motorSpeed = +(1200 + Math.random() * 30 - 15).toFixed(2);
    partCount += 1;
  }, 1000);

  await server.start();
  const endpointUrl = server.getEndpointUrl();

  console.log("===============================================================");
  console.log("  Multi-Model Industrial OPC UA Simulation Server Running");
  console.log(`  Endpoint: ${endpointUrl}`);
  console.log("===============================================================");
  console.log("Available Simulation Models & Sample NodeIds:");
  console.log("  1. Boiler & Alarms (OPC Labs):");
  console.log(`     - ns=${ns.index};s=Boiler_1.Pressure`);
  console.log(`     - ns=${ns.index};s=Boiler_1.HighPressureAlarm`);
  console.log("  2. HVAC AirConditioner (Peakboard):");
  console.log(`     - ns=${ns.index};s=AirConditioner_1.State`);
  console.log(`     - ns=${ns.index};s=AirConditioner_1.Temperature`);
  console.log(`     - ns=${ns.index};s=AirConditioner_1.PowerConsumption`);
  console.log("  3. CNC Machine & Robotics (umati):");
  console.log(`     - ns=${ns.index};s=CNC_Machine_1.SpindleSpeed`);
  console.log(`     - ns=${ns.index};s=CNC_Machine_1.AxisX`);
  console.log("  4. Raw Signal Generation (Prosys):");
  console.log(`     - ns=${ns.index};s=Signals.SineWave`);
  console.log(`     - ns=${ns.index};s=Signals.SawTooth`);
  console.log("  5. Siemens S7-1500 DB Tags:");
  console.log(`     - ns=${ns.index};s="DB_Motor"."MotorSpeed"`);
  console.log(`     - ns=${ns.index};s="DB_Production"."PartCount"`);
  console.log("===============================================================");
  console.log("Press Ctrl+C to stop.");
}

main().catch(err => console.error("Server error:", err));
