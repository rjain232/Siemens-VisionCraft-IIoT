/**
 * OPC UA Client in Node.js (node-opcua)
 * Compatible with:
 *  - Public Test Server (opc.tcp://opcuademo.sterfive.com:26543)
 *  - Siemens S7-1200 / S7-1500 (e.g. opc.tcp://192.168.1.10:4840)
 *  - Local Mock Server (opc.tcp://127.0.0.1:4840/freeopcua/server/)
 */

const {
  OPCUAClient,
  AttributeIds,
  TimestampsToReturn,
  BrowseDirection,
  NodeClassMask
} = require("node-opcua");

// Parse command line arguments: node client.js [url] [nodeId]
const args = process.argv.slice(2);
const ENDPOINT_URL = args[0] || "opc.tcp://opcuaserver.com:48010";
const NODE_ID = args[1] || "ns=3;s=AirConditioner_1.Temperature";

async function readTag(session, nodeId) {
  console.log(`\n--- 1. READING SINGLE TAG: ${nodeId} ---`);
  try {
    const dataValue = await session.read({
      nodeId: nodeId,
      attributeId: AttributeIds.Value
    });
    console.log(`Value     : ${dataValue.value ? dataValue.value.value : "null"}`);
    console.log(`Status    : ${dataValue.statusCode.toString()}`);
    console.log(`Timestamp : ${dataValue.sourceTimestamp || dataValue.serverTimestamp}`);
  } catch (err) {
    console.error(`Failed to read tag ${nodeId}:`, err.message);
  }
}

async function browseRootObjects(session) {
  console.log("\n--- 2. BROWSING ROOT OBJECTS ---");
  try {
    const browseResult = await session.browse({
      nodeId: "ns=0;i=85", // ObjectIds.ObjectsFolder
      browseDirection: BrowseDirection.Forward,
      includeSubtypes: true,
      nodeClassMask: NodeClassMask.Object | NodeClassMask.Variable,
      resultMask: 63
    });

    console.log(`Discovered ${browseResult.references.length} nodes under ObjectsFolder:`);
    for (const ref of browseResult.references) {
      console.log(`  [${ref.nodeClass}] DisplayName: "${ref.displayName.text}" | NodeId: ${ref.nodeId.toString()}`);
    }
  } catch (err) {
    console.error("Browse error:", err.message);
  }
}

async function subscribeTag(session, nodeId, durationSeconds = 5) {
  console.log(`\n--- 3. LIVE SUBSCRIPTION ON ${nodeId} (${durationSeconds}s) ---`);
  
  const subscription = await session.createSubscription2({
    requestedPublishingInterval: 1000,
    requestedLifetimeCount: 100,
    requestedMaxKeepAliveCount: 10,
    maxNotificationsPerPublish: 10,
    publishingEnabled: true,
    priority: 10
  });

  const monitoredItem = await subscription.monitor(
    {
      nodeId: nodeId,
      attributeId: AttributeIds.Value
    },
    {
      samplingInterval: 1000,
      discardOldest: true,
      queueSize: 10
    },
    TimestampsToReturn.Both
  );

  monitoredItem.on("changed", (dataValue) => {
    console.log(`  >> [LIVE UPDATE] Value: ${dataValue.value ? dataValue.value.value : "null"} | Time: ${dataValue.sourceTimestamp}`);
  });

  // Keep subscription alive for specified duration
  await new Promise((resolve) => setTimeout(resolve, durationSeconds * 1000));
  
  await subscription.terminate();
  console.log("Subscription ended.");
}

async function main() {
  console.log("==================================================");
  console.log(`Connecting to: ${ENDPOINT_URL}`);
  console.log(`Target Tag   : ${NODE_ID}`);
  console.log("==================================================");

  const client = OPCUAClient.create({
    applicationName: "Node-RED OPC UA Client",
    applicationUri: "urn:RJAIN:Node-RED OPC UA Client",
    endpointMustExist: false,
    connectionStrategy: {
      maxRetry: 2,
      initialDelay: 2000
    }
  });

  try {
    await client.connect(ENDPOINT_URL);
    console.log("Connected to server successfully!");

    const session = await client.createSession();
    console.log("OPC UA session established!");

    // 1. Read Single Tag
    await readTag(session, NODE_ID);

    // 2. Browse Objects
    await browseRootObjects(session);

    // 3. Monitor tag updates
    await subscribeTag(session, NODE_ID, 5);

    // Clean disconnect
    await session.close();
    await client.disconnect();
    console.log("\nDisconnected cleanly. Done!");
  } catch (err) {
    console.error("OPC UA Client Error:", err);
    process.exit(1);
  }
}

main();
