@echo off
echo =======================================================
echo   Running OPC UA Python Client (Live HVAC Server)
echo =======================================================
python C:\Users\SDS\opcua-demo\python\client.py
pause
