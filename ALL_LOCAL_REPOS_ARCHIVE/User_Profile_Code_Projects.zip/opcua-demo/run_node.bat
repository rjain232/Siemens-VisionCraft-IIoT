@echo off
echo =======================================================
echo   Running OPC UA Node.js Client (Live HVAC Server)
echo =======================================================
node C:\Users\SDS\opcua-demo\node\client.js
pause
