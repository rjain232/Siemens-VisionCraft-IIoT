"""
Mock Siemens S7-1500 OPC UA Server using asyncua.
Use this to test your client locally without an active internet connection or physical PLC.
"""

import asyncio
import random
from asyncua import Server, ua


async def main():
    server = Server()
    await server.init()

    endpoint = "opc.tcp://127.0.0.1:4840/UA/SiemensMockServer"
    server.set_endpoint(endpoint)
    server.set_server_name("Mock Siemens S7-1500 Server")
    server.set_security_policy([ua.SecurityPolicyType.NoSecurity])

    # Setup Siemens-like namespace
    uri = "http://siemens.com/simatic/opcua"
    idx = await server.register_namespace(uri)
    print(f"Registered Namespace: '{uri}' at index ns={idx}")

    # Create a Simulated DB folder under Objects
    db_folder = await server.nodes.objects.add_folder(idx, "DataBlocksGlobal")

    # Add simulated Siemens tags
    motor_speed = await db_folder.add_variable(
        f'ns={idx};s="DB_Motor"."MotorSpeed"', "MotorSpeed", 1200.0, ua.VariantType.Double
    )
    part_count = await db_folder.add_variable(
        f'ns={idx};s="DB_Production"."PartCount"', "PartCount", 0, ua.VariantType.Int32
    )
    cycle_time = await db_folder.add_variable(
        f'ns={idx};s="DB_Production"."CycleTime"', "CycleTime", 12.5, ua.VariantType.Double
    )

    await motor_speed.set_writable()
    await part_count.set_writable()
    await cycle_time.set_writable()

    print(f"\nMock OPC UA Server is starting on: {endpoint}")
    print(f"Sample NodeIds available:")
    print(f'  - ns={idx};s="DB_Motor"."MotorSpeed"')
    print(f'  - ns={idx};s="DB_Production"."PartCount"')
    print(f'  - ns={idx};s="DB_Production"."CycleTime"')
    print("\nPress Ctrl+C to stop the server.\n")

    async with server:
        count = 0
        while True:
            await asyncio.sleep(1.0)
            count += 1

            # Simulate changing PLC values
            new_speed = 1200.0 + random.uniform(-15.0, 15.0)
            new_cycle = 12.0 + random.uniform(-0.5, 0.5)

            await motor_speed.write_value(round(new_speed, 2))
            await part_count.write_value(count)
            await cycle_time.write_value(round(new_cycle, 2))


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nMock server stopped.")
