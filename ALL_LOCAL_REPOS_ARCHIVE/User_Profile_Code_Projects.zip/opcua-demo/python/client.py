"""
OPC UA Client in Python (asyncua)
Compatible with:
 - Public Test Servers (e.g. opc.tcp://opcuademo.sterfive.com:26543)
 - Siemens S7-1200 / S7-1500 (e.g. opc.tcp://192.168.1.10:4840)
 - Local Mock Server (opc.tcp://127.0.0.1:4840/UA/SiemensMockServer)
"""

import argparse
import asyncio
import sys
from asyncua import Client

DEFAULT_ENDPOINT = "opc.tcp://opcuaserver.com:48010"
DEFAULT_NODE_ID = "ns=3;s=AirConditioner_1.Temperature"


class TagChangeHandler:
    """Handles monitored item data change events from the OPC UA server."""
    def datachange_notification(self, node, val, data):
        val_obj = data.monitored_item.Value
        timestamp = val_obj.SourceTimestamp or val_obj.ServerTimestamp
        status = val_obj.StatusCode
        print(f"  >> [UPDATE] Node: {node.nodeid} | Value: {val} | Status: {status} | Time: {timestamp}")


async def action_read(client: Client, node_id_str: str):
    """Reads a single tag."""
    print(f"\n--- 1. READING TAG: {node_id_str} ---")
    node = client.get_node(node_id_str)
    try:
        val = await node.read_value()
        data_val = await node.read_data_value()
        print(f"Value     : {val}")
        print(f"Status    : {data_val.StatusCode}")
        print(f"Timestamp : {data_val.SourceTimestamp or data_val.ServerTimestamp}")
    except Exception as e:
        print(f"Error reading node '{node_id_str}': {e}")


async def action_browse(client: Client, max_depth: int = 2):
    """Browses root objects folder to discover tags (e.g. Siemens DBs)."""
    print(f"\n--- 2. BROWSING ADDRESS SPACE (Root -> Objects) ---")
    objects = client.nodes.objects
    children = await objects.get_children()

    for child in children:
        browse_name = await child.read_browse_name()
        display_name = await child.read_display_name()
        node_class = await child.read_node_class()
        print(f"[{node_class.name}] Name: \"{display_name.Text}\" | NodeId: {child.nodeid}")

        if max_depth > 1:
            sub_children = await child.get_children()
            for sub in sub_children[:10]:
                sub_name = await sub.read_display_name()
                sub_class = await sub.read_node_class()
                print(f"    |-- [{sub_class.name}] \"{sub_name.Text}\" (NodeId: {sub.nodeid})")


async def action_subscribe(client: Client, node_id_str: str, duration: int = 5):
    """Creates a real-time subscription on a tag."""
    print(f"\n--- 3. SUBSCRIBING TO: {node_id_str} FOR {duration} SECONDS ---")
    node = client.get_node(node_id_str)
    handler = TagChangeHandler()
    sub = await client.create_subscription(period=1000, handler=handler)
    handle = await sub.subscribe_data_change(node)

    try:
        await asyncio.sleep(duration)
    finally:
        await sub.unsubscribe(handle)
        await sub.delete()
        print("Subscription closed.")


async def main():
    parser = argparse.ArgumentParser(description="OPC UA Python Client (asyncua)")
    parser.add_argument("--url", default=DEFAULT_ENDPOINT, help=f"OPC UA Server URL (default: {DEFAULT_ENDPOINT})")
    parser.add_argument("--nodeid", default=DEFAULT_NODE_ID, help=f"NodeId to read/subscribe (default: {DEFAULT_NODE_ID})")
    parser.add_argument("--action", choices=["read", "subscribe", "browse", "all"], default="subscribe",
                        help="Action to perform: read, subscribe, browse, or all (default: subscribe)")
    parser.add_argument("--duration", type=int, default=10, help="Subscription duration in seconds (default: 10)")
    args = parser.parse_args()

    print(f"==================================================")
    print(f"Connecting to OPC UA Server: {args.url}")
    print(f"Target Tag                 : {args.nodeid}")
    print(f"==================================================")

    try:
        async with Client(url=args.url) as client:
            print("Successfully connected to OPC UA Server!\n")

            if args.action in ("read", "all"):
                await action_read(client, args.nodeid)

            if args.action in ("browse", "all"):
                await action_browse(client)

            if args.action in ("subscribe", "all"):
                await action_subscribe(client, args.nodeid, duration=args.duration)

            print("\nDisconnected successfully. Done!")
    except Exception as err:
        print(f"\nConnection / OPC UA Error: {err}")
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())
