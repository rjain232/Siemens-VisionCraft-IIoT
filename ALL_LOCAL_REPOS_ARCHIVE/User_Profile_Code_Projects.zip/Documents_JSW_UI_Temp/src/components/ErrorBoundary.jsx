import { Component } from "react";

/**
 * ErrorBoundary — catches any uncaught React render error
 * (white screen fix: WebSocket crash, API crash, etc.)
 */
export default class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, info) {
    console.error("[ErrorBoundary] App crashed:", error, info.componentStack);
  }

  handleReload = () => {
    window.location.reload();
  };

  render() {
    if (this.state.hasError) {
      return (
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            height: "100vh",
            backgroundColor: "#f8fafc",
            fontFamily: "Arial, sans-serif",
            gap: "16px",
          }}
        >
          <div style={{ fontSize: "48px" }}>⚠️</div>
          <h2 style={{ color: "#1e3a5f", margin: 0 }}>Connection Lost</h2>
          <p style={{ color: "#64748b", margin: 0, textAlign: "center", maxWidth: "400px" }}>
            The app lost its connection — likely due to sleep, network interruption, or a background error.
          </p>
          <button
            onClick={this.handleReload}
            style={{
              marginTop: "8px",
              padding: "10px 28px",
              backgroundColor: "#2744A0",
              color: "white",
              border: "none",
              borderRadius: "6px",
              fontSize: "15px",
              cursor: "pointer",
              fontWeight: "600",
            }}
          >
            Reload App
          </button>
          <p style={{ color: "#94a3b8", fontSize: "12px", margin: 0 }}>
            Error: {this.state.error?.message}
          </p>
        </div>
      );
    }

    return this.props.children;
  }
}

