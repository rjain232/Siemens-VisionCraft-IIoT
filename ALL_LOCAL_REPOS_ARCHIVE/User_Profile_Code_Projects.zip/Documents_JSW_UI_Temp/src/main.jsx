import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App.jsx";
import ErrorBoundary from "./components/ErrorBoundary.jsx";
import { jsPDF } from "jspdf";
import { installPdfExportCache } from "./utils/reportExportCache";
import { installExportInterceptors } from "./utils/backgroundExportInterceptor";

try {
  installExportInterceptors();
  installPdfExportCache(jsPDF);
} catch (error) {
  console.warn("PDF export caching is unavailable:", error);
}

window.Apex = {
  chart: {
    fontFamily: "'Karla', sans-serif",
  },
};

// ── Auto-reload when network comes back (laptop wake / reconnect) ──
let wasOffline = false;
window.addEventListener("offline", () => {
  wasOffline = true;
  console.warn("[Network] Connection lost.");
});
window.addEventListener("online", () => {
  if (wasOffline) {
    console.log("[Network] Connection restored. Reloading app...");
    wasOffline = false;
    window.location.reload();
  }
});

// ── Auto-reload when laptop wakes from sleep ──
document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "visible") {
    // If page was hidden for >3 min, force a reload to re-establish connections
    const hiddenAt = window._hiddenAt;
    if (hiddenAt && Date.now() - hiddenAt > 3 * 60 * 1000) {
      console.log("[Visibility] Woke from long sleep. Reloading...");
      window.location.reload();
    }
  } else {
    window._hiddenAt = Date.now();
  }
});

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  </StrictMode>,
);
