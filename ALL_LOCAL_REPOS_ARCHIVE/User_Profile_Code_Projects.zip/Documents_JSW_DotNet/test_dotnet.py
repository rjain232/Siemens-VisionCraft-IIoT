import requests
import time
import random

URL = "http://localhost:5171/api/AIOps/analyze"

print("Starting Robot Simulator...")
print("Transmitting data to .NET AIOps Agent...\n")

motor_temp = 78.0

for i in range(4):
    # Simulate the motor slowly overheating
    motor_temp += random.uniform(1.0, 4.0)
    
    payload = {
        "RobotId": "R-01",
        "MotorTemp": round(motor_temp, 2),
        "CurrentAmps": 12.5
    }
    
    # Send data to your C# API
    response = requests.post(URL, json=payload)
    
    if response.status_code == 200:
        data = response.json()
        print(f"Sent Temp: {data['inputMetrics']['motorTemp']}C")
        print(f".NET Agent Decision: {data['agenticDecision']}\n")
    
    time.sleep(2)

