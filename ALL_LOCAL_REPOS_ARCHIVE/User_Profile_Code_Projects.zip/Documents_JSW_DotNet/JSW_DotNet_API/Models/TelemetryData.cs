namespace JSW_DotNet_API.Models;

public class TelemetryData {
    public string RobotId { get; set; } = "Unknown";
    public double MotorTemp { get; set; }
    public double CurrentAmps { get; set; }
}
