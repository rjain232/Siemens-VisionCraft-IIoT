using Microsoft.AspNetCore.Mvc;
using JSW_DotNet_API.Models;
using JSW_DotNet_API.Services;
using System;

namespace JSW_DotNet_API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AIOpsController : ControllerBase {
    private readonly AgenticDiagnosticService _aiService;

    public AIOpsController(AgenticDiagnosticService aiService) {
        _aiService = aiService;
    }

    [HttpPost("analyze")]
    public IActionResult Analyze([FromBody] TelemetryData telemetry) {
        var diagnosis = _aiService.AnalyzeTelemetry(telemetry);
        return Ok(new {
            Timestamp = DateTime.UtcNow,
            Robot = telemetry.RobotId,
            InputMetrics = new { telemetry.MotorTemp, telemetry.CurrentAmps },
            AgenticDecision = diagnosis
        });
    }
}
