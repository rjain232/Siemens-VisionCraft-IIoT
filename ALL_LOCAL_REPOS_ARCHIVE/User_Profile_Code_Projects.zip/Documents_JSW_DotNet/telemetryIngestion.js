/**
 * telemetryIngestion.js
 * 
 * This is the "bridge" endpoint between Node-RED and the JSW React Dashboard.
 * 
 * FLOW:
 *   Node-RED (reads Siemens PLC / Modbus)
 *     --> POST /api/telemetry/ingest
 *       --> writes to InfluxDB (via telemetryUtils.js)
 *         --> telemetry_wss.js queries InfluxDB --> pushes to LiveScada.jsx (React)
 */

const express = require('express');
const router = express.Router();

// Path goes up 3 levels from src/routes/ to reach the JSW root where telemetryUtils.js lives
const { writeTelemetry } = require('../../../telemetryUtils');

// In-memory store for the latest reading per robot (for fast GET access)
const latestReadings = new Map();

/**
 * POST /api/telemetry/ingest
 *
 * Called by Node-RED's "http request" node every time new PLC data arrives.
 * Node-RED sends this JSON body:
 * {
 *   "robotId":     "R-01",    -- from Modbus tag / OPC-UA node ID
 *   "lineId":      "Line_1",  -- from Node-RED static context
 *   "motorTemp":   82.5,      -- PLC register value in Celsius
 *   "currentAmps": 11.2,      -- PLC register value in Amperes
 *   "source":      "modbus"   -- protocol: "modbus" | "s7" | "opcua" | "mqtt"
 * }
 */
router.post('/ingest', (req, res) => {
    const { robotId, lineId, motorTemp, currentAmps, source = 'unknown' } = req.body;

    if (!robotId || motorTemp === undefined || currentAmps === undefined) {
        return res.status(400).json({
            success: false,
            error: 'Missing required fields: robotId, motorTemp, currentAmps'
        });
    }

    if (isNaN(motorTemp) || isNaN(currentAmps)) {
        return res.status(400).json({
            success: false,
            error: 'motorTemp and currentAmps must be valid numbers'
        });
    }

    // Write to InfluxDB using existing telemetryUtils logic
    writeTelemetry(
        robotId,
        lineId || 'Line_Unknown',
        parseFloat(motorTemp),
        parseFloat(currentAmps)
    );

    // Cache latest reading per robot for fast status lookups
    latestReadings.set(robotId, {
        robotId,
        lineId,
        motorTemp: parseFloat(motorTemp),
        currentAmps: parseFloat(currentAmps),
        source,
        timestamp: new Date().toISOString()
    });

    console.log(`[NodeRED Bridge] Source: ${source} | Robot: ${robotId} | Temp: ${motorTemp}C | Amps: ${currentAmps}A`);

    return res.status(200).json({
        success: true,
        message: `Telemetry ingested for ${robotId}`,
        data: { robotId, motorTemp, currentAmps, source }
    });
});

/**
 * GET /api/telemetry/latest
 * Returns the most recent reading for ALL robots currently reporting.
 */
router.get('/latest', (req, res) => {
    return res.status(200).json({
        success: true,
        count: latestReadings.size,
        data: Array.from(latestReadings.values())
    });
});

/**
 * GET /api/telemetry/latest/:robotId
 * Returns the most recent reading for ONE specific robot.
 * Example: GET /api/telemetry/latest/R-01
 */
router.get('/latest/:robotId', (req, res) => {
    const reading = latestReadings.get(req.params.robotId);
    if (!reading) {
        return res.status(404).json({
            success: false,
            error: `No recent data found for robot: ${req.params.robotId}`
        });
    }
    return res.status(200).json({ success: true, data: reading });
});

module.exports = router;

