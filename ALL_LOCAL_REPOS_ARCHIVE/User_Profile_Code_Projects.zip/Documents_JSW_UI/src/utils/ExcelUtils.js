import * as XLSX from "xlsx";
import { saveAs } from "file-saver";

export const generateExcel = (headers, rows, filename) => {
  const columnHeaders = headers.map((header) => header.label);
  const dataRows = rows.map((row) =>
    headers.map((header) => row[header.accessor] || ""),
  );
  const worksheet = XLSX.utils.aoa_to_sheet([columnHeaders, ...dataRows]);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, filename.slice(0, 31));
  const excelBuffer = XLSX.write(workbook, { bookType: "xlsx", type: "array" });
  const fileBlob = new Blob([excelBuffer], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });

  saveAs(fileBlob, `${filename.replace(/\s+/g, "_")}.xlsx`);
};

export const generateExcelWithGroupedHeaders = (
  headers,
  rows,
  filename,
  headerRows = [],
  merges = [],
  includeColumnHeaderRow = true,
) => {
  const columnHeaders = headers.map((header) => header.label);
  const dataRows = rows.map((row) =>
    headers.map((header) => row[header.accessor] || ""),
  );
  const worksheetRows = includeColumnHeaderRow
    ? [...headerRows, columnHeaders, ...dataRows]
    : [...headerRows, ...dataRows];
  const worksheet = XLSX.utils.aoa_to_sheet(worksheetRows);

  if (merges.length > 0) {
    worksheet["!merges"] = merges;
  }

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, filename.slice(0, 31));
  const excelBuffer = XLSX.write(workbook, { bookType: "xlsx", type: "array" });
  const fileBlob = new Blob([excelBuffer], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });

  saveAs(fileBlob, `${filename.replace(/\s+/g, "_")}.xlsx`);
};

export const generateExcelWithSheets = (sheets, filename) => {
  const workbook = XLSX.utils.book_new();

  sheets.forEach(({ sheetName, headers, rows }) => {
    const columnHeaders = headers.map((header) => header.label);
    const dataRows = rows.map((row) =>
      headers.map((header) => row[header.accessor] || ""),
    );
    const worksheet = XLSX.utils.aoa_to_sheet([columnHeaders, ...dataRows]);
    XLSX.utils.book_append_sheet(workbook, worksheet, sheetName);
  });

  const excelBuffer = XLSX.write(workbook, { bookType: "xlsx", type: "array" });
  const fileBlob = new Blob([excelBuffer], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });

  saveAs(fileBlob, `${filename.replace(/\s+/g, "_")}.xlsx`);
};
