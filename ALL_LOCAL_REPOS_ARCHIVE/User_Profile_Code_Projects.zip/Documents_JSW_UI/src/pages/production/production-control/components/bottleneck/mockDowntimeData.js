// ── Dummy downtime data generator ──────────────────────────────────────────
// Produces data in the same shape DowntimeBottleneckChart expects:
//   [{ id, name, downtime, severity, stations: [{ id, name, downtime, severity, substations: [...] }] }]
//
// Respects the currently selected filters:
//   - areaId / lineId / stationId: narrow which lines/stations/substations appear
//   - startDate / endDate: seeds the random downtime so the same filter
//     combination + date range always produces the same numbers (deterministic
//     "dummy" data instead of re-randomizing every render)

const LINE_CATALOG = {
  UB: { name: "UB", stations: ["UB010", "UB020", "UB030", "UB040", "UB050", "UB060", "UB070", "UB080", "UB090", "UB0100"] },
  FE: { name: "FE", stations: ["FE010", "FE020", "FE030", "FE040", "FE050"] },
  FF: { name: "FF", stations: ["FF010", "FF020", "FF030", "FF040"] },
  RF: { name: "RF", stations: ["RF010", "RF020", "RF030", "RF040"] },
};

function severityFor(downtime) {
  if (downtime <= 0) return "OK";
  if (downtime < 20) return "LOW";
  if (downtime < 60) return "MEDIUM";
  if (downtime < 150) return "HIGH";
  return "CRITICAL";
}

// Simple deterministic PRNG so the same seed always gives the same numbers
function seededRandom(seed) {
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

function seedFromString(str) {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = (hash << 5) - hash + str.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash) || 1;
}

function makeSubstations(stationId, rand, count = 2) {
  return Array.from({ length: count }, (_, i) => {
    const downtime = Math.round(rand() * 90);
    return {
      id: `${stationId}RBT${i + 1}`,
      name: `${stationId}RBT${i + 1}`,
      downtime,
      severity: severityFor(downtime),
    };
  });
}

function makeStation(stationId, rand) {
  const substations = makeSubstations(stationId, rand);
  const downtime = substations.reduce((sum, s) => sum + s.downtime, 0);
  return {
    id: stationId,
    name: stationId,
    downtime,
    severity: severityFor(downtime),
    substations,
  };
}

function makeLine(lineId, lineName, stationIds, rand) {
  const stations = stationIds.map((sid) => makeStation(sid, rand));
  const downtime = stations.reduce((sum, s) => sum + s.downtime, 0);
  return {
    id: lineId,
    name: lineName,
    downtime,
    severity: severityFor(downtime),
    stations,
  };
}

/**
 * generateDowntimeData
 * @param {Object} filters
 * @param {string} filters.areaId     - selected area id (or "" / "All")
 * @param {string} filters.lineId     - selected line id, e.g. "FE", or "All"
 * @param {string} filters.stationId  - selected station id, e.g. "FE010", or "All"
 * @param {string|Date} filters.startDate
 * @param {string|Date} filters.endDate
 */
export function generateDowntimeData({ areaId, lineId, stationId, startDate, endDate } = {}) {
  const seedKey = [areaId, lineId, stationId, startDate, endDate].filter(Boolean).join("|") || "default";
  const rand = seededRandom(seedFromString(seedKey));

  // Narrow which lines to generate based on lineId filter
  const lineIds =
    lineId && lineId !== "All" && LINE_CATALOG[lineId]
      ? [lineId]
      : Object.keys(LINE_CATALOG);

  return lineIds.map((lid) => {
    const catalog = LINE_CATALOG[lid];
    // Narrow which stations to generate based on stationId filter
    const stationIds =
      stationId && stationId !== "All" && catalog.stations.includes(stationId)
        ? [stationId]
        : catalog.stations;
    return makeLine(lid, catalog.name, stationIds, rand);
  });
}