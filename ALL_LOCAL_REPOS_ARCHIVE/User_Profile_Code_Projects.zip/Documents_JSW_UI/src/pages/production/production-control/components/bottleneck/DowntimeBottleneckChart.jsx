import { ArrowLeft } from "lucide-react";
import { useState, useMemo, useEffect } from "react";
import { Treemap, ResponsiveContainer, Tooltip } from "recharts";

// ── Relative color scale (equipment level only) ───────────────────────────────
// Instead of bucketed severity colors, shades equipment/substation cells on a
// light-to-dark red gradient based on each item's downtime rank relative to
// the min/max within its own station — so the worst-performing equipment
// always stands out, even if every item in the group is technically "MEDIUM".
const LIGHT_RED = [254, 226, 226]; // red-100
const DARK_RED = [127, 29, 29]; // red-900

function lerpColor(a, b, t) {
  const r = Math.round(a[0] + (b[0] - a[0]) * t);
  const g = Math.round(a[1] + (b[1] - a[1]) * t);
  const bl = Math.round(a[2] + (b[2] - a[2]) * t);
  return `rgb(${r},${g},${bl})`;
}

/**
 * Builds a value -> color lookup for a set of equipment items, scaling
 * light red (lowest downtime) to dark red (highest downtime) within the
 * group. Items with downtime 0 are always rendered as OK/green regardless
 * of rank, since "no downtime" shouldn't be painted as a lesser bottleneck.
 */
function buildRelativeColorScale(items) {
  const downtimes = items.map((i) => i.downtime);
  const min = Math.min(...downtimes);
  const max = Math.max(...downtimes);
  const range = max - min;

  return (downtime) => {
    if (downtime <= 0) return severityColor("OK", 0.9);
    const t = range === 0 ? 1 : (downtime - min) / range;
    return lerpColor(LIGHT_RED, DARK_RED, t);
  };
}

// ── Color helpers (unchanged) ─────────────────────────────────────────────────
function severityColor(severity, alpha = 1) {
  switch (severity) {
    case "OK":
      return `rgba(34,197,94,${alpha})`;
    case "LOW":
      return `rgba(132,204,22,${alpha})`;
    case "MEDIUM":
      return `rgba(234,179,8,${alpha})`;
    case "HIGH":
      return `rgba(249,115,22,${alpha})`;
    case "CRITICAL":
      return `rgba(239,68,68,${alpha})`;
    default:
      return `#fff`;
  }
}
function severityLabel(severity) {
  switch (severity) {
    case "OK":
      return "OK";
    case "LOW":
      return "LOW";
    case "MEDIUM":
      return "MED";
    case "HIGH":
      return "HIGH";
    case "CRITICAL":
      return "CRITICAL";
    default:
      return "#0000";
  }
}
function severityBadgeClass(severity) {
  switch (severity) {
    case "OK":
      return "bg-green-100 text-green-700";
    case "LOW":
      return "bg-lime-100 text-lime-700";
    case "MEDIUM":
      return "bg-yellow-100 text-yellow-700";
    case "HIGH":
      return "bg-orange-100 text-orange-700";
    case "CRITICAL":
      return "bg-red-100 text-red-700";
    default:
      return "bg-gray-100 text-gray-700";
  }
}

const CustomCell = (props) => {
  const { x, y, width, height, name, downtime, severity, onClick } = props;
  if (width < 4 || height < 4) return null;

  const fill = severityColor(severity, 0.9);
  const textVisible = width > 45 && height > 28;

  // Scale font size proportionally to the cell's smaller dimension, so text
  // grows on big rectangles instead of capping out small, while never
  // overflowing a short-but-wide or tall-but-narrow cell. Clamped to a
  // sensible min/max range.
  const minSide = Math.min(width, height);
  const titleFontSize = Math.max(11, Math.min(minSide / 5, 28));
  const subFontSize = Math.max(9, Math.min(minSide / 7, 18));

  return (
    <g
      onClick={() => onClick && onClick(name, downtime)}
      style={{ cursor: onClick ? "pointer" : "default" }}
    >
      <rect
        x={x + 2}
        y={y + 2}
        width={width - 4}
        height={height - 4}
        rx={6}
        ry={6}
        fill={fill}
        stroke="rgba(255,255,255,0.4)"
        strokeWidth={1.5}
      />
      {textVisible && (
        <>
          <text
            x={x + width / 2}
            y={y + height / 2 - titleFontSize / 2}
            textAnchor="middle"
            dominantBaseline="middle"
            fill="#fff"
            fontSize={titleFontSize}
            fontWeight="700"
            fontFamily="monospace"
          >
            {name}
          </text>
          <text
            x={x + width / 2}
            y={y + height / 2 + subFontSize}
            textAnchor="middle"
            dominantBaseline="middle"
            fill="rgba(255,255,255,0.85)"
            fontSize={subFontSize}
            fontFamily="sans-serif"
          >
            {downtime > 0 ? `${downtime} min` : "OK"}
          </text>
        </>
      )}
    </g>
  );
};

const CustomTooltip = ({ active, payload }) => {
  if (!active || !payload?.length) return null;
  const { name, downtime, severity } = payload[0].payload;
  return (
    <div className="bg-white text-slate-900 text-xs rounded-lg px-3 py-2 shadow-xl border border-slate-200">
      <p className="font-bold font-mono">{name}</p>
      <p className="text-slate-600">
        Downtime:{" "}
        <span className="text-slate-900 font-semibold">{downtime} min</span>
      </p>
      <p className="mt-0.5">
        <span
          className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${severityBadgeClass(severity)}`}
        >
          {severityLabel(severity)}
        </span>
      </p>
    </div>
  );
};

const Legend = () => (
  <div className="flex flex-wrap items-center gap-2 sm:gap-3 lg:gap-5 text-[10px] sm:text-xs font-semibold text-slate-600 uppercase tracking-tight sm:tracking-wide">
    {[
      { label: "OK", color: "bg-green-500" },
      { label: "Low", color: "bg-lime-400" },
      { label: "Medium", color: "bg-yellow-500" },
      { label: "High", color: "bg-orange-500" },
      { label: "Critical", color: "bg-red-500" },
    ].map(({ label, color }) => (
      <div key={label} className="flex items-center gap-1">
        <span className={`w-2 h-2 sm:w-3 sm:h-3 rounded-sm ${color}`} />
        {label}
      </div>
    ))}
  </div>
);

// ── Main component ────────────────────────────────────────────────────────────
// `data`: same shape as before [{ id, name, downtime, severity, stations: [...] }]
// `lockedLine`: line id already selected upstream via the Line filter.
//   When set, skips the "all lines" card grid and opens on that line's station treemap.
// `lockedStation`: station id already selected upstream via the Station filter.
//   When set (requires lockedLine too), skips the station treemap and opens
//   directly on that station's equipment/substation treemap.
// Both "locks" remove the corresponding breadcrumb back-button, since going
// back up a level there is the filter bar's job, not the chart's.
export default function DowntimeBottleneckChart({
  data,
  lockedLine = null,
  lockedStation = null,
}) {
  const treemapData = useMemo(() => data ?? [], [data]);

  const [drillLine, setDrillLine] = useState(lockedLine);
  const [drillStation, setDrillStation] = useState(lockedStation);

  // Re-sync drill state whenever data or the locked line/station change
  // (e.g. user picks a different Line/Station in the filter, or date range).
  useEffect(() => {
    setDrillLine(lockedLine);
    setDrillStation(lockedLine ? lockedStation : null); // station lock only meaningful with a line lock
  }, [lockedLine, lockedStation, treemapData]);

  const topData = useMemo(
    () =>
      treemapData.map((item) => ({
        name: item.id,
        downtime: item.downtime,
        severity: item.severity,
        size: Math.max(item.downtime, 40),
      })),
    [treemapData],
  );

  const drillData = useMemo(() => {
    if (!drillLine) return [];
    const line = treemapData.find((l) => l.id === drillLine);
    if (!line) return [];
    return (line.stations || []).map((st) => ({
      name: st.id,
      downtime: st.downtime,
      severity: st.severity,
      size: Math.max(st.downtime, 15),
    }));
  }, [treemapData, drillLine]);

  const equipmentData = useMemo(() => {
    if (!drillLine || !drillStation) return [];
    const line = treemapData.find((l) => l.id === drillLine);
    const station = line?.stations?.find((s) => s.id === drillStation);
    if (!station) return [];
    return (station.substations || []).map((substation) => ({
      name: substation.id,
      downtime: substation.downtime,
      severity: substation.severity,
      size: Math.max(substation.downtime, 22),
    }));
  }, [treemapData, drillLine, drillStation]);

  // Can the breadcrumb step back past the line? Only if the line wasn't forced.
  const canGoBackToAllLines = !lockedLine;
  // Can the breadcrumb step back past the station? Only if the station wasn't forced.
  const canGoBackToLineView = !lockedStation;

  return (
    <div className="bg-white border border-gray-200 rounded-lg px-4 py-3 mb-4">
      <div className="mb-6">
        <div className="mt-4">
          <Legend />
        </div>
      </div>

      {(drillLine || drillStation) && (
        <div className="flex items-center gap-2 text-sm mb-4">
          {((drillStation && canGoBackToLineView) ||
            (!drillStation && canGoBackToAllLines)) && (
            <button
              onClick={() => {
                if (drillStation) {
                  setDrillStation(null);
                  return;
                }
                setDrillLine(null);
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium text-gray-500 hover:bg-gray-100 transition-all"
            >
              <ArrowLeft size={14} /> {drillStation ? "Line View" : "All Lines"}
            </button>
          )}
          {drillLine &&
            (canGoBackToAllLines || (drillStation && canGoBackToLineView)) && (
              <span className="text-slate-400">/</span>
            )}
          {drillLine && (
            <button
              onClick={() => {
                if (drillStation && canGoBackToLineView) setDrillStation(null);
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium text-gray-500 ${
                drillStation && canGoBackToLineView
                  ? "hover:bg-gray-100 transition-all"
                  : ""
              }`}
            >
              {drillLine}
            </button>
          )}
          {drillStation && (
            <>
              <span className="text-slate-400">/</span>
              <span className="text-slate-900 font-bold">{drillStation}</span>
            </>
          )}
        </div>
      )}

      {/* All-lines card grid: only when no line is locked/selected */}
      {!drillLine && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 sm:gap-3 lg:gap-4">
          {topData.map((line) => {
            const lineObj = treemapData.find((l) => l.id === line.name);
            const stations = lineObj?.stations || [];
            const stationData = stations.map((st) => ({
              name: st.id,
              downtime: st.downtime,
              severity: st.severity,
              size: Math.max(st.downtime, 15),
            }));
            return (
              <div
                key={line.name}
                onClick={() => setDrillLine(line.name)}
                className="rounded-sm overflow-hidden border cursor-pointer group transition-all hover:scale-[1.02] hover:shadow-2xl"
                style={{
                  borderColor: severityColor(line.severity, 0.5),
                  background: severityColor(line.severity, 0.08),
                }}
              >
                <div
                  className="px-4 py-3 flex items-center justify-between"
                  style={{ background: severityColor(line.severity, 0.25) }}
                >
                  <span className="font-black text-xl tracking-tight">
                    {line.name}
                  </span>
                  <div className="text-right">
                    <span
                      className={`text-xs px-2 py-0.5 rounded-full font-bold ${severityBadgeClass(line.severity)}`}
                    >
                      {severityLabel(line.severity)}
                    </span>
                    <p className="text-xs text-slate-500 mt-0.5">
                      {line.downtime} min total
                    </p>
                  </div>
                </div>
                <div
                  className="h-56 sm:h-64 lg:h-72 px-2 pb-2 pt-0 sm:p-3 lg:px-4 lg:pb-4 lg:pt-0"
                  style={{ background: severityColor(line.severity, 0.25) }}
                >
                  <ResponsiveContainer width="100%" height="100%">
                    <Treemap
                      data={stationData}
                      dataKey="size"
                      aspectRatio={1}
                      content={
                        <CustomCell onClick={(name) => setDrillStation(name)} />
                      }
                    >
                      <Tooltip content={<CustomTooltip />} />
                    </Treemap>
                  </ResponsiveContainer>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Station-level treemap: skipped entirely if a station is locked */}
      {drillLine && !drillStation && (
        <div>
          {drillData.length > 0 &&
            (() => {
              const worst = drillData.reduce((a, b) =>
                b.downtime > a.downtime ? b : a,
              );
              return worst.downtime > 0 ? (
                <div className="my-4 flex items-center gap-3 bg-red-50 border border-red-200 rounded-xl px-4 py-3 text-sm">
                  <span className="text-red-600 text-lg">⚠</span>
                  <div>
                    <span className="font-bold text-rose-700">
                      {worst.name}
                    </span>
                    <span className="text-slate-600 ml-2">
                      is your highest-downtime station on line {drillLine}
                    </span>
                  </div>
                  <span className="ml-auto font-mono font-bold text-rose-700">
                    {worst.downtime} min
                  </span>
                </div>
              ) : null;
            })()}

          <div className="rounded-2xl overflow-hidden">
            <div style={{ height: "clamp(300px, 50vh, 500px)" }}>
              <ResponsiveContainer width="100%" height="100%">
                <Treemap
                  data={drillData}
                  dataKey="size"
                  aspectRatio={1}
                  content={
                    <CustomCell onClick={(name) => setDrillStation(name)} />
                  }
                >
                  <Tooltip content={<CustomTooltip />} />
                </Treemap>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}

      {/* Equipment/substation-level treemap */}
      {drillLine && drillStation && (
        <div className="mb-4">
          <div className="rounded-2xl overflow-hidden bg-white shadow-sm">
            <div style={{ height: "clamp(300px, 50vh, 480px)" }}>
              <ResponsiveContainer width="100%" height="100%">
                <Treemap
                  data={equipmentData}
                  dataKey="size"
                  aspectRatio={1}
                  content={<CustomCell onClick={null} />}
                >
                  <Tooltip content={<CustomTooltip />} />
                </Treemap>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
