import React, { useState, useEffect, useMemo, useRef } from "react";
import FilterBar from "../../../../sharedComponents/FilterBar";
import { formatStationName, formatClusterName } from "../../../../utils/Formatters";
import DateRangeBar from "../../../../sharedComponents/DateRangeBar";
import DowntimeBottleneckChart from "./bottleneck/DowntimeBottleneckChart";
import { masterApi } from "../../../../services/api";
import { generateDowntimeData } from "./bottleneck/mockDowntimeData";
import {
  downloadBottleneckExcel,
  downloadBottleneckPdf,
} from "../../../../utils/bottleneckDownload";
import { SearchPromptState, NoDataState } from "../../../../sharedComponents/EmptyState";

const ALL = "All";
const opt = (value, label) => ({ value, label });

export default function Bottleneck() {
  const [masterData, setMasterData] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isDownloading, setIsDownloading] = useState(false);
  const [dateFilter, setDateFilter] = useState({});
  const [hasSearched, setHasSearched] = useState(false);
  const [filters, setFilters] = useState({
    areaId: "",
    lineId: ALL,
    stationId: ALL,
    equipmentId: "",
  });

  useEffect(() => {
    masterApi
      .getMasterData()
      .then((res) => {
        const data = res?.data || [];
        setMasterData(data);
        const firstArea = data[0]; 
        setFilters({
          areaId: firstArea?.ClusterId ?? "",
          lineId: ALL,
          stationId: ALL,
          equipmentId: "",
        });
      })
      .catch(console.error)
      .finally(() => setIsLoading(false));
  }, []);

  const lines = useMemo(
    () =>
      masterData.find((c) => c.ClusterId === Number(filters.areaId))?.Lines ||
      [],
    [masterData, filters.areaId],
  );
  const stations = useMemo(() => {
    if (filters.lineId === ALL) {
      return lines.flatMap((l) => l.Stations || []);
    }
    return (
      lines.find((l) => l.LineId === Number(filters.lineId))?.Stations || []
    );
  }, [lines, filters.lineId]);

  const equipments = useMemo(() => {
    if (filters.stationId === ALL) {
      return stations.flatMap((s) => s.SubStations || []);
    }
    return (
      stations.find((s) => s.StationId === Number(filters.stationId))
        ?.SubStations || []
    );
  }, [stations, filters.stationId]);

  const isStationDisabled = filters.lineId === ALL;
  const isEquipmentDisabled = filters.stationId === ALL;

  // Selected area/cluster has no lines under it at all -> nothing to show
  const areaHasNoData = Boolean(filters.areaId) && lines.length === 0;

  const filterConfig = [
    {
      type: "select",
      key: "areaId",
      label: "Area",
      // Show every cluster, including ones with no lines under them —
      // selecting one of those will surface the "No data" state below.
      options: masterData.map((c) =>
        opt(c.ClusterId, formatClusterName(c.ClusterName)),
      ),
    },
    {
      type: "select",
      key: "lineId",
      label: "Line",
      options: [
        opt(ALL, "All Lines"),
        ...lines.map((l) => opt(l.LineId, l.LineName)),
      ],
    },
    {
      type: "select",
      key: "stationId",
      label: "Station",
      options: [
        opt(ALL, "All Stations"),
        ...stations.map((s) =>
          opt(s.StationId, formatStationName(s.StationName)),
        ),
      ],
      disabled: isStationDisabled,
    },
  ];

  const handleFiltersChange = (newFilters) => {
    if (newFilters.areaId !== filters.areaId) {
      newFilters = {
        ...newFilters,
        lineId: ALL,
        stationId: ALL,
        equipmentId: "",
      };
    } else if (newFilters.lineId !== filters.lineId) {
      newFilters = { ...newFilters, stationId: ALL, equipmentId: "" };
    } else if (newFilters.stationId !== filters.stationId) {
      newFilters = { ...newFilters, equipmentId: "" };
    }
    setFilters(newFilters);
  };

  //    dummy-data generator (chart works off codes like "FE", "FE010") ──────
  const selectedLine = useMemo(
    () => lines.find((l) => l.LineId === Number(filters.lineId)),
    [lines, filters.lineId],
  );
  const selectedStation = useMemo(
    () => stations.find((s) => s.StationId === Number(filters.stationId)),
    [stations, filters.stationId],
  );

  const chartData = useMemo(
    () =>
      generateDowntimeData({
        areaId: filters.areaId,
        lineId: selectedLine?.LineName ?? ALL,
        stationId: selectedStation?.StationName ?? ALL,
        startDate: dateFilter?.startDate,
        endDate: dateFilter?.endDate,
      }),
    [
      filters.areaId,
      selectedLine,
      selectedStation,
      dateFilter?.startDate,
      dateFilter?.endDate,
    ],
  );

  // id used inside chartData's `id` field for each line entry — matches the
  // `lid` key from LINE_CATALOG in generateDowntimeData, e.g. "FE", "UB"
  const lockedLine =
    filters.lineId !== ALL ? (selectedLine?.LineName ?? null) : null;
  const lockedStation =
    lockedLine && filters.stationId !== ALL
      ? (selectedStation?.StationName ?? null)
      : null;

  const chartContainerRef = useRef(null);

  const handleDownload = async () => {
    setIsDownloading(true);
    try {
      const meta = {
        areaLabel: formatClusterName(
          masterData.find((c) => c.ClusterId === Number(filters.areaId))
            ?.ClusterName,
        ),
        lineLabel: selectedLine?.LineName ?? "All Lines",
        stationLabel: selectedStation?.StationName ?? "All Stations",
        startDate: dateFilter?.startDate,
        endDate: dateFilter?.endDate,
      };

      await downloadBottleneckPdf(chartData, meta, chartContainerRef.current);
      downloadBottleneckExcel(chartData);
    } catch (err) {
      console.error("Bottleneck download failed:", err);
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <div className="m-4">
      <FilterBar
        config={filterConfig}
        filters={filters}
        onChange={handleFiltersChange}
        isLoading={isLoading}
      />
      <DateRangeBar
        onSearch={(start, end, startTime, endTime) => {
          setDateFilter({ startDate: start, endDate: end, startTime, endTime });
          setHasSearched(true);
        }}
        onDownload={handleDownload}
        showDownload={true}
        showTime={true}
        selectedStartDate={dateFilter?.startDate}
        selectedEndDate={dateFilter?.endDate}
        isDownloading={isDownloading}
      />
      {areaHasNoData ? (
        <NoDataState />
      ) : (
        <div ref={chartContainerRef}>
          {!hasSearched ? (
            <SearchPromptState pageName="Bottleneck" />
          ) : (
            <DowntimeBottleneckChart
              data={chartData}
              lockedLine={lockedLine}
              lockedStation={lockedStation}
            />
          )}
        </div>
      )}
    </div>
  );
}