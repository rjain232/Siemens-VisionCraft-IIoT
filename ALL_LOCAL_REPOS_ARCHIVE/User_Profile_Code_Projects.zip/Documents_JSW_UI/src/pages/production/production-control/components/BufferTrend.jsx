import { useState, useMemo, useEffect, useRef, useCallback } from "react";
import { DateInput } from "../../../../sharedComponents/DateRangeBar";
import FilterBar from "../../../../sharedComponents/FilterBar";
import { Search, Download } from "lucide-react";
import CardContainer from "../../../../sharedComponents/CardContainer";
import { masterApi, lineBufferApi } from "../../../../services/api";
import DataTable from "../../../../sharedComponents/DataTable";
import BacklogChart from "./buffer-trend/BacklogChart";
import { generateExcel } from "../../../../utils/ExcelUtils";
import {
  buildAutoTableConfig,
  drawPdfPageChrome,
  loadBrandingLogos,
  loadKarlaFont,
} from "../../../../utils/PdfUtils";
import { Activity } from "lucide-react";
import { SearchPromptState, NoDataState } from "../../../../sharedComponents/EmptyState";
import { ChartShimmer, TableShimmer } from "../../../../sharedComponents/Shimmer";
import { formatClusterName } from "../../../../utils/Formatters";
const MONTH_NAMES = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December",
];

function parseAsLocalTime(isoString) {
  if (typeof isoString !== "string") return new Date(isoString);
  return new Date(isoString.replace(/Z$/, ""));
}

function formatTimestamp(dateInput) {
  const date = dateInput instanceof Date ? dateInput : new Date(dateInput);
  const day = String(date.getDate()).padStart(2, "0");
  const month = MONTH_NAMES[date.getMonth()];
  const year = date.getFullYear();
  const time = `${String(date.getHours()).padStart(2, "0")}:${String(
    date.getMinutes(),
  ).padStart(2, "0")}:${String(date.getSeconds()).padStart(2, "0")}`;

  return `${day} ${month} ${year} ${time}`;
}

function formatStatusLabel(status) {
  if (!status) return status;
  const lower = status.toLowerCase();
  if (lower.includes("below") && lower.includes("min")) return "Near Minimum Threshold";
  if (lower.includes("above") && lower.includes("max")) return "Near Max Threshold";
  return status;
}

function getShift(date) {
  const minutes = date.getHours() * 60 + date.getMinutes();
  if (minutes >= 6 * 60 + 30 && minutes < 15 * 60) return "A";
  if (minutes >= 15 * 60 && minutes < 23 * 60 + 30) return "B";
  return "C";
}

function getShiftAnchor(dateStr) {
  if (!dateStr) return new Date();
  return new Date(`${dateStr}T06:30:00`);
}

function toFileToken(value) {
  return String(value || "all").replace(/[^a-z0-9]+/gi, "_");
}

function downloadBufferTrendExcel(rows, columns, filename) {
  const headers = columns.map((column) => ({
    label: column.label,
    accessor: column.key,
  }));
  generateExcel(headers, rows, filename);
}

async function downloadBufferTrendPDF(chartRef, rows, columns, filterLabels) {
  const { default: jsPDF } = await import("jspdf");
  const { default: autoTable } = await import("jspdf-autotable");

  const doc = new jsPDF({ orientation: "landscape", unit: "mm", format: "a4" });
  const fontFamily = await loadKarlaFont(doc);

  let [jswImg, schaefflerImg] = await loadBrandingLogos();
  if (!jswImg || !schaefflerImg) {
    await new Promise((resolve) => setTimeout(resolve, 300));
    const retryResult = await loadBrandingLogos();
    jswImg = jswImg ?? retryResult[0];
    schaefflerImg = schaefflerImg ?? retryResult[1];
  }

  const pageW = doc.internal.pageSize.getWidth();
  const pageH = doc.internal.pageSize.getHeight();
  const margin = 14;
  const headerH = 40;
  const footerH = 22;
  const firstTimestamp = rows[0]?.dateTime ?? "All";
  const lastTimestamp = rows.at(-1)?.dateTime ?? "All";
  const subLines = [
    `Date Range : ${firstTimestamp}  To  ${lastTimestamp}`,
    `Area : ${filterLabels.area}   |   Line : ${filterLabels.line}`,
  ];

  let chartImgData = null;
  let chartAspect = 0.42;
  if (chartRef.current) {
    try {
      const { toPng } = await import("html-to-image");
      chartImgData = await toPng(chartRef.current, {
        cacheBust: true,
        pixelRatio: 2,
        backgroundColor: "#ffffff",
      });
      const rect = chartRef.current.getBoundingClientRect();
      if (rect.width > 0) chartAspect = rect.height / rect.width;
    } catch (error) {
      console.warn("Buffer trend chart capture failed:", error.message);
    }
  }

  const subH = subLines.length * 5.5 + 10;
  const contentTop = headerH + subH;
  const contentW = pageW - margin * 2;
  const contentH = pageH - contentTop - footerH;

  doc.setFont(fontFamily, "bold");
  doc.setFontSize(10);
  doc.setTextColor(22, 70, 161);

  if (chartImgData) {
    const maxImgH = contentH - 10;
    const imgH = Math.min(contentW * chartAspect, maxImgH);
    const imgW = Math.min(contentW, imgH / chartAspect);
    const imgX = margin + (contentW - imgW) / 2;
    const imgY = contentTop + 8;

    doc.setDrawColor(226, 232, 240);
    doc.setLineWidth(0.3);
    doc.addImage(chartImgData, "PNG", imgX, imgY, imgW, imgH);
  } else {
    doc.setFont(fontFamily, "normal");
    doc.setFontSize(10);
    doc.setTextColor(100, 116, 139);
    doc.text("Chart preview unavailable.", margin, contentTop + 16);
  }

  doc.addPage();
  autoTable(doc, {
    startY: headerH + 8,
    ...buildAutoTableConfig(columns, rows, doc, fontFamily),
    tableWidth: "auto",
    columnStyles: {
      1: { cellWidth: 34 },
      5: { cellWidth: 32 },
    },
  });

  const totalPages = doc.internal.getNumberOfPages();
  for (let pageNum = 1; pageNum <= totalPages; pageNum++) {
    doc.setPage(pageNum);
    drawPdfPageChrome(doc, {
      pageNum,
      totalPages,
      fontFamily,
      title: "Buffer Trend Report",
      subLines: pageNum === 1 ? subLines : [],
      jswImg,
      schaefflerImg,
    });
  }

  doc.save(
    `Buffer_Trend_${toFileToken(filterLabels.area)}_${toFileToken(filterLabels.line)}.pdf`,
  );
}

export default function BufferTrend() {
  const today = new Date().toISOString().split("T")[0];
  const [isDownloading, setIsDownloading] = useState(false);
  const [selectedDate, setSelectedDate] = useState(today);
  const [filters, setFilters] = useState({
    area: "all",
    line: "all",
  });
  const [masterClusters, setMasterClusters] = useState([]);
  const chartRef = useRef(null);
  const [rawRows, setRawRows] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const [hasSearched, setHasSearched] = useState(false);
  const [appliedDate, setAppliedDate] = useState(null);
  const [appliedAreaLabel, setAppliedAreaLabel] = useState("");
  const [appliedLineLabel, setAppliedLineLabel] = useState("");

  useEffect(() => {
    const loadMasterData = async () => {
      try {
        const res = await masterApi.getMasterData();
        const clusters = res.data ?? [];
        setMasterClusters(clusters);

        const firstCluster = clusters[0];
        if (firstCluster) {
          const firstClusterId = String(firstCluster.ClusterId);
          const firstLine = (firstCluster.Lines ?? [])[0];
          const firstLineId = firstLine ? String(firstLine.LineId) : "all";

          setFilters((prev) => ({
            ...prev,
            area: firstClusterId,
            line: firstLineId,
          }));
        }
      } catch (err) {
        console.error("Master data failed:", err);
      }
    };
    loadMasterData();
  }, []);

  const areaOptions = useMemo(
    () =>
      masterClusters.map((cluster) => ({
        value: String(cluster.ClusterId),
        label: formatClusterName(cluster.ClusterName),
      })),
    [masterClusters],
  );

  const selectedCluster = useMemo(
    () =>
      masterClusters.find(
        (cluster) => String(cluster.ClusterId) === filters.area,
      ) ?? null,
    [filters.area, masterClusters],
  );

  const lineOptions = useMemo(() => {
    const lines =
      filters.area === "all"
        ? masterClusters.flatMap((cluster) => cluster.Lines ?? [])
        : (selectedCluster?.Lines ?? []);

    return lines.map((line) => ({
      value: String(line.LineId),
      label: line.LineName,
    }));
  }, [filters.area, masterClusters, selectedCluster]);

  const config = useMemo(
    () => [
      { type: "select", key: "area", label: "Area", options: areaOptions },
      { type: "select", key: "line", label: "Line", options: lineOptions },
    ],
    [areaOptions, lineOptions],
  );

  const canSearch = Boolean(selectedDate);

  const selectedAreaLabel = useMemo(() => {
    return (
      areaOptions.find((option) => option.value === filters.area)?.label ??
      "All"
    );
  }, [areaOptions, filters.area]);

  const selectedLineLabel = useMemo(() => {
    return (
      lineOptions.find((option) => option.value === filters.line)?.label ??
      "All"
    );
  }, [lineOptions, filters.line]);

  const fetchData = useCallback(
    async (currentFilters, date) => {
      setLoading(true);
      setError(null);
      try {
        const clusterId =
          currentFilters.area === "all" || currentFilters.area === "__null__"
            ? null
            : Number(currentFilters.area);
        const lineId =
          currentFilters.line === "all" || currentFilters.line === "__null__"
            ? null
            : Number(currentFilters.line);

        const res = await lineBufferApi.getLineBufferHistory({
          clusterId,
          lineId,
          selectedDate: date,
          pageNumber: 1,
          pageSize: 100000,
        });

        setRawRows(res?.tableData ?? []);
        setHasSearched(true);
      } catch (err) {
        setError(err.message);
        setRawRows([]);
      } finally {
        setLoading(false);
      }
    },
    [],
  );

  useEffect(() => {
    if (!hasSearched) return;
    if (!canSearch) {
      setRawRows([]);
      return;
    }
    const timer = setTimeout(() => {
      setAppliedDate(selectedDate);
      setAppliedAreaLabel(selectedAreaLabel);
      setAppliedLineLabel(selectedLineLabel);
      fetchData(filters, selectedDate);
    }, 300);
    return () => clearTimeout(timer);
  }, [filters, selectedDate]);

  function handleFilterChange(newFilters) {
    if (newFilters.area !== filters.area) {
      if (newFilters.area === "all") {
        newFilters.line = "all";
      } else if (newFilters.area === "__null__") {
        newFilters.line = "__null__";
      } else {
        const cluster = masterClusters.find(
          (c) => String(c.ClusterId) === newFilters.area,
        );
        const firstLine = (cluster?.Lines ?? [])[0];
        newFilters.line = firstLine ? String(firstLine.LineId) : "all";
      }
    }
    setFilters(newFilters);
  }

  // Anchor point = 06:30 on the date that was actually searched.
  const shiftAnchor = useMemo(
    () => getShiftAnchor(appliedDate || selectedDate),
    [appliedDate, selectedDate],
  );

  const mappedData = useMemo(() => {
    return rawRows.map((row) => {
      const tsDate = parseAsLocalTime(row.TimeStamp);
      const minutesFromAnchor = Math.round(
        (tsDate.getTime() - shiftAnchor.getTime()) / 60000,
      );
      return {
        id: row.Id,
        rawTimestamp: row.TimeStamp,
        minutesFromAnchor,
        dateTime: formatTimestamp(tsDate),
        shift: row.Shift ?? getShift(tsDate),
        area: formatClusterName(row.AreaName ?? selectedAreaLabel),
        line: row.LineName ?? selectedLineLabel,
        value: row.BufferValue,
        min: row.MinThreshold,
        max: row.MaxThreshold,
        target: row.Target,
        status: formatStatusLabel(row.StatusName ?? row.Status),
      };
    });
  }, [rawRows, selectedAreaLabel, selectedLineLabel, shiftAnchor]);

  const chartData = useMemo(
    () => [...mappedData].sort((a, b) => a.minutesFromAnchor - b.minutesFromAnchor),
    [mappedData],
  );

  const tableColumns = useMemo(
    () => [
      { key: "sr", label: "Sr. No.", sortable: false, width: "60px" },
      { key: "dateTime", label: "Timestamp", type: "mono", sortable: true, width: "180px" },
      { key: "shift", label: "Shift", type: "shift", sortable: true, width: "70px" },
      { key: "area", label: "Area", sortable: true, width: "120px" },
      { key: "line", label: "Line", type: "primary", sortable: true, width: "120px" },
      { key: "value", label: "Buffer Level", sortable: true, width: "110px" },
      { key: "max", label: "Max Threshold", sortable: true, width: "120px" },
      { key: "min", label: "Min Threshold", sortable: true, width: "120px" },
      { key: "target", label: "Target", sortable: true, width: "90px" },
      { key: "status", label: "Status", sortable: true, width: "200px" },
    ],
    [],
  );

  const tableData = useMemo(
    () =>
      mappedData.map((row, index) => ({
        ...row,
        sr: index + 1,
      })),
    [mappedData],
  );

  const handleDownload = async () => {
    if (!hasSearched || tableData.length === 0) return;
    try {
      setIsDownloading(true);
      downloadBufferTrendExcel(tableData, tableColumns, "Buffer Trend");
      await downloadBufferTrendPDF(chartRef, tableData, tableColumns, {
        area: appliedAreaLabel,
        line: appliedLineLabel,
      });
    } catch (err) {
      console.log(err);
    } finally {
      setIsDownloading(false);
    }
  };

  const handleSearch = () => {
    if (!selectedDate) return;
    setAppliedDate(selectedDate);
    setAppliedAreaLabel(selectedAreaLabel);
    setAppliedLineLabel(selectedLineLabel);
    fetchData(filters, selectedDate);
  };

  return (
    <div className="p-2">
      <FilterBar
        config={config}
        filters={filters}
        onChange={handleFilterChange}
      />
      <CardContainer>
        <div className="flex flex-wrap items-end gap-3">
          <DateInput
            label="Select Date"
            value={selectedDate ?? null}
            onChange={(date) => setSelectedDate(date)}
            rangeStart={selectedDate}
            rangeEnd={selectedDate}
            showTime={false}
          />
          <div className="flex-1"></div>

          <div className="flex items-end gap-2">
            <button
              onClick={handleSearch}
              disabled={!canSearch}
              className="flex items-center gap-1.5 bg-sky-600 hover:bg-sky-700 active:bg-sky-800 text-white text-sm font-semibold px-4 py-[7px] rounded-md transition-colors shadow-sm disabled:opacity-50"
              style={{ backgroundColor: "rgb(22, 70, 161)" }}
            >
              <Search size={13} /> Search
            </button>
            <button
              onClick={handleDownload}
              disabled={isDownloading}
              className="flex items-center gap-1.5 border border-sky-600 text-sky-600 hover:bg-sky-50 text-sm font-semibold px-4 py-[7px] rounded-md transition-colors disabled:opacity-50"
              style={{
                color: "rgb(22, 70, 161)",
                borderColor: "rgb(22, 70, 161)",
              }}
            >
              <Download size={13} />
              {isDownloading ? "Downloading..." : "Download"}
            </button>
          </div>
        </div>
      </CardContainer>

      {!canSearch || !hasSearched ? (
        <SearchPromptState pageName="Buffer Trend" />
      ) : (
        <>
          {error && !loading && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 mt-4">
              <p className="text-sm text-red-600">⚠️ Error: {error}</p>
            </div>
          )}

          {loading ? (
            <>
              <CardContainer title="Backlog Description - Previous">
                <ChartShimmer />
              </CardContainer>
              <TableShimmer rows={8} />
            </>
          ) : !error && tableData.length === 0 ? (
            <NoDataState />
          ) : !error && tableData.length > 0 ? (
            <>
              <CardContainer title={`Backlog Description - Previous`} ref={chartRef}>
                <BacklogChart data={chartData} />
              </CardContainer>

              <DataTable
                title="Backlog Description - Previous"
                columns={tableColumns}
                data={tableData}
              />
            </>
          ) : null}
        </>
      )}
    </div>
  );
}