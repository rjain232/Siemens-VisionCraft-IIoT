import React, { useState, useEffect, useMemo } from "react";
import { KPIShimmer, ChartShimmer } from "../../../../sharedComponents/Shimmer";
import EmptyState, { NoDataState } from "../../../../sharedComponents/EmptyState";
import {
  BatteryFull,
  BatteryLow,
  BatteryCharging,
  BatteryWarning,
  AlertTriangle,
  Cpu,
  Globe,
  HardDrive,
  Activity,
} from "lucide-react";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  Tooltip,
} from "recharts";
import { masterApi } from "../../../../services/api";
import { useRobotHealth } from "../../../../hooks/useRobotHealth";
import FilterBar from "../../../../sharedComponents/FilterBar";
import { formatClusterName } from "../../../../utils/Formatters";
import RobotIcon from "../../../../assets/robotic-arm (1).png";

const HOURS = Array.from({ length: 25 }, (_, i) => `${String(i).padStart(2, "0")}:00`);

const makeSeries = () =>
  HOURS.map((h) => ({ time: h, value: Math.floor(20 + Math.random() * 60) }));

const normalizeName = (name) => (name || "").trim();

const Button = ({
  label,
  onClick,
  bgColor = "bg-[#0e71ad]",
  textColor = "text-white",
  icon: Icon,
  className = "",
}) => (
  <button
    onClick={onClick}
    className={`${bgColor} hover:opacity-80 ${textColor} font-semibold py-2 px-4 rounded-lg flex items-center gap-2 transition-opacity ${className}`}
  >
    {Icon && <Icon size={18} />}
    {label}
  </button>
);

const ModalHOC = ({ isOpen, onClose, children }) => {
  useEffect(() => {
    document.body.classList.toggle("modal-open", isOpen);
    return () => document.body.classList.remove("modal-open");
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 flex items-center justify-center z-50 px-4"
      style={{ backgroundColor: "rgba(15, 23, 42, 0.45)" }}
      onClick={onClose}
    >
      <div
        className="relative bg-white rounded-2xl shadow-2xl w-full max-w-[420px] border border-gray-100"
        style={{ boxShadow: "0 8px 40px 0 rgba(14,113,173,0.25)" }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-4 sm:px-6 py-4 border-l-4 border-l-[#0e71ad] bg-[#eaf4fb] rounded-t-2xl">
          <h3 className="text-sm font-bold text-[#0e71ad] tracking-wide uppercase">Robot Details</h3>
          <button
            className="text-gray-400 hover:text-gray-700 text-xl font-bold leading-none transition-colors"
            onClick={onClose}
          >
            ✕
          </button>
        </div>
        <div className="px-4 sm:px-6 py-5">{children}</div>
      </div>
    </div>
  );
};

const RobotArmIcon = ({ size = 35 }) => (
  <img
    src={RobotIcon}
    alt="Robot Arm"
    width={size}
    height={size}
    className="object-contain"
  />
);

const getStatusWiseColor = (status) => {
  switch (status) {
    case "Active":
      return "bg-green-500";
    case "Breakdown":
      return "bg-[#dc3545]";
    case "Power Off":
      return "bg-[#ff6347]";
    default:
      return "bg-gray-400";
  }
};

const STATUS_PILL_STYLES = {
  Active: "bg-green-50 text-green-600",
  Idle: "bg-gray-100 text-gray-500",
  Breakdown: "bg-red-50 text-red-600",
  Stop: "bg-amber-100 text-amber-700",
  Unknown: "bg-gray-100 text-gray-500",
};

const Robo = ({ name, status, batteryStatus, isEmpty }) => {
  const isBreakdown = status === "Breakdown";
  const isKnownBattery = batteryStatus === "High" || batteryStatus === "Low";

  if (isEmpty) {
    return (
      <div className="w-full min-h-[104px] flex flex-col items-center justify-center bg-gray-50 border border-dashed border-gray-300 rounded-xl">
        <span className="text-gray-300 text-xs font-medium">—</span>
      </div>
    );
  }

  return (
    <div
      className={`w-full bg-white rounded-xl shadow-[0_2px_10px_rgba(15,23,42,0.10)] hover:shadow-[0_6px_20px_rgba(15,23,42,0.18)] hover:-translate-y-0.5 transition-all duration-200 p-3 border-2 ${isBreakdown ? "border-red-300" : "border-gray-300"
        }`}
    >
      <h2
        className="text-[13px] font-bold text-gray-800 leading-tight truncate"
        title={name}
      >
        {name}
      </h2>

      <div className="flex items-start gap-2 mt-2">
        <div className="relative flex-shrink-0 w-11 h-11 rounded-lg bg-gray-50 flex items-center justify-center">
          <RobotArmIcon size={30} />
          {isBreakdown && (
            <div className="absolute -top-1.5 -right-1.5 animate-pulse">
              <AlertTriangle size={12} className="text-yellow-500" />
            </div>
          )}
        </div>
        <div className="flex flex-col gap-1.5">
          <span
            className={`inline-block text-[10px] font-semibold px-2 py-0.5 rounded-full ${STATUS_PILL_STYLES[status] || "bg-gray-100 text-gray-500"
              } ${isBreakdown ? "animate-pulse" : ""}`}
          >
            {status}
          </span>

          <div className="flex items-center gap-1.5">
            {batteryStatus === "High" ? (
              <BatteryFull className="text-green-600 w-4 h-4 flex-shrink-0" />
            ) : batteryStatus === "Low" ? (
              <BatteryLow className="text-red-600 w-4 h-4 flex-shrink-0" />
            ) : (
              <BatteryWarning className="text-gray-400 w-4 h-4 flex-shrink-0" />
            )}
            <span className="text-[12px] font-bold text-[#1e3a8a] leading-none">
             %
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};


const RobotDetails = ({ robot, onBack }) => {
  const waterFlow = useMemo(() => makeSeries(), [robot?.SubStationId]);
  const temperature = useMemo(() => makeSeries(), [robot?.SubStationId]);
  const weldForce = useMemo(() => makeSeries(), [robot?.SubStationId]);
  const current = useMemo(() => makeSeries(), [robot?.SubStationId]);
  const status = robot?.HealthStatus || "Unknown";
  const batteryStatus = robot?.BatteryStatus || "Unknown";
  const isKnownBattery = batteryStatus === "High" || batteryStatus === "Low";

  const getBatteryIcon = (val) => {
    if (val === "High") return <BatteryFull className="text-green-500 w-6 h-6" />;
    if (val === "Low") return <BatteryWarning className="text-red-500 w-6 h-6" />;
    return <BatteryCharging className="text-gray-400 w-6 h-6" />;
  };

  const getStatusColor = (s) => {
    if (s === "Active") return "bg-green-500";
    if (s === "Idle") return "bg-yellow-500";
    if (s === "Breakdown") return "bg-red-500";
    return "bg-gray-400";
  };

  return (
    <div className="bg-gray-100 py-4 px-4">
      <Button
        label="Back to Layout"
        onClick={onBack}
        bgColor="bg-white"
        textColor="text-[#0e71ad] border border-[#0e71ad]"
        className="mb-4"
      />
      <div className="flex flex-col lg:flex-row gap-4">
        <div className="w-full lg:w-1/3 flex flex-col items-center justify-start bg-white shadow-md rounded-xl py-6">
          <h2 className="text-xl font-semibold mb-6 text-center px-2">
            Robot: {robot?.SubStationName ?? "—"}
          </h2>
          <RobotArmIcon size={80} />
          <div className="p-4 rounded-lg bg-white min-w-full text-center">
            <p className={`text-md font-semibold text-white py-1 rounded ${getStatusColor(status)}`}>
              {status}
            </p>
            <div className="flex items-center justify-center gap-2 mt-3">
              {getBatteryIcon(batteryStatus)}
              <span className="font-semibold text-gray-700">
                {isKnownBattery ? batteryStatus : "Unknown"}
              </span>
            </div>
            {robot?.stationName && (
              <p className="text-sm text-gray-500 mt-3">Station: {robot.stationName}</p>
            )}
            {robot?.lineName && (
              <p className="text-sm text-gray-500">Line: {robot.lineName}</p>
            )}
          </div>
        </div>

        <div className="w-full lg:w-2/3 flex-1 grid grid-cols-1 sm:grid-cols-2 gap-4">
          {[
            { title: "Water Flow", data: waterFlow, type: "area" },
            { title: "Temperature", data: temperature, type: "bar" },
            { title: "Weld Gun Force", data: weldForce, type: "line" },
            { title: "Current", data: current, type: "line" },
          ].map(({ title, data, type }) => (
            <div key={title} className="bg-white p-4 shadow-md rounded-lg">
              <h3 className="text-lg font-bold mb-2">{title}</h3>
              <ResponsiveContainer width="100%" height={150}>
                {type === "area" ? (
                  <AreaChart data={data}>
                    <XAxis dataKey="time" hide />
                    <Tooltip />
                    <Area type="monotone" dataKey="value" stroke="#00893D" fill="#00893D" fillOpacity={0.3} />
                  </AreaChart>
                ) : type === "bar" ? (
                  <BarChart data={data}>
                    <XAxis dataKey="time" hide />
                    <Tooltip />
                    <Bar dataKey="value" fill="#00893D" />
                  </BarChart>
                ) : (
                  <LineChart data={data}>
                    <XAxis dataKey="time" hide />
                    <Tooltip />
                    <Line type="monotone" dataKey="value" stroke="#00893D" dot={false} />
                  </LineChart>
                )}
              </ResponsiveContainer>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

const StationColumn = ({ station, robotHealthMap, onSelectRobot }) => {
  const apiRobots = [];
  const seenNames = new Set();
  (station.SubStations || []).forEach((ss) => {
    const name = ss.SubStationName || "";
    if (!/RB\d+/i.test(name)) return;
    const key = normalizeName(name);
    if (seenNames.has(key)) return;
    seenNames.add(key);
    apiRobots.push(ss);
  });

  if ((station.SubStations || []).length === 0 && !station.StationName) return null;

  return (
    <div className="flex flex-col gap-3 w-full sm:w-auto">
      <div className="mb-1">
        <h3 className="text-[15px] font-bold text-[#1e3a8a] tracking-tight">
          {station.StationName}
        </h3>
        <div className="h-[3px] w-8 bg-[#0e71ad] rounded-full mt-1" />
      </div>

      <div className="grid grid-cols-2 gap-2.5 w-full sm:w-[316px]">
        {apiRobots.map((r) => {
          const health = robotHealthMap[normalizeName(r.SubStationName)] || null;
          return (
            <div key={r.SubStationId} onClick={() => onSelectRobot(r, health)} className="cursor-pointer">
              <Robo
                name={r.SubStationName}
                status={health?.HealthStatus || "Unknown"}
                batteryStatus={health?.BatteryStatus || "Unknown"}
              />
            </div>
          );
        })}
      </div>
    </div>
  );
};

const RobotLayout = ({ onSelectRobotForEvents }) => {
  const [clusters, setClusters] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [filters, setFilters] = useState({ cluster: "", line: "" });
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedRobot, setSelectedRobot] = useState(null);

  // ── real robot health data via WebSocket ──────────────────────────
  const { data: healthList } = useRobotHealth();
  const robotHealthMap = useMemo(() => {
    const map = {};
    (healthList || []).forEach((r) => {
      map[normalizeName(r.Robot_Name)] = r;
    });
    return map;
  }, [healthList]);

  const clusterOptions = useMemo(
    () => clusters.map((c) => ({ label: formatClusterName(c.ClusterName), value: String(c.ClusterId) })),
    [clusters]
  );

  const selectedCluster = useMemo(
    () => clusters.find((c) => String(c.ClusterId) === filters.cluster),
    [clusters, filters.cluster]
  );

  const lineOptions = useMemo(
    () =>
      (selectedCluster?.Lines || []).map((line) => ({
        label: line.LineName,
        value: String(line.LineId),
      })),
    [selectedCluster]
  );

  const noLinesAvailable =
    clusters.length > 0 && Boolean(filters.cluster) && lineOptions.length === 0;

  useEffect(() => {
    if (!filters.cluster && clusters.length) {
      setFilters({ cluster: String(clusters[0].ClusterId), line: "" });
    }
  }, [clusters]);

  useEffect(() => {
    if (selectedCluster?.Lines?.length) {
      setFilters((prev) => ({
        ...prev,
        line: prev.line || String(selectedCluster.Lines[0].LineId),
      }));
    }
  }, [selectedCluster]);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        setLoading(true);
        setError(null);
        const res = await masterApi.getMasterData();
        const clusterList = res?.data || [];
        if (!cancelled) setClusters(clusterList);
      } catch (e) {
        if (!cancelled) setError(e.message || "Failed to load master data");
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, []);

  const selectedLine = useMemo(
    () => selectedCluster?.Lines?.find((l) => String(l.LineId) === filters.line) || null,
    [selectedCluster, filters.line]
  );

  const stations = selectedLine?.Stations || [];

  if (loading) return <div className="p-4 space-y-4"><KPIShimmer /><ChartShimmer /></div>;

  if (error) {
    return (
      <div className="px-4 py-6 text-red-600 font-semibold">
        Failed to load lines: {error}
      </div>
    );
  }

  const filterConfig = [
    { key: "cluster", label: "Cluster", type: "select", options: clusterOptions },
    { key: "line", label: "Line", type: "select", options: lineOptions },
  ];

  const handleRobotClick = (robot, health, station) => {
    setSelectedRobot({
      ...robot,
      ...(health || {}),
      stationName: station.StationName,
      lineName: selectedLine?.LineName,
    });
    setIsModalOpen(true);
  };

  return (
    <div>
      <div className="px-4 py-3">
        <FilterBar config={filterConfig} filters={filters} onChange={setFilters} />
      </div>
    <div className="mt-4 px-4 pb-6">
        {noLinesAvailable ? (
          <EmptyState
            icon={Activity}
            color="sky"
            title="No line or station available for the selected area"
          />
        ) : stations.length === 0 ? (
          <NoDataState subtitle="Try selecting a different line" />
        ) : (
          <div className="flex flex-wrap justify-center gap-x-6 sm:gap-x-10 gap-y-8">
            {stations.map((station) => (
              <StationColumn
                key={station.StationId}
                station={station}
                robotHealthMap={robotHealthMap}
                onSelectRobot={(robot, health) => handleRobotClick(robot, health, station)}
              />
            ))}
          </div>
        )}
      </div>

      <ModalHOC isOpen={isModalOpen} onClose={() => setIsModalOpen(false)}>
        {selectedRobot && (
          <div className="space-y-4">
            <div className="flex items-center justify-between gap-3 flex-wrap text-gray-700">
              <div className="flex items-center gap-2 min-w-0 shrink-0">
                <Cpu className="w-5 h-5 sm:w-6 sm:h-6 text-blue-600 flex-shrink-0" />
                <span className="font-medium whitespace-nowrap">Name</span>
              </div>
              <span className="font-semibold text-right break-words">{selectedRobot.SubStationName}</span>
            </div>
            <div className="flex items-center justify-between gap-3 flex-wrap text-gray-700">
              <div className="flex items-center gap-2 min-w-0 shrink-0">
                <HardDrive className="w-5 h-5 sm:w-6 sm:h-6 text-green-600 flex-shrink-0" />
                <span className="font-medium whitespace-nowrap">Make</span>
              </div>
              <span className="font-semibold text-right break-words">
                {selectedRobot.Make || "N/A"}
              </span>
            </div>
            <div className="flex items-center justify-between gap-3 flex-wrap text-gray-700">
              <div className="flex items-center gap-2 min-w-0 shrink-0">
                <Globe className="w-5 h-5 sm:w-6 sm:h-6 text-red-600 flex-shrink-0" />
                <span className="font-medium whitespace-nowrap">IP Address</span>
              </div>
              <span className="font-semibold text-right break-words">
                {selectedRobot.IP || "N/A"}
              </span>
            </div>
          </div>
        )}
      </ModalHOC>
    </div>
  );
};

const RobotHealth = () => {
  const [view, setView] = useState("layout");
  const [activeRobot, setActiveRobot] = useState(null);

  return (
    <>
      {view === "layout" ? (
        <RobotLayout
          onSelectRobotForEvents={(robot) => {
            setActiveRobot(robot);
            setView("events");
          }}
        />
      ) : (
        <RobotDetails
          robot={activeRobot}
          onBack={() => setView("layout")}
        />
      )}
    </>
  );
};

export default RobotHealth;