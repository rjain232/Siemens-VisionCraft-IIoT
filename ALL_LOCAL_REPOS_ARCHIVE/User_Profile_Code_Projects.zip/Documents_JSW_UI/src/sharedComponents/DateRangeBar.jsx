import { memo, useState, useEffect, useRef } from "react";
import { createPortal } from "react-dom";
import {
  Calendar,
  X,
  Search,
  Download,
  Clock,
  ChevronUp,
  ChevronDown,
} from "lucide-react";

const DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const MONTHS = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];

function getDaysInMonth(y, m) {
  return new Date(y, m + 1, 0).getDate();
}
function getFirstDay(y, m) {
  return new Date(y, m, 1).getDay();
}

function toDateStr(d) {
  if (!d) return "";
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function parseDate(str) {
  if (!str) return null;
  const [y, m, d] = str.split("-").map(Number);
  return new Date(y, m - 1, d);
}

function Spinner({ val, min, max, onChange }) {
  const pad = (n) => String(n).padStart(2, "0");
  return (
    <div className="flex flex-col items-center w-10">
      <button
        onClick={() => onChange(pad(val >= max ? min : val + 1))}
        className="w-full flex justify-center py-0.5 hover:bg-blue-50 rounded text-gray-400 hover:text-blue-700 transition-colors"
      >
        <ChevronUp size={14} />
      </button>
      <input
        type="text"
        value={pad(val)}
        maxLength={2}
        onChange={(e) => {
          const n = parseInt(e.target.value);
          if (!isNaN(n) && n >= min && n <= max) onChange(pad(n));
        }}
        className="w-10 text-center text-sm font-bold text-blue-800 bg-blue-50 border border-blue-200 rounded py-1 outline-none focus:ring-2 focus:ring-blue-300"
      />
      <button
        onClick={() => onChange(pad(val <= min ? max : val - 1))}
        className="w-full flex justify-center py-0.5 hover:bg-blue-50 rounded text-gray-400 hover:text-blue-700 transition-colors"
      >
        <ChevronDown size={14} />
      </button>
    </div>
  );
}

function CompactTimePicker({ value, onChange }) {
  const [h, m] = (value || "00:00").split(":").map(Number);
  const pad = (n) => String(n).padStart(2, "0");
  return (
    <div className="border-t border-gray-100 pt-2 mt-2">
      <div className="flex items-center gap-1 mb-2">
        <Clock size={11} className="text-blue-700" />
        <span className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">
          Time
        </span>
      </div>
      <div className="flex items-center gap-1 justify-center mb-2">
        <Spinner
          val={h}
          min={0}
          max={23}
          onChange={(v) => onChange(`${v}:${pad(m)}`)}
        />
        <span className="text-base font-bold text-gray-400 pb-0.5">:</span>
        <Spinner
          val={m}
          min={0}
          max={59}
          onChange={(v) => onChange(`${pad(h)}:${v}`)}
        />
      </div>
    </div>
  );
}

function SingleCalendar({
  viewYear,
  viewMonth,
  onPrev,
  onNext,
  onSelect,
  rangeStart,
  rangeEnd,
}) {
  const today = new Date();
  const daysInMonth = getDaysInMonth(viewYear, viewMonth);
  const firstDay = getFirstDay(viewYear, viewMonth);
  const start = parseDate(rangeStart);
  const end = parseDate(rangeEnd);

  const getState = (day) => {
    const dStr = toDateStr(new Date(viewYear, viewMonth, day));
    if (rangeStart === dStr) return "start";
    if (rangeEnd === dStr) return "end";
    if (start && end) {
      const d = new Date(viewYear, viewMonth, day);
      if (d > start && d < end) return "in-range";
    }
    return "none";
  };

  const cells = [];
  for (let i = 0; i < firstDay; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(d);

  return (
    <div className="w-64">
      <div className="flex items-center justify-between mb-2">
        <button
          onClick={onPrev}
          className="p-1 hover:bg-gray-100 rounded transition-colors"
        >
          <svg width="14" height="14" viewBox="0 0 16 16" fill="none">
            <path
              d="M10 12L6 8L10 4"
              stroke="#374151"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </button>
        <span className="text-sm font-semibold text-gray-800">
          {MONTHS[viewMonth]} {viewYear}
        </span>
        <button
          onClick={onNext}
          className="p-1 hover:bg-gray-100 rounded transition-colors"
        >
          <svg width="14" height="14" viewBox="0 0 16 16" fill="none">
            <path
              d="M6 4L10 8L6 12"
              stroke="#374151"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </button>
      </div>
      <div className="grid grid-cols-7 mb-0.5">
        {DAYS.map((d) => (
          <div
            key={d}
            className="text-center text-[11px] font-semibold text-gray-400 py-0.5"
          >
            {d}
          </div>
        ))}
      </div>
      <div className="grid grid-cols-7">
        {cells.map((day, idx) => {
          if (!day) return <div key={"e" + idx} />;
          const state = getState(day);
          const isToday =
            toDateStr(new Date(viewYear, viewMonth, day)) === toDateStr(today);
          let cellCls =
            "relative flex items-center justify-center h-7 cursor-pointer ";
          let numCls =
            "w-7 h-7 flex items-center justify-center rounded-full text-xs transition-all ";
          if (state === "start" || state === "end")
            numCls += "bg-blue-700 text-white font-bold";
          else if (state === "in-range") {
            cellCls += "bg-blue-50";
            numCls += "text-blue-800 hover:bg-blue-100";
          } else numCls += "text-gray-700 hover:bg-blue-100";
          return (
            <div
              key={day}
              className={cellCls}
              onClick={() =>
                onSelect(toDateStr(new Date(viewYear, viewMonth, day)))
              }
            >
              <div className={numCls}>
                {day}
                {isToday && state === "none" && (
                  <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-blue-700" />
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export function DateInput({
  label,
  value,
  timeValue,
  onChange,
  onTimeChange,
  rangeStart,
  rangeEnd,
  showTime,
}) {
  const [open, setOpen] = useState(false);
  const triggerRef = useRef(null);
  const popupRef = useRef(null);
  const [popupStyle, setPopupStyle] = useState({});

  const init = value ? parseDate(value) : new Date();
  const [viewYear, setViewYear] = useState(init.getFullYear());
  const [viewMonth, setViewMonth] = useState(init.getMonth());

  useEffect(() => {
    if (!open || !triggerRef.current) return;

    const rect = triggerRef.current.getBoundingClientRect();
    const popupWidth = 268;
    const popupHeight = showTime ? 390 : 280;
    const BUFFER = 30;

    let top = rect.bottom + 6;
    let left = rect.left;

    if (window.innerHeight - rect.bottom < popupHeight + BUFFER) {
      const topSpace = rect.top;
      if (topSpace > window.innerHeight - rect.bottom) {
        top = rect.top - popupHeight - 6;
      }
    }

    if (left + popupWidth > window.innerWidth) {
      left = window.innerWidth - popupWidth - 10;
    }
    if (left < 10) left = 10;
    if (top < 6) top = 6;

    setPopupStyle({ position: "fixed", top, left, zIndex: 99999 });

    const handleScroll = () => setOpen(false);
    window.addEventListener("scroll", handleScroll, true);

    const handleResize = () => {
      if (!triggerRef.current) return;
      const r = triggerRef.current.getBoundingClientRect();
      let t = r.bottom + 6;
      let l = r.left;
      if (window.innerHeight - r.bottom < popupHeight + BUFFER) {
        if (r.top > window.innerHeight - r.bottom) t = r.top - popupHeight - 6;
      }
      if (l + popupWidth > window.innerWidth)
        l = window.innerWidth - popupWidth - 10;
      if (l < 10) l = 10;
      if (t < 6) t = 6;
      setPopupStyle({ position: "fixed", top: t, left: l, zIndex: 99999 });
    };
    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("scroll", handleScroll, true);
      window.removeEventListener("resize", handleResize);
    };
  }, [open, showTime]);

  useEffect(() => {
    const handler = (e) => {
      if (
        triggerRef.current &&
        !triggerRef.current.contains(e.target) &&
        popupRef.current &&
        !popupRef.current.contains(e.target)
      )
        setOpen(false);
    };
    if (open) document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [open]);

  const prevMonth = () =>
    viewMonth === 0
      ? (setViewMonth(11), setViewYear((y) => y - 1))
      : setViewMonth((m) => m - 1);
  const nextMonth = () =>
    viewMonth === 11
      ? (setViewMonth(0), setViewYear((y) => y + 1))
      : setViewMonth((m) => m + 1);

  return (
    <div className="flex flex-col gap-1 relative" ref={triggerRef}>
      <label className="text-[11px] font-medium text-gray-400 uppercase tracking-wider">
        {label}
      </label>
      <div
        onClick={() => setOpen((p) => !p)}
        className={`flex items-center gap-1.5 bg-white border rounded-md px-2.5 py-[7px] cursor-pointer transition-all min-w-[148px] ${
          open
            ? "border-blue-700 ring-2 ring-blue-100"
            : "border-gray-200 hover:border-gray-300"
        }`}
      >
        <Calendar size={13} className="text-gray-400 shrink-0" />
        <span
          className={`text-sm flex-1 ${value ? "text-gray-800 font-medium" : "text-gray-400"}`}
        >
          {value || "Select date"}
        </span>
        {showTime && value && (
          <span className="flex items-center gap-0.5 text-[11px] font-semibold text-blue-700 bg-blue-50 border border-blue-100 px-1.5 py-0.5 rounded-md">
            <Clock size={9} />
            {timeValue || "00:00"}
          </span>
        )}
        {value && (
          <button
            onClick={(e) => {
              e.stopPropagation();
              onChange("");
              if (showTime) onTimeChange("00:00");
            }}
            className="text-gray-300 hover:text-gray-500 ml-0.5 transition-colors"
          >
            <X size={11} />
          </button>
        )}
      </div>

      {open &&
        createPortal(
          <div style={popupStyle} ref={popupRef}>
            <div className="bg-white border border-gray-200 rounded-xl shadow-xl p-3">
              <SingleCalendar
                viewYear={viewYear}
                viewMonth={viewMonth}
                onPrev={prevMonth}
                onNext={nextMonth}
                onSelect={(v) => {
                  onChange(v);
                  if (!showTime) setOpen(false);
                }}
                rangeStart={rangeStart}
                rangeEnd={rangeEnd}
              />
              {showTime && (
                <>
                  <CompactTimePicker
                    value={timeValue || "00:00"}
                    onChange={onTimeChange}
                  />
                  <button
                    onClick={() => setOpen(false)}
                    className="mt-2.5 w-full text-white text-xs font-semibold py-1.5 rounded-lg transition-colors"
                    style={{ backgroundColor: "rgb(22, 70, 161)" }}
                  >
                    Confirm
                  </button>
                </>
              )}
            </div>
          </div>,
          document.body,
        )}
    </div>
  );
}

function CustomDurationSelect({ label, options, value, onChange }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  const selected = [...options, { value: "", label: "Select Duration" }].find(
    (o) => o.value === value,
  ) || { value: "", label: "Select Duration" };

  useEffect(() => {
    const handler = (e) => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    if (open) document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [open]);

  const allOptions = [{ value: "", label: "Select Duration" }, ...options];

  return (
    <div className="flex flex-col gap-1 min-w-[180px]" ref={ref}>
      <label className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">
        {label}
      </label>

      <div className="relative">
        <button
          onClick={() => setOpen((p) => !p)}
          className={`w-full flex items-center justify-between gap-2 bg-white border rounded-md px-3 py-[7px] text-sm font-medium transition-all
            ${
              open
                ? "border-blue-700 ring-2 ring-blue-100 text-blue-800"
                : "border-gray-200 text-gray-700 hover:border-gray-300"
            }`}
        >
          <span className="truncate">{selected.label}</span>
          <ChevronDown
            size={13}
            className={`text-gray-400 transition-transform ${open ? "rotate-180 text-blue-700" : ""}`}
          />
        </button>

        {open && (
          <div className="absolute z-50 top-full mt-1 left-0 w-full bg-white border border-gray-200 rounded-xl shadow-xl overflow-hidden">
            {allOptions.map((opt) => {
              const isActive = opt.value === value;
              return (
                <button
                  key={opt.value || "select-duration"}
                  onClick={() => {
                    onChange(opt.value);
                    setOpen(false);
                  }}
                  className={`w-full text-left px-3 py-2 text-sm transition-colors
                    ${
                      isActive
                        ? "bg-blue-50 text-blue-800 font-semibold"
                        : "text-gray-700 hover:bg-gray-50"
                    }`}
                >
                  {opt.label}
                </button>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}


// added new building block for search using DateRangeBar.
function CustomSearchInput({ label, placeholder, value, onChange }) {
  return (
    <div className="flex flex-col gap-1 min-w-[180px]">
      <label className="text-[11px] font-medium text-gray-400 uppercase tracking-wider">
        {label}
      </label>
      <div
        className={`flex items-center gap-1.5 bg-white border rounded-md px-2.5 py-[7px] transition-all ${
          value
            ? "border-blue-700 ring-2 ring-blue-100"
            : "border-gray-200 hover:border-gray-300 focus-within:border-blue-700 focus-within:ring-2 focus-within:ring-blue-100"
        }`}
      >
        <Search size={13} className="text-gray-400 shrink-0" />
        <input
          type="text"
          value={value}
          placeholder={placeholder}
          onChange={(e) => onChange(e.target.value)}
          className="text-sm flex-1 outline-none placeholder:text-gray-400 text-gray-800 font-medium bg-transparent min-w-0"
        />
        {value && (
          <button
            onClick={() => onChange("")}
            className="text-gray-300 hover:text-gray-500 ml-0.5 transition-colors shrink-0"
          >
            <X size={11} />
          </button>
        )}
      </div>
    </div>
  );
}

export default memo(function DateRangeBar({
  onSearch = () => {},
  onDownload = () => {},
  showTime = false,
  showDownload = false,
  showDateInputs = true,
  withContainer = true,
  selectedStartDate = "",
  selectedEndDate = "",
  isDownloading = false,
  durationOptions = [],
  selectedDuration = "",
  onDurationChange = () => {},
  // --- new, opt-in search field ---
  showSearch = false,
  searchLabel = "Search",
  searchPlaceholder = "Search...",
  searchValue = "",
  onSearchValueChange = () => {},
}) {
  const getToday = () => {
    const today = new Date();
    return `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
  };

  const [startDate, setStartDate] = useState(getToday());
  const [endDate, setEndDate] = useState(getToday());
  const [startTime, setStartTime] = useState("00:00");
  const [endTime, setEndTime] = useState("23:59");

  useEffect(() => {
    if (selectedStartDate) setStartDate(selectedStartDate);
  }, [selectedStartDate]);

  useEffect(() => {
    if (selectedEndDate) setEndDate(selectedEndDate);
  }, [selectedEndDate]);

  const handleDurationChange = (value) => {
    if (!value) {
      setStartDate(getToday());
      setEndDate(getToday());
    }
    onDurationChange(value);
  };

  const handleSearch = () => {
    onSearch(startDate, endDate, startTime, endTime);
  };

  const content = (
    <div className="flex flex-wrap items-end gap-3">
      {showDateInputs && (
        <>
          <DateInput
            label="Start Date"
            value={startDate}
            timeValue={startTime}
            onChange={setStartDate}
            onTimeChange={setStartTime}
            rangeStart={startDate}
            rangeEnd={endDate}
            showTime={showTime}
          />
          <DateInput
            label="End Date"
            value={endDate}
            timeValue={endTime}
            onChange={setEndDate}
            onTimeChange={setEndTime}
            rangeStart={startDate}
            rangeEnd={endDate}
            showTime={showTime}
          />
           {durationOptions.length > 0 && (
            <div className="flex flex-col gap-1 min-w-[180px]">
              <CustomDurationSelect
                label="Duration"
                value={selectedDuration}
                options={durationOptions}
                onChange={handleDurationChange}
              />
            </div>
          )}
          {showSearch && (
            <CustomSearchInput
              label={searchLabel}
              placeholder={searchPlaceholder}
              value={searchValue}
              onChange={onSearchValueChange}
            />
          )}
         
        </>
      )}
      {showDateInputs ? <div className="flex-1" /> : <div className="w-0" />}
      <div className="flex items-end gap-2">
        <button
          onClick={handleSearch}
          className="flex items-center gap-1.5 text-white text-sm font-semibold px-4 py-[7px] rounded-md transition-colors shadow-sm"
          style={{ backgroundColor: "rgb(22, 70, 161)" }}
        >
          <Search size={13} /> Search
        </button>
        {showDownload && (
          <button
            onClick={onDownload}
            disabled={isDownloading}
            className="flex items-center gap-1.5 text-sm font-semibold px-4 py-[7px] rounded-md transition-colors disabled:opacity-50 bg-transparent border"
            style={{
              color: "rgb(22, 70, 161)",
              borderColor: "rgb(22, 70, 161)",
            }}
          >
            <Download size={13} />
            {isDownloading ? "Downloading..." : "Download"}
          </button>
        )}
      </div>
    </div>
  );

  if (!withContainer) {
    return content;
  }

  return (
    <div className="bg-white border border-gray-200 rounded-lg px-4 py-3 mb-4">
      {content}
    </div>
  );
});