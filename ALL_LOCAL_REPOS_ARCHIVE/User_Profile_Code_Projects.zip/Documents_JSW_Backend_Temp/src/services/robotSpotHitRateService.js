const { executeStoredProcedure, sql } = require("../utils/dbUtils");

const getSpotHitRate = async ({
  lineId,
  stationId,
  robotId,
  startDate,
  endDate,
}) => {
  try {
    const result = await executeStoredProcedure("dbo.app_Robot_SpotHitRate", {
      LineId: { type: sql.Int, value: lineId ? parseInt(lineId, 10) : null },
      StationId: {
        type: sql.Int,
        value: stationId ? parseInt(stationId, 10) : null,
      },
      RobotId: { type: sql.Int, value: robotId ? parseInt(robotId, 10) : null },
      StartDate: { type: sql.Date, value: startDate || null },
      EndDate: { type: sql.Date, value: endDate || null },
    });

    return result.recordset || [];
  } catch (error) {
    console.error("Robot SpotHitRate Service Error:", error);
    throw error;
  }
};

// 👉 NEW MLOPS INTEGRATION
const getPredictiveMaintenance = async (robotWeldCount, energyKwh, tempC) => {
  try {
    // 1. Your Node.js backend talks to the Python FastAPI Server
    const mlResponse = await fetch("http://127.0.0.1:8000/predict-mtbf", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        robot_weld_count: robotWeldCount,
        energy_consumption_kwh: energyKwh,
        operating_temperature: tempC
      })
    });

    if (!mlResponse.ok) {
      throw new Error("Failed to reach MLOps Server");
    }

    const mlData = await mlResponse.json();
    return mlData; // Returns { predicted_mtbf_hours: 274.95, maintenance_required: false }

  } catch (error) {
    console.error("MLOps Prediction Error:", error);
    return null;
  }
};

module.exports = { getSpotHitRate, getPredictiveMaintenance };
