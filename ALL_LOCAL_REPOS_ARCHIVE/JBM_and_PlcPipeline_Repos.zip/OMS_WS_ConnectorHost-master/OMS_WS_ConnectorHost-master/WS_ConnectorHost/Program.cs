﻿using System;
using System.ServiceProcess;

namespace WS_ConnectorHost
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main()
        {
#if DEBUG
            Console.WriteLine("====================================");
            Console.WriteLine("WS_ConnectorHost - DEBUG MODE");
            Console.WriteLine("====================================");

            Service1 service = new Service1();

            // Calls OnStart()
            service.OnDebug();

            Console.WriteLine("Service Started in Debug Mode.");
            Console.WriteLine("Press ENTER to stop...");

            Console.ReadLine();

            service.Stop();
#else
            ServiceBase[] ServicesToRun;
            ServicesToRun = new ServiceBase[]
            {
                new Service1()
            };

            ServiceBase.Run(ServicesToRun);
#endif
        }
    }
}