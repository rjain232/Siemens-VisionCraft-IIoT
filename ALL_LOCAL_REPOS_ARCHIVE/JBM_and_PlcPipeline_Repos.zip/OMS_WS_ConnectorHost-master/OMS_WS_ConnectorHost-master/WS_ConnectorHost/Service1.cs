﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace WS_ConnectorHost
{//New 
    public partial class Service1 : ServiceBase
    {
        private System.Timers.Timer timer = null;
        private BusinessLayer bl = new BusinessLayer();
        public Service1()
        {
            InitializeComponent();

        }
        public void OnDebug()
        {
            OnStart(null);

        }
        protected override void OnStart(string[] args)
        {
            ConnectorHostLogs("Service Started");
            CreateDirIfNotExist();
            #region timer
            timer = new System.Timers.Timer();
            this.timer.Interval = 6;//60000 * Convert.ToInt32(ConfigurationManager.AppSettings["Duration"]);// For Minuts
            this.timer.Elapsed += Timer_Elapsed;
            timer.Enabled = true;
            #endregion
        }

        private void Timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            lock (timer)
            {
                string[] IPMStextFIle = Directory.GetFiles(ConfigurationManager.AppSettings["filepath"].ToString(), "*.txt");

                try
                {
                    if (IPMStextFIle.Count() != 0)
                    {

                        for (var i = 0; i < IPMStextFIle.Count(); i++)
                        {
                            string filename = Path.GetFileName(IPMStextFIle[i]);

                            DataTable dataTable = new DataTable();
                            List<string[]> rows = new List<string[]>();
                            using (StreamReader reader = new StreamReader(IPMStextFIle[i]))
                            {
                                while (!reader.EndOfStream)
                                {
                                    string line = reader.ReadLine();
                                    string[] columns = line.Split(',');
                                    rows.Add(columns);
                                }
                            }
                            if (rows.Count > 0)
                            {

                                int sr = 1;
                                foreach (string column in rows[0])
                                {
                                    dataTable.Columns.Add("Value" + sr, typeof(string)); // Change the data type accordingly if needed
                                    sr++;
                                }

                                for (int j = 0; j < rows.Count; j++) // Start from index 1 to skip the header row
                                {
                                    dataTable.Rows.Add(rows[j]);
                                }
                            }

                            if (dataTable.Rows.Count > 0)
                            {
                                BusinessLayer bl = new BusinessLayer();
                                int filecode = Convert.ToInt32(bl.MaxFileCode());
                                try
                                {
                                    foreach (DataRow row in dataTable.Rows)
                                    {

                                        string vCode = row["Value6"].ToString() + "-" + "-" + "-" + "-" + "-" + "-" + "-" + "-" + "-" + row["Value16"].ToString();
                                        if (!string.IsNullOrEmpty(row["Value1"].ToString()) && !string.IsNullOrEmpty(row["Value2"].ToString()) && !string.IsNullOrEmpty(vCode))
                                        {
                                            bl.InsertProductionDetails(row["Value1"].ToString(), row["Value2"].ToString(), vCode, row["Value4"].ToString(), DateTime.Now, filename, filecode);
                                        }

                                    }
                                    ConnectorHostLogs($"File Injested Successfully({filename})");
                                    File.Delete(IPMStextFIle[i]);
                                }
                                catch (Exception ex)
                                {
                                    bl.FileDelete(filecode);
                                    ConnectorHostLogs($"Error while File Injested({IPMStextFIle[i]}), details-{ex.Message.ToString()}");
                                }


                            }

                        }
                    }
                }
                catch (Exception ex)
                {
                    ConnectorHostLogs(ex.ToString());
                }
            }
        }
        private static void CreateDirIfNotExist()
        {
            try
            {
                string logPath = ConfigurationManager.AppSettings["LogPath"].ToString();

                string[] strArr = new string[] { @"ConnectorHost" };
                foreach (string str in strArr)
                {
                    string fullapth = logPath + "" + str;
                    if (!Directory.Exists(fullapth))
                    {
                        Directory.CreateDirectory(fullapth);
                    }
                }
            }
            catch (Exception)
            {

            }

        }

        static void ConnectorHostLogs(string s)
        {
            try
            {
                string currentDirectory = ConfigurationManager.AppSettings["LogPath"].ToString() + "ConnectorHost";// System.IO.Directory.GetCurrentDirectory().ToString();

                using (System.IO.StreamWriter file = new System.IO.StreamWriter(currentDirectory + @"\" + "ConnectorHostLogs" + ".txt", true))
                {
                    file.WriteLine(DateTime.Now.ToString() + " " + s);
                }


                string filePath = currentDirectory + "\\ConnectorHostLogs.txt"; // Path to your file
                long maxSizeInBytes = 1000000;
                // Check if the file exists
                if (!File.Exists(filePath))
                {
                    //Console.WriteLine($"File not found: {filePath}");
                    return;
                }

                // Get the file size
                FileInfo fileInfo = new FileInfo(filePath);
                long fileSize = fileInfo.Length;

                //Console.WriteLine($"Current file size: {fileSize} bytes");

                // Check if the file size exceeds the maximum allowed size
                if (fileSize > maxSizeInBytes)
                {
                    // Create a new file name with a timestamp
                    string directory = fileInfo.DirectoryName;
                    string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(filePath);
                    string extension = fileInfo.Extension;
                    string newFileName = $"{fileNameWithoutExtension}_{DateTime.Now:yyyyMMdd_HHmmss}{extension}";
                    string newFilePath = Path.Combine(directory, newFileName);

                    // Rename the file
                    File.Move(filePath, newFilePath);

                    //Console.WriteLine($"File renamed to: {newFilePath}");
                }
            }
            catch (Exception )
            {
                //Console.WriteLine($"An error occurred: {ex.Message}");
            }
        }
        protected override void OnStop()
        {
            timer.Stop();
            ConnectorHostLogs("Service Stoped");
        }
    }
}
