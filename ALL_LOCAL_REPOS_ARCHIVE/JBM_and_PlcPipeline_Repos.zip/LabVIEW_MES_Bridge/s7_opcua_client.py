"""
Siemens S7-1200 / S7-1500 OPC UA Data Collector
Reads DB tags, cycle times, alarms, and production counts via OPC UA
and forwards them directly into the JSW MES Pipeline.
"""

import asyncio
import json
import requests
from datetime import datetime
from asyncua import Client, ua

# ==========================================
# CONFIGURATION
# ==========================================
# Replace with your actual S7-1200 / S7-1500 IP address:
# Port 4840 is the standard Siemens OPC UA server port
PLC_OPCUA_ENDPOINT = "opc.tcp://192.168.0.1:4840"

# Target Node IDs in your Siemens DB (Data Block):
# Format for Siemens TIA Portal OPC UA: "ns=3;s=\"DB_Production\".\"ActualCount\""
# Or numeric index: "ns=2;s=Channel1.Device1.Tag1"
NODE_IDS_TO_READ = {
    "vin": 'ns=3;s="DB_MES"."Current_VIN"',
    "actualCount": 'ns=3;s="DB_Production"."ActualCount"',
    "cycleTimeSec": 'ns=3;s="DB_Production"."StationCycleTime"',
    "alarmActive": 'ns=3;s="DB_Alarms"."GeneralAlarm"',
    "weldCurrentKA": 'ns=3;s="DB_Welding"."ActualWeldCurrent"'
}

GATEWAY_ENDPOINT = "http://localhost:8085/api/labview/weld-event"


async def read_plc_data():
    print(f"[{datetime.now().strftime('%H:%M:%S')}] Connecting to Siemens S7 PLC at: {PLC_OPCUA_ENDPOINT}...")
    
    # Optional Security: For unencrypted testing, use None.
    # If S7-1500 requires User/Pass or Cert, configure security policies here.
    async with Client(url=PLC_OPCUA_ENDPOINT, timeout=5) as client:
        print("✅ Connected to Siemens S7 OPC UA Server!")

        # Infinite polling loop
        while True:
            try:
                collected_data = {
                    "timestamp": datetime.now().isoformat(),
                    "plcIp": PLC_OPCUA_ENDPOINT
                }

                # Read each configured tag
                for tag_name, node_str in NODE_IDS_TO_READ.items():
                    try:
                        node = client.get_node(node_str)
                        val = await node.read_value()
                        collected_data[tag_name] = val
                    except Exception as tag_err:
                        # Fallback for offline tags / DB address testing
                        collected_data[tag_name] = None

                print(f"[PLC READ] {json.dumps(collected_data)}")

                # Forward directly into JSW MES Gateway
                try:
                    payload = {
                        "vin": collected_data.get("vin") or "JSW-SIM-VIN",
                        "robotId": "S7-1500-LINE-01",
                        "weldCurrentKA": collected_data.get("weldCurrentKA") or 11.8,
                        "status": "OK" if not collected_data.get("alarmActive") else "ALARM"
                    }
                    res = requests.post(GATEWAY_ENDPOINT, json=payload, timeout=2)
                    if res.status_code == 200:
                        print(f"  └─► Forwarded to JSW MES (HTTP 200)")
                except Exception as post_err:
                    print(f"  └─► MES Forwarding Warning: {post_err}")

            except Exception as loop_err:
                print(f"❌ Error during read cycle: {loop_err}")

            await asyncio.sleep(1.0)  # 1-second sample rate


if __name__ == "__main__":
    try:
        asyncio.run(read_plc_data())
    except KeyboardInterrupt:
        print("\nOPC UA Collector stopped by user.")
    except Exception as e:
        print(f"Connection failed: {e}")
        print("\nTIP: Make sure the S7-1200/1500 PLC has OPC UA Server activated in TIA Portal.")
