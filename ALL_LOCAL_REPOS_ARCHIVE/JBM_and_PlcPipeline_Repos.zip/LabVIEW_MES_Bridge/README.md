# JSW Plant Automation: LabVIEW to MES Integration Guide

## 1. Overview
This project sets up the direct pipeline connecting **National Instruments LabVIEW 2026 (64-bit)** to the **JSW Shop-Floor MES Ecosystem**.

```
  ┌─────────────────────────────────────────────────────────────┐
  │                 LabVIEW 2026 Test VI                        │
  │   - Automated Body Welding Telemetry                        │
  │   - Spot Weld Quality / Current Sensors                     │
  │   - Barcode / VIN Traceability Scan                         │
  └──────────────────────────────┬──────────────────────────────┘
                                 │ HTTP POST (JSON Payload)
                                 ▼
  ┌─────────────────────────────────────────────────────────────┐
  │           JSW - LabVIEW MES Telemetry Gateway               │
  │           Port: 8085 (Daemon running on local machine)      │
  └──────────────────────────────┬──────────────────────────────┘
                                 │
                 ┌───────────────┴───────────────┐
                 ▼                               ▼
  ┌─────────────────────────────┐ ┌─────────────────────────────┐
  │   JSW_Backend (Node/Express)│ │   MSSQL Server (RJAIN)      │
  │   Port: 8080                │ │   DB: DB_Reporting_JSW      │
  │   - Live WebSocket Push     │ │   - Historical Traceability │
  │   - OEE & Quality Analytics │ │   - Weld Data & Part Marriage│
  └─────────────────────────────┘ └─────────────────────────────┘
```

---

## 2. Active Bridge Details
* **Gateway Status**: Online & Listening on **`http://localhost:8085`**
* **Telemetry Endpoint**: `POST http://localhost:8085/api/labview/weld-event`
* **Health Check**: `GET http://localhost:8085/health`

### Payload Structure Sent from LabVIEW:
```json
{
  "vin": "JSW-2026-X9921",
  "robotId": "ROBOT-WELD-04",
  "weldCurrentKA": 12.4,
  "status": "OK"
}
```

---

## 3. How to Connect Inside LabVIEW 2026

1. Open **LabVIEW 2026** (`C:\Program Files\National Instruments\LabVIEW 2026\LabVIEW.exe`).
2. Press `Ctrl + N` to create a **New VI**, then `Ctrl + E` to switch to the **Block Diagram**.
3. Right-click on the Block Diagram:
   - Navigate to **Data Communication ➔ Protocols ➔ HTTP Client**.
   - Drop the **`POST.vi`** onto the diagram.
4. Set the **URL** terminal to:
   ```txt
   http://localhost:8085/api/labview/weld-event
   ```
5. Set the **Headers** terminal to:
   ```txt
   Content-Type: application/json
   ```
6. Wire your sensor/test data cluster into **`Flatten To JSON.vi`** and connect it to the **Body** input of `POST.vi`.
7. Click **Run** in LabVIEW! The Gateway receives the data instantly and forwards it into the JSW MES system.
