
$progId = "LabVIEW.Application"
try {
    $lv = [System.Activator]::CreateInstance([System.Type]::GetTypeFromProgID($progId))
    if ($lv) {
        Write-Output "LabVIEW COM Server loaded successfully! Version: $($lv.Version)"
    } else {
        Write-Output "Could not create LabVIEW COM instance."
    }
} catch {
    Write-Output "LabVIEW COM Error: $($_.Exception.Message)"
}
