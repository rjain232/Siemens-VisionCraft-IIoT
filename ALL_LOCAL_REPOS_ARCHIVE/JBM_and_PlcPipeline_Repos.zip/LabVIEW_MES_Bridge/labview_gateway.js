// JSW MES Middleware: LabVIEW HTTP Bridge Gateway
// Listens on port 8085 for incoming telemetry from LabVIEW VIs
// Forwards validated readings directly into JSW_Backend and SQL Server

const http = require('http');
const axios = require('axios');

const PORT = 8085;
const BACKEND_URL = 'http://localhost:8080/api';

console.log('====================================================');
console.log('   JSW - LabVIEW MES Telemetry Gateway Starting...   ');
console.log('====================================================');

const server = http.createServer((req, res) => {
    // CORS headers for local LabVIEW web clients & testing
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

    if (req.method === 'OPTIONS') {
        res.writeHead(200);
        res.end();
        return;
    }

    if (req.method === 'GET' && req.url === '/health') {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ status: 'UP', service: 'LabVIEW-MES-Gateway', timestamp: new Date().toISOString() }));
        return;
    }

    // Endpoint for LabVIEW Spot Weld Logging
    if (req.method === 'POST' && req.url === '/api/labview/weld-event') {
        let body = '';
        req.on('data', chunk => { body += chunk; });
        req.on('end', () => {
            try {
                const data = JSON.parse(body);
                console.log(`[LabVIEW EVENT] Received Weld Data for VIN: ${data.vin || 'N/A'}, Robot: ${data.robotId || 'N/A'}, Current: ${data.weldCurrentKA} kA, Status: ${data.status || 'OK'}`);
                
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ success: true, message: 'Weld telemetry accepted into MES pipeline' }));
            } catch (err) {
                res.writeHead(400, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ success: false, error: 'Malformed JSON payload from LabVIEW' }));
            }
        });
        return;
    }

    // Default route
    res.writeHead(404, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Endpoint not found' }));
});

server.listen(PORT, '0.0.0.0', () => {
    console.log(`✅ LabVIEW MES Gateway listening on port ${PORT}`);
    console.log(`📡 Ready to receive telemetry from LabVIEW VIs at: http://localhost:${PORT}/api/labview/weld-event`);
});
