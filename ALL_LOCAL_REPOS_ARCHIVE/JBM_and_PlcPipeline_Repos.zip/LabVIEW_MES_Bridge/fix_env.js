
const fs = require('fs');

const envPaths = [
    'C:\\Program Files (x86)\\JSW_App\\backend\\.env',
    'C:\\Program Files (x86)\\JSW_App\\.env'
];

for (const p of envPaths) {
    if (fs.existsSync(p)) {
        let content = fs.readFileSync(p, 'utf8');
        content = content.replace(/DB_SERVER=.*/g, 'DB_SERVER=127.0.0.1');
        content = content.replace(/172\.20\.136\.209/g, '127.0.0.1');
        fs.writeFileSync(p, content, 'utf8');
        console.log(`Updated ${p} to DB_SERVER=127.0.0.1`);
    }
}
