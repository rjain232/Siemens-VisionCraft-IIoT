
const fs = require('fs');
let code = fs.readFileSync('src/app.js', 'utf8');

const targetReq = 'const subscriptionRoutes = require("./routes/subscriptionRoutes");';
const repReq = 'const subscriptionRoutes = require("./routes/subscriptionRoutes");\r\nconst cloudIotRoutes = require("./routes/cloudIotRoutes");';

const targetUse = 'app.use("/api/subscriptions", subscriptionRoutes);';
const repUse = 'app.use("/api/subscriptions", subscriptionRoutes);\r\napp.use("/api/cloud-iot", cloudIotRoutes);';

code = code.replace(targetReq, repReq);
code = code.replace(targetUse, repUse);

fs.writeFileSync('src/app.js', code, 'utf8');
console.log('Successfully mounted /api/cloud-iot in src/app.js');
