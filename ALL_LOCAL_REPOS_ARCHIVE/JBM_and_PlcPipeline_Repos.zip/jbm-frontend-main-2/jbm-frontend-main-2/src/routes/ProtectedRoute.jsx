// ProtectedRoute.js
import PropTypes from "prop-types";
import { Navigate } from "react-router-dom";

const ProtectedRoute = ({ isAuthenticated, children }) => {
  return isAuthenticated ? children : <Navigate to="/login" />;
};

ProtectedRoute.propTypes = {
  isAuthenticated: PropTypes.bool.isRequired, // Changed to `bool` to match the correct type
  children: PropTypes.node.isRequired,
};

export default ProtectedRoute;
