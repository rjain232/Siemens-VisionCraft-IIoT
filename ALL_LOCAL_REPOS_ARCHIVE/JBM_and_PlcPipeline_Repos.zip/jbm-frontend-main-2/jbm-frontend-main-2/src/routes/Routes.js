import { path } from "framer-motion/client";
import LazyLoader from "../utils/LazyLoader";

export const LoginRoute = {
  path: "/login",
  component: LazyLoader("LoginPage"),
};

export const LayoutRoute = {
  path: "/",
  component: LazyLoader("Layout"),
};

export const routesConfig = [
  { path: "oee", component: LazyLoader("OEE") },
 // { path: "line-status", component: LazyLoader("LineStatus") },
  { path: "robot-monitoring", component: LazyLoader("RobotMonitoring") },
  { path: "machine-setup", component: LazyLoader("MachineSetup") },
  { path: "production-control", component: LazyLoader("ProductionControl") },
  { path: "maintenance", component: LazyLoader("PredictiveAnalysis") },
  { path: "notifications", component: LazyLoader("Notification") },
  {path : "line-status" , component : LazyLoader("Safety")},
  {path : "power-consumption" , component : LazyLoader("PowerConsumption")},
  {path: "about", component: LazyLoader("About")}, // Added About route
  {path: "help", component: LazyLoader("Help")}, // Added Help route
];
