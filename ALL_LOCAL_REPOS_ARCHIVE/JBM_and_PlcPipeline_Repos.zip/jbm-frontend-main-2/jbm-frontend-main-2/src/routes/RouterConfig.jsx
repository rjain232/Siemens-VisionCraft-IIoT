import { Suspense } from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import { useAuthContext } from "../hooks/AuthContext"
import ProtectedRoute from "./ProtectedRoute";
import { routesConfig, LoginRoute, LayoutRoute } from "./Routes";
import { Loader } from "../common/components/Loader";

const RouterConfig = () => {
  const { isAuthenticated, login} = useAuthContext();

  return (
    <Suspense fallback={<Loader/>}>
      <Routes>
        {/* Login Route */}
        <Route
          path={LoginRoute.path}
          element={<LoginRoute.component onLogin={login} />}
        />
        {/* Protected Routes */}
        <Route
          path={LayoutRoute.path}
          element={
            isAuthenticated ? (
              <LayoutRoute.component/>
            ) : (
              <Navigate to={LoginRoute.path} replace />
            )
          }
        >
          {/* Nested Routes */}
          {routesConfig.map(({ path, component: Component }) => (
            <Route
              key={path}
              path={path}
              element={
                <ProtectedRoute isAuthenticated={isAuthenticated}>
                  <Component />
                </ProtectedRoute>
              }
            />
          ))}
        </Route>
        {/* Fallback for Unknown Routes */}
        <Route
          path="*"
          element={
            isAuthenticated ? (
              <Navigate to={LayoutRoute.path} replace />
            ) : (
              <Navigate to={LoginRoute.path} replace />
            )
          }
        />
      </Routes>
    </Suspense>
  );
};

export default RouterConfig;
