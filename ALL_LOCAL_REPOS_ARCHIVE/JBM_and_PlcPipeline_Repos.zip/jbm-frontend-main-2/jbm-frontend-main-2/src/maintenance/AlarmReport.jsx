import DateRangeSelector from "../common/components/DateRangeSelector ";
import withTable from "../hoc/withTable";
import DataTable from "../common/components/DataTable";
import useAxios from "../hooks/useAxios";
import { generate_TablePDF } from "../utils/PdfLib";
import {generateExcel} from "../utils/ExcelUtils";
import { format } from "date-fns";
import { useEffect, useState } from "react";
import { Loader } from "../common/components/Loader";
import Dropdown from "../common/components/Dropdown";
import { LineName } from "../utils/constants";

const columns_alarms = [
  { label: "Date", accessor: "Date" },
  { label: "Time", accessor: "Time" },
  {label : "Station" , accessor : "Station"},
  { label: "Alarm Reason", accessor: "AlarmReason" },
  { label: "Downtime (Sec)", accessor: "DownTime" },
];
const DEFAULT_STATION = "ML40";

const EnhancedTable_alarms = withTable(DataTable);
const AlarmReport = () => {
    const [selectedStation, setSelectedStation] = useState(DEFAULT_STATION);
     const [params, setParams] = useState({
      station: DEFAULT_STATION,
    });
    const {
      data: alarmreportData,
      loading: alarmreportDataLoading,
      error: alarmreportDataError,
      refetch: refetchalarmreportData,
    } = useAxios("/alarmreport", { method: "GET",params }, true);

   

    const {
      data: stations,
      loading: stationsLoading,
      error: stationsError,
      refetch: refetchStations,
    } = useAxios("/stations", { method: "GET" }, true);

 const [dateFilter, setDateFilter] = useState({
    startDate: null,
    endDate: null,
    duration: null,
    shift: null,
  });
  const [downloading, setDownloading] = useState(false);
  const downloadPDF = () => {
    setDownloading(true);
    generateExcel(columns_alarms, alarmreportData, `${LineName} ${selectedStation} Alarm Report`);
    generate_TablePDF(columns_alarms, alarmreportData, `${LineName} ${selectedStation} Alarm Report`,dateFilter);
    setDownloading(false);
  };

  const handleSearch = (startDate, endDate,duration,shift) => {
    setDateFilter({
      startDate,
      endDate,
      duration,
      shift,
    });
    refetchalarmreportData({
      params: {
        startDate: format(startDate, "yyyy-MM-dd HH:mm:ss"),
        endDate: format(endDate, "yyyy-MM-dd HH:mm:ss"),
        station:selectedStation
      },
    });
  };

    useEffect(() => {
      setParams((prev) => ({
        ...prev,
        startDate: dateFilter?.startDate,
        endDate: dateFilter?.endDate,
        station: selectedStation,
      }));
    }, [selectedStation]);
 
  if(alarmreportDataError){
    return <div>Error in fetching data ... </div>
  }

  return (
    <>
     
        <DateRangeSelector
         onDownload={downloadPDF}
          onSearch={handleSearch} 
          selectedStartDate={dateFilter?.startDate}
          selectedEndDate={dateFilter?.endDate} 
          isDownloading={downloading}
          />
         <div className="mb-4">
             <Dropdown
               options={
                 stations?.map((station) => ({
                   value: station.StationName,
                   label: station.StationName,
                 })) ?? []
               }
               selectedValue={selectedStation}
               placeholder={"Select Station"}
               onChange={(val) => {
                 setSelectedStation(val);
               }}
               justify={"start"}
             />
           </div>

        {alarmreportDataLoading && (
          <div><Loader/></div>
        )}

        {!alarmreportDataLoading && (
          <EnhancedTable_alarms
            data={alarmreportData}
            columns={columns_alarms}
            enableSearch={true}
            enableFilter={false}
            enablePagination={true}
          />
        )}
     
    </>
  );
};
export default AlarmReport;
