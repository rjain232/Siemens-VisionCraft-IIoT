import jsPDF from "jspdf";
import withTable from "../hoc/withTable";
import axiosInstance from "../common/axioInstance/AxioInstance";
import DataTable from "../common/components/DataTable";
import DateRangeSelector from "../common/components/DateRangeSelector ";
import DropdwonTools from "../common/components/DropdownTools";
import { useCallback, useEffect, useMemo, useState } from "react";
import {generateExcel} from "../utils/ExcelUtils";
import { generatePDF } from "../utils/PdfLib";
import useAxios from "../hooks/useAxios";
import Button from "../common/components/Button";
import ModalHOC from "../hoc/ModalHOC"
import AddActivityForm from "./AddActivityForm";
import { PlusIcon } from "lucide-react";

const EnhancedTable = withTable(DataTable);

const TDMTools = ({ toolSelected ,changeTool}) => {
  const [rowState, setRowState] = useState({});
  const [reportBy, setReportBy] = useState("");
  const [showAddActivityForm , setShowAddActivityForm] = useState(false)
  const [isLastWeekPending, setIsLastWeekPending] = useState(false);

  const {
    data: activityData,
    loading: isActivityDataLoading,
    error: isActivityDataError,
    refetch: refetchActivities,
  } = useAxios(
    "/getActivities",
    { method: "GET", params: { toolId: toolSelected.value } },
    true
  );
  //  console.log("activityData", activityData);
  const {
    refetch: postToolActivity,
    loading: isSubmitting,
    error: submitError,
  } = useAxios(
    "/updateTool_Maintenance",
    { method: "POST", data: [] }, 
    false 
  );

  const changeFormVisibility = () =>{
      setShowAddActivityForm(!showAddActivityForm)
  }

  const handleRemarkChange = useCallback((id, value) => {
    setRowState((prev) => ({
      ...prev,
      [id]: { ...prev[id], remark: value },
    }));
  }, []);

  const handleCheckboxChange = useCallback((id, checked) => {
    setRowState((prev) => ({
      ...prev,
      [id]: { ...prev[id], checked },
    }));
  }, []);

  const handleReportByChange = useCallback((e) => {
    const value = e.target.value;
    ///console.log("value", value);
    setReportBy(value);
  }, []);

  const columns = useMemo(
    () => [
      {
        label: "Activity",
        accessor: "Activity",
      },
      {
        label: "Action",
        accessor: "Action",
        cellRenderer: (row) => (
          <input
            type="checkbox"
            checked={rowState[row.Id]?.checked || false}
            onChange={(e) => handleCheckboxChange(row.Id, e.target.checked)}
          />
        ),
      },
      {
        label: "Remark",
        accessor: "Remarks",
        cellRenderer: (row) => (
          <input
            type="text"
            className="form-control border border-gray-400 p-2 rounded-md w-full"
            value={rowState[row.Id]?.remark || ""}
            placeholder="Enter Remark"
            onChange={(e) => handleRemarkChange(row.Id, e.target.value)}
          />
        ),
      },
    ],
    [rowState, handleCheckboxChange, handleRemarkChange]
  );
  
  
  const handleToolChange = (e) => {
    changeTool({
      value: e.target.value, // Store value
      text: e.target.options[e.target.selectedIndex].text, // Store visible text
    });

  };
  useEffect(() => {
    const currentDate = new Date();
  
    const hasPending = activityData?.some((activity) => {
      const uptoSchedule = activity.Upto_Schedule ? new Date(activity.Upto_Schedule) : null;
      return uptoSchedule && uptoSchedule <= currentDate;
    });
    setIsLastWeekPending(hasPending);
  }, [activityData]);
  

  const handleGenerateReportClick = async() => {
    //#region Insert in table
    if (!reportBy.trim()) {
      alert("Please enter the name before generating the report."); // You can use a toast instead of alert
      return;
    }
    
    const filteredData = activityData
    .filter((item) => rowState[item.Id]?.checked) // Only checked items
    .map((item) => ({
      ToolId: toolSelected.value,
      Activity: item.Activity,
      Action: 1,
      Remark: rowState[item.Id]?.remark || "",
      reportBy:reportBy,
    }));

    //console.log("Submited Report Data:", filteredData);
    if (filteredData.length === 0) {
      alert("Please select at least one activity to generate the report.");
      return;
    }
    const response = await postToolActivity({
      data: filteredData,
    });
   // console.log("Submitted Successfully:", response?.success);
    
    if (response?.success) {
      //console.log("Submitted Successfully:", response);
      refetchActivities();
      setReportBy("");
      // Optionally show a toast or success message
    }
    //#endregion
   

     //#region Downloadtool Activity report
     // const tableColumn = [
    //   { label: "Activity Name", accessor: "Activity" },
    //   { label: "Action", accessor: "Checked" },
    //   { label: "Remark", accessor: "Remark" },
    // ];
    // const data = activityData.map((item) => ({
    //   Activity: item.Activity,
    //   Checked: rowState[item.Id]?.checked ? "Done" : "Not Done",
    //   Remark: rowState[item.Id]?.remark || "-",
    // }));
    // generatePDF(tableColumn, data, `${toolSelected.text} Tool Maintenance Report`);
    // generateExcel(tableColumn, data, `${toolSelected.text} Maintenance Report`);
     //#endregion
  };

  return (
    <>
    <div className="mt-4">
      <div className="flex items-center justify-between space-x-4">
        <div className="flex items-center space-x-4">
        <DropdwonTools value={toolSelected} onChange={handleToolChange} />
        <span className="text-lg font-semibold text-gray-700">
          Selected Tool: {toolSelected.text}  
              {isLastWeekPending && (
                <span className="text-red-500 font-semibold"> Last week pending activity</span>
              )}
        </span>
        </div>
        <div>
          <Button label="Add Activities" onClick={changeFormVisibility} icon={PlusIcon}></Button>
        </div>
      </div>

      {isActivityDataLoading ? (
        <>Loading ...</>
      ) : (
        <div className="mt-6">
          {toolSelected && activityData?.length > 0 ? (
            <>
              <EnhancedTable
                data={activityData}
                columns={columns}
                enableSearch={false}
                enableFilter={false}
                enablePagination={true}
              />
              <div className="mt-4 flex justify-between items-center">
                <span className="text-lg font-semibold text-gray-700">
                  Name:
                  <input
                    type="text"
                    className="ml-2 px-2 py-1 border border-gray-300 rounded-md"
                    placeholder="Enter Name"
                    onChange={handleReportByChange}
                  />
                </span>

                <button
                  onClick={handleGenerateReportClick}
                  className="bg-blue-500 text-white py-2 px-4 rounded"
                >
                  Generate Report
                </button>
              </div>
            </>
          ) : (
            <p className="text-gray-500 mt-2">
              {toolSelected
                ? "No activities found for the selected tool."
                : "Select a tool to view activities."}
            </p>
          )}
        </div>
      )}
    </div>

    <ModalHOC isOpen={showAddActivityForm} onClose={changeFormVisibility}>
      <AddActivityForm />
    </ModalHOC>
    </>
  );
};

export default TDMTools;
