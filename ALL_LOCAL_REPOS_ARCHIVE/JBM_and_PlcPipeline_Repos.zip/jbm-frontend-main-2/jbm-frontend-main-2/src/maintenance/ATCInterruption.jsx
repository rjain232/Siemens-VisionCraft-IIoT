import DataTable from "../common/components/DataTable";
import DateRangeSelector from "../common/components/DateRangeSelector ";
import withTable from "../hoc/withTable";
import useAxios from "../hooks/useAxios";
import { format } from "date-fns";
import { generate_TablePDF } from "../utils/PdfLib";
import {generateExcel} from "../utils/ExcelUtils";
import { useState } from "react";
import { LineName } from "../utils/constants";
const columns = [
  {
    label: "Robot ID",
    accessor: "deviceId",
  },
  {
    label: "Date",
    accessor: "date",
  },
  {
    label: "Time",
    accessor: "time",
  },
];

const EnhancedTable = withTable(DataTable);

const ATCInterruption = () => {
  const {
    data: atcinterruptionData,
    loading: atcinterruptionDataLoading,
    error: atcinterruptionDataError,
    refetch: refetchatcinterruptionData,
  } = useAxios("/atcinterruption", { method: "GET" }, true);
  //Done by Arshiya
  const formattedData = atcinterruptionData?.map((item) => ({
    ...item,
    date: item.date ? format(new Date(item.date), "dd-MM-yyyy") : "",
  })) ?? [];

  const [dateFilter, setDateFilter] = useState({
    startDate: null,
    endDate: null,
    duration: null,
    shift: null,
  });
  const handleSearch = (startDate, endDate) => {
    setDateFilter({
      startDate,
      endDate,
      //duration,
      // shift,
    });
    refetchatcinterruptionData({
      params: {
        startDate: format(startDate, "yyyy-MM-dd HH:mm:ss"),
        endDate: format(endDate, "yyyy-MM-dd HH:mm:ss"),
      },
    });
  };
  const [downloading, setDownloading] = useState(false);

  const handleDownload = async() => {
    setDownloading(true);
    generate_TablePDF(columns, formattedData, `${LineName} ATC Interruption`, dateFilter);
    generateExcel(columns, formattedData, `${LineName} ATC Interruption`);
    new Promise((resolve) => setTimeout(resolve, 10)).then(() => {
      setDownloading(false);
    });
    
  };

  if (atcinterruptionDataError) {
    return <div>Error in fetching data ....</div>;
  }

  return (
    <div>
      <DateRangeSelector
        onDownload={handleDownload}
        onSearch={handleSearch}
        selectedStartDate={dateFilter?.startDate}
        selectedEndDate={dateFilter?.endDate}
        isDownloading={downloading} />
      {!atcinterruptionDataLoading && (
        <EnhancedTable
          data={formattedData}
          columns={columns}
          enableSearch={true}
          enableFilter={false}
          enablePagination={true}
        />
      )}
    </div>
  );
};

export default ATCInterruption;
