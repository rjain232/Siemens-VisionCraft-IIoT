import DateRangeSelector from "../common/components/DateRangeSelector ";
import BarGraphSafetyAlarm from "../common/testexperiments/BarGraphSafetyAlarm";
import useAxios from "../hooks/useAxios";
import { useState } from "react";
import { format } from "date-fns";
import { generatePDF } from "../utils/PdfLib";
import {generateExcel} from "../utils/ExcelUtils";
import {
  addGlobalStylesForPDF,
  addPageNumber,
  cleanupChartStyles,
  pageFooterFormat,
  pageHeadFormat,
  renderChartToPDF,
  reportFromToShiftHeaders,
} from "../utils/PdfLib";
import { useRef } from "react";
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";
import { LineName } from "../utils/constants";
const Top10Alarms = () => {
     const[dateFilter,setDateFilter] = useState({
           startDate: null,
           endDate: null,
        //    duration: null,
        //    shift: null,    
       });
    const {
        data: alarmData=[],
        loading: Top10AlarmDataLoading,
        error: Top10AlarmDataError,
        refetch: refetchTop10AlarmData,
      } = useAxios("/top10alarms", { method: "GET"},true);

       //console.log("at api alarmData--",alarmData)
       const columns_alarms = [
        { label: "Count", accessor: "count" },
        { label: "Time(sec)", accessor: "time" },
        { label: "Code", accessor: "Code" },
        {label:"Alarm Description" , accessor:"Description"}
      ];

  // References for your charts
  const chart1Ref = useRef(null);
  // const chart2Ref = useRef(null);
  // const chart3Ref = useRef(null);
  const [downloading, setDownloading] = useState(false);

  const exportPdfAlarmLogReport = async () => {
    const doc = new jsPDF();
    const chartRefs = [chart1Ref];
    reportFromToShiftHeaders(doc, dateFilter);
    addGlobalStylesForPDF();
    chartRefs.forEach((ref) => ref.current?.classList.add("pdf-export"));
    let yOffset = 50;
    await renderChartToPDF(doc, chartRefs, yOffset);
    pageHeadFormat(doc, `${LineName} Top 10 Alarms`, false);

    doc.addPage();
    await generatePDF(doc, columns_alarms, alarmData, `${LineName} Top 10 Alarms`);
    cleanupChartStyles(chartRefs);
    doc.save(`${LineName}_Top_10_Alarms_Report.pdf`);
  };
    const handleDownload = () => {       
        try {
          setDownloading(true);
          generateExcel(columns_alarms, alarmData, `${LineName} Top 10 Alarms`)
    
          exportPdfAlarmLogReport().then(() => {
            setDownloading(false);
          });
        }
        catch (error) {
         // console.log(error);
        };
    };
  const handleSearch = (
      startDate,
      endDate,
    ) => {
      setDateFilter({
        startDate,
        endDate,
       
      });
      refetchTop10AlarmData({
        params: {
          startDate: startDate
            ? format(new Date(startDate), "yyyy-MM-dd HH:mm:ss")
            : null,
          endDate: endDate ? format(endDate, "yyyy-MM-dd HH:mm:ss") : null,
         
        },
      });
    }; 
    return (
        <>
            <div>
                <DateRangeSelector showDownload={true}
                    onDownload={handleDownload}
                    onSearch={handleSearch}
                    showDate={true}
                    showShift={true}
                    activeTab={"Top 10 Alarms"}
                    selectedStartDate={dateFilter?.startDate}
                    selectedEndDate={dateFilter?.endDate}
                    isDownloading={downloading}
                    />
                {!Top10AlarmDataLoading && 
                <div ref={chart1Ref}>
                <BarGraphSafetyAlarm Top10alarmData={alarmData} />
                </div>
                }
            </div>
        </>

    );
};
export default Top10Alarms;