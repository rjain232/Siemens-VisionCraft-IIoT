import React, { useState } from "react";
import useAxios from "../hooks/useAxios";

const tools = [
  { value: "", label: "Select Tool" },
  { value: "tool1", label: "Tool 1" },
  { value: "tool2", label: "Tool 2" },
  { value: "tool3", label: "Tool 3" },
];

const AddActivityForm = () => {
  const { data, loading, error, refetch } = useAxios(
    "/upload", // endpoint (no need for full URL if axiosInstance is configured)
    { method: "POST" },
    false // fetchOnMount = false
  );
  const [form, setForm] = useState({
    tool: "",
    activityName: "",
    file: null,
  });
  const [errorMsg, setErrorMsg] = useState("");

  const MAX_FILE_SIZE_MB = 5;

  const handleChange = (e) => {
    const { name, value, files } = e.target;
    setErrorMsg("");
    if (files) {
      const file = files[0];
      const validTypes = [
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "application/vnd.ms-excel",
      ];
      const maxSize = MAX_FILE_SIZE_MB * 1024 * 1024;

      if (!validTypes.includes(file.type)) {
        setErrorMsg("Only Excel files (.xls, .xlsx) are allowed.");
        return;
      }

      if (file.size > maxSize) {
        setErrorMsg(`File must be smaller than ${MAX_FILE_SIZE_MB}MB.`);
        return;
      }

      setForm((prev) => ({
        ...prev,
        [name]: file,
      }));
    } else {
      setForm((prev) => ({
        ...prev,
        [name]: value,
      }));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle form submission logic here
    //console.log(form);
  };

  const handleUpload = async () => {
    if (!form.file) return alert("Please select a file.");

    //console.log("form.file", form.file.name);

    const formData = new FormData();
    formData.append("file", form.file);

    const response = await refetch({
      data: formData,
      headers: {
        "Content-Type": "multipart/form-data",
      },
    });

    //console.log("Uploaded Excel Data:", response);
  };

  return (
    <form className="max-w-md mx-auto space-y-6" onSubmit={handleSubmit}>
      <h4 className="text-center text-lg font-semibold">Add Activity</h4>
      {/* <div>
                
                <label className="block mb-2 text-sm font-medium text-gray-700">
                    Tool
                </label>
                <select
                    name="tool"
                    value={form.tool}
                    onChange={handleChange}
                    className="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                >
                    {tools.map((tool) => (
                        <option key={tool.value} value={tool.value}>
                            {tool.label}
                        </option>
                    ))}
                </select>
            </div>

            <div>
                <label className="block mb-2 text-sm font-medium text-gray-700">
                    Activity Name
                </label>
                <input
                    type="text"
                    name="activityName"
                    value={form.activityName}
                    onChange={handleChange}
                    className="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Enter activity name"
                    required
                />
            </div> */}

      <div>
        <label className="block mb-2 text-sm font-medium text-gray-700">
          Upload Excel File
        </label>
        <input
          type="file"
          name="file"
          accept=".xlsx, .xls"
          onChange={handleChange}
          className="block w-full text-sm text-gray-700 file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
          required
        />
      </div>
      {errorMsg && <p style={{ color: "red" }}>{errorMsg}</p>}
      {error && <p style={{ color: "red" }}>Error uploading file.</p>}
      {data?.status && <p style={{ color: "green" }}>{data?.message}</p>}

      <div className="flex">
        <button
          type="submit"
          className="w-full bg-purple-950 text-white py-2 rounded hover:opacity-80 transition"
          onClick={handleUpload}
        >
          {loading ? "Uploading..." : "Upload Excel"}
        </button>
      </div>
    </form>
  );
};

export default AddActivityForm;
