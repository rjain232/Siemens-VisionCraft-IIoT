import withTable from "../hoc/withTable";
import DataTable from "../common/components/DataTable";
import DateRangeSelector from "../common/components/DateRangeSelector ";
import useAxios from "../hooks/useAxios";
import { format } from "date-fns";
import { generate_TablePDF } from "../utils/PdfLib";
import { generateExcel } from "../utils/ExcelUtils";
import { useState } from "react";
import { LineName } from "../utils/constants";
const columns = [
  {
    label: "Timestamp",
    accessor: "timestamp",
  },
  {
    label: "Alarm Name",
    accessor: "alarmname",
  },
  {
    label: "Alarm Description",
    accessor: "alarmdescription",
  },
];

const EnhancedTable = withTable(DataTable);

const MiscellaneousAlarms = () => {
  const {
    data: miscellaneousAlarmsData,
    loading: miscellaneousAlarmsDataLoading,
    error: miscellaneousAlarmsDataError,
    refetch: refetchmiscellaneousAlarmsData,
  } = useAxios("/miscellaneousAlarms", { method: "GET" }, true);
  //console.log("miscellaneousAlarmsData==",miscellaneousAlarmsData);
  
  //Done by Arshiya
  const formattedData = miscellaneousAlarmsData?.map((item) => ({
    ...item,
    timestamp: item.timestamp
      ? format(new Date(item.timestamp), "dd-MM-yyyy   HH:mm:ss")
      : "",
  })) ?? [];



  const [dateFilter, setDateFilter] = useState({
    startDate: null,
    endDate: null,
    // duration: null,
    // shift: null,
  });
  const handleSearch = (startDate, endDate) => {
    setDateFilter({
      startDate,
      endDate,

    });
    refetchmiscellaneousAlarmsData({
      params: {
        startDate: format(startDate, "yyyy-MM-dd HH:mm:ss"),
        endDate: format(endDate, "yyyy-MM-dd HH:mm:ss"),
      },
    });
  };
  const [downloading, setDownloading] = useState(false);
  const handleDownload = () => {
    setDownloading(true)
    generateExcel(columns, formattedData, `${LineName} Misc Alarms`);
    generate_TablePDF(columns, formattedData, `${LineName} Miscellaneous Alarms Report`, dateFilter);
    setDownloading(false)
  };

  if (miscellaneousAlarmsDataError) {
    return <div>Error in fetching data ....</div>;
  }

  return (
    <div>
      <DateRangeSelector
        onDownload={handleDownload}
        onSearch={handleSearch}
        selectedStartDate={dateFilter?.startDate}
        selectedEndDate={dateFilter?.endDate}
        isDownloading={downloading}
      />
      {!miscellaneousAlarmsDataLoading && (
        <EnhancedTable
          data={formattedData}
          columns={columns}
          enableSearch={true}
          enableFilter={false}
          enablePagination={true}
        />
      )}
    </div>
  );
};

export default MiscellaneousAlarms;
