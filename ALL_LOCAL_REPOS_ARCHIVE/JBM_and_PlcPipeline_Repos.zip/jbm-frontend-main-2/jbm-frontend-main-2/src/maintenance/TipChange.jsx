import { useState } from "react";
import DateRangeSelector from "../common/components/DateRangeSelector ";
import BarGraphTipChange from "../common/testexperiments/BarGraphTipChange";
import TipChangeCount from "../common/testexperiments/TipChangeCount";
import useAxios from "../hooks/useAxios";
import { format } from "date-fns";
import { generatePDF } from "../utils/PdfLib";
import { generateExcel } from "../utils/ExcelUtils";
import {
  addGlobalStylesForPDF,
  addPageNumber,
  cleanupChartStyles,
  pageFooterFormat,
  pageHeadFormat,
  renderChartToPDF,
  reportFromToShiftHeaders,
} from "../utils/PdfLib";
import { useRef } from "react";
import { jsPDF } from "jspdf";
import { LineName } from "../utils/constants";

const tipChangeCountDataColumns = [
  {
    label: "Timestamp",
    accessor: "timestamp",
  },
  {
    label: "Robot Id",
    accessor: "robotid",
  },
  {
    label: "Tip Change Count",
    accessor: "tipchangecount",
  },
];

const TipChange = () => {
  const [dateFilter, setDateFilter] = useState({
    startDate: null,
    endDate: null,
    duration: null,
    shift: null,
  });
  const {
    data: tipchangecountData,
    loading: tipchangecountLoading,
    error: tipchangecountDataError,
    refetch: refetchtipchangecountData,
  } = useAxios("/tipchangecount", { method: "GET" }, true);

  const formattedData =
    tipchangecountData?.Tip_ChangeCount_Table?.map((item) => ({
      ...item,
      timestamp: item.timestamp
        ? format(new Date(item.timestamp), "dd-MM-yyyy")
        : "",
    })) ?? [];

  const handleSearch = (startDate, endDate) => {
    setDateFilter({
      startDate,
      endDate,
    });
    refetchtipchangecountData({
      params: {
        startDate: startDate
          ? format(new Date(startDate), "yyyy-MM-dd HH:mm:ss")
          : null,
        endDate: endDate ? format(endDate, "yyyy-MM-dd HH:mm:ss") : null,
      },
    });
  };
  const chart1Ref = useRef(null);
  // const chart2Ref = useRef(null);
  // const chart3Ref = useRef(null);
  const [downloading, setDownloading] = useState(false);

  const exportPdfTipchangeReport = async () => {
    const doc = new jsPDF();
    const chartRefs = [chart1Ref];
    reportFromToShiftHeaders(doc, dateFilter);
    addGlobalStylesForPDF();
    chartRefs.forEach((ref) => ref.current?.classList.add("pdf-export"));
    let yOffset = 50;
    await renderChartToPDF(doc, chartRefs, yOffset);
    pageHeadFormat(doc, `${LineName} Tip Change Report`, false);

    doc.addPage();
    // await generatePDF(doc, tipChangeCountDataColumns, tipchangecountData?.Tip_ChangeCount_Table, "Tip Change Report");
    await generatePDF(
      doc,
      tipChangeCountDataColumns,
      formattedData,
      `${LineName} Tip Change Report`,
    );
    cleanupChartStyles(chartRefs);
    doc.save(`${LineName}_Tip_Change_Report.pdf`);
  };
  const handleDownload = () => {
    try {
      setDownloading(true);
      // generateExcel(tipChangeCountDataColumns, tipchangecountData?.Tip_ChangeCount_Table, "Tip Change Report");
      generateExcel(
        tipChangeCountDataColumns,
        formattedData,
        `${LineName}_Tip_Change_Report`,
      );

      exportPdfTipchangeReport().then(() => {
        setDownloading(false);
      });
    } catch (error) {
      //console.log(error);
    }
  };
  // console.log("at api tipchangecount--", tipchangecountData);
  return (
    <>
      <div>
        <DateRangeSelector
          onDownload={handleDownload}
          onSearch={handleSearch}
          showDate={true}
          showShift={true}
          activeTab={"Tipchangecount"}
          selectedStartDate={dateFilter?.startDate}
          selectedEndDate={dateFilter?.endDate}
          isDownloading={downloading}
        />
        {tipchangecountLoading && (
          <div className="flex justify-center items-center h-64">
            <p className="text-gray-500 text-lg">Loading...</p>
          </div>
        )}
        <div ref={chart1Ref} className="mb-6">
          {!tipchangecountLoading && (
            <BarGraphTipChange
              tipchangedata={tipchangecountData?.Tip_ChangeCount_Bar_Data}
            />
          )}
        </div>
        {!tipchangecountLoading && (
          <TipChangeCount tipchangedata={formattedData} />
        )}
      </div>
    </>
  );
};
export default TipChange;
