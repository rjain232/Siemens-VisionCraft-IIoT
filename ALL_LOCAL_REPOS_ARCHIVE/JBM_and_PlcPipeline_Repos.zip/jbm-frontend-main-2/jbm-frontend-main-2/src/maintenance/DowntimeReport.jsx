import withTable from "../hoc/withTable";
import DataTable from "../common/components/DataTable";
import DateRangeSelector from "../common/components/DateRangeSelector ";
import Dropdown from "../common/components/Dropdown";
import { useCallback, useEffect, useState } from "react";
import BarGraphDowntime from "../common/testexperiments/BarGraphDowntime";
import useAxios from "../hooks/useAxios";
import { generatePDF } from "../utils/PdfLib";
import { generateExcel } from "../utils/ExcelUtils";
import { format } from "date-fns";
import {
  addGlobalStylesForPDF,
  addPageNumber,
  cleanupChartStyles,
  pageFooterFormat,
  pageHeadFormat,
  renderChartToPDF,
  reportFromToShiftHeaders,
} from "../utils/PdfLib";
import { useRef } from "react";
import { jsPDF } from "jspdf";
import { Loader } from "../common/components/Loader";
import { LineName } from "../utils/constants";

const DEFAULT_STATION = "ML40";

const EnhancedTable_DownTime = withTable(DataTable);
const DowntimeReport = () => {
  const [selectedStation, setSelectedStation] = useState(DEFAULT_STATION);
  const [remarks, setRemarks] = useState({});
  const [params, setParams] = useState({
    station: DEFAULT_STATION,
  });

  const {
    data: stations,
    loading: stationsLoading,
    error: stationsError,
    refetch: refetchStations,
  } = useAxios("/stations", { method: "GET" }, true);

  const {
    data: data,
    loading: alarmsLoading,
    error: alarmsDataError,
    refetch: refetchalarmsData,
  } = useAxios("/alarms", { method: "GET", params }, true);

  const columns_DT = [
    { label: "Date", accessor: "Date" },
    { label: "Start Time", accessor: "StartTime" },
    { label: "End Time", accessor: "EndTime" },
    { label: "Station", accessor: "Station" },
    { label: "Fault Code", accessor: "AlarmCode" },
    { label: "Alarm Reason", accessor: "AlarmReason" },
    { label: "Downtime (Sec)", accessor: "DownTime" },
    {
      label: "Remark",
      accessor: "remark",
      cellRenderer: (row) => (
        <input
          type="text"
          className="form-control border border-gray-400 p-2 rounded-md w-full"
          value={remarks[row.Id]?.remark || ""}
          placeholder="Enter Remark"
          onChange={(e) => handleRemarkChange(row.Id, e.target.value)}
        />
      ),
    },
  ];
  const [dateFilter, setDateFilter] = useState({
    startDate: null,
    endDate: null,
    // duration: null,
    // shift: null,
  });
  // console.log("data", data);
  const formattedData =
    data?.Downtime_Table_Report?.map((item) => {
      const dateTime = new Date(`${item.ProductionDate} ${item.Time}`);

      return {
        Id: item.Id,
        Date: !isNaN(dateTime) ? format(dateTime, "dd-MM-yyyy") : "-",
        // StartTime: !isNaN(new Date(item?.StartTime)) ? format(new Date(item?.StartTime), "HH:mm:ss") : "-",
        // EndTime: !isNaN(new Date(item?.EndTime)) ? format(new Date(item?.EndTime), "HH:mm:ss") : "-",
        StartTime: item?.StartTime.split("T")[1]?.split(".")[0] || "-",
        EndTime: item?.EndTime.split("T")[1]?.split(".")[0] || "-",
        Station: item.Station,
        AlarmCode: item.AlarmCode,
        AlarmReason: item.AlarmReason,
        DownTime: item.DownTime,
        remark: remarks[item.Id]?.remark || "-",
      };
    }) ?? [];

  const handleSearch = (startDate, endDate) => {
    setDateFilter({
      startDate,
      endDate,
    });
    refetchalarmsData({
      params: {
        startDate: startDate
          ? format(new Date(startDate), "yyyy-MM-dd HH:mm:ss")
          : null,
        endDate: endDate ? format(endDate, "yyyy-MM-dd HH:mm:ss") : null,
        station: selectedStation,
      },
    });
    // console.log("startDate endDate==", startDate, endDate);
  };
  // References for your charts
  const chart1Ref = useRef(null);
  // const chart2Ref = useRef(null);
  // const chart3Ref = useRef(null);
  const [downloading, setDownloading] = useState(false);

  const exportPdfDowntimeLogReport = async () => {
    const doc = new jsPDF();
    const chartRefs = [chart1Ref];
    reportFromToShiftHeaders(doc, dateFilter);
    addGlobalStylesForPDF();
    chartRefs.forEach((ref) => ref.current?.classList.add("pdf-export"));
    let yOffset = 50;
    await renderChartToPDF(doc, chartRefs, yOffset);
    pageHeadFormat(doc, `${LineName} ${data?.station} Downtime Report`, false);

    doc.addPage();
    await generatePDF(doc, columns_DT, formattedData, `${LineName} ${data?.station} Downtime Report`);
    cleanupChartStyles(chartRefs);
    doc.save(`${LineName} ${data?.station} Downtime Report`);
  };
  const handleDownload = () => {
    try {
      setDownloading(true);
      generateExcel(columns_DT, formattedData, `${LineName} ${data?.station} Downtime Report`);

      exportPdfDowntimeLogReport().then(() => {
        setDownloading(false);
      });
    } catch (error) {
      //console.log(error);
    }
  };

  const handleRemarkChange = useCallback((id, value) => {
    setRemarks((prev) => ({
      ...prev,
      [id]: { ...prev[id], remark: value },
    }));
  }, []);

  useEffect(() => {
    setParams((prev) => ({
      ...prev,
      startDate: dateFilter?.startDate,
      endDate: dateFilter?.endDate,
      station: selectedStation,
    }));
  }, [selectedStation]);
  //console.log("data?.Downtime_Table_Report", data?.Downtime_Table_Report)

  return (
    <div className="pt-2">
      <DateRangeSelector
        showDownload={true}
        onDownload={handleDownload}
        onSearch={handleSearch}
        showDate={true}
        showShift={true}
        activeTab={"Downtime Report"}
        selectedStartDate={dateFilter?.startDate}
        selectedEndDate={dateFilter?.endDate}
        isDownloading={downloading}
      />
      <div className="mb-4">
        <Dropdown
          options={
            stations?.map((station) => ({
              value: station.StationName,
              label: station.StationName,
            })) ?? []
          }
          selectedValue={selectedStation}
          placeholder={"Select Station"}
          onChange={(val) => {
            setSelectedStation(val);
          }}
          justify={"start"}
        />
      </div>
      {alarmsDataError ? (
        <div className="text-red-600">Error loading data</div>
      ) : alarmsLoading ? (
        <div>
          <Loader />
        </div>
      ) : (
        <div className="pt-1">
          <div ref={chart1Ref} className="mb-6">
            <BarGraphDowntime
              top10Alarm={data?.Downtime_Bar_Data}
              title={`Downtime Overview [ ${data?.station} ]`}
            />
          </div>
          <EnhancedTable_DownTime
            // data={
            //   filter.key !== "" && filter.value.length > 0
            //     ? filter.value
            //     : data?.Downtime_Table_Report || [] // Fallback to empty array
            // }
            data={formattedData}
            columns={columns_DT}
            enableSearch={true}
            enableFilter={false}
            enablePagination={true}
          />
        </div>
      )}
    </div>
  );
};

export default DowntimeReport;
