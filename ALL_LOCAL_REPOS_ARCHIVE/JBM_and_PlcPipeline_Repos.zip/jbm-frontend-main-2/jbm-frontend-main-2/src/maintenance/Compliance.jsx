import React, { useState } from "react";
import Chart from "react-apexcharts";
import ChartCard from "../common/testexperiments/ChartCard";
import { ClipboardCheck, ClipboardPlus, ClipboardX } from "lucide-react";
import ToolsComplianceBarGraph from "../common/testexperiments/ToolsComplianceBarGraph";
import ModalHOC from "../hoc/ModalHOC";
import withTable from "../hoc/withTable";
import DataTable from "../common/components/DataTable";
import PropTypes from "prop-types";
import useAxios from "../hooks/useAxios";

const EnhancedTable = withTable(DataTable);
const Compliance = ({ changeTool, changeTab }) => {
  const [pendingActivitiesOpen, setPendingActivitiesOpen] = useState(false);
  const {
    data: complianceData,
    loading: complianceDataLoading,
    error: complianceDataError,
  } = useAxios("/complianceData", { method: "GET" }, true);

  const chartOptions = {
    chart: {
      type: "pie",
      events: {
        dataPointSelection: (event, chartContext, config) => {
          const clickedIndex = config.dataPointIndex;
          handleClick(clickedIndex);
        },
      },
    },
    labels: ["Completed Activities", "Pending Activities"],
    colors: ["#00893D", "#A12E2D"],
    legend: {
      position: "bottom",
      markers: {
        radius: 4,
      },
    },
    dataLabels: {
      enabled: true,
      formatter: (val, opts) => opts.w.config.series[opts.seriesIndex],
    },
    tooltip: {
      theme: "light",
      style: {
        fontSize: "14px",
        backgroundColor: "#ffffff",
        color: "#000000",
      },
    },
  };

  const handleClick = (index) => {
    if (index === 0) {
      handleCompletedClick();
    } else if (index === 1) {
     // console.log("Pending clicked");
      handlePendingClick();
    }
  };

  const handleCompletedClick = () => {
    // alert("Completed portion clicked!");
  };

  const handlePendingClick = () => {
    setPendingActivitiesOpen(true);
  };

  const handlePendingToolSelected = (value) => {
    changeTool({
      value: value.ToolId,
      text: value.ToolName,
    });
    changeTab("TDM Tools");
    setPendingActivitiesOpen(false);
  };
  if (complianceDataError) {
    return <div>Error in fetching data ...</div>;
  }

  return (
    !complianceDataLoading && (
      <>
        <div className="grid grid-cols-3 gap-4 w-full mb-4 mt-2">
          <StatCard
            icon={ClipboardPlus}
            title={"Total Activities"}
            value={complianceData?.activitiesCount?.TotalActivities}
          ></StatCard>
          <StatCard
            icon={ClipboardCheck}
            title={"Completed Activities"}
            value={complianceData?.activitiesCount?.ActivitiesPerformed}
          ></StatCard>
          <StatCard
            icon={ClipboardX}
            title={"Pending Activities"}
            value={complianceData?.activitiesCount?.ActivitiesToBeCompleted}
          ></StatCard>
        </div>
        <div className="flex flex-row gap-4">
          <div>
            <ChartCard title="Compliance Ratio">
              <Chart
                options={chartOptions}
                series={complianceData?.chartSeries}
                type="pie"
                height={290}
              />
            </ChartCard>
          </div>
          <div className="flex-1">
            <ChartCard title={"Current Week Details"}>
              {complianceData?.currentWeekDetails &&
              complianceData?.currentWeekDetails?.length > 0 ? (
                <ToolsComplianceBarGraph
                  data={complianceData?.currentWeekDetails}
                />
              ) : (
                <div className="flex items-center justify-center">
                  <span className="text-sm text-gray-400">
                    No data available for current week
                  </span>
                </div>
              )}
            </ChartCard>
          </div>
        </div>
        <ModalHOC
          isOpen={pendingActivitiesOpen}
          onClose={() => {
            setPendingActivitiesOpen(false);
          }}
        >
          <EnhancedTable
            data={complianceData?.pendingActivitiesData}
            columns={[
              { label: "Tool ID", accessor: "ToolName" },
              { label: "Status", accessor: "Status" },
            ]}
            enableSearch={true}
            enableFilter={true}
            enablePagination={false}
            onRowClick={handlePendingToolSelected}
          />
        </ModalHOC>
      </>
    )
  );
};

Compliance.propTypes = {
  changeTool: PropTypes.func.isRequired,
  changeTab: PropTypes.func.isRequired,
};

export default Compliance;

const StatCard = ({ title, value, icon: Icon }) => (
  <div className="bg-white p-4 border-t-4 border-slate-400 rounded-xl shadow-md flex items-center space-x-4 hover:shadow-lg transition-shadow duration-300">
    {/* Icon Section */}
    <div className="bg-purple-100 p-3 rounded-full">
      <Icon className="text-purple-950 w-8 h-8" />
    </div>

    {/* Text Content */}
    <div className="w-full">
      <h2 className="text-lg font-semibold text-start text-gray-700 mb-2">
        {title}
      </h2>
      <div className="flex justify-start  w-full ">
        <div className="flex-1">
          <p className="text-xl font-bold text-gray-500">{value}</p>
        </div>
      </div>
    </div>
  </div>
);

StatCard.propTypes = {
  title: PropTypes.string.isRequired,
  value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
  icon: PropTypes.elementType.isRequired,
};
