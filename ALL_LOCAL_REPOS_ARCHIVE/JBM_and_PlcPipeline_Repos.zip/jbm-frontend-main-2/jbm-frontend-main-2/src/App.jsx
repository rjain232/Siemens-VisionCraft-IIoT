import { BrowserRouter as Router } from "react-router-dom";
import RouterConfig from "./routes/RouterConfig";
import { AuthProvider } from "./hooks/AuthContext";
import { useLicense } from "./hooks/useLicense";

function App() {
  // const { license, loading } = useLicense();
 
  //  if (loading) {
  //    return <div>Loading...</div>;
  //  }
 
  //  if (!license?.valid) {
  //    return (
  //      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-6">
  //     <div className="bg-white border border-gray-200 rounded-2xl shadow-sm p-10 max-w-md w-full text-center">
  //       {/* Icon */}
  //       <div className="w-16 h-16 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-6">
  //         <svg className="w-8 h-8 text-red-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
  //           <path strokeLinecap="round" strokeLinejoin="round"
  //             d="M16.5 10.5V6.75a4.5 4.5 0 10-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 002.25-2.25v-6.75a2.25 2.25 0 00-2.25-2.25H6.75a2.25 2.25 0 00-2.25 2.25v6.75a2.25 2.25 0 002.25 2.25z" />
  //         </svg>
  //       </div>
 
  //       <h1 className="text-xl font-semibold text-gray-900 mb-2">Access Denied</h1>
 
  //       {/* {formattedDate && (
  //         <p className="text-sm text-gray-400 mb-4">Expired on {formattedDate}</p>
  //       )}*/}
 
  //       <p className="text-sm text-gray-500 leading-relaxed">
  //         {"Somthing went wrong. Please contact your administrator."}
  //       </p> 
  //     </div>
  //   </div>
  
  //    );
  //  }
  return (
    <AuthProvider>
    <Router>
      <RouterConfig/>
    </Router>
    </AuthProvider>
  );
}

export default App;
