import { useState, useMemo } from "react";
import PropTypes from "prop-types";
import Pagination from "../common/components/Pagination";

const withTable = (WrappedComponent) => {
  const TableHOC = ({
    data,
    columns,
    filters = [],
    enableSearch = true,
    enableFilter = true,
    enablePagination = true,
    onRowClick = undefined
  }) => {
    const [searchQuery, setSearchQuery] = useState("");
    const [activeFilters, setActiveFilters] = useState(
      filters.reduce(
        (acc, filter) => ({ ...acc, [filter.key]: filter.options[0] }),
        {}
      )
    );
    const [currentPage, setCurrentPage] = useState(1);
    const [rowsPerPage, setRowsPerPage] = useState(5);

    const handleRowsPerPageChange = (rows) => {
      setRowsPerPage(rows);
    };

    // Filtered data with multi-filter and search applied
    const filteredData = useMemo(() => {
      let result = data;

      // Apply active filters
      if (enableFilter) {
        Object.keys(activeFilters).forEach((key) => {
          const filterValue = activeFilters[key];
          if (filterValue && filterValue !== "all") {
            const filterCondition = filters.find(
              (f) => f.key === key
            ).condition;
            result = result.filter((item) =>
              filterCondition(item, filterValue)
            );
          }
        });
      }
      // Apply search
      if (enableSearch && searchQuery) {
        result = result.filter((item) =>
          columns.some((col) =>
            String(item[col.accessor] ?? "")
              .toLowerCase()
              .includes(searchQuery.toLowerCase())
          )
        );
      }

      return result;
    }, [
      data,
      searchQuery,
      activeFilters,
      filters,
      columns,
      enableFilter,
      enableSearch,
    ]);

    // Paginated data
    const paginatedData = useMemo(() => {
      const startIndex = (currentPage - 1) * rowsPerPage;
      return filteredData.slice(startIndex, startIndex + rowsPerPage);
    }, [filteredData, currentPage, rowsPerPage]);

    const totalPages = Math.ceil(filteredData.length / rowsPerPage);

    return (
      <div className=" rounded-md p-4 bg-white">
        {/* Table */}
        <WrappedComponent
          data={enablePagination ? paginatedData : filteredData}
          columns={columns}
          onRowClick={onRowClick}
        />

        {/*Pagination*/}
        {enablePagination && (
          <Pagination
            currentPage={currentPage}
            totalPages={totalPages}
            onPageChange={(page) => setCurrentPage(page)}
            rowsPerPage={rowsPerPage}
            setRowsPerPage={handleRowsPerPageChange}
          />
        )}
      </div>
    );
  };

  // Add prop types validation
  TableHOC.propTypes = {
    data: PropTypes.arrayOf(PropTypes.object).isRequired, // Array of data objects
    columns: PropTypes.arrayOf(
      PropTypes.shape({
        label: PropTypes.string.isRequired, // Label of the column
        accessor: PropTypes.string.isRequired, // Key in the data object
      })
    ).isRequired,
    filters: PropTypes.arrayOf(
      PropTypes.shape({
        key: PropTypes.string.isRequired, // Filter key to match with data
        label: PropTypes.string.isRequired, // Label for the filter dropdown
        options: PropTypes.arrayOf(PropTypes.string).isRequired, // Options for the dropdown
        condition: PropTypes.func.isRequired, // Filter condition function
      })
    ),
    enableSearch: PropTypes.bool, // Enable or disable search
    enableFilter: PropTypes.bool, // Enable or disable filter
    enablePagination: PropTypes.bool, // Enable or disable pagination
    rowsPerPage: PropTypes.number, // Number of rows per page for pagination
    onRowClick:PropTypes.func
  };

  TableHOC.defaultProps = {
    filters: [],
    enableSearch: true,
    enableFilter: true,
    enablePagination: true,
    rowsPerPage: 5,
    onRowClick:undefined
  };

  return TableHOC;
};

export default withTable;
