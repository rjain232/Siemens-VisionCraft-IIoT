import { createContext, useContext, useState } from "react";
import { jwtDecode } from "jwt-decode";

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const token = localStorage.getItem("token");

  const [isAuthenticated, setIsAuthenticated] = useState(
    token && jwtDecode(token).exp * 1000 > Date.now()
  );

  const login = (token, navigate) => {
    localStorage.setItem("token", token);
    setIsAuthenticated(true);
    navigate("/"); 
  };

  const logout = () => {
    localStorage.removeItem("token");
    setIsAuthenticated(false);
    //navigate("/login"); 
  };


  return (
    <AuthContext.Provider value={{ isAuthenticated, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};


export const useAuthContext = () => {
  return useContext(AuthContext);
};
