import { useEffect, useState } from "react";
import axios from "axios";
const BASE_API = import.meta.env.VITE_BASE_API_URL;

export const useLicense = () => {
  const [license, setLicense] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkLicense = async () => {
      try {
        const response = await axios.get(
          `${BASE_API}/license/status`
        );

        setLicense(response.data);
      } catch (error) {
        setLicense({
          valid: false,
          message:
            error.response?.data?.message ||
            "License Invalid",
        });
      } finally {
        setLoading(false);
      }
    };

    checkLicense();
  }, []);

  return { license, loading };
};