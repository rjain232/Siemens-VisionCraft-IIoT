import { useState, useEffect, useCallback, useMemo } from "react";
import axiosInstance from "../utils/AxiosInstance";

const useAxios = (endpoint, config = {}, fetchOnMount = true) => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(fetchOnMount);
  const [error, setError] = useState(null);

  const memoizedConfig = useMemo(() => config, [JSON.stringify(config)]);

  const fetchData = useCallback(
    async (overrideConfig = {}) => {
      setLoading(true);
      setError(null);
      try {
        const response = await axiosInstance({
          url: endpoint,
          method: memoizedConfig.method || "GET",
          params: memoizedConfig.params || {},
          data: memoizedConfig.data || {},
          headers: {
            ...memoizedConfig.headers, // Pass custom headers
            ...overrideConfig.headers, // Allow dynamic header overrides
          },
          ...memoizedConfig,
          ...overrideConfig,
        });
       
        setData(response?.data);
        return response.data
      } catch (err) {
        setError(err);
        throw err.response.data;
      } finally {
        setLoading(false);
      }
    },
    [endpoint, memoizedConfig]
  );
  
 useEffect(() => {
    if (fetchOnMount) fetchData();
  }, [fetchOnMount, fetchData ]);

  return { data, loading, error, refetch: fetchData };
};

export default useAxios;
