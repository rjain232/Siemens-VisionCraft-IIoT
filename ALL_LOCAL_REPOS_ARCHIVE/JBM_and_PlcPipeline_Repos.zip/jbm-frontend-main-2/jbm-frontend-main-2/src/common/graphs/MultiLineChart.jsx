import React from "react";
import Chart from "react-apexcharts";

function generateDateRange(startDate, endDate) {
  const start = new Date(startDate);
  const end = new Date(endDate);
  const dateArray = [];

  while (start <= end) {
    const formattedDate = start.toISOString().split('T')[0]; // yyyy-mm-dd
    dateArray.push(formattedDate);
    start.setDate(start.getDate() + 1);
  }

  return dateArray;
}

// Utility to get all dates between start and end
function getDateRange(startDate, endDate) {
  const dateArray = [];
  const currentDate = new Date(startDate);
  const end = new Date(endDate);

  while (currentDate <= end) {
    dateArray.push(currentDate.toISOString().split('T')[0]);
    currentDate.setDate(currentDate.getDate() + 1);
  }

  return dateArray;
}

// Main transformation function
function transformData(input, startDate, endDate) {
  const dateRange = getDateRange(startDate, endDate);
  
  return input.map(robot => {
    const dateToAccuracy = {};

    // Build a lookup map for the robot's spot data
    robot.spotdata.forEach(entry => {
      dateToAccuracy[entry.date] = entry.spotaccuracy;
    });

    // Create data array in order of the full date range
    const dataArray = dateRange.map(date => dateToAccuracy[date] ?? 0); // default to 0 if missing

    return {
      name: robot.RobotName,
      data: dataArray,
    };
  });
}


const MultiLineChart = ({data , startDate,endDate}) => {

  const options = {
    chart: {
      type: "line",
      height: 350,
      toolbar: {
        show: false,
      }
    },
    stroke: {
      curve: "straight",
      width: 3,
    },
    markers: {
      size: 0,
      colors: ["#FF4560", "#008FFB", "#00E396"],
      strokeWidth: 2,
    },
    legend: {
      show: true,
    },
    colors: ["#FF4560", "#008FFB", "#00E396"],
    xaxis: {
      categories: generateDateRange(startDate, endDate),
    },
    yaxis: {
      title: {
        text: "Spot Accuracy",
      },
      labels: {
        formatter: (value) => `${value}%`,
      },
    },
    tooltip: {
      y: {
        formatter: (value) => `${value}%`,
      },
    },
  };

  // const series = [
  //   {
  //     name: "Robot 1",
  //     data: [20, 50, 40, 43, 60, 70, 80, 90, 100, 95, 85, 33, 65, 27, 45, 56, 25],
  //   },
  //   {
  //     name: "Robot 2",
  //     data: [15, 45, 35, 45, 23, 65, 45, 85, 95, 90, 33, 70, 65, 50, 80, 30, 20],
  //   },
  //   {
  //     name: "Robot 3",
  //     data: [34, 45, 32, 43, 54, 45, 54, 32, 21, 67, 76, 69, 85,44, 42, 41, 30],
  //   },
  // ];
  const series = transformData(data, startDate, endDate);
  console.log("Series Data:", series);

  

  return (
    <div className="w-full">
      <Chart options={options} series={series} type="line" height={290} />
    </div>
  );
};

export default MultiLineChart;
