import PropTypes from "prop-types";
import Chart from "react-apexcharts";

const ColumnWithMarkerChart = ({data}) => {
  const options = {
    chart: {
      type: "bar",
      height: 350,
    },
    plotOptions: {
      bar: {
        columnWidth: "50%",
      },
    },
    dataLabels: {
      enabled: false,
    },
    stroke: {
      show: false,
    },
    markers: {
      size: [6],
      colors: ["#6B46C1"],
      strokeColors: "#6B46C1",
      strokeWidth: 2,
    },
    legend: {
      show: true,
    },
    colors: ["#00BC56", "#6B46C1"],
    xaxis: {
      categories: data?.map((robot) => `Robot ${robot.RobotId}`),
      title: {
        text: "Robot ID",
      }
    },
    yaxis:{
        min:10,
        
    }
  };

  // const series =  [
  //   {
  //     name: 'Actual',
  //     data: [
  //       {
  //         x: 'Robot 1',
  //         y: 30,
  //         goals: [
  //           {
  //             name: 'Total',
  //             value: 50,
  //             strokeHeight: 5,
  //             strokeColor: '#775DD0'
  //           }
  //         ]
  //       },
  //       {
  //         x: 'Robot 2',
  //         y: 44,
  //         goals: [
  //           {
  //             name: 'Total',
  //             value: 54,
  //             strokeHeight: 5,
  //             strokeColor: '#775DD0'
  //           }
  //         ]
  //       },
  //       {
  //         x: 'Robot 3',
  //         y: 54,
  //         goals: [
  //           {
  //             name: 'Total',
  //             value: 62,
  //             strokeHeight: 5,
  //             strokeColor: '#775DD0'
  //           }
  //         ]
  //       },
  //       {
  //         x: 'Robot 4',
  //         y: 66,
  //         goals: [
  //           {
  //             name: 'Total',
  //             value: 75,
  //             strokeHeight: 5,
  //             strokeColor: '#775DD0'
  //           }
  //         ]
  //       },
  //       {
  //         x: 'Robot 5',
  //         y: 40,
  //         goals: [
  //           {
  //             name: 'Total',
  //             value: 30,
  //             strokeHeight: 13,
  //             strokeWidth: 0,
  //             strokeLineCap: 'round',
  //             strokeColor: '#775DD0'
  //           }
  //         ]
  //       },
  //       {
  //         x: 'Robot 6',
  //         y: 71,
  //         goals: [
  //           {
  //             name: 'Total',
  //             value: 75,
  //             strokeHeight: 5,
  //             strokeColor: '#775DD0'
  //           }
  //         ]
  //       },
  //       {
  //         x: 'Robot 7',
  //         y: 73,
  //         goals: [
  //           {
  //             name: 'Total',
  //             value: 87,
  //             strokeHeight: 5,
  //             strokeColor: '#775DD0'
  //           }
  //         ]
  //       },
  //       {
  //         x: 'Robot 8',
  //         y: 45,
  //         goals: [
  //           {
  //             name: 'Total',
  //             value: 53,
  //             strokeHeight: 5,
          
  //             strokeColor: '#775DD0'
  //           }
  //         ]
  //       }
  //     ]
  //   }
  // ];

  const series = [
  {
    name: 'Actual',
    data: data?.map((robot) => {
      const total = robot.TotalActual + robot.TotalMissed;
      return {
        x: `Robot ${robot.RobotId}`,  // You can also use `Robot ${robot.RobotId}` if preferred
        y: robot.TotalActual,
        goals: [
          {
            name: 'Total',
            value: total,
            strokeHeight: 5,
            strokeColor: '#775DD0'
          }
        ]
      };
    })
  }
];

  return (
  
      <Chart options={options} series={series} type="bar" height={290} />
  
  );
};
ColumnWithMarkerChart.propTypes = {
  data: PropTypes.arrayOf(
    PropTypes.shape({
      RobotId: PropTypes.number.isRequired,
      TotalActual: PropTypes.number.isRequired,
      TotalMissed: PropTypes.number.isRequired,
    })
  ).isRequired,
};

export default ColumnWithMarkerChart;
