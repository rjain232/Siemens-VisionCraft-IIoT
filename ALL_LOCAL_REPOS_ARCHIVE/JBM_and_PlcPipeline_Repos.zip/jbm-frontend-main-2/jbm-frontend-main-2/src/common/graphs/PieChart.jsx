import Chart from "react-apexcharts";

const PieChart = ({ chartSeries, labels, colors ,height , chartType }) => {
  const chartOptions = {
    chart: {
      type: "pie",
      offsetY: 0,
    },
    labels: labels,
    colors: colors,
    legend: {
      position: "bottom",
      horizontalAlign: "center",
      //floating: false, // Important: Prevents overlap
      offsetY: 20,
      markers: {
        width: 10,
        height: 10
      },
      itemMargin: {
        //horizontal: 10, // ⬅️ Increase spacing between items
       // vertical: 15,    // ⬅️ Increase top-bottom spacing
      },
    },
    
    dataLabels: {
      enabled: true,
     // formatter: (val, opts) => opts.w.config.series[opts.seriesIndex],
     formatter: (val, opts) => {

        const value = opts.w.config.series[opts.seriesIndex];
      
        return chartType === "Downtime" ? `${value} min` :`${value}`  ;
      }
    },
     tooltip: {
      theme: "dark",
      style: {
        fontSize: "14px",
        backgroundColor: "#ffffff",
        color: "#000000",
        fontColor: "#ffff",
      },
      y: {
        formatter: (value) => chartType === "Downtime" ? `${value} min` :`${value}`  ,
      }
   
    },
  };

  return (
    <Chart
      options={chartOptions}
      series={chartSeries}
      type="pie"
      height={height || 240}
    />
  );
};

export default PieChart;
