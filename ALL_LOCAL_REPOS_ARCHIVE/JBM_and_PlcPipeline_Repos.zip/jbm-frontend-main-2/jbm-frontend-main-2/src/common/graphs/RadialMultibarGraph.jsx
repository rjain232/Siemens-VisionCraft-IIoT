import React from 'react'

const RadialMultibarGraph = () => {
  return (
    <div>RadialMultibarGraph</div>
  )
}

export default RadialMultibarGraph