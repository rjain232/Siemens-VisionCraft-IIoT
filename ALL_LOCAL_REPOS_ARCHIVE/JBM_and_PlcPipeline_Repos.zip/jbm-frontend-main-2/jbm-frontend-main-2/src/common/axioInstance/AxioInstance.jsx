import axios from "axios";

const axiosInstance = axios.create({
  baseURL: "http://localhost:9000/api", // Replace with your API base URL
  headers: {
    "Content-Type": "application/json",
  },
});
axios.defaults.timeout = 600000;

// Request Interceptor
axiosInstance.interceptors.request.use(
  (config) => {
    const tempToken = false; // Setting temporary token as false
    if (tempToken) {
      config.headers["Authorization"] = `Bearer ${tempToken}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

export default axiosInstance;
