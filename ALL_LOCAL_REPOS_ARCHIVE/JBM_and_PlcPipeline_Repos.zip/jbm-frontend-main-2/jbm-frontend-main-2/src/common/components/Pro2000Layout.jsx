import React, { useState, useEffect } from 'react'
import SVGAlert from './SVGAlert';
import lineLayoutSvg from "../../assets/LineLayout3.svg";
import robotImage from "../../assets/robotic-arm (1).png"
import PLCIcon from "../../assets/plc (8).png";
import HMIIcon from "../../assets/lcd.png"
import workerImage from "../../assets/worker.png"
import SafetyGate from './SafetyGate';
import MotorIcon from "../../assets/motor.png"
import StationNameTags from './StationNameTags';
import EmergencyState from './EmergencyState';
import CabinImage from '../../assets/truck.png';

const Pro2000Layout = () => {
  const [scale, setScale] = useState(1);
  const [viewBoxX, setViewBoxX] = useState(270);
  const [viewBoxY, setViewBoxY] = useState(-135);
  const [isPanning, setIsPanning] = useState(false);
  const [startX, setStartX] = useState(0);
  const [startY, setStartY] = useState(0);

  const viewBoxWidth = 1700;
  const viewBoxHeight = 960;

  const [tooltip, setTooltip] = useState({ visible: false, x: 0, y: 0, text: "C0001" });

  // Function to show tooltip
  const handleMouseEnter = (event, text, xPosition, yPosition) => {
    //console.log("event.nativeEvent.offsetX, event.nativeEvent.offsetY", event.nativeEvent.offsetX, event.nativeEvent.offsetY)
    setTooltip({
      visible: true,
      x: xPosition, // Adjust for better placement
      y: yPosition,
      text: text,
    });
  };

  // Function to hide tooltip
  const handleMouseLeave = () => {
    setTooltip({ ...tooltip, visible: false });
  };
  // useEffect(() => {
  //     setViewBoxX(270);
  //     setViewBoxY(-60);
  // }, []);

  // Handle zooming
  const handleWheel = (event) => {
    event.preventDefault();
    let newScale = scale + (event.deltaY > 0 ? -0.1 : 0.1);

    if (newScale < 1) newScale = 1; // Prevent zooming out beyond original size
    if (newScale > 3) newScale = 3; // Limit max zoom

    setScale(newScale);
  };

  // Start panning (only if zoomed in)
  const handleMouseDown = (event) => {
    if (scale === 1) return; // Disable panning at the initial zoom level

    setIsPanning(true);
    setStartX(event.clientX);
    setStartY(event.clientY);
  };

  // Handle panning
  const handleMouseMove = (event) => {
    if (!isPanning) return;

    const dx = (startX - event.clientX) / scale;
    const dy = (startY - event.clientY) / scale;

    setViewBoxX((prevX) => prevX + dx);
    setViewBoxY((prevY) => prevY + dy);

    setStartX(event.clientX);
    setStartY(event.clientY);
  };

  // Stop panning
  const handleMouseUp = () => {
    setIsPanning(false);
  };

  // Reset zoom and position on double-click
  const handleDoubleClick = () => {
    setScale(1);
    setViewBoxX(270);
    setViewBoxY(-135);
  };

  const data = [
    { label: 'Daily Target', value: '800' },
    { label: 'Actual Production', value: '25' },
    { label: 'LHS | RHS Split', value: '30' },
    { label: 'Monthly Target', value: '28' },
  ];

  const cellWidth = 250; // Width for a single column
  const cellHeight = 85; // Increased height for stacked layout
  const tableStartX = 2050; // Left padding
  const tableStartY = 410; // Top padding
  const borderRadius = 10; // Rounded corners
  const cellSpacing = 20; // Space between cells


  const robots = [
    { id: "robot1", x: 150, y: 285 },
    { id: "robot2", x: 150, y: 150 },
    { id: "robot3", x: 250, y: 128 },
    { id: "robot4", x: 255, y: 285 },
    { id: "robot5", x: 410, y: 300 },
    { id: "robot6", x: 410, y: 105 },
    { id: "robot7", x: 580, y: 128 },
    { id: "robot8", x: 580, y: 285 },
    { id: "robot9", x: 800, y: 285 },
    { id: "robot10", x: 800, y: 130 },
    { id: "robot11", x: 1000, y: 270 },
    { id: "robot12", x: 1000, y: 155 },
    { id: "robot13", x: 1152, y: 155 },
    { id: "robot14", x: 1152, y: 270 },
    { id: "robot15", x: 920, y: 570 },
    { id: "robot16", x: 1380, y: 710 },
    { id: "robot17", x: 1230, y: 270 },
    { id: "robot18", x: 1230, y: 155 },
    { id: "robot19", x: 1310, y: 155 },
    { id: "robot20", x: 1310, y: 270 },
    { id: "robot21", x: 920, y: 670 }
  ];

  const safetyComponents = [
    {
      id: "ML10SG1Label",
      name: "Safety Gate 2",
      label: "S.G - 2",
      x: 220,
      y: 40,
      error: false
    },
    {
      id: 2,
      name: "Safety Gate 5",
      label: "S.G - 5",
      x: 650,
      y: -60,
      error: false
    },
    {
      id: 3,
      name: "Light Curtain 1",
      label: "LC 1",
      x: 410,
      y: -60,
      error: false
    },
    {
      id: 24,
      name: "Run Stand",
      label: "RS 1",
      x: 410,
      y: -110,
      error: false
    },
    {
      id: 4,
      name: "Light Curtain 2",
      label: "LC 2",
      x: 580,
      y: -60,
      error: false
    },
    {
      id: 25,
      name: "Run Stand",
      label: "RS 2",
      x: 580,
      y: -110,
      error: false
    },
    {
      id: 5,
      name: "Safety Gate 7",
      label: "S.G - 7",
      x: 780,
      y: 10,
      error: false
    },
    {
      id: 6,
      name: "Safety Gate 9",
      label: "S.G - 9",
      x: 1095,
      y: 40,
      error: false
    },
    {
      id: 7,
      name: "Safety Gate 8",
      label: "S.G - 8",
      x: 1102,
      y: 400,
      error: false
    },
    {
      id: 8,
      name: "Safety Gate 6",
      label: "S.G - 6",
      x: 760,
      y: 425,
      error: false
    },
    {
      id: 9,
      name: "Light Curtain",
      label: "LC 5",
      x: 670,
      y: 480,
      error: false
    },
    {
      id: 26,
      name: "Run Stand",
      label: "RS 5",
      x: 670,
      y: 530,
      error: false
    },
    {
      id: 10,
      name: "Light Curtain 1",
      label: "LC 4",
      x: 490, // ........Last update
      y: 480,
      error: false
    },
    {
      id: 27,
      name: "Run Stand",
      label: "RS 4",
      x: 490, // ........Last update
      y: 530,
      error: false
    },
    {
      id: 11,
      name: "Safety Gate 4",
      label: "S.G - 4",
      x: 580,// ........Last update
      y: 480,
      error: false
    },
    {
      id: 12,
      name: "Light Curtain 1",
      label: "LC 3",
      x: 400,
      y: 480,
      error: false
    },
    {
      id: 28,
      name: "Run Stand",
      label: "RS 3",
      x: 400,
      y: 530,
      error: false
    },
    {
      id: 13,
      name: "Safety Gate 3",
      label: "S.G - 3",
      x: 175,
      y: 400,
      error: false
    },
    {
      id: 14,
      name: "Light Curtain 1",
      label: "LC 8",
      x: -75,
      y: 275,
      error: false
    },
    {
      id: 15,
      name: "Safety Gate 1",
      label: "S.G - 1",
      x: -75,
      y: 50,
      error: false
    },

    // {
    //   id: 15,
    //   name: "Safety Gate 2",
    //   label: "S.G - 2",
    //   x: 1102,
    //   y: 555,
    //   error: false
    // },
    {
        id: 16,
        name: "Run Stand 1",
        label: "RS 1",
        label2: "Stand 1",
        x: 1080,
        y: 710,
        error: false
    },
    {
        id: 17,
        name: "Light Curtain / Operating",
        label: "LC/OP 6",
        label2: "Operating",
        x: 1080,
        y: 760,
        error: false
    },
    {
        id: 18,
        name: "Safety Gate 1",
        label: "S.G - 1",
        x: 755,
        y: 640,
        error: false
    },
    {
      id: 19,
      name: "Safety Gate 1",
      label: "S.G - 1",
      x: 1270,
      y: 715,
      error: false
    },
    {
      id: 20,
      name: "Run Stand 1",
      label: "RS 1",
      label2: "Stand 1",
      x: 1700,
      y: 685,
      error: false
    },
    {
      id: 21,
      name: "Light Curtain 7",
      label: "LC 7",
      x: 1700,
      y: 730,
      error: false
    },
    {
      id: 22,
      name: "Safety Gate 11",
      label: "S.G - 11",
      x: 2010,
      y: 45,
      error: false
    },
    {
      id: 23,
      name: "Light Curtain 9",
      label: "LC 9",
      x: 2100,
      y: 320,
      error: false
    },

    {
      id: 29,
      name: "Safety Gate 10",
      label: "S.G - 10",
      x: 1422,
      y: 430,
      error: false
    },
    {
      id: 30,
      name: "Light Curtain 8",
      label: "LC 8",
      x: 1300,
      y: 350,
      error: false
    },
    {
        id: 31,
        name: "RFRS1",
        label: "RS 2",
        x: 1130,
        y: 590,
        error: false
    },
    {
        id: 32,
        name: "RFLC2",
        label: "LC 2",
        x: 1130,
        y: 640,
        error: false
    },
    {
      id: 33,
      name: "ML30RS1",
      label: "RS 1",
      x: 905,
      y: -60,
      error: false
    },
    {
      id: 34,
      name: "Light Curtain 2",
      label: "LC 2",
      x: 905,
      y: -10,
      error: false
    },

  ];

  const StationNameTag = [
    {
      id: 1,
      name: "Station Name",
      label: "ML 10",
      x: 210,
      y: 500,
    },
    {
      id: 2,
      name: "Station Name",
      label: "ML 20",
      x: 530,
      y: 650,
    },
    {
      id: 3,
      name: "Station Name",
      label: "ML 30",
      x: 825,
      y: -90,
    },
    {
      id: 4,
      name: "Station Name",
      label: "ML 40",
      x: 1080,
      y: -90,
    },
    {
      id: 5,
      name: "Station Name",
      label: "RF 10",
      x: 930,
      y: 765,
    },
    {
      id: 6,
      name: "Station Name",
      label: "HEMMING",
      width: 90,
      x: 1450,
      y: 590,
    },
    {
      id: 7,
      name: "Station Name",
      label: "ML50",
      x: 1260,
      y: -90,
    },
    {
      id: 7,
      name: "Station Name",
      label: "MFL LHS EMG",
      width: 115,
      x: 1750,
      // y:20,
      y: 95
    },
    {
      id: 8,
      name: "Station Name",
      label: "MFL RHS EMG",
      width: 115,
      x: 1750,
      y: 380,
    },
    {
      id: 9,
      name: "Station Name",
      label: "MFL 10",
      x: 1540,
      y: 320,
    },
    {
      id: 10,
      name: "Station Name",
      label: "MFL 20",
      x: 1610,
      y: 320,
    },
    {
      id: 11,
      name: "Station Name",
      label: "MFL 30",
      x: 1680,
      y: 320,
    },
    {
      id: 12,
      name: "Station Name",
      label: "MFL 40",
      x: 1750,
      y: 320,
    },
    {
      id: 13,
      name: "Station Name",
      label: "MFL 50",
      x: 1820,
      y: 320,
    },
    {
      id: 14,
      name: "Station Name",
      label: "MFL 60",
      x: 1890,
      y: 320,
    },

    {
      id: 15,
      name: "Station Name",
      label: "MFL 70",
      x: 1960,
      y: 320,
    },
    {
      id: 16,
      name: "Station Name",
      label: "MFL 80",
      x: 2030,
      y: 320,
    },

  ];

  const emergencyStates = [
    {
      id: "EmgMLTopStartPLC1",
      emergencyStateActive: false,
      emergencyStateX: 50,
      emergencyStatey: -40,
    },
    {
      id: "EmgMLBottomStartPLC2",
      emergencyStateActive: false,
      emergencyStateX: 50,
      emergencyStatey: 510,

    },
    {
      id: "EmgMLTopEndPLC3",
      emergencyStateActive: false,
      emergencyStateX: 1825,
      emergencyStatey: -40,

    },
    {
      id: "EmgMLStartLeft1",
      emergencyStateActive: false,
      emergencyStateX: -45,
      emergencyStatey: 210,
    },
    {
      id: "EmgMLTopEnd1",
      emergencyStateActive: false,
      emergencyStateX: 1433,
      emergencyStatey: 100,
    },
    {
      id: "EmgMLBottomEndOpBox01",
      emergencyStateActive: false,
      emergencyStateX: 1395,
      emergencyStatey: 520,
    },
    {
      id: "EmgMLBottomEndHMI",
      emergencyStateActive: false,
      emergencyStateX: 1510,
      emergencyStatey: 520,
    },
    {
      id: "EmgMLRightEndOp03Panel",
      emergencyStateActive: false,
      emergencyStateX: 2265,
      emergencyStatey: 285,
    },
    {
      id: "EmgMLStartEndHMI",
      emergencyStateActive: false,
      emergencyStateX: -45,
      emergencyStatey: 500,
    },
    {
      id: "EmgMlSg1",
      emergencyStateX: -45,
      emergencyStatey: 115,
      emergencyStateActive: false
    },
    {
      id: "EmgMlSg2",
      emergencyStateX: 250,
      emergencyStatey: 10,
      emergencyStateActive: false
    },
    {
      id: "EmgMlSg5",
      emergencyStateX: 680,
      emergencyStatey: -90,
      emergencyStateActive: false
    },
    {
      id: "EmgMlSg7",
      emergencyStateX: 810,
      emergencyStatey: -20,
      emergencyStateActive: false
    },
    {
      id: "EmgMlSg9",
      emergencyStateX: 1070,
      emergencyStatey: 60,
      emergencyStateActive: false
    },
    {
      id: "EmgMlSg8",
      emergencyStateX: 1133,
      emergencyStatey: 465,
      emergencyStateActive: false
    },
    {
      id: "EmgMlSg4",
      emergencyStateX: 610, // ........Last update
      emergencyStatey: 545,
      emergencyStateActive: false
    },
    {
      id: "EmgMlSg3",
      emergencyStateX: 205,
      emergencyStatey: 465,
      emergencyStateActive: false
    },
    {
        id:"EmgRFSg1",
        emergencyStateX : 785,
        emergencyStatey : 705,
        emergencyStateActive : false 
      },
    {
      id: "EmgMLSg6",
      emergencyStateX: 790,
      emergencyStatey: 490,
      emergencyStateActive: false
    },
    {
      id: "EmgHMSg1",
      emergencyStateX: 1300,
      emergencyStatey: 780,
      emergencyStateActive: false
    },
    {
      id: "EmgMLSg11",
      emergencyStateX: 1985,
      emergencyStatey: 65,
      emergencyStateActive: false
    },
    {
      id: "EmgMLSg10",
      emergencyStateX: 1395,
      emergencyStatey: 450,
      emergencyStateActive: false
    },
    {
        id: "EmgRFRS1",
        isOpened: false,
        emergencyStateActive : false,
        emergencyStateX : 1165,
        emergencyStatey : 730
    },
    {
        id: "EmgRFRS2",
        isOpened: false,
        emergencyStateActive : false,
        emergencyStateX : 1215,
        emergencyStatey : 610
    },
    {
      id: "EmgHMRS1",
      isOpened: false,
      emergencyStateActive: true,
      emergencyStateX: 1785,
      emergencyStatey: 705
    },
    {
      id: "EmgML20RS1",
      isOpened: false,
      emergencyStateActive: true,
      emergencyStateX: 385,
      emergencyStatey: -90
    },
    {
      id: "EmgML20RS2",
      isOpened: false,
      emergencyStateActive: true,
      emergencyStateX: 555,
      emergencyStatey: -90
    },
    {
      id: "EmgML20RS3",
      isOpened: false,
      emergencyStateActive: false,
      emergencyStateX: 430,
      emergencyStatey: 595
    },
    {
      id: "EmgML20RS4",
      isOpened: false,
      emergencyStateActive: false,
      emergencyStateX: 520, // ........Last update
      emergencyStatey: 595
    },
    {
      id: "EmgML20RS5",
      isOpened: false,
      emergencyStateActive: false,
      emergencyStateX: 700,
      emergencyStatey: 595
    },
    {
      id: "EmgMFL10Top",
      emergencyStateActive: false,
      emergencyStateX: 1568,
      emergencyStatey: 170,

    },
    {
      id: "EmgMFL10Bottom",
      emergencyStateActive: false,
      emergencyStateX: 1568,
      emergencyStatey: 285,

    },
    {
      id: "EmgMFL20Top",
      emergencyStateActive: false,
      emergencyStateX: 1640,
      emergencyStatey: 170,

    },
    {
      id: "EmgMFL20Bottom",
      emergencyStateActive: false,
      emergencyStateX: 1640,
      emergencyStatey: 285,

    },
    {
      id: "EmgMFL30Top",
      emergencyStateActive: false,
      emergencyStateX: 1710,
      emergencyStatey: 170,

    },
    {
      id: "EmgMFL30Bottom",
      emergencyStateActive: false,
      emergencyStateX: 1710,
      emergencyStatey: 285,

    },
    {
      id: "EmgMFL40Top",
      emergencyStateActive: false,
      emergencyStateX: 1780,
      emergencyStatey: 170,

    },
    {
      id: "EmgMFL40Bottom",
      emergencyStateActive: false,
      emergencyStateX: 1780,
      emergencyStatey: 285,

    },
    {
      id: "EmgMFL50Top",
      emergencyStateActive: false,
      emergencyStateX: 1845,
      emergencyStatey: 170,

    },
    {
      id: "EmgMFL50Bottom",
      emergencyStateActive: false,
      emergencyStateX: 1845,
      emergencyStatey: 285,

    },
    {
      id: "EmgMFL60Top",
      emergencyStateActive: false,
      emergencyStateX: 1919,
      emergencyStatey: 170,

    },
    {
      id: "EmgMFL60Bottom",
      emergencyStateActive: false,
      emergencyStateX: 1919,
      emergencyStatey: 285,

    },
    {
      id: "EmgMFL70Top",
      emergencyStateActive: false,
      emergencyStateX: 1990,
      emergencyStatey: 170,

    },
    {
      id: "EmgMFL70Bottom",
      emergencyStateActive: false,
      emergencyStateX: 1990,
      emergencyStatey: 285,

    },
    {
      id: "EmgMFL80Top",
      emergencyStateActive: false,
      emergencyStateX: 2055,
      emergencyStatey: 170,

    },
    {
      id: "EmgMFL80Bottom",
      emergencyStateActive: false,
      emergencyStateX: 2055,
      emergencyStatey: 285,

    },
    {
      id: "EmgRFPlc",
      emergencyStateActive: false,
      emergencyStateX: 660,
      emergencyStatey: 780,
    },
    {
      id: "EmgHemmingPlc",
      emergencyStateActive: false,
      emergencyStateX: 1825,
      emergencyStatey: 780,
    },
  ]

  const safetyGates = [
    {
      id: "MLSg1",
      name: "S.G - 1",
      x1: "15",
      x2: "15",
      y: "62.5",
      isOpened: false,
      isLeftGate: true,
    },
    {
      id: "MLSg2",
      name: "S.G - 2",
      x1: "225",
      x2: "225",
      y: "113",
      isOpened: false,
      isLeftGate: true,
      isLeftOpen:true,
    },
    {
      id: "MLSg5",
      name: "S.G - 5",
      x1: "653",
      x2: "706",
      y: "20",
      isOpened: false,
    },
    {
      id: "MLSg7",
      name: "S.G - 7",
      x1: "788",
      x2: "835",
      y: "68",
      isOpened: false,
    },
    {
      id: "MLSg9",
      name: "S.G - 9",
      x1: "1104",
      x2: "1140",
      y: "98",
      isOpened: false,

    },
    {
      id: "MLSg8",
      name: "S.G - 8",
      x1: "1110",
      x2: "1150",
      y: "380",
      isOpened: false,
      isBottomGate: true,

    },
    {
      id: "MLSg4",
      name: "S.G - 4",
      x1: "602", // ........Last update
      x2: "643", // ........Last update
      y: "466", // ........Last update
      isOpened: false,
      isBottomGate: true,
    },
    {
      id: "MLSg3",
      name: "S.G - 3",
      x1: "175",
      x2: "225",
      y: "378",
      isOpened: false,
      isBottomGate: true,
     
    },
    {
        id: "RFSg1",
        name: "RF S.G - 1",
        x1: "830",
        x2: "830",
        y: "665",
        isOpened: false,
        isBottomGate: false,
        isLeftGate: true,
    },
    {
        id: "MLSg6",
        name: "S.G - 6",
        x1: "830",
        x2: "830",
        y: "420",
        isOpened: false,
        isBottomGate: false,
        isLeftGate: true,
       
    },
    {
      id: "RFSg2",
      name: "S.G - 12",
      x1: "1050",
      x2: "1050",
      y: "570",
      isOpened: false,
      isBottomGate: false,
      isLeftGate: true,

    },
    {
      id: "HMSg1",
      name: "S.G - 13",
      x1: "1400",
      x2: "1440",
      y: "800",
      isOpened: false,
      isBottomGate: true,

    },
    {
      id: "MLSg11",
      name: "S.G - 1",
      x1: "2100",
      x2: "2100",
      y: "62",
      isOpened: false,
      isLeftGate: true,

    },
    {
      id: "MLSg10",
      name: "S.G - 9",
      x1: "1430",
      x2: "1470",
      y: "400",
      isOpened: false,
      isBottomGate: true,
    }

  ]


  const drives = [
    {
      id: 1,
      drive: "drive1",
      x: 23,
      y: 230,
      width: 60,
      height: 25,
      fill: "#666b6e"
    },
    {
      id: 2,
      drive: "drive2",
      x: 180,
      y: 230,
      width: 140,
      height: 25,
      fill: "#666b6e"
    },
    {
      id: 3,
      drive: "drive3",
      x: 450,
      y: 230,
      width: 200,
      height: 25,
      fill: "#666b6e"
    },
    {
      id: 4,
      drive: "drive4",
      x: 800,
      y: 230,
      width: 140,
      height: 25,
      fill: "#666b6e"
    },
    {
      id: 5,
      drive: "drive5",
      x: 1050,
      y: 230,
      width: 120,
      height: 25,
      fill: "#666b6e"
    },
    {
      id: 6,
      drive: "drive6",
      x: 1270,
      y: 230,
      width: 85,
      height: 25,
      fill: "#666b6e"
    },
    {
      id: 7,
      drive: "drive7",
      x: 1540,
      y: 230,
      width: 60,
      height: 25,
      fill: "#666b6e"
    },
    {
      id: 8,
      drive: "drive8",
      x: 1610,
      y: 230,
      width: 60,
      height: 25,
      fill: "#666b6e"
    },
    {
      id: 9,
      drive: "drive9",
      x: 1680,
      y: 230,
      width: 60,
      height: 25,
      fill: "#666b6e"
    },
    {
      // id: 10,
      // drive: "drive10",
      // x: 2000,
      // y: 45,
      // width: 135,
      // height: 260,
      // fill: "none",
      // stroke: "#4608B2",
      // strokeWidth: "4"
    },
    {
      id: 11,
      drive: "drive11",
      x: 2115,
      y: 230,
      width: 90,
      height: 25,
      fill: "#666b6e"
    },
    {
      id: 12,
      drive: "drive12",
      x: 2115,
      y: 135,
      width: 90,
      height: 25,
      fill: "#666b6e"
    },
    {
      id: 13,
      drive: "drive13",
      x: 1750,
      y: 230,
      width: 60,
      height: 25,
      fill: "#666b6e"
    },
    {
      id: 14,
      drive: "drive14",
      x: 1820,
      y: 230,
      width: 60,
      height: 25,
      fill: "#666b6e"
    },
    {
      id: 15,
      drive: "drive15",
      x: 1890,
      y: 230,
      width: 60,
      height: 25,
      fill: "#666b6e"
    },
    {
      id: 15,
      drive: "drive15",
      x: 1960,
      y: 230,
      width: 60,
      height: 25,
      fill: "#666b6e"
    },
    {
      id: 16,
      drive: "drive16",
      x: 2030,
      y: 230,
      width: 60,
      height: 25,
      fill: "#666b6e"
    },
    {
      id: 17,
      drive: "drive6",
      x: 1405,
      y: 230,
      width: 60,
      height: 25,
      fill: "#666b6e"
    },
  ];

  return (
    <div
      className="w-full h-full "
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
    >
      <svg
        width="100%"
        height="100%"
        viewBox={`${viewBoxX} ${viewBoxY} ${viewBoxWidth / scale} ${viewBoxHeight / scale
          }`}
        onWheel={handleWheel}
        onMouseDown={handleMouseDown}
        onDoubleClick={handleDoubleClick}
        style={{
          cursor: scale > 1 ? (isPanning ? "grabbing" : "grab") : "default",
          transition: "viewBox 0.3s ease-out",
          
        }}
      >


        <>
          <rect
            id={"HMI1Start"}
            x={-105}
            y={470}
            width="90"
            height="60"
            fill="none"
            stroke="black"
            strokeWidth="2"
            strokeDasharray="5,5" // Creates the dotted effect
          />
          <text
            x={-71} // Center horizontally
            y={495} // Center vertically
            fontSize="14"
            fontWeight="bold"
            fill="black"
            textAnchor="end"
            alignmentBaseline="middle" // Ensures vertical centering
          >
            {'HMI'}
          </text>
          <text
            x={-71} // Center horizontally
            y={510} // Center vertically
            fontSize="14"
            fontWeight="bold"
            fill="black"
            textAnchor="end"
            alignmentBaseline="middle" // Ensures vertical centering
          >
            {'EMG'}
          </text>

          <rect
            id={"EMG1AtStart"}
            x={-105}
            y={180}
            width="90"
            height="60"
            fill="none"
            stroke="black"
            strokeWidth="2"
            strokeDasharray="5,5" // Creates the dotted effect
          />
          <rect
            x={1405}
            y={70}
            width="90"
            height="60"
            fill="none"
            stroke="black"
            strokeWidth="2"
            strokeDasharray="5,5" // Creates the dotted effect
          />
          <rect
            x={1369}
            y={490}
            width="100"
            height="60"
            fill="none"
            stroke="black"
            strokeWidth="2"
            strokeDasharray="5,5" // Creates the dotted effect
          />
          <rect
            x={1485}
            y={490}
            width="90"
            height="60"
            fill="none"
            stroke="black"
            strokeWidth="2"
            strokeDasharray="5,5" // Creates the dotted effect
          />
          <rect
            x={2240}
            y={255}
            width="100"
            height="60"
            fill="none"
            stroke="black"
            strokeWidth="2"
            strokeDasharray="5,5" // Creates the dotted effect
          />
          <>
            <rect
              x={10}
              y={-80}
              width="150"
              height="80"
              fill="none"
              stroke="black"
              strokeWidth="2"
              strokeDasharray="5,5" // Creates the dotted effect
            />
            <image
              key={"plc1"}
              href={PLCIcon}
              x={85}
              y={-70}
              width="60"
              height="60"
            />
          </>

          <>
            <rect
              x={10}
              y={470}
              width="150"
              height="80"
              fill="none"
              stroke="black"
              strokeWidth="2"
              strokeDasharray="5,5" // Creates the dotted effect
            />
            <image
              key={"plc2"}
              href={PLCIcon}
              x={85}
              y={480}
              width="60"
              height="60"
            />
          </>


          <>
            <rect
              x={620}
              y={740}
              width="150"
              height="80"
              fill="none"
              stroke="black"
              strokeWidth="2"
              strokeDasharray="5,5" // Creates the dotted effect
            />
            <image
              id={"RFPLC"}
              href={PLCIcon}
              x={695}
              y={750}
              width="60"
              height="60"
            />
          </>

          <>
            <rect
              id={"HemmingPLCRect"}
              x={1790}
              y={740}
              width="150"
              height="80"
              fill="none"
              stroke="black"
              strokeWidth="2"
              strokeDasharray="5,5" // Creates the dotted effect
            />
            <image
              id={"HemmingPLC"}
              href={PLCIcon}
              x={1865}
              y={750}
              width="60"
              height="60"
            />
          </>


          <>
            <rect
              x={1790}
              y={-80}
              width="150"
              height="80"
              fill="none"
              stroke="black"
              strokeWidth="2"
              strokeDasharray="5,5" // Creates the dotted effect
            />
            <image
              key={"plc3"}
              href={PLCIcon}
              x={1865}
              y={-70}
              width="60"
              height="60"
            />
          </>



          <text
            x={-71} // Center horizontally
            y={211} // Center vertically
            fontSize="14"
            fontWeight="bold"
            fill="black"
            textAnchor="end"
            alignmentBaseline="middle" // Ensures vertical centering
          >
            {'EMG'}
          </text>

          <text
            x={1458} // Center horizontally
            y={100} // Center vertically
            fontSize="14"
            fontWeight="bold"
            fill="black"
            textAnchor="start"
            alignmentBaseline="middle" // Ensures vertical centering
          >
            {'EMG'}
          </text>

          <text
            x={1420} // Center horizontally
            y={505} // Center vertically
            fontSize="14"
            fontWeight="bold"
            fill="black"
            textAnchor="start"
            alignmentBaseline="middle" // Ensures vertical centering
          >
            {'OP'}
          </text>
          <text
            x={1420} // Center horizontally
            y={520} // Center vertically
            fontSize="14"
            fontWeight="bold"
            fill="black"
            textAnchor="start"
            alignmentBaseline="middle" // Ensures vertical centering
          >
            {'BOX01'}
          </text>
          <text
            x={1420} // Center horizontally
            y={533} // Center vertically
            fontSize="14"
            fontWeight="bold"
            fill="black"
            textAnchor="start"
            alignmentBaseline="middle" // Ensures vertical centering
          >
            {'EMG'}
          </text>

          <text
            x={1535} // Center horizontally
            y={515} // Center vertically
            fontSize="14"
            fontWeight="bold"
            fill="black"
            textAnchor="start"
            alignmentBaseline="middle" // Ensures vertical centering
          >
            {'HMI'}
          </text>
          <text
            x={1535} // Center horizontally
            y={529} // Center vertically
            fontSize="14"
            fontWeight="bold"
            fill="black"
            textAnchor="start"
            alignmentBaseline="middle" // Ensures vertical centering
          >
            {'EMG'}
          </text>

          <text
            x={2290} // Center horizontally
            y={280} // Center vertically
            fontSize="14"
            fontWeight="bold"
            fill="black"
            textAnchor="start"
            alignmentBaseline="middle" // Ensures vertical centering
          >
            {'OP03'}
          </text>
          <text
            x={2290} // Center horizontally
            y={294} // Center vertically
            fontSize="14"
            fontWeight="bold"
            fill="black"
            textAnchor="start"
            alignmentBaseline="middle" // Ensures vertical centering
          >
            {'PANEL'}
          </text>
          {/* <text
        x={1420} // Center horizontally
        y={533} // Center vertically
        fontSize="14"
        fontWeight="bold"
        fill="black"
        textAnchor="start"
        alignmentBaseline="middle" // Ensures vertical centering
      >
        {'EMG'}
      </text> */}

          {safetyComponents.map((alert, index) => (
            // <></>
            <SVGAlert
              key={index}
              id={index}
              x={alert.x}
              y={alert.y}
              label={alert.label}
              error={alert.error}
              scale={scale}
            />
          ))}

          {emergencyStates.map((emgState) => (
            <EmergencyState
              x={emgState.emergencyStateX ? emgState.emergencyStateX : emgState.x1}
              y={emgState.emergencyStatey ? emgState.emergencyStatey : emgState.y}
              error={emgState.emergencyStateActive}
              radius={emgState.radius}
              key={emgState.id}
              id={emgState.id}
            />
          ))}

          {StationNameTag.map((station) => (
            <StationNameTags
              key={station.id}
              x={station.x}
              y={station.y}
              label={station.label}
              error={station.error}
              customWidth={station?.width}
            />
          ))}
          {/*Drives*/}
          {drives.map((drive) => (
            <rect
              key={drive.id}
              id={drive.id}
              x={drive.x}
              y={drive.y}
              width={drive.width}
              height={drive.height}
              fill={drive.fill}
              stroke={drive.stroke}
              strokeWidth={drive.strokeWidth}
            />
          ))}

          <image
            key={"op1"}
            href={workerImage}
            x={1635}
            y={710}
            width="30"
            height="30"
          />

          {/* Robots inside the SVG */}
          {robots.map((robot) => {
            const isNotInUse = ["robot17", "robot18", "robot19", "robot20"].includes(robot.id);
            return (
              <image
                id={robot.id}
                key={robot.id}
                href={robotImage}
                x={robot.x}
                y={robot.y}
                width="60"
                height="60"
                style={{
                  filter: isNotInUse ? "grayscale(100%)" : "none",
                  opacity: isNotInUse ? 0.4 : 1,
                  pointerEvents: "none"  // Optional: disables interaction
                }}
              />
            );
          })}


          {/* Render doors dynamically */}
          {safetyGates.map((gate) => (
            <SafetyGate
              key={gate.id}
              x1={gate.x1}
              x2={gate.x2}
              y={gate.y}
              isOpened={gate.isOpened}
              isBottomGate={gate.isBottomGate}
              isLeftGate={gate.isLeftGate}
              isLeftOpen={gate.isLeftOpen}
              id={gate.id}
            />
          ))}
        </>


        <image
          id={"Cabin1"}
          key={"Cabin1"}
          href={CabinImage}
          x={270}
          y={190}
          width="40"
          height="40"
          onMouseEnter={(e) => handleMouseEnter(e, "C0001", 220, 160)}
          onMouseLeave={handleMouseLeave}
        />
        <image
          id={"Cabin2"}
          key={"Cabin2"}
          href={CabinImage}
          x={590}
          y={190}
          width="40"
          height="40"
          onMouseEnter={(e) => handleMouseEnter(e, "C0002", 540, 160)}
          onMouseLeave={handleMouseLeave}
        />
        <image
          id={"Cabin3"}
          key={"Cabin3"}
          href={CabinImage}
          x={900}
          y={190}
          width="40"
          height="40"
          onMouseEnter={(e) => handleMouseEnter(e, "C0003", 850, 160)}
          onMouseLeave={handleMouseLeave}
        />
        <image
          id={"Cabin4"}
          key={"Cabin4"}
          href={CabinImage}
          x={1130}
          y={190}
          width="40"
          height="40"
          onMouseEnter={(e) => handleMouseEnter(e, "C0004", 1080, 160)}
          onMouseLeave={handleMouseLeave}
        />
        <>
          <line
            id="1"
            x1="15"
            x2="135"
            y1="45"
            y2="45"
            stroke="#4608B2"
            strokeWidth="4"
          />
          <line
            id="2"
            x1="135"
            x2="135"
            y1="43"
            y2="200"
            stroke="#4608B2"
            strokeWidth="4"
          />
          <line
            id="3"
            x1="15"
            x2="15"
            y1="83"
            y2="275"
            stroke="#4608B2"
            strokeWidth="4"
          />

          <line
            id="4"
            x1="135"
            x2="227"
            y1="135"
            y2="135"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>
         
<line id="5" x1="225" x2="270" y1="100" y2="100" stroke="#4608B2"strokeWidth="4"></line>

          <line
            id="7"
            x1="135"
            x2="135"
            y1="271"
            y2="380"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>
          <line
            id="8"
            x1="225"
            x2="385"
            y1="378"
            y2="378"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>
          <line
            id="8.5"
            x1="135"
            x2="175"
            y1="378"
            y2="378"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>
          <line
            id="9"
            x1="17"
            x2="133"
            y1="273"
            y2="273"
            stroke="gray"
            strokeWidth="4"
          ></line>
          <line
            id="10"
            x1="36"
            x2="45"
            y1="276"
            y2="276"
            stroke="gray"
            strokeWidth="5"
          ></line>
          <line
            id="11"
            x1="90"
            x2="100"
            y1="276"
            y2="276"
            stroke="gray"
            strokeWidth="5"
          ></line>

          <line
            id="12LC8"
            x1="17"
            x2="65"
            y1="280"
            y2="280"
            stroke="green"
            strokeWidth="4"
          ></line>
          <line
            id="13LC8"
            x1="70"
            x2="120"
            y1="280"
            y2="280"
            stroke="green"
            strokeWidth="4"
          ></line>
          <line
            id="14LC8"
            x1="17"
            x2="65"
            y1="310"
            y2="310"
            stroke="green"
            strokeWidth="4"
          ></line>
          <line
            id="15LC8"
            x1="70"
            x2="120"
            y1="310"
            y2="310"
            stroke="green"
            strokeWidth="4"
          ></line>
          <line
            id="16"
            x1="36"
            x2="46"
            y1="314"
            y2="314"
            stroke="gray"
            strokeWidth="5"
          ></line>
          <line
            id="17"
            x1="90"
            x2="100"
            y1="314"
            y2="314"
            stroke="gray"
            strokeWidth="5"
          ></line>

          <line
            id="18"
            x1="266"
            x2="360"
            y1="100"
            y2="100"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>
          <line
            id="19"
            x1="362"
            x2="362"
            y1="75"
            y2="200"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>
          <line
            id="20"
            x1="402"
            x2="402"
            y1="20"
            y2="76"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>
          <line id="20.5" x1="360" x2="404" y1="75" y2="75" stroke="#4608B2"strokeWidth="4"></line>
          <line
            id="21"
            x1="482"
            x2="482"
            y1="20"
            y2="70"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>
          <line
            id="22"
            x1="480"
            x2="570"
            y1="70"
            y2="70"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>
          <line
            id="23"
            x1="568"
            x2="568"
            y1="20"
            y2="70"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>

          <line
            id="24LC1"
            x1="469"
            x2="476"
            y1="30"
            y2="30"
            stroke="gray"
            strokeWidth="8"
          ></line>
          <line
            id="25LC1"
            x1="409"
            x2="415"
            y1="30"
            y2="30"
            stroke="gray"
            strokeWidth="8"
          ></line>

          <line
            id="26LC1"
            x1="416"
            x2="416"
            y1="10"
            y2="50"
            stroke="green"
            strokeWidth="4"
          ></line>
          <line
            id="ML20RS4"
            x1="416"
            x2="468"
            y1="0"
            y2="0"
            stroke="#fc9d03"
            strokeWidth="4"
          ></line>
          <line
            id="28LC1"
            x1="468"
            x2="468"
            y1="10"
            y2="50"
            stroke="green"
            strokeWidth="4"
          ></line>

          <line
            id="29"
            x1="655"
            x2="655"
            y1="20"
            y2="85"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>
          <line
            id="30LC2"
            x1="574"
            x2="580"
            y1="30"
            y2="30"
            stroke="gray"
            strokeWidth="8"
          ></line>
          <line
            id="31LC2"
            x1="642"
            x2="648"
            y1="30"
            y2="30"
            stroke="gray"
            strokeWidth="8"
          ></line>
          <line
            id="32LC2"
            x1="582"
            x2="582"
            y1="10"
            y2="50"
            stroke="green"
            strokeWidth="4"
          ></line>
          <line
            id="ML20RS5"
            x1="582"
            x2="640"
            y1="0"
            y2="0"
            stroke="#fc9d03"
            strokeWidth="4"
          ></line>
          <line
            id="33LC2"
            x1="640"
            x2="640"
            y1="10"
            y2="50"
            stroke="green"
            strokeWidth="4"
          ></line>

          <line
            id="34"
            x1="704"
            x2="704"
            y1="20"
            y2="108"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>
          <line
            id="35"
            x1="790"
            x2="790"
            y1="85"
            y2="107"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>
          <line
            id="36"
            x1="702"
            x2="790"
            y1="107"
            y2="107"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>
          <line
            id="37"
            x1="790"
            x2="790"
            y1="67"
            y2="109"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>
          <line
            id="38"
            x1="835"
            x2="835"
            y1="67"
            y2="109"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>
           <line
            id="38.5"
            x1="835"
            x2="888"
            y1="107"
            y2="107"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>
          <line
            id="39"
            x1="980"
            x2="1020"
            y1="107"
            y2="107"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>
          <line
            id="40"
            x1="1020"
            x2="1020"
            y1="105"
            y2="139"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>
          <line
            id="41"
            x1="1018"
            x2="1106"
            y1="139"
            y2="139"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>
          <line
            id="42"
            x1="1106"
            x2="1106"
            y1="98"
            y2="141"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>

          <line
            id="43"
            x1="1142"
            x2="1142"
            y1="97"
            y2="140"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>
          <line
            id="44"
            x1="1140"
            x2="1525"
            y1="139"
            y2="139"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>
          <line
            id="45"
            x1="1225"
            x2="1225"
            y1="140"
            y2="200"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>
          <line
            id="46"
            x1="990"
            x2="990"
            y1="105"
            y2="200"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>
          <line
            id="47"
            x1="750"
            x2="750"
            y1="105"
            y2="200"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>

          <line
            id="47.1"
            x1="1225"
            x2="1225"
            y1="280"
            y2="340"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>
          <line
            id="48"
            x1="1150"
            x2="1410"
            y1="340"
            y2="340"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>
          <line
            id="49"
            x1="990"
            x2="1114"
            y1="340"
            y2="340"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>
          <line
            id="50"
            x1="1152"
            x2="1152"
            y1="342"
            y2="380"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>
          <line
            id="51"
            x1="1112"
            x2="1112"
            y1="342"
            y2="380"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>
          {/* <line id="52" x1="1003" x2="1003" y1="315" y2="340" stroke="#4608B2" strokeWidth="4"></line>
      <line id="53" x1="990" x2="1002" y1="317" y2="317" stroke="#4608B2" strokeWidth="4"></line> */}
          <line
            id="54"
            x1="990"
            x2="990"
            y1="280"
            y2="342"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>

          <line
            id="55"
            x1="753"
            x2="753"
            y1="280"
            y2="405"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>
          <line
              id="56"
              x1="733"
              x2="830"
              y1="407"
              y2="407"
              stroke="#4608B2"
              strokeWidth="4"
            ></line>
          <line
            id="57"
            x1="731"
            x2="731"
            y1="405"
            y2="465"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>

          <line
            id="58"
            x1="667"
            x2="667"
            y1="405"
            y2="425"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>
          <line
            id="59"
            x1="641"
            x2="641"
            y1="422"
            y2="465"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>
          <line
            id="60"
            x1="640"
            x2="665"
            y1="423"
            y2="423"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>

          <line
            id="61"
            x1="528"
            x2="528"
            y1="405"
            y2="465"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>
          <line
            id="62"
            x1="468"
            x2="530"
            y1="405"
            y2="405"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>
          <line
            id="63"
            x1="604" // ........Last update
            x2="604" // ........Last update
            y1="422" // ........Last update
            y2="465" // ........Last update
            stroke="#4608B2"
            strokeWidth="4"
          ></line>
          <line
            id="64"
            x1="470"
            x2="470"
            y1="405"
            y2="465"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>

          <line
            id="65"
            x1="385"
            x2="385"
            y1="376"
            y2="465"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>

            <line
              id="66"
              x1="830"
              x2="830"
              y1="440"
              y2="650"
              stroke="#4608B2"
              strokeWidth="4"
            ></line>

          <line
            id="67"
            x1="362"
            x2="362"
            y1="280"
            y2="376"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>
          <line
            id="68"
            x1="13"
            x2="135"
            y1="320"
            y2="320"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>
          <line
            id="69"
            x1="830"
            x2="930"
            y1="500"
            y2="500"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>
          <line
              id="70"
              x1="1050"
              x2="1050"
              y1="340"
              y2="610"
              stroke="#4608B2"
              strokeWidth="4"
            ></line>
          {/* <line
            id="71"
            x1="1050"
            x2="1050"
            y1="590"
            y2="650"
            stroke="#4608B2"
            strokeWidth="4"
          ></line> */}
          <line
              id="72"
              x1="1048"
              x2="1100"
              y1="610"
              y2="610"
              stroke="#4608B2"
              strokeWidth="4"
            ></line>
             <line
              id="73"
              x1="830"
              x2="830"
              y1="680"
              y2="750"
              stroke="#4608B2"
              strokeWidth="4"
            ></line>
          <line
              id="74"
              x1="830"
              x2="1050"
              y1="750"
              y2="750"
              stroke="#4608B2"
              strokeWidth="4"
            ></line>

          <line
            id="75"
            x1="1377"
            x2="1377"
            y1="137"
            y2="200"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>
          <line
            id="76"
            x1="1377"
            x2="1377"
            y1="280"
            y2="400"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>

          {/* hemming */}
          <line
            id="77"
            x1="1440"
            x2="1650"
            y1="800"
            y2="800"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>
          <line
            id="78"
            x1="1350"
            x2="1650"
            y1="650"
            y2="650"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>
          <line
            id="79"
            x1="1348"
            x2="1400"
            y1="800"
            y2="800"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>
          <line
            id="80"
            x1="1650"
            x2="1650"
            y1="648"
            y2="700"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>
          <line
            id="81"
            x1="1650"
            x2="1650"
            y1="750"
            y2="802"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>
          {/* hemming end */}

          <line
            id="82LC3"
            x1="400"
            x2="400"
            y1="405"
            y2="450"
            stroke="green"
            strokeWidth="4"
          ></line>
          <line
            id="ML20RS1"
            x1="400"
            x2="454"
            y1="460"
            y2="460"
            stroke="#fc9d03"
            strokeWidth="4"
          ></line>
          <line
            id="83LC3"
            x1="454"
            x2="454"
            y1="405"
            y2="450"
            stroke="green"
            strokeWidth="4"
          ></line>
          <line
            id="84LC3"
            x1="392"
            x2="398"
            y1="425"
            y2="425"
            stroke="gray"
            strokeWidth="8"
          ></line>
          <line
            id="85LC3"
            x1="456"
            x2="462"
            y1="425"
            y2="425"
            stroke="gray"
            strokeWidth="8"
          ></line>

          <line
            id="85LC4"
            x1="542" // ........Last update
            x2="542" // ........Last update
            y1="414"
            y2="450"
            stroke="green"
            strokeWidth="4"
          ></line>
          <line
            id="ML20RS2"
            x1="540" // ........Last update
            x2="592" // ........Last update
            y1="460"
            y2="460"
            stroke="#fc9d03"
            strokeWidth="4"
          ></line>
          <line
            id="86LC4"
            x1="590" // ........Last update
            x2="590"  // ........Last update
            y1="414"
            y2="450"
            stroke="green"
            strokeWidth="4"
          ></line>
          <line
            id="87LC4"
            x1="534" // ........Last update
            x2="540" // ........Last update
            y1="432"
            y2="432"
            stroke="gray"
            strokeWidth="8"
          ></line>
          <line
            id="88LC4"
            x1="592" // ........Last update
            x2="598" // ........Last update
            y1="432"
            y2="432"
            stroke="gray"
            strokeWidth="8"
          ></line>

          <line
            id="89LC5"
            x1="680"
            x2="680"
            y1="405"
            y2="450"
            stroke="green"
            strokeWidth="4"
          ></line>
          <line
            id="ML20RS3"
            x1="680"
            x2="715"
            y1="460"
            y2="460"
            stroke="#fc9d03"
            strokeWidth="4"
          ></line>

          <line
            id="90LC5"
            x1="715"
            x2="715"
            y1="405"
            y2="450"
            stroke="green"
            strokeWidth="4"
          ></line>
          <line
            id="91LC5"
            x1="672"
            x2="678"
            y1="424"
            y2="424"
            stroke="gray"
            strokeWidth="8"
          ></line>
          <line
            id="92LC5"
            x1="717"
            x2="723"
            y1="424"
            y2="424"
            stroke="gray"
            strokeWidth="8"
          ></line>

<line
              id="92LC6"
              x1="1000"
              x2="1048"
              y1="695"
              y2="695"
              stroke="green"
              strokeWidth="4"
            ></line>
            <line
              id="93LC6"
              x1="1000"
              x2="1048"
              y1="735"
              y2="735"
              stroke="green"
              strokeWidth="4"
            ></line>
            <line
              id="94LC6"
              x1="1021"
              x2="1027"
              y1="689"
              y2="689"
              stroke="gray"
              strokeWidth="8"
            ></line>
            <line
              id="95LC6"
              x1="1021"
              x2="1027"
              y1="740"
              y2="740"
              stroke="gray"
              strokeWidth="8"
            ></line>

          <line
            id="96LC7"
            x1="1633"
            x2="1668"
            y1="705"
            y2="705"
            stroke="green"
            strokeWidth="4"
          ></line>
          <line
            id="97LC7"
            x1="1633"
            x2="1668"
            y1="745"
            y2="745"
            stroke="green"
            strokeWidth="4"
          ></line>

          <line
            id="98"
            x1="1350"
            x2="1350"
            y1="648"
            y2="800"
            stroke="#4608B2"
            strokeWidth="4"
          ></line>

            {/* runstand */}
            <line
              id="99"
              x1="1060"
              x2="1060"
              y1="690"
              y2="740"
              stroke="#fc9d03"
              strokeWidth="4"
            ></line>
            <line
              id="100"
              x1="1680"
              x2="1680"
              y1="705"
              y2="745"
              stroke="#fc9d03"
              strokeWidth="4"
            ></line>


          <line id="101" x1="1375" x2="1430" y1="400" y2="400" stroke="#4608B2" strokeWidth="4"></line>
          <line id="102" x1="1470" x2="1527" y1="400" y2="400" stroke="#4608B2" strokeWidth="4"></line>
          <line id="103" x1="1525" x2="1525" y1="137" y2="200" stroke="#4608B2" strokeWidth="4"></line>
          <line id="104" x1="1525" x2="1525" y1="280" y2="400" stroke="#4608B2" strokeWidth="4"></line>

          <line id="105LC" x1="1415" x2="1415" y1="320" y2="365" stroke="green" strokeWidth="4"></line>
          <line id="106LC" x1="1485" x2="1485" y1="320" y2="365" stroke="green" strokeWidth="4" />

          <line id="107" x1="1490" x2="1527" y1="340" y2="340" stroke="#4608B2" strokeWidth="4"></line>

          <line id="108" x1="1000" x2="1100" y1="680" y2="680" stroke="#4608B2" strokeWidth="4"></line>


          <line
            id="109LC7"
            x1="1048"
            x2="1100"
            y1="625"
            y2="625"
            stroke="green"
            strokeWidth="4"
          ></line>
            <line
              id="110LC7"
              x1="1048"
              x2="1100"
              y1="665"
              y2="665"
              stroke="green"
              strokeWidth="4"
            ></line>
            <line
              id="111LC6"
              x1="1074"
              x2="1080"
              y1="620"
              y2="620"
              stroke="gray"
              strokeWidth="8"
            ></line>
          <line
            id="112LC6"
            x1="1074"
            x2="1080"
            y1="670"
            y2="670"
            stroke="gray"
            strokeWidth="8"
          ></line>

          <line
            id="113RunStand"
            x1="1110"
            x2="1110"
            y1="620"
            y2="670"
            stroke="#fc9d03"
            strokeWidth="4"
          ></line>






          <line
            id="114LC2"
            x1="895"
            x2="901"
            y1="77"
            y2="77"
            stroke="gray"
            strokeWidth="8"
          ></line>
          <line
            id="115LC2"
            x1="968"
            x2="974"
            y1="77"
            y2="77"
            stroke="gray"
            strokeWidth="8"
          ></line>
          <line
            id="116LC2"
            x1="901"
            x2="901"
            y1="55"
            y2="95"
            stroke="green"
            strokeWidth="4"
          ></line>
          <line
            id="ML30RS1"
            x1="901"
            x2="968"
            y1="45"
            y2="45"
            stroke="#fc9d03"
            strokeWidth="4"
          ></line>
          <line
            id="117LC2"
            x1="968"
            x2="968"
            y1="55"
            y2="95"
            stroke="green"
            strokeWidth="4"
          ></line>

<line id="118" x1="888" x2="888" y1="67" y2="109" stroke="#4608B2" stroke-width="4"></line>
<line id="119" x1="980" x2="980" y1="67" y2="109" stroke="#4608B2" stroke-width="4"></line>


                </>
            <image href={MotorIcon} height={40} width={40} x={90} y={223} id={1}/> 
            <image href={MotorIcon} height={40} width={40} x={35} y={195} id={2}/> 
            <image href={MotorIcon} height="40" width="40" x="230" y="195" id={3}></image>
            <image href={MotorIcon} height="40" width="40" x="350" y="220" id={5}></image>
            <image href={MotorIcon} height={40} width={40} x={230} y={250} id={6}/>
            <image href={MotorIcon} height="40" width="40" x="530" y="195" id={7}></image>
            <image href={MotorIcon} height="40" width="40" x="530" y="250" id={8}></image>
            <image href={MotorIcon} height="40" width="40" x="730" y="220" id={9}></image>
            <image href={MotorIcon} height="40" width="40" x="850" y="195" id={10}></image>
            <image href={MotorIcon} height="40" width="40" x="850" y="250" id={11}></image>
            <image href={MotorIcon} height="40" width="40" x="970" y="220" id={12}></image>
            <image href={MotorIcon} height="40" width="40" x="1090" y="195" id="13"></image>
            {/* <image href={MotorIcon} height="40" width="40" x="1130" y="190" id="14"></image> */}
            <image href={MotorIcon} height="40" width="40" x="1090" y="250" id="15"></image>
            <image href={MotorIcon} height="40" width="40" x="1205" y="220" id="16"></image>
            <image href={MotorIcon} height="40" width="40" x="1292" y="250" id="17"></image>

        <image
          href={MotorIcon}
          height="40"
          width="40"
          x="1550"
          y="195"
          id="18"
        ></image>
        <image
          href={MotorIcon}
          height="40"
          width="40"
          x="1620"
          y="195"
          id="19"
        ></image>
        <image
          href={MotorIcon}
          height="40"
          width="40"
          x="1690"
          y="195"
          id="20"
        ></image>
        <image
          href={MotorIcon}
          height="40"
          width="40"
          x="1760"
          y="195"
          id="21"
        ></image>
        <image
          href={MotorIcon}
          height="40"
          width="40"
          x="1830"
          y="195"
          id="22"
        ></image>
        <image
          href={MotorIcon}
          height="40"
          width="40"
          x="1900"
          y="195"
          id="23"
        ></image>
        <image
          href={MotorIcon}
          height="40"
          width="40"
          x="1970"
          y="195"
          id="24"
        ></image>
        <image
          href={MotorIcon}
          height="40"
          width="40"
          x="2040"
          y="195"
          id="25"
        ></image>

        <image
          href={MotorIcon}
          height="40"
          width="40"
          x="2140"
          y="195"
          id="26"
        ></image>
        <image
          href={MotorIcon}
          height="40"
          width="40"
          x="2140"
          y="100"
          id="27"
        ></image>

        <image
          href={MotorIcon}
          height="40"
          width="40"
          x="1417"
          y="195"
          id="28"
        ></image>
        <image
          href={MotorIcon}
          height="40"
          width="40"
          x="1485"
          y="220"
          id="29"
        ></image>

        <rect
          id="1"
          x="345"
          y="218"
          width="50"
          height="45"
          fill="none"
          stroke="black"
          strokeWidth="2"
        ></rect>
        <rect
          id="2"
          x="725"
          y="218"
          width="50"
          height="45"
          fill="none"
          stroke="black"
          strokeWidth="2"
        ></rect>
        <rect
          id="3"
          x="965"
          y="218"
          width="50"
          height="45"
          fill="none"
          stroke="black"
          strokeWidth="2"
        ></rect>
        <rect
          id="4"
          x="1200"
          y="218"
          width="50"
          height="45"
          fill="none"
          stroke="black"
          strokeWidth="2"
        ></rect>
        <rect
          id="5"
          x="1480"
          y="218"
          width="50"
          height="45"
          fill="none"
          stroke="black"
          strokeWidth="2"
        ></rect>

        {/* MFL vertical ramp */}
        <line
          id="1"
          x1="2100"
          x2="2100"
          y1="82"
          y2="175"
          stroke="#4608B2"
          strokeWidth="4"
        />
        <line
          id="2"
          x1="2230"
          x2="2230"
          y1="45"
          y2="305"
          stroke="#4608B2"
          strokeWidth="4"
        />
        <line
          id="3"
          x1="2098"
          x2="2232"
          y1="45"
          y2="45"
          stroke="#4608B2"
          strokeWidth="4"
        />
        <line
          id="4"
          x1="2098"
          x2="2232"
          y1="305"
          y2="305"
          stroke="#4608B2"
          strokeWidth="4"
        />
        <line
          id="5"
          x1="2100"
          x2="2100"
          y1="279"
          y2="305"
          stroke="#4608B2"
          strokeWidth="4"
        />
        {/* MFL vertical ramp safty door */}
        <line
          id="1"
          x1="2080"
          x2="2125"
          y1="275"
          y2="275"
          stroke="green"
          strokeWidth="4"
        />
        <line
          id="2"
          x1="2080"
          x2="2125"
          y1="180"
          y2="180"
          stroke="green"
          strokeWidth="4"
        />

        {/* <text
        x={2000} // Center horizontally
        y={500} // Center vertically
        fontSize="18"
        fontWeight="bold"
        fill="black"
        textAnchor="end"
        alignmentBaseline="middle" // Ensures vertical centering
      >
        {'Daily Target'}
      </text> */}

        <defs>
          <filter id="shadow" x="-10%" y="-10%" width="120%" height="120%">
            <feDropShadow dx="2" dy="2" stdDeviation="3" floodColor="gray" />
          </filter>
        </defs>

        {data.map((row, rowIndex) => {
          const cellX = tableStartX;
          const cellY = tableStartY + rowIndex * (cellHeight + cellSpacing); // Adds spacing
          const textY = cellY + cellHeight / 2; // Center both texts

          return (
            <g key={rowIndex}>
              {/* Background Styling with Shadow */}
              <rect
                x={cellX}
                y={cellY}
                width={cellWidth}
                height={cellHeight}
                fill="white" // White background
                stroke="gray" // Gray border
                strokeWidth="1"
                rx={borderRadius}
                ry={borderRadius}
                filter="url(#shadow)" // Apply shadow effect
              />
              {/* Centered Label and Value */}
              <text
                x={cellX + cellWidth / 2}
                y={textY - 15} // Shift label slightly up
                dominantBaseline="middle"
                textAnchor="middle"
                fontSize="22"
                fontWeight="bold"
                fill="black"
              >
                {row.label}
              </text>
              <text
                x={cellX + cellWidth / 2}
                y={textY + 20} // Shift value slightly down
                dominantBaseline="middle"
                textAnchor="middle"
                fontSize="22"
                fill="black"
                fontWeight="bold"
              >
                {row.value}
              </text>
            </g>
          );
        })}

        {tooltip.visible && (
          <g>
            {/* Tooltip background */}
            <rect
              x={tooltip.x}
              y={tooltip.y - 25}
              width="150"
              height="50"
              rx="5"
              ry="5"
              fill="#F3F4F6"
              opacity="0.8"
              stroke="black"
              filter="url(#shadow)"
            />
            {/* Tooltip text */}
            <text
              x={tooltip.x + 45}
              y={tooltip.y}
              fill="black"
              fontSize="20"
              fontWeight={"bold"}
              dominantBaseline="middle"
              textAnchor="start"
            >
              {tooltip.text}
            </text>
          </g>
        )}

      </svg>
    </div>
  );
}

export default Pro2000Layout