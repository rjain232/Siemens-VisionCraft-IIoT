const ShiftSelector = ({ value, onChange }) => {
    return (
      <select
        value={value}
        onChange={onChange}
        className="block w-auto px-4 py-2 text-gray-700 bg-white border border-gray-300 rounded-lg shadow-sm focus:ring focus:ring-indigo-500 focus:border-indigo-500"
        >
        <option value="" className="font-bold">
          Select Shift
        </option>
        <option value="A">Shift A</option>
        <option value="B">Shift B</option>
        <option value="C">Shift C</option>
      </select>
    );
  };
  
  export default ShiftSelector;
  