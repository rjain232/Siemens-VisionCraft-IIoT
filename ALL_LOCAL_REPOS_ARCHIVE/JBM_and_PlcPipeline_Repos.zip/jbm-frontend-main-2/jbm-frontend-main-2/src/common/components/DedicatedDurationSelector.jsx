const DedicatedDurationSelector = ({ value, onChange }) => {
    return (
      <select
        value={value}
        onChange={onChange}
        className="block w-auto px-4 py-2 text-gray-700 bg-white border border-gray-300 rounded-lg shadow-sm focus:ring focus:ring-indigo-500 focus:border-indigo-500"
        >
        <option value="" className="font-bold">
          Select Duration
        </option>
        <option value="Daily">Day Wise</option>
        <option value="Monthly">Month Wise</option>
      </select>
    );
  };
  
  export default DedicatedDurationSelector;
  