import PropTypes from "prop-types";
import React, { useState } from "react";

const MultiSelectDropdown = ({ options, label, placeholder, onChange }) => {
  const [selectedOptions, setSelectedOptions] = useState([]);
  const [isOpen, setIsOpen] = useState(false);

  const toggleDropdown = () => {
    setIsOpen(!isOpen);
  };

  const handleOptionClick = (option) => {
    const isSelected = selectedOptions.includes(option);
    const updatedSelections = isSelected
      ? selectedOptions.filter((item) => item !== option)
      : [...selectedOptions, option];

    setSelectedOptions(updatedSelections);
    if (onChange) {
      onChange(updatedSelections);
    }
  };

  return (
    <div className="relative w-full max-w-sm flex col-auto place-items-center">
      {label && (
        <label className="block text-sm font-medium text-gray-700 mb-1">
          {label}
        </label>
      )}
      <div
        className="block w-full ml-6 px-4 py-2 text-gray-700 bg-white border border-gray-300 rounded-lg shadow-sm cursor-pointer focus:ring focus:ring-indigo-500 focus:border-indigo-500"
        onClick={toggleDropdown}
      >
        {selectedOptions.length > 0
          ? selectedOptions.join(", ")
          : placeholder || "Select options"}
      </div>

      {isOpen && (
        <ul className="absolute z-10 mt-2  w-full bg-white border border-gray-300 rounded-lg shadow-lg max-h-60 overflow-y-auto">
          {options?.map((option, index) => (
            <li
              key={index}
              className={`px-4 py-2 cursor-pointer hover:bg-indigo-100 ${
                selectedOptions.includes(option)
                  ? "bg-indigo-500 text-white"
                  : ""
              }`}
              onClick={() => handleOptionClick(option)}
            >
              {option}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

MultiSelectDropdown.propTypes = {
  options: PropTypes.array.isRequired,
  label: PropTypes.string,
  placeholder: PropTypes.string,
  onChange: PropTypes.func.isRequired,
};

export default MultiSelectDropdown;
