import React from 'react'
import HemmingLayoutImage from "../../assets/HemmingLayout.svg"
import robotImage from "../../assets/robotic-arm (1).png"
import SVGAlert from './SVGAlert';

const HemmingLayout = () => {
    const safetyComponents =[
        {
            id:2,
            name:"Run Stand 1",
            label:"Run",
            label2:"Stand 1",
            x:"370",
            y:"-15",
            error:true
        },
        {
            id:3,
            name:"Light Curtain 1",
            label:"LC 1",
            x:"370",
            y:"40",
            error:false
        },
        {
            id:1,
            name:"Safety Gate 1",
            label:"S.G - 1",
            x:"10",
            y:"5",
            error:false
        },
        
      
      ];
  return (
  <svg className="absolute left-[1380px] top-[720px] " x="750" y="450" height={400} width={650}>
       <image href={HemmingLayoutImage} width="90%" height="90%" />
       <image href={robotImage} height={50} width={50} x="120" y="175"/>
       {safetyComponents.map((alert, index) => (
        <SVGAlert
          key={index}
          x={alert.x}
          y={alert.y}
          label={alert.label}
          label2={alert.label2}
          error={alert.error}
        />
      ))}
     <text x="275" y="370" fontSize="18" fill="black">{"HEMMING"}</text>
       </svg>  )
}

export default HemmingLayout