import React from 'react'
import {motion} from "framer-motion";

const EmergencyState = ({id,x,y,error ,radius}) => {
  return (
   
    <motion.circle
      id={id}
      cx={x}
      cy={y}
      r={radius ? radius :"20"} /* Rounded corners */
      stroke={"black"}
      strokeWidth={2}
      fill={error ? "red" : "white"} /* Background color */
      animate={error ? { opacity: [1, 0, 1] } : { opacity: 1 }}
      transition={error &&{ repeat: Infinity, duration: 1, ease: "linear" }}
      
    />

  )
}

export default EmergencyState