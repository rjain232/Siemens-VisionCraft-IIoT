import React from 'react'
import { motion } from 'framer-motion'
import WarningIcon from "../../assets/warning.png"

const SVGAlert = ({x,y,label,label2 ,error,  id}) => {
  return (
   <>
    {/* Background rectangle */}
    <motion.rect
      id={id}
      x={x}
      y={y}
      width="60"
      height="40"
      rx="5" /* Rounded corners */
      fill={error ? "red" : "green"} /* Background color */
      animate={error ? { opacity: [1, 0, 1] }  : {opacity : 1}}
      transition={error &&{ repeat: Infinity, duration: 1, ease: "linear" }}
    />
  
    {/* Blinking effect for error state */}
    {/* {error && (
      <animate
        xlinkHref="#textLabel"
        attributeName="opacity"
        values="1;0.5;1"
        dur="1s"
        repeatCount="indefinite"
      />
    )} */}
  
    {/* Label text */}
    <text
      id={id}
      x={x+30}
      y={y+20}
      fontSize="12"
      fontWeight="bold"
      fill="white"
      textAnchor="middle"
      dominantBaseline="middle"
      
    >
      {label}
    </text>
  
    {/* Additional text if label2 exists */}
    {label2 && (
      <text
        x="40"
        y="45"
        fontSize="12"
        fontWeight="bold"
        fill="white"
        textAnchor="middle"
        dominantBaseline="middle"
      >
        {label2}
      </text>
    )}
  </>
  
  )
}

export default SVGAlert