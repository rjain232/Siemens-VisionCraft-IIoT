import { useState } from "react";
import DateTimePicker from "./DateTimePicker";
import Button from "./Button";
import { Download, Search } from "lucide-react";
import PropTypes from "prop-types";
import { formatDate } from "../../utils/Formatters";
import "./DateRangeSelector.css";
import DurationSelector from "./DurationSelector ";
import ShiftSelector from "./ShiftSelector";
import DedicatedDurationSelector from "./DedicatedDurationSelector";
import { validateDateRange } from "../../utils/validators";
import toast from "react-hot-toast";
import { endOfWeek, startOfWeek } from "date-fns";

const getCurrentShift = () => {
   const now = new Date();

  const totalMinutes = now.getHours() * 60 + now.getMinutes();

  if (totalMinutes >= 360 && totalMinutes <= 899) {
    // 06:00 - 14:59
    return "A";
  } else if (totalMinutes >= 900 && totalMinutes <= 1409) {
    // 15:00 - 23:29
    return "B";
  } else {
    // 23:30 - 05:59
    return "C";
  }
}
const DateRangeSelector = ({
  onSearch,
  onDownload,
  showDuration = true,
  showDownload = true,
  showDate = true,
  showShift,
  activeTab, // Receiving activeTab to determine conditional rendering
  selectedStartDate,
  selectedEndDate,
  selectedDuration,
  selectedShift,
  isDownloading = false,
  TimeSelection = true
}) => {
  const [startDate, setStartDate] = useState(selectedStartDate || null);
  const [endDate, setEndDate] = useState(selectedEndDate || null);
  const [showTime] = useState(TimeSelection);
  const [duration, setDuration] = useState(selectedDuration || ""); // State for DurationSelector
  const [shift, setShift] = useState(selectedShift || getCurrentShift()); // State for ShiftSelector
  const [dedicatedDuration, setDedicatedDuration] = useState(""); // State for DedicatedDurationSelector

  const handleDurationChange = (value) => {
    setStartDate(null);
    setEndDate(null);
    setDuration(value);
  };

  return (
    <div className={`mb-4 w-full ${!showDate && "mt-4"}`}>
{
  showDate && (
    <div className="pb-2">
      {activeTab === "Downtime Report" ? (
        startDate && endDate
          ? `${formatDate(startDate)}  To  ${formatDate(endDate)}`
          : `${formatDate(startOfWeek(new Date(), { weekStartsOn: 1 }))}  To  ${formatDate(endOfWeek(new Date(), { weekStartsOn: 1 }))}`
      ) : (
        startDate && endDate
          ? `${formatDate(startDate)}  To  ${formatDate(endDate)}`
          : formatDate(new Date())
      )}
    </div>
  )
}
      <div className="flex justify-between items-center gap-4 w-fit">
        <div>
          <DateTimePicker
            selectedDate={startDate}
            onChange={setStartDate}
            showTime={showTime}
            placeholder="Select Start Date"
            disabled={duration !== ""}
            
          />
        </div>

        <div>
          <DateTimePicker
            selectedDate={endDate}
            onChange={setEndDate}
            showTime={showTime}
            placeholder="Select End Date"
            disabled={duration !== ""}
          />
        </div>

        {showDuration && activeTab === "Report" && (
          <div>
            <DurationSelector
              value={duration}
              onChange={(e) => handleDurationChange(e.target.value)}
              disabled={startDate !== null || endDate !== null}
            />
          </div>
        )}

        {/* Show Shift Selector only for Hourly Production Report */}
        {(activeTab === "Hourly Production Report" ||
          activeTab === "Overall OEE" ||
          activeTab === "Top 10 Faults") && (
          <div>
            <ShiftSelector
              value={shift}
              onChange={(e) => setShift(e.target.value)}
            />
          </div>
        )}

        {/* Show Dedicated Duration Selector only for Dedicated Production Report */}
        {activeTab === "Detail Production Report" && (
          <div>
            <DedicatedDurationSelector
              value={dedicatedDuration}
              onChange={(e) => setDedicatedDuration(e.target.value)}
            />
          </div>
        )}

        <div>
          <Button
            label="Search"
            onClick={() => {
              const { error, errorMsg } = validateDateRange(startDate, endDate , duration);
              if (error) {
                toast.error(errorMsg);
                return;
              }
              onSearch(startDate, endDate, duration, shift, dedicatedDuration);
            }}
            icon={Search}
            
          />
        </div>

        {showDownload && (
          <div>
            <Button
              label={isDownloading ? "Downloading..." : "Download"}
              onClick={() => onDownload()}
              bgColor="bg-white"
              textColor="text-purple-950 border border-purple-950"
              icon={Download}
            />
          </div>
        )}
      </div>
    </div>
  );
};

DateRangeSelector.propTypes = {
  onSearch: PropTypes.func.isRequired,
  onDownload: PropTypes.func.isRequired,
  showDuration: PropTypes.bool,
  showDownload: PropTypes.bool,
  showDate: PropTypes.bool,
  showShift: PropTypes.bool,
  activeTab: PropTypes.string, // Prop to determine which selector to show
  selectedStartDate: PropTypes.any,
};

export default DateRangeSelector;
