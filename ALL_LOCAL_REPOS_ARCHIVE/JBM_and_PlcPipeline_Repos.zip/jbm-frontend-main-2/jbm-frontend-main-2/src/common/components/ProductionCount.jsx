import React from 'react'

import DataTable from "./DataTable";
import withTable from "../../hoc/withTable";

const data = [
  {
    "Date": "10-02-2025",
    "Shift": "A",
    "Line Name": "A1",
    "Production Count": 1200,
    "Production Scrapped": 50
  },
  {
    "Date": "10-02-2025",
    "Shift": "B",
    "Line Name": "B2",
    "Production Count": 1350,
    "Production Scrapped": 75
  },
  {
    "Date": "10-02-2025",
    "Shift": "c",
    "Line Name": "C3",
    "Production Count": 1100,
    "Production Scrapped": 60
  },
  {
    "Date": "11-02-2025",
    "Shift": "A",
    "Line Name": "D4",
    "Production Count": 1450,
    "Production Scrapped": 90
  },
  {
    "Date": "11-02-2025",
    "Shift": "B",
    "Line Name": "E5",
    "Production Count": 1600,
    "Production Scrapped": 120
  },
  {
    "Date": "11-02-2025",
    "Shift": "c",
    "Line Name": "F6",
    "Production Count": 1250,
    "Production Scrapped": 80
  }
]

const columns = [
  { label: "Date", accessor: "Date" },
  { label: "Shift", accessor: "Shift" },
  { label: "Line Name", accessor: "Line Name" },
  { label: "Production Count", accessor: "Production Count" },
  { label: "Production Scrapped", accessor: "Production Scrapped" },
];


const ProductionCount = () => {
    const EnhancedTable = withTable(DataTable)

  return (
    
    <EnhancedTable
      data={data}
      columns={columns}
      enableSearch={true}
      enableFilter={false}
      enablePagination={true}
    />

  )
}

export default ProductionCount