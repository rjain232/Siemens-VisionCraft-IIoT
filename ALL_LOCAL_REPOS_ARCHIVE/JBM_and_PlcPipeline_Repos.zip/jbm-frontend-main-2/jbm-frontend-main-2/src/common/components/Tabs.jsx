import React, { useState } from "react";

const Tabs = ({ tabs, onTabChange }) => {
  const [activeTab, setActiveTab] = useState(tabs[0]);

  const handleTabClick = (tab) => {
    setActiveTab(tab);
    onTabChange(tab); // Notify parent component about tab change
  };

  return (
    <div className="border-b flex space-x-6">
      {tabs?.map((tab) => (
        <div
          key={tab}
          onClick={() => handleTabClick(tab)}
          className={`cursor-pointer py-2 px-4 ${
            activeTab === tab
              ? "border-b-2 border-purple-500 text-purple-500 font-semibold bg-white rounded-sm"
              : "text-gray-500 hover:text-gray-700"
          }`}
        >
          {tab}
        </div>
      ))}
    </div>
  );
};

export default Tabs;
