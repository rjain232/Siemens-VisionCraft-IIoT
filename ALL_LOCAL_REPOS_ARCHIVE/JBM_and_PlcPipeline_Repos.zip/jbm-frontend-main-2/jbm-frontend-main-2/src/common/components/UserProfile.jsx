import PropTypes from "prop-types";
import userIcon from "../../assets/user.png";

const UserProfile = ({ user , onBackHandler , onLogoutHandler , icon}) => {
  return (
    <div className="flex flex-col items-center text-center">
      <img
        src={userIcon ?? icon }
        alt="Profile"
        className="w-24 h-24 rounded-full border-2 border-purple-500"
      />
       <span className="inline-block bg-purple-200 text-purple-800 px-3 py-1 rounded-full mt-4 text-sm">
        {user?.Username}
      </span>
      <h2 className="text-xl font-semibold ">{`${user?.FirstName} ${user?.LastName}`}</h2>
      <p className="text-gray-600">{user?.Email}</p>
     
      <div className="mt-4 flex gap-4">
        <button className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700" onClick={onBackHandler}>
          Back
        </button>
        <button className="px-4 py-2 border-2 border-red-600 text-red-600 rounded-lg hover:bg-red-50 hover:text-red-700" onClick={onLogoutHandler}>
          Logout
        </button>
      </div>
    </div>
  );
};

UserProfile.propTypes = {
  user: PropTypes.shape({
    FirstName: PropTypes.string,
    LastName: PropTypes.string,
    Email: PropTypes.string.isRequired,
    Username: PropTypes.string.isRequired,
  }).isRequired,
  onBackHandler:PropTypes.func,
  onLogoutHandler:PropTypes.func
};

export default UserProfile;
