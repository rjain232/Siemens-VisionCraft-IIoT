import React from "react";
import { motion } from "framer-motion";

const StationNameTags = ({ x, y, label, error ,customWidth}) => {
  const width = customWidth ? customWidth :60; // Rectangle width
  const height = 30; // Rectangle height
  const centerX = x + width / 2; // Center X position
  const centerY = y + height / 2; // Center Y position

  return (
    <>
      {/* Outer Rounded Rectangle (Outline Only) */}
      <motion.rect
        x={x}
        y={y}
        width={width}
        height={height}
        rx="5" // Rounded corners
        fill="none" // Empty inside
        stroke="black"
        strokeWidth="1.5"
        animate={error && { opacity: [1, 0, 1] }}
        transition={error && { repeat: Infinity, duration: 1, ease: "linear" }}
      />

      {/* Centered Label */}
      <text
        x={centerX} // Center horizontally
        y={centerY} // Center vertically
        fontSize="14"
        fontWeight="bold"
        fill="black"
        textAnchor="middle"
        alignmentBaseline="middle" // Ensures vertical centering
      >
        {label}
      </text>
    </>
  );
};

export default StationNameTags;
