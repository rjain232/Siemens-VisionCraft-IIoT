import { useState, useEffect } from "react";
import PropTypes from "prop-types";

const TabWrapper = ({
  tabs = [],
  defaultTab = "",
  onTabChange,
  externalTab = null,
  stateSync = false,
  className = "",
}) => {
  const initialTab = defaultTab || tabs[0]?.key;
  const [activeTab, setActiveTab] = useState(initialTab);

  // Sync with externalTab if enabled
  useEffect(() => {
    if (stateSync && externalTab) {
      setActiveTab(externalTab);
    }
  }, [externalTab, stateSync]);

  const handleTabClick = (key) => {
    setActiveTab(key);
    onTabChange?.(key); // optional chaining
  };

  const currentTab = tabs.find((tab) => tab.key === activeTab);

  return (
    <>
      <div className="border-b flex space-x-2">
        {tabs.map(({ key, label }) => (
          <div
            key={key}
            onClick={() => handleTabClick(key)}
            className={`cursor-pointer py-2 px-4 ${
              key === activeTab
                ? "border-b-2 border-purple-500 text-purple-500 font-semibold bg-white rounded-sm"
                : "text-gray-500 hover:text-gray-700"
            }`}
          >
            {label}
          </div>
        ))}
      </div>

      <div className="mt-2">
        {currentTab?.component || null}
      </div>
   </>
  );
};
TabWrapper.propTypes = {
  tabs: PropTypes.arrayOf(
    PropTypes.shape({
      key: PropTypes.string.isRequired,
      label: PropTypes.node.isRequired,
      component: PropTypes.node,
    })
  ),
  defaultTab: PropTypes.string,
  onTabChange: PropTypes.func,
  externalTab: PropTypes.string,
  stateSync: PropTypes.bool,
  className: PropTypes.string,
};

export default TabWrapper;
