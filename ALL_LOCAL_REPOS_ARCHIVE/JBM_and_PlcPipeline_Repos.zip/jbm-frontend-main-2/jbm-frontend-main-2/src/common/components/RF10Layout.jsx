import React from 'react'
import RF10LayoutImage from '../../assets/RF10Layout.svg'
import robotImage from "../../assets/robotic-arm (1).png"
import SVGAlert from './SVGAlert';
import Safety from '../../pages/Safety';
import SafetyGate from './SafetyGate';

const RF10Layout = () => {
    const safetyComponents =[
        {
            id:1,
            name:"Safety Gate 2",
            label:"S.G - 2",
            x:"400",
            y:"10",
            error:false
        },
        {
            id:2,
            name:"Run Stand 1",
            label:"Run",
            label2:"Stand 1",
            x:"440",
            y:"110",
            error:true
        },
        {
            id:3,
            name:"Light Curtain / Operating",
            label:"LC /",
            label2:"Operating",
            x:"440",
            y:"175",
            error:false
        },
        {
            id:4,
            name:"Safety Gate 1",
            label:"S.G - 1",
            x:"45",
            y:"140",
            error:false
        }
      ];

    const safetyGates = [
        {
            id:1,
            name : "S.G - 1",
            x1:"70",
            x2:"120",
            y:"380",
            isOpened:true,
            isBottomGate:true
        },
    ]

  return (
  <svg className="absolute left-[800px] top-[500px] mt-10" x="750" y="450"  height={600} width={600}>
       <image href={RF10LayoutImage} height={"100%"} width={"80%"}/>
       <image href={robotImage} height={70} width={70} x="170" y="320"/>
       {safetyComponents.map((alert, index) => (
        <SVGAlert
          key={index}
          x={alert.x}
          y={alert.y}
          label={alert.label}
          label2={alert.label2}
          error={alert.error}
        />
      ))}
      {safetyGates.map((gate) => (
        <SafetyGate
          x1={gate.x1}
          x2={gate.x2}
          y={gate.y}
          isOpened={gate.isOpened}
          isBottomGate={gate.isBottomGate}
          isLeftGate={gate.isLeftGate}
          key={gate.id}
        />
      ))}
       <text x="275" y="570" fontSize="18" fill="black">{"RF_10"}</text>
       </svg>
  )
}

export default RF10Layout