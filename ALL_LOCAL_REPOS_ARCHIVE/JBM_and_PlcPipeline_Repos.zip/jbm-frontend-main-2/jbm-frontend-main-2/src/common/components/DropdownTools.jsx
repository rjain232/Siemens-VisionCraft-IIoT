import useAxios from "../../hooks/useAxios";

const DropdwonTools =({ value, onChange })=>{
   const {
    data: toolsData,
    loading: toolsDataLoading,
    error: toolsDataError,
  } = useAxios("/getTools", { method: "GET" }, true);
  
    return (
        <select
          value={value.value}
          onChange={onChange}
          className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5"
          style={{ width: "230px", paddingRight: "43px" }}
        >
          <option value="" className="font-bold">
            Select Tool
          </option>
        {!toolsDataLoading && toolsData?.map(item =>   <option key={item.ToolId} value={item.ToolId}>{item.ToolName}</option>) }
        </select>
      );
}
export default DropdwonTools;