import  { useState, useEffect, useRef } from "react";
import { FiChevronDown } from "react-icons/fi";
import PropTypes from "prop-types";

const MultiSelect = ({ options = [], label, placeholder, onChange }) => {
  const [selectedValues, setSelectedValues] = useState([]);
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef(null);

  const toggleDropdown = () => {
    setIsOpen(!isOpen);
  };

  const handleOptionClick = (option) => {
    const isSelected = selectedValues.includes(option.value);
    const updatedSelections = isSelected
      ? selectedValues.filter((val) => val !== option.value)
      : [...selectedValues, option.value];

    setSelectedValues(updatedSelections);
    if (onChange) {
      // Emit selected values
      onChange(updatedSelections);
    }
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const selectedLabels = options
    .filter((opt) => selectedValues.includes(opt.value))
    .map((opt) => opt.label);

  return (
    <div className="relative w-fit max-w-sm" ref={dropdownRef}>
      {label && (
        <label className="block text-sm font-medium text-gray-700 mb-1">
          {label}
        </label>
      )}
      <div
        className="flex items-center justify-between px-3 py-1.5 text-gray-700 bg-white border border-gray-300 rounded-lg shadow-sm cursor-pointer w-56  min-h-[2.5rem]"
        onClick={toggleDropdown}
      >
        <div className="flex-1 overflow-y-auto whitespace-normal break-words text-sm leading-tight">
          {selectedLabels.length > 0 ? (
            selectedLabels.join(", ")
          ) : (
            <span className="text-gray-400">{placeholder}</span>
          )}
        </div>
        <FiChevronDown
          className={`ms-2 flex-shrink-0 transition-transform ${
            isOpen ? "rotate-180" : ""
          }`}
        />
      </div>

      {isOpen && (
        <ul className="absolute z-10 mt-2 w-full bg-white border border-gray-300 rounded-lg shadow-lg max-h-60 overflow-y-auto">
          {options.map((option, index) => (
            <li
              key={index}
              className="flex items-center px-4 py-2 cursor-pointer hover:bg-indigo-100"
            >
              <input
                type="checkbox"
                checked={selectedValues.includes(option.value)}
                onChange={() => handleOptionClick(option)}
                className="mr-2"
              />
              {option.label}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};
MultiSelect.propTypes = {
  options: PropTypes.arrayOf(
    PropTypes.shape({
      value: PropTypes.any.isRequired,
      label: PropTypes.string.isRequired,
    })
  ),
  label: PropTypes.string,
  placeholder: PropTypes.string,
  onChange: PropTypes.func,
};
export default MultiSelect;
