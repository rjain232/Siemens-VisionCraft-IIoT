import PropTypes from "prop-types";
import { useState } from "react";

const DataTable = ({ data, columns ,onRowClick}) => {
  return (
    <table className="w-full text-sm border-collapse" id="table">
      <thead>
        <tr>
          <th
            key="sr_no"
            className="px-2 py-2 text-center font-medium border border-gray-300 tracking-wider bg-gray-50 text-red-950 min-w-[50px] w-[60px] whitespace-nowrap"
          >
            Sr. No
          </th>
          {columns.map((col) => (
            <th
              key={col.accessor}
              className="px-4 py-3 font-medium border border-gray-300 tracking-wider bg-gray-50 text-red-950 text-center"
            >
              {col.label}
            </th>
          ))}
        </tr>
      </thead>
      {data.length === 0 ? (
        <tbody>
          <tr>
            <td colSpan={columns.length + 1} className="border border-gray-300 px-4 py-3 bg-white text-center">
              No data available
            </td>
          </tr>
        </tbody>
      ) : (
        <tbody>
          {data.map((row, index) => (
            <tr key={row.Id} onClick={onRowClick ? ()=>onRowClick(row) : ()=>{}}>
              <td className="border border-gray-300 px-2 py-2 bg-white text-center min-w-[50px] w-[60px]">
                {index + 1}
            </td>
            {columns.map((col) => (
              <td key={col.accessor} className="border border-gray-300 px-4 py-3 bg-white text-center">
                {col.cellRenderer ? (
                 col.cellRenderer(row)
                ) : (
                  row[col.accessor]
                )}
              </td>
            ))}
          </tr>
        ))}
      </tbody>)}

    </table>
  );
};

// Add PropTypes validation
DataTable.propTypes = {
  data: PropTypes.arrayOf(PropTypes.object.isRequired).isRequired,
  columns: PropTypes.arrayOf(
    PropTypes.shape({
      label: PropTypes.string.isRequired,
      accessor: PropTypes.string.isRequired,
      cellRenderer: PropTypes.func,
    }).isRequired
  ).isRequired,
  onRowClick : PropTypes.func
};

export default DataTable;
