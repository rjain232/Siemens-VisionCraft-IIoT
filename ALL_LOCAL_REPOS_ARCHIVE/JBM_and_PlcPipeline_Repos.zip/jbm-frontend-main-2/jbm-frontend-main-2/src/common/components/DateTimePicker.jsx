import PropTypes from "prop-types";
import { forwardRef } from "react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

// eslint-disable-next-line react/display-name
const CustomInput = forwardRef(({ value, onClick, showTime }, ref) => (
  <div className="relative w-auto">
    {/* Calendar Icon */}
    <div className="absolute inset-y-0 start-0 flex items-center ps-3 pointer-events-none">
      <svg
        className="w-4 h-4 text-gray-500 dark:text-gray-400"
        aria-hidden="true"
        xmlns="http://www.w3.org/2000/svg"
        fill="currentColor"
        viewBox="0 0 20 20"
      >
        <path d="M20 4a2 2 0 0 0-2-2h-2V1a1 1 0 0 0-2 0v1h-3V1a1 1 0 0 0-2 0v1H6V1a1 1 0 0 0-2 0v1H2a2 2 0 0 0-2 2v2h20V4ZM0 18a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8H0v10Zm5-8h10a1 1 0 0 1 0 2H5a1 1 0 0 1 0-2Z" />
      </svg>
    </div>

    {/* Input Field */}
    <input        
      ref={ref}
      value={value}
      onClick={onClick}
      readOnly
      className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block ps-10 pr-1 py-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
      placeholder={showTime ? "DD-MM-YYYY HH:MM" : "DD-MM-YYYY"}
    />
  </div>
));

const DateTimePicker = ({ selectedDate, onChange, showTime ,disabled}) => {
  return (
    <DatePicker
      disabled={disabled || false}
      selected={selectedDate}
      onChange={onChange}
      showTimeSelect={showTime}
      timeFormat="HH:mm"
      isClearable={true}
      timeIntervals={15}
      dateFormat={showTime ? "dd-MM-yyyy HH:mm" : "dd-MM-yyyy"}
      customInput={<CustomInput showTime={showTime} />}
      className="mt-1 block w-auto border rounded-lg px-3 py-2 text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
    />
  );

};

CustomInput.propTypes = {
  value : PropTypes.string,
  onClick : PropTypes.func
}

DateTimePicker.propTypes = {
  selectedDate: PropTypes.instanceOf(Date),
  onChange: PropTypes.func.isRequired,
  showTime: PropTypes.bool,
  placeholder: PropTypes.string,
  disabled: PropTypes.bool,
};

export default DateTimePicker;
