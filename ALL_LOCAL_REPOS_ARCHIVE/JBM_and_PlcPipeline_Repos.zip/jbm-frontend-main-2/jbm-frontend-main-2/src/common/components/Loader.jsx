import { BallTriangle } from "react-loader-spinner";

const Loader = () => {
  return (
    <div className="flex justify-center items-center h-screen bg-gray-100">
        <BallTriangle color="purple"/>
    </div>
  );
};

export { Loader };
