import React from 'react'
import EmergencyState from './EmergencyState'
import PLCIcon from "../../assets/plc.png"

const PLCEmergencyBox = ({id , x, y , height , width}) => {
  return (
   <>
   <rect
           id={"HMI1Start"}
              x={-105}
              y={470}
              width="90"
              height="60"
              fill="none"
              stroke="black"
              strokeWidth="2"
              strokeDasharray="5,5" // Creates the dotted effect
            />
   </>
  )
}

export default PLCEmergencyBox