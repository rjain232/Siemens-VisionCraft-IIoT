import PropTypes from "prop-types";

const Pagination = ({
  currentPage,
  totalPages,
  onPageChange,
  visiblePageCount = 5,
  rowsPerPage,
  setRowsPerPage,
  rowsPerPageOptions = [5, 10, 20, 50], // Dropdown options for rows per page
}) => {
  const getPageNumbers = () => {
    const pages = [];
    const half = Math.floor(visiblePageCount / 2);
    const start = Math.max(1, currentPage - half);
    const end = Math.min(totalPages, currentPage + half);

    for (let i = start; i <= end; i++) {
      pages.push(i);
    }

    return pages;
  };

  const pageNumbers = getPageNumbers();

  return (
    <div className="flex flex-col md:flex-row md:items-center justify-between mt-4 space-y-4 md:space-y-0">
      {/* Left Section: Page Info */}
      <div className="text-sm text-gray-600">
        <span className="text-sm text-gray-600 me-2">Rows per page</span>
        <select
          value={rowsPerPage}
          onChange={(e) => setRowsPerPage(Number(e.target.value))}
          className="px-3 py-1 text-sm border rounded-md focus:ring focus:ring-blue-500"
        >
          {rowsPerPageOptions.map((option) => (
            <option key={option} value={option}>
              {option}
            </option>
          ))}
        </select>
      </div>

      {/* Right Section: Pagination */}
      <div className="flex items-center space-x-2">
        {/* Previous Button */}
        <button
          onClick={() => onPageChange(currentPage - 1)}
          disabled={currentPage === 1}
          className={`px-3 py-1 rounded-md ${
            currentPage === 1
              ? "bg-gray-200 text-gray-400 cursor-not-allowed"
              : "bg-blue-500 text-white hover:bg-blue-600"
          }`}
        >
          Previous
        </button>

        {/* Page Numbers */}
        {pageNumbers.map((page) => (
          <button
            key={page}
            onClick={() => onPageChange(page)}
            className={`px-3 py-1 rounded-md ${
              page === currentPage
                ? "bg-blue-600 text-white font-semibold"
                : "bg-gray-100 text-gray-600 hover:bg-blue-100"
            }`}
          >
            {page}
          </button>
        ))}

        {/* Next Button */}
        <button
          onClick={() => onPageChange(currentPage + 1)}
          disabled={currentPage === totalPages}
          className={`px-3 py-1 rounded-md ${
            currentPage === totalPages
              ? "bg-gray-200 text-gray-400 cursor-not-allowed"
              : "bg-blue-500 text-white hover:bg-blue-600"
          }`}
        >
          Next
        </button>
      </div>
    </div>
  );
};

Pagination.propTypes = {
  currentPage: PropTypes.number.isRequired, // Current active page
  totalPages: PropTypes.number.isRequired, // Total number of pages
  onPageChange: PropTypes.func.isRequired, // Callback to handle page changes
  visiblePageCount: PropTypes.number, // Number of page numbers to display
  rowsPerPage: PropTypes.number.isRequired, // Current rows per page count
  setRowsPerPage: PropTypes.func.isRequired, // Callback to change rows per page
  rowsPerPageOptions: PropTypes.arrayOf(PropTypes.number), // Array of rows per page options
};

// Default props for optional properties
Pagination.defaultProps = {
  visiblePageCount: 5, // Default to 5 visible page numbers
  rowsPerPageOptions: [5, 10, 20, 50], // Default rows per page options
};

export default Pagination;
