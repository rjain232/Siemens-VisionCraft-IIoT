import PropTypes from "prop-types";

const Button = ({
  label,
  onClick,
  bgColor = "bg-purple-900",
  textColor = "text-white",
  icon: Icon,
  className = "",
}) => {
  return (
    <button
      onClick={onClick}
      className={`${bgColor} hover:opacity-80 ${textColor} font-semibold py-2 px-4 rounded-lg flex items-center gap-2 ${className} background-color: rgb(59 7 100 / var(--tw-bg-opacity,))`}
      
   >
      {Icon && <Icon size={18} />} {/* Render icon if provided */}
      {label}
    </button>
  );
};

Button.propTypes = {
  label: PropTypes.string.isRequired,
  onClick: PropTypes.func.isRequired,
  bgColor: PropTypes.string,
  textColor: PropTypes.string,
  icon: PropTypes.elementType,
  className: PropTypes.string,
};

export default Button;
