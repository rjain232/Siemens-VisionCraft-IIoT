import React from 'react'

const SafetyGate = ({id,x1 , x2 , y, isOpened ,isBottomGate , isLeftGate,isLeftOpen}) => {
   // console.log(x1,x2,y)
  return (
    <line
    id={id}
    x1={isOpened ? isLeftOpen ? `${(Number(x1)-15)}`:x1:x1}
    x2={isOpened ? isLeftGate ? isLeftOpen ? x2 : `${(Number(x2)-15)}` : x2 : x2}
    y1={isOpened ? isBottomGate ? `${(Number(y)+15)}` :`${(Number(y)-15)}` : isLeftGate ? `${(Number(y)-15)}`: y}
    y2={isLeftGate ? `${(Number(y)+20)}` :y}
    stroke="#f511c7"
    strokeWidth="2"
  />
  )
}

export default SafetyGate