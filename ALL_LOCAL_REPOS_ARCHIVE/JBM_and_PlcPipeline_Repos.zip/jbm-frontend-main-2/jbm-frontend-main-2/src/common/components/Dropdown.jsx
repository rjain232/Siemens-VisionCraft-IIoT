import PropTypes from "prop-types";

const Dropdown = ({ options, selectedValue, onChange, label, placeholder , justify }) => {
  return (
    <div className={`w-auto max-w-sm flex col-auto place-items-center justify-${justify}`}>
      {label && (
        <label className="block text-md text-gray-700 mb-1 font-bold">
          {label}
        </label>
      )}
      <select
        value={selectedValue}
        onChange={(e) => onChange(e.target.value)}
        className="block w-auto px-4 py-2 text-gray-700 bg-white border border-gray-300 rounded-lg shadow-sm focus:ring focus:ring-indigo-500 focus:border-indigo-500"
      >
        {placeholder && (
          <option value="" disabled>
            {placeholder}
          </option>
        )}
        {options.map((option, index) => (
          <option key={index} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
    </div>
  );
};

Dropdown.propTypes = {
  options: PropTypes.arrayOf(
    PropTypes.shape({
      value: PropTypes.string.isRequired,
      label: PropTypes.string.isRequired,
    })
  ).isRequired,
  selectedValue: PropTypes.string.isRequired,
  onChange: PropTypes.func.isRequired,
  label: PropTypes.string,
  placeholder: PropTypes.string,
};

export default Dropdown;
