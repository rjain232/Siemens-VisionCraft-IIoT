import PropTypes from 'prop-types';

const DurationSelector = ({ value, onChange ,disabled }) => {
  return (
    <select
      value={value}
      onChange={onChange}
      disabled={disabled || false}
      className="block w-auto px-4 py-2 text-gray-700 bg-white border border-gray-300 rounded-lg shadow-sm focus:ring focus:ring-indigo-500 focus:border-indigo-500"
      >
      <option value="" className="font-bold">
        Select Duration
      </option>
      <option value="Last10Days">Last 10 Days</option>
      <option value="CurrentMonth">Current Month</option>
      <option value="Last3Months">Last 3 Months</option>
      <option value="Last6Months">Last 6 Months</option>
    </select>
  );
};

DurationSelector.propTypes = {
  value: PropTypes.string.isRequired,
  onChange: PropTypes.func.isRequired,
   disabled: PropTypes.bool,
};

export default DurationSelector;
