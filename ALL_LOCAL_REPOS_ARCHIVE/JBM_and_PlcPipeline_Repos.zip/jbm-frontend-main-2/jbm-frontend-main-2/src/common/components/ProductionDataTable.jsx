import PropTypes from "prop-types";

const ProductionDataTable = ({ data, columns }) => {
  // Group headers
  const groupedHeaders = [
    { label: " ", colspan: 1 },
    { label: " ", colspan: 1 },
    { label: "A", colspan: 2 },
    { label: "B", colspan: 2 },
    { label: "C", colspan: 2 },
  ];

  return (
    <table className="w-full text-sm border-collapse" id="table">
      <thead>
        {/* First row for grouped headers */}
        <tr>
          {groupedHeaders.map((header, index) => (
            <th
              key={index}
              colSpan={header.colspan}
              className="px-4 py-2 text-center font-bold border border-gray-300 bg-gray-200"
            >
              {header.label}
            </th>
          ))}
        </tr>

        {/* Second row for individual columns */}
        <tr>
        <th
            key="sr_no"
            className="px-2 py-2 text-center font-medium border border-gray-300 tracking-wider bg-gray-50 text-red-950 min-w-[50px] w-[60px] whitespace-nowrap"
          >
            Sr. No
          </th>
           {columns.map((col) => (
            <th
              key={col.accessor}
              className="px-4 py-2 font-medium border border-gray-300 bg-gray-50 text-center"
            >
              {col.label.includes(" - ") ? col.label.split(" - ")[1] : col.label}
            </th>
          ))}
        </tr>
      </thead>
      <tbody>
        {data.map((row, index) => (
          <tr key={index}>
            <td className="border border-gray-300 px-2 py-2 text-center bg-white">
              {index + 1}
            </td>
            {columns.map((col) => (
              <td
                key={col.accessor}
                className="border border-gray-300 px-4 py-2 text-center bg-white"
              >
                {row[col.accessor]}
              </td>
            ))}
          </tr>
        ))}
      </tbody>
    </table>
  );
};

// Add PropTypes validation
ProductionDataTable.propTypes = {
  data: PropTypes.arrayOf(PropTypes.object.isRequired).isRequired,
  columns: PropTypes.arrayOf(
    PropTypes.shape({
      label: PropTypes.string.isRequired,
      accessor: PropTypes.string.isRequired,
    }).isRequired
  ).isRequired,
};

export default ProductionDataTable;
