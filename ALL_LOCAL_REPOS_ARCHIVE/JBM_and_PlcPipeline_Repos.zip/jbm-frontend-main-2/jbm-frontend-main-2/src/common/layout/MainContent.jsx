import { Outlet, useLocation, useNavigate } from "react-router-dom";
import netpositivelogo from "../../assets/Netp_Logo_2.10.png";
import Summary from "../../pages/Summary";
import { BiSolidBell } from "react-icons/bi";
import { useState } from "react";
import Dashboard from "../../pages/Dashboard";
import Dashboard2 from "../../pages/Dashboard2";
import useAxios from "../../hooks/useAxios";
import { useEffect } from "react";

const MainContent = () => {
  const [notificationCount , setNotificationCount] = useState(0);
  const location = useLocation();
  const navigate = useNavigate()
  const getPageName = (path) => {
    // Remove leading "/" and replace hyphens with spaces
    const page = path.split("/").pop();
    return page.charAt(0).toUpperCase() + page.slice(1).replace(/-/g, " ");
  };

  const {
    data: pending_activityData,
    loading,
    error,
    refetch,
  } = useAxios("/notification", { method: "GET" }, true);

  // useEffect(() => {
  //   if (pending_activityData?.notification) {
  //     setNotificationCount(pending_activityData.notification.length);
  //    // console.log("notificationCount",notificationCount);
  //    const fetchData = () => {
  //     refetch();};
     

  //     const interval = setInterval(fetchData, 10000); // fetch every 10 seconds
    
  //     return () => clearInterval(interval);
  //   }
   

  // }, [pending_activityData]);
  // Get the page name from the current location pathname
  const pageNameold = getPageName(location.pathname);
  const notificationClickHandler = () =>{
   // setNotificationCount(0)
    navigate('/notifications')
  }
  const capitalizeTitle = (title) => {
    //console.log(title)
    if (title === "Tdm tool") return "TDM Tool"
    if (title === "Atcinterruption") return "ATC Interruption"
    if(title === "Oee") return "OEE"
    return title
      .split(' ')          // Split by spaces
      .map(word =>          // Capitalize the first letter of each word
        word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()
      )
      .join(' ');          // Join the words back into a single string
  };
  const pageName = capitalizeTitle(pageNameold);
  
  return (
    <>
      <div className="flex  justify-between  w-full pt-7 pl-7 pr-7 pb-6 bg-gray-100">
        <h1 className="text-2xl font-semibold mt-1">
          {pageName || "Overview"}
        </h1>
        <div className="flex items-center space-x-10">
            <h1 className="text-2xl font-semibold mt-1 py-2 px-8 text-purple-950 bg-white shadow-sm rounded-lg">
          {"Titan"}
        </h1>
          <div className="relative flex items-center w-10 h-10 justify-center">
            <BiSolidBell className="text-6xl text-gray-700 hover:scale-110 transition-transform duration-300" onClick={notificationClickHandler} />
            {notificationCount > 0 && (
              <span className="absolute -top-1 -right-3 bg-red-500 text-white text-xs font-bold rounded-full px-2 py-0.5 min-w-[20px] text-center">
                {notificationCount}
              </span>
            )}
          </div>
          <img
            src={netpositivelogo}
            height={30}
            width={130}
            className="hover:scale-110 transition-transform duration-500 ease-in-out"
          />
        </div>
      </div>
      <main className="h-[78.9vh]   px-7 bg-gray-100 overflow-auto">
        <div className="mt-0 mb-3">
          {!pageName && <Dashboard2 />}
          <Outlet />
        </div>
      </main>
    </>
  );
};

export default MainContent;
