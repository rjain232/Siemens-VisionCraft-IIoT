import DhruvaLogo from "../../assets/DHRUVA-logo(Icon ONLY).png";
import schaefflerLogo from "../../assets/schaeffler.png";
const Footer = () => {
  return (
    <footer className="bg-white flex text-slate-500 px-4 rounded-md w-full h-[7.8%] justify-center place-items-center shadow-lg">
      <p className=" flex justify-center items-center text-sm">
        Developed by {" "}
        <img
          src={schaefflerLogo}
          width="100"
          height="100"
          alt="logo"
          className="mx-1 h-auto align-middle"
        />{" "}
        {/* <img
          src={DhruvaLogo}
          width="22"
          height="20%"
          alt="logo"
          className="mx-1"
        />{" "} */}

        | All rights reserved
      </p>
    </footer>
  );
};

export default Footer;
