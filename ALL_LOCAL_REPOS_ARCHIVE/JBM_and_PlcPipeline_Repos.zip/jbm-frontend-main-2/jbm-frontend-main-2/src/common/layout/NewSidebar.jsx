import { EllipsisVertical } from "lucide-react";
import { useState } from "react";
import { SidebarMenus } from "./LayoutConfig";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import useAxios from "../../hooks/useAxios";
import UserProfile from "../components/UserProfile";
import ModalHOC from "../../hoc/ModalHOC";
import { useAuthContext } from "../../hooks/AuthContext";
import controlIcon from './../../assets/icons/control.png'; // Adjust the path as necessary
import jbmLogo from './../../assets/jbm.png'; // Adjust the path as necessary
import userIcon from './../../assets/user.png'; // Adjust the path as necessary

const NewSidebar = () => {
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const {logout} = useAuthContext ();
  const [viewProfile , setViewProfile] = useState(false);
  
  const { data : user } = useAxios(
    "/user-profile",
    { method: "GET" },
    true,
  );


  const handleLogout = () => {
    logout(); 
    navigate("/login");
  };

  const handleProfileClick = () => {
      setViewProfile(!viewProfile)
  }
  
  return (
    <div
      className={` ${
        open ? "min-w-[16rem]" : "w-20"
      } bg-purple-950 min-h-screen p-5  pt-5 relative duration-300`}
    >
      {open && (
        <img
          src={controlIcon}
          className={`absolute cursor-pointer -right-3 top-9 w-7 border-dark-purple
           border-2 rounded-full  ${!open && "rotate-180"}`}
          onClick={() => setOpen(!open)}
        />
      )}
      <div className="flex gap-x-4 items-center">
        <img
          src={jbmLogo}
          className={`${
            !open ? "h-10 w-10" : "h-12 w-11"
          } cursor-pointer duration-500 ${open && "rotate-[360deg]"}`}
          onClick={() => setOpen(!open)}
        />
        <h1
          className={`text-white origin-left font-medium text-xl duration-200 ${
            !open && "scale-0"
          }`}
        >
          JBM Group
        </h1>
      </div>
      <ul className="pt-4">
        {SidebarMenus.map((Menu, index) => {
          const isActive = window.location.pathname === Menu.link;

          return (
            <Link to={Menu.link} key={index}>
              <li
                className={`flex rounded-md p-2 cursor-pointer hover:bg-purple-200 hover:text-purple-950 text-gray-300 text-sm items-center gap-x-4 group
          ${Menu.gap ? "mt-9" : "mt-1"} ${isActive ? "bg-purple-200 text-purple-950" : ""}`}
              >
                {Menu.icon}
                <span className={`${!open && "hidden"} origin-left duration-200`}>
                  {Menu.text}
                </span>
                {!open && (
                  <div
                    className={`absolute left-full rounded-md px-2 py-1 ml-4 bg-purple-200 text-purple-950 text-sm 
              invisible opacity-20 -translate-x-3 transition-all group-hover:visible group-hover:opacity-100 z-50`}
                  >
                    {Menu.text}
                  </div>
                )}
              </li>
            </Link>
          );
        })}
      </ul>


      <div
        className={`absolute bottom-0 left-0 w-full h-[8.2%] p-2 text-purple-50 text-sm border-t border-purple-400 ${
          open ? "place-items-start" : "place-items-center"
        }`}
      >
        <div className="flex place-items-center h-11 gap-x-4">
          {/* User Image */}
          <img className="w-10 h-10" src={userIcon} alt="User" />

          {/* User Information */}
          {open && user && (
            <div className="w-40">
              <div className="origin-left duration-200">{user?.Username}</div>
              <div>{user?.Email}</div>
            </div>
          )}

          {/* Options Icon */}
          {open && (
            <div className="relative group">
              <EllipsisVertical strokeWidth={1} size={36} />

              {/* Action Menu on Hover */}
              <div className="absolute right-0 mt-2 w-32 bg-white text-purple-950 rounded-md shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all bottom-full mb-3">
                <ul>
                  <li className="p-2 hover:bg-purple-100 hover:rounded-md cursor-pointer" onClick={handleProfileClick}>Profile</li>
                  <li className="p-2 hover:bg-purple-100 hover:rounded-md cursor-pointer" onClick={handleLogout}>Logout</li>
                </ul>
              </div>
            </div>
          )}
        </div>

      </div>

        <ModalHOC isOpen = {viewProfile} onClose={handleProfileClick}>
            <UserProfile user={user} onBackHandler={handleProfileClick} onLogoutHandler={handleLogout} icon={userIcon}/>
        </ModalHOC>

      {/* {viewProfile &&<div><UserProfile  isOpen = {viewProfile} onClose = {handleProfileClick}/></div>} */}
    </div>
  );
};
export default NewSidebar;
