import Footer from "./Footer";
import NewSidebar from "./NewSidebar";
import MainContent from "./MainContent";
import  { Toaster } from "react-hot-toast";
const Layout = () => {
  return (
    <div className="flex">
       <NewSidebar/>
       <div className="w-screen">
       
        <Toaster
        position="top-center"
        toastOptions={{
          style: {
            background: "#333",
            color: "#fff",
          },
        }}
      />
       <MainContent/>
      <Footer/>
      </div>
      </div>
  );
};

export default Layout;
