import {
  Network,
  Bot,
  MonitorCog,
  Boxes,
  RefreshCcw,
  Bolt,
  FileText,
  Info,
  CircleHelp,
  Home,
  ShieldAlert,
  HardHat,
  Gauge,
  Zap
} from "lucide-react";

export const SidebarMenus = [
  {
    icon: <Home />,
    text: "Overview",
    active: true,
    link: "/",
  },
  {
    icon: <Gauge />,
    text: "OEE",
    active: true,
    link: "/oee",
  },
  // {
  //   icon: <Network />,
  //   text: "Line Status",
  //   active: false,
  //   link: "/line-status",
  // },
  {
    icon: <Bot />,
    text: "Robot Monitoring",
    active: false,
    link: "/robot-monitoring",
  },
  // {
  //   icon: <MonitorCog />,
  //   text: "Machine Setup",
  //   active: false,
  //   link: "/machine-setup",
  // },
  {
    icon: <Boxes />,
    text: "Production Control",
    active: false,
    link: "/production-control",
  },
  // {
  //   icon: <RefreshCcw />,
  //   text: "Cycle Time",
  //   active: false,
  //   link: "/cycle-time",
  // },
  { icon: <Bolt />, text: "Maintenance", active: false, link: "/maintenance" },
  // {
  //   icon: <ShieldAlert />,
  //   text: "ATC Interruption",
  //   active: false,
  //   link: "/atcinterruption"
  // },
  {
    // icon: <HardHat />,
    icon: <Network />,
    text: "Line Status",
    active: false,
    link: "/line-status",
  },
  //  {
  //   icon: <Zap />,
  //   text: "Power Consumption",
  //   active: false,
  //   link: "/power-consumption"
  // },
  {
    icon: <Info />,
    text: "About",
    active: false,
    link: "/about",
  },
  {
    icon: <CircleHelp />,
    text: "Help",
    active: false,
    link: "/help"
  },
  
];

export const clientLogo = "./src/assets/jbm.png"
export const sidebarHeader = "JBM Group"

