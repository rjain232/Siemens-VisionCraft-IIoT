import { Battery, BatteryCharging, BatteryWarning } from "lucide-react";
import React, { useState } from "react";
import Chart from "react-apexcharts";

const RobotDetails = () => {
  const graphOptions = {
    chart: {
      type: "line",
      height: 150,
      toolbar: {
        show: false,
      },
    },

    colors: ["#00893D"],

    dataLabels: {
      enabled: false,
    },
    stroke: {
      show: true,
      colors: "#00893D",
      width: 2,
      dashArray: 0,
    },
    fill: {
      color: "#00893D",
    },
    xaxis: {
      labels: {
        show: false,
      },
      categories: [
        "00:00",
        "01:00",
        "02:00",
        "03:00",
        "04:00",
        "05:00",
        "06:00",
        "07:00",
        "08:00",
        "09:00",
        "10:00",
        "11:00",
        "12:00",
        "13:00",
        "14:00",
        "15:00",
        "16:00",
        "17:00",
        "18:00",
        "19:00",
        "20:00",
        "21:00",
        "22:00",
        "23:00",
        "24:00",
      ],
    },
  };

  const graphData = [
    {
      name: "Data",
      data: [
        10, 40, 30, 60, 50, 10, 40, 30, 60, 50, 10, 40, 30, 60, 50, 10, 40, 30,
        60, 50, 10, 40, 30, 60, 50,
      ],
    },
  ];

  // Dummy Station Data
  const stationsData = [
    { id: 1, name: "Robot 1", battery: 80, status: "Active" },
  ];

  // Battery Icon based on battery %
  const getBatteryIcon = (battery) => {
    if (battery > 75) return <Battery className="text-green-500 w-6 h-6" />;
    if (battery > 40)
      return <BatteryCharging className="text-yellow-500 w-6 h-6" />;
    return <BatteryWarning className="text-red-500 w-6 h-6" />;
  };

  // Status Colors
  const getStatusColor = (status) => {
    if (status === "Production") return "bg-green-500";
    if (status === "Idle") return "bg-yellow-500";
    return "bg-red-500";
  };

  const getBatteryHealth = (Percent) => {
    if (Percent > 75) return "Good";
    if (Percent > 40) return "Average";
    return "Low";
  };

  const [stations, setStations] = useState(stationsData);
  return (
    <div className="flex bg-gray-100 py-4">
      {/* Left Section - Robot Image & Name */}
      <div className="w-1/3 flex flex-col items-center justify-start bg-white shadow-md rounded-xl ">
        <h2 className="text-xl font-semibold mt-4 mb-8">Robot Name: KUKA_01</h2>
        <img src="./src/assets/Robot1_img.jpg" alt="Robot" className="h-96" />

        {stations.map((station) => (
          <div
            key={station.id}
            className="p-4  rounded-lg bg-white min-w-full "
          >
            <p
              className={`text-md text-center font-semibold ${getStatusColor(
                station.status
              )}`}
            >
              {station.status}
            </p>
            
          </div>
        ))}
      </div>

      {/* Right Section - Grid with Graphs */}
      <div className="w-2/3 flex-1 grid grid-cols-2 gap-4 ps-4">
        <div className="bg-white p-4 shadow-md rounded-lg">
          <h3 className="text-lg font-bold">Water Flow</h3>
          <Chart
            options={graphOptions}
            series={graphData}
            type="area"
            height={200}
          />
        </div>

        <div className="bg-white p-4 shadow-md rounded-lg">
          <h3 className="text-lg font-bold">Temperature</h3>
          <Chart
            options={graphOptions}
            series={graphData}
            type="bar"
            height={200}
          />
        </div>

        <div className="bg-white p-4 shadow-md rounded-lg">
          <h3 className="text-lg font-bold">Weld Gun Force</h3>
          <Chart
            options={graphOptions}
            series={graphData}
            type="line"
            height={200}
          />
        </div>

        <div className="bg-white p-4 shadow-md rounded-lg">
          <h3 className="text-lg font-bold">Current</h3>
          <Chart
            options={graphOptions}
            series={graphData}
            type="line"
            height={200}
          />
        </div>
      </div>
    </div>
  );
};

export default RobotDetails;
