import React from "react";
import Chart from "react-apexcharts";

const ProductionCard = ({ title, okCount, nokCount }) => {
  const totalProduction = okCount + nokCount;

  const chartOptions = {
    chart: {
      type: "pie",
    },
    labels: ["OK", "NOK"],
    colors: ["#00893D", "#A12E2D"],
    legend: {
      position: "bottom",
      markers: {
        radius: 4,
      },
    },
    dataLabels: {
      enabled: true,
      formatter: (val, opts) => opts.w.config.series[opts.seriesIndex],
    },
    tooltip: {
        theme: "light",
        style: {
          fontSize: "14px",
          backgroundColor: "#ffffff",
          color: "#000000",
        },
      },
  };

  const chartSeries = [okCount, nokCount];

  return (
    <div className="bg-white rounded-xl shadow-xl p-4 flex flex-col items-center border-t-4 border-gray-400 transform hover:scale-105 transition-transform duration-300">
      <h2 className="text-xl font-semibold text-gray-800 text-center mb-0">
        {title}
      </h2>
      <div className="flex justify-center mb-0">
        <Chart options={chartOptions} series={chartSeries} type="pie" width={300} />
      </div>
      <div className="text-center">
        <p className="text-gray-600 font-medium">Total Production</p>
        <p className="text-2xl font-bold text-gray-900">{totalProduction}</p>
      </div>
      
    </div>
  );
};

export default ProductionCard;
