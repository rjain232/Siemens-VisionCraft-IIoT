import React from "react";
import { useGauge } from "use-gauge";


const START_ANGLE = 45;
const END_ANGLE = 325;

export default function MyGauge({ value }) {
  const gauge = useGauge({
    domain: [0, 1000],
    startAngle: START_ANGLE,
    endAngle: END_ANGLE,
    numTicks: 100,
    diameter: 220,
  });
  const gauge2 = useGauge({
    domain: [0, 1000],
    startAngle: START_ANGLE,
    endAngle: END_ANGLE,
    numTicks: 91,
    diameter: 320,
  });

  const needle = gauge.getNeedleProps({
    value,
    baseRadius: 10,
    tipRadius: 1,
  });

  const getClassByValue = (val) => {
    return val <= 200
      ? "stroke-green-400"
      : val >= 201 && val <= 501
      ? "stroke-red-400"
      : "stroke-red-800";
  };

  return (
    <div className="p-4 d-none">
      <svg className="w-full overflow-visible p-2" {...gauge.getSVGProps()}>
        <g id="ticksOut">
          <path
            {...gauge.getArcProps({
              offset: 0,
              startAngle: START_ANGLE,
              endAngle: gauge.valueToAngle(200),
            })}
            fill="none"
            className="stroke-green-400"
            strokeLinecap="round"
            strokeWidth={5}
          />
          <path
            {...gauge.getArcProps({
              offset: 0,
              startAngle: gauge.valueToAngle(201),
              endAngle: gauge.valueToAngle(700),
            })}
            fill="none"
            className="stroke-red-400"
            strokeLinecap="round"
            strokeWidth={5}
          />
          <path
            {...gauge.getArcProps({
              offset: 0,
              startAngle: gauge.valueToAngle(701),
              endAngle: gauge.valueToAngle(999),
            })}
            fill="none"
            className="stroke-red-800"
            strokeLinecap="round"
            strokeWidth={5}
          />
        </g>
        <g id="ticks">
          {gauge2.ticks.map((angle) => {
            const asValue = gauge2.angleToValue(angle);
            const showText = asValue % 10 === 0;

            return (
              <React.Fragment key={`tick-group-${angle}`}>
                <line
                  className="stroke-gray-300"
                  strokeWidth={2}
                  {...gauge2.getTickProps({
                    angle,
                    length: showText ? 10 : 6,
                  })}
                />
                {showText && (
                  <text
                    className="fill-gray-400 font-medium"
                    {...gauge2.getLabelProps({ angle, offset: -30 })}
                  >
                    {asValue}
                  </text>
                )}
              </React.Fragment>
            );
          })}
        </g>
        <g id="arcs">
          <path
            {...gauge.getArcProps({
              offset: 30,
              startAngle: START_ANGLE,
              endAngle: END_ANGLE,
            })}
            fill="none"
            className="stroke-gray-200"
            strokeLinecap="round"
            strokeWidth={24}
          />

          {value <= 200 && (
            <path
              {...gauge.getArcProps({
                offset: 30,
                startAngle: START_ANGLE,
                endAngle: gauge.valueToAngle(value),
              })}
              fill="none"
              className="stroke-green-400"
              strokeLinecap="round"
              strokeWidth={24}
            />
          )}
          {value >= 200 && (
            <path
              {...gauge.getArcProps({
                offset: 30,
                startAngle: START_ANGLE,
                endAngle: gauge.valueToAngle(value),
              })}
              fill="none"
              className="stroke-red-400"
              strokeLinecap="round"
              strokeWidth={24}
            />
          )}
          {value >= 201 && value <= 700 && (
            <path
              {...gauge.getArcProps({
                offset: 30,
                startAngle: START_ANGLE,
                endAngle: gauge.valueToAngle(value),
              })}
              fill="none"
              className="stroke-red-400"
              strokeLinecap="round"
              strokeWidth={24}
            />
          )}
          {value >= 701 && (
            <path
              {...gauge.getArcProps({
                offset: 30,
                startAngle: START_ANGLE,
                endAngle: gauge.valueToAngle(value),
              })}
              fill="none"
              className="stroke-red-800"
              strokeLinecap="round"
              strokeWidth={24}
            />
          )}
        </g>

        <g id="needle">
          <circle className="fill-gray-300" {...needle.base} r={20} />
          <circle className="fill-gray-700" {...needle.base} />
          <circle className="fill-gray-700" {...needle.tip} />
          <polyline className="fill-gray-700" points={needle.points} />
          <circle className="fill-white" {...needle.base} r={4} />
          <text x="0" y="100" textAnchor="middle" className="font-bold text-xl" >
            {`${value}`}
          </text>
        </g>

        {/* <svg x="-25" y="0">
          <path strokeWidth="4" className={getClassByValue(value)} d="m0 110 l50 0" />
        </svg> */}
      </svg>
    </div>
  );
}
