import React, { useState } from "react";
import Chart from "react-apexcharts";



function formatTime(value) {
   let totalMilliseconds = Math.round(value * 1000);

  let hours = Math.floor(totalMilliseconds / 3600000);
  let mins = Math.floor((totalMilliseconds % 3600000) / 60000);
  let secs = Math.floor((totalMilliseconds % 60000) / 1000);
  let millis = totalMilliseconds % 1000;

  return (
    String(hours).padStart(2, "0") + ":" +
    String(mins).padStart(2, "0") + ":" +
    String(secs).padStart(2, "0") + "." +
    String(millis).padStart(3, "0")
  );
}

const BarGraphSafetyAlarm = ({Top10alarmData=[]}) => {
  const [hoverDescription, setHoverDescription] = useState("");
  const [hoverPosition, setHoverPosition] = useState({ x: 0, y: 0 });
  const alarmData = Top10alarmData;
  
  const xCategories = alarmData.map((item) => item.count);
  const yData = alarmData.map((item) => item.time);
  const legendColors = [
    "#400000",
    "#800000",
    "#BF0000",
    "#ed0404",
    "#f41f1f",
    "#f93131",
    "#e05353",
    "#f26060",
    "#9e7373",
    "#d19999",
  ];

  const chartOptions = {
    chart: {
      type: "bar",
      height: 400,
      toolbar: { show: false },
    },
    plotOptions: {
      bar: {
        distributed: true, // Each column will have its own color
        borderRadius: 2,
        horizontal: false,
        columnWidth: "50%",
        dataLabels: {
          position: 'top', // top, center, bottom
        },
      }, 
    },
    xaxis: {
      categories: xCategories,
      title: { text: "Alarm Frequency" },
    },
    yaxis: {
      title: { text: "Time (Minutes)" },
     
       labels: {
      formatter: function (value) {
        return formatTime(value);
      },
    },
      
    },
    dataLabels: {
      offsetY: -25,
      enabled: true,
      textAnchor: 'middle',
      style: { fontSize: "12px", colors: ["#000"]},
      formatter: function (value) {
        return formatTime(value);
      },
    },
    legend: {
      show: false,
    },
    colors: legendColors,
    tooltip: {
      y: {
        formatter: function (value) {
          return formatTime(value);
        },
      },
    },
  };

  const chartSeries = [
    {
      name: "Time",
      data: yData, // Time for each fault
    },
  ];

  return (
    <div className="bg-white rounded-xl shadow-lg pt-4 px-6 pb-2 w-[99.9%]">
      <h2 className="text-2xl font-bold text-center mb-4">
        Top 10 Critical Alarms
      </h2>
      {alarmData.length > 0 ?(
        <>
          <div>
            <Chart
              options={chartOptions}
              series={chartSeries}
              type="bar"
              height={400}
            />
            {hoverDescription ? (
              <div
                className="pointer-events-none fixed z-50 max-w-xs rounded-md border border-slate-300 bg-slate-900/95 px-3 py-2 text-sm text-white shadow-lg"
                style={{
                  left: hoverPosition.x,
                  top: hoverPosition.y,
                  transform: "translate(-50%, -110%)",
                  whiteSpace: "normal",
                }}
              >
                {hoverDescription}
              </div>
            ) : null}
          </div>
          <div className="mt-4 flex flex-wrap justify-center gap-2">
            {alarmData.map((alarm, idx) => {
              const description = alarm.AlarmDescription || alarm.Description || alarm.AlarmReason || "No description available";
              return (
                <button
                  key={`${alarm.Code}-${idx}`}
                  type="button"
                  className="flex items-center gap-2 rounded-md border border-slate-200 px-3 py-2 text-sm text-slate-700 hover:bg-slate-100 transition"
                  onMouseEnter={(event) => {
                    setHoverDescription(description);
                    setHoverPosition({ x: event.clientX, y: event.clientY });
                  }}
                  onMouseMove={(event) => {
                    setHoverPosition({ x: event.clientX, y: event.clientY });
                  }}
                  onMouseLeave={() => {
                    setHoverDescription("");
                    setHoverPosition({ x: 0, y: 0 });
                  }}
                  title={description}
                >
                  <span
                    className="h-3 w-3 rounded-full"
                    style={{ backgroundColor: legendColors[idx % legendColors.length] }}
                  />
                  <span>{alarm.Code}</span>
                </button>
              );
            })}
          </div>
        </>
      ) : (
        <div className="text-gray-500 text-sm text-center py-4">
          No alarm data available
        </div>
      )}
    </div>
  );
};

export default BarGraphSafetyAlarm;
