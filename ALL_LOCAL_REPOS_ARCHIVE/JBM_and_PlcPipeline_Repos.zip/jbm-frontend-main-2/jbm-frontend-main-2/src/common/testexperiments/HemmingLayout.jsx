import { motion } from "framer-motion";
import WorkerIcon from "../../assets/worker.png"
import RobotIcon from "../../assets/robotic-arm (1).png"
import WarningIcon from "../../assets/warning.png"
import { useState, useEffect } from "react";


const HemmingLayout = ({height , width}) => {
  const [error , setError] = useState({
    isSafetyGateError : true,
    isLCError : true,
    isRunStandError : true
  })

  // useEffect(() => {
  //   // Simulate an error occurring after 2 seconds (for testing)
  //   setTimeout(() => {
  //     setIsError(true);
  //   }, 2000);
  // }, []);

  return (
    <div className={`flex ${height} ${width}`}>
      <svg width="900" viewBox="0 0 800 500" className="border border-blue-500">
        {/* Top horizontal conveyor */}
        <rect x="0" y="80" width="700" height="13" fill="#c9c900" />
        {/* Top left vertical conveyor */}
        <rect x="150" y="80" width="13" height="60" fill="#c9c900" />
        {/* Right vertical conveyor */}
        <rect x="700" y="30" width="13" height="433" fill="#c9c900" />
        {/* bottom horizontal conveyor */}
        <rect x="300" y="450" width="400" height="13" fill="#c9c900" />
        {/* Top Right battery like symbol */}
        <rect x="640" y="30" width="50" height="30" fill="#00c900" />
        <rect x="690" y="40" width="5" height="13" fill="gray" />

        <rect x="150" y="350" width="270" height="13" fill="#A95100" />
        

        {/* Dashed Line inner reactangle */}

        {/* Bottom dashed line */}
        <line x1="80" y1="380" x2="140" y2="380" stroke="#d1d0cd" strokeWidth="2"></line>
        <line x1="150" y1="380" x2="205" y2="380" stroke="#d1d0cd" strokeWidth="2"></line>
        <line x1="215" y1="380" x2="270" y2="380" stroke="#c9c900" strokeWidth="2"></line>
        <line x1="280" y1="380" x2="340" y2="380" stroke="#d1d0cd" strokeWidth="2"/>
        <line x1="350" y1="380" x2="410" y2="380" stroke="#d1d0cd" strokeWidth="2"></line>
        <line x1="420" y1="380" x2="480" y2="380" stroke="#d1d0cd" strokeWidth="2"></line>
         {/* Breakup lines like circuit diagram for BOTTOM horizontal line */}
         <line x1="140" x2="140" y1="375" y2="384"stroke="#d1d0cd" strokeWidth="4"/>
        <line x1="150" x2="150" y1="375" y2="384"stroke="#d1d0cd" strokeWidth="4"/>
        <line x1="205" x2="205" y1="375" y2="384"stroke="#d1d0cd" strokeWidth="4"/>
        <line x1="215" x2="215" y1="375" y2="384"stroke="#d1d0cd" strokeWidth="4"/>
        <line x1="270" x2="270" y1="375" y2="384"stroke="#d1d0cd" strokeWidth="4"/>
        <line x1="280" x2="280" y1="375" y2="384"stroke="#d1d0cd" strokeWidth="4"/>
        <line x1="340" x2="340" y1="375" y2="384"stroke="#d1d0cd" strokeWidth="4"/>
        <line x1="350" x2="350" y1="375" y2="384"stroke="#d1d0cd" strokeWidth="4"/>
        <line x1="410" x2="410" y1="375" y2="384"stroke="#d1d0cd" strokeWidth="4"/>
        <line x1="420" x2="420" y1="375" y2="384"stroke="#d1d0cd" strokeWidth="4"/>

        {/* Left vertical dashed Line */}
        <line x1="80"  x2="80" y1="180" y2="220" stroke="#d1d0cd" strokeWidth="2"> </line>
        <line x1="80"  x2="80" y1="250" y2="280" stroke="#d1d0cd" strokeWidth="2"> </line>
        <line x1="80"  x2="80" y1="290" y2="330" stroke="#d1d0cd" strokeWidth="2"> </line>
        <line x1="80"  x2="80" y1="340" y2="380" stroke="#d1d0cd" strokeWidth="2"> </line>

    {/* Breakup lines like circuit diagram for LEFT vertical line */}
        <line x1="77" x2="83" y1="220" y2="220"stroke="#d1d0cd" strokeWidth="1"/>
        <line x1="77" x2="83" y1="225" y2="225"stroke="#0a0909" strokeWidth="4"/>
        <line x1={error?.isSafetyGateError ? "65" : "80"} x2="80" y1={error?.isSafetyGateError ? "235" : "230"} y2={error?.isSafetyGateError ? "240" : "245"} stroke="#d1d0cd" strokeWidth="1"/>
        <line x1="77" x2="83" y1="245" y2="245"stroke="#0a0909" strokeWidth="4"/>
        <line x1="77" x2="83" y1="250" y2="250"stroke="#d1d0cd" strokeWidth="1"/>
        <line x1="77" x2="83" y1="280" y2="280"stroke="#d1d0cd" strokeWidth="4"/>
        <line x1="77" x2="83" y1="290" y2="290"stroke="#d1d0cd" strokeWidth="4"/>
        <line x1="77" x2="83" y1="330" y2="330"stroke="#d1d0cd" strokeWidth="4"/>
        <line x1="77" x2="83" y1="340" y2="340"stroke="#d1d0cd" strokeWidth="4"/>

      {/* Top horizontal dashed line */}
        <line x1="80" y1="180" x2="140" y2="180" stroke="#d1d0cd" strokeWidth="2"></line>
        <line x1="150" y1="180" x2="205" y2="180" stroke="#d1d0cd" strokeWidth="2"></line>
        <line x1="215" y1="180" x2="270" y2="180" stroke="#d1d0cd" strokeWidth="2"></line>
        <line x1="280" y1="180" x2="340" y2="180" stroke="#d1d0cd" strokeWidth="2"/>
        <line x1="350" y1="180" x2="410" y2="180" stroke="#d1d0cd" strokeWidth="2"></line>
        <line x1="420" y1="180" x2="480" y2="180" stroke="#d1d0cd" strokeWidth="2"></line>
        
        {/* Breakup lines like circuit diagram for TOP horizontal line */}
        <line x1="140" x2="140" y1="175" y2="184"stroke="#d1d0cd" strokeWidth="4"/>
        <line x1="150" x2="150" y1="175" y2="184"stroke="#d1d0cd" strokeWidth="4"/>
        <line x1="205" x2="205" y1="175" y2="184"stroke="#d1d0cd" strokeWidth="4"/>
        <line x1="215" x2="215" y1="175" y2="184"stroke="#d1d0cd" strokeWidth="4"/>
        <line x1="270" x2="270" y1="175" y2="184"stroke="#d1d0cd" strokeWidth="4"/>
        <line x1="280" x2="280" y1="175" y2="184"stroke="#d1d0cd" strokeWidth="4"/>
        <line x1="340" x2="340" y1="175" y2="184"stroke="#d1d0cd" strokeWidth="4"/>
        <line x1="350" x2="350" y1="175" y2="184"stroke="#d1d0cd" strokeWidth="4"/>
        <line x1="410" x2="410" y1="175" y2="184"stroke="#d1d0cd" strokeWidth="4"/>
        <line x1="420" x2="420" y1="175" y2="184"stroke="#d1d0cd" strokeWidth="4"/>
        
        {/* Right operator position up and down line */}
        <line x1="480"  x2="480" y1="320" y2="380" stroke="#d1d0cd" strokeWidth="2"> </line>
        <line x1="480"  x2="480" y1="180" y2="220" stroke="#d1d0cd" strokeWidth="2"> </line>
        <line x1="475" x2="485" y1="220" y2="220"stroke="#d1d0cd" strokeWidth="4"/>
        <line x1="475" x2="485" y1="320" y2="320"stroke="#d1d0cd" strokeWidth="4"/>
        {/* Breakup lines like circuit diagram for RIGHT  Vertical line and operator position indication */}
        <rect x="475" y="308" width="10" height="7" fill="#616675" />
        <line x1="460" x2="500" y1="235" y2="235"stroke="#d1d0cd" strokeWidth="1"/>
        <image href={WorkerIcon} x="465" y="252" height="30" width="30"/>
        <line x1="460" x2="500" y1="305" y2="305"stroke="#d1d0cd" strokeWidth="1"/>
        <rect x="475" y="225" width="10" height="7" fill="#616675" />

        <rect x="120" y="225" width="310" height="100" fill="#bac8cf" />
        {/* Image second (appears on top) */}
        <image href={RobotIcon} x="124" y="240" height="60" width="60" />
        <rect x="150" y="300" width="13" height="80" fill="#A95100" />


        <rect x="510" y="180" width="100" height="50" stroke="blue" fill="none" />
        { error?.isRunStandError && <motion.image
        href={WarningIcon}
        x="540"
        y="190"
        height="30"
        width="30"
        animate={{ opacity: [1, 0, 1] } }
        transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
      />}
      <text x="530" y="200" fontSize="14" fill="black">Run</text>
      <text x="530" y="220" fontSize="14" fill="black">Stand-1</text>

      {/* Small Rectangle */}
      <rect x="515" y="230" width="60" height="30" stroke="blue" fill="none" />
      { error?.isLCError && <motion.image
        href={WarningIcon}
        x="535"
        y="235"
        height="20"
        width="20"
        animate={{ opacity: [1, 0, 1] } }
        transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
      />}
      <text x="530" y="250" fontSize="14" fill="black">LC1</text>

      <rect x="10" y="240" width="60" height="30" stroke="blue" fill="none" />
      { error.isSafetyGateError && <motion.image
        href={WarningIcon}
        x="25"
        y="240"
        height="30"
        width="30"
        animate={{ opacity: [1, 0, 1] } }
        transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
      />}
      <text x="25" y="260" fontSize="14" fill="black">S.G-1</text>
        </svg>
    </div>
  );
};

export default HemmingLayout;
