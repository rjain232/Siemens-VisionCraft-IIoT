import React ,{useState , useEffect} from "react";
import Chart from "react-apexcharts";

const LineGraph = () => {
    const [chartSeries, setChartSeries] = useState([
        { name: "Robot 1", data: [] },
     
      ]);
    
      const chartOptions = {
        chart: {
          type: "line",
          height: 350,
        },
        stroke: {
          curve: "smooth",
          width: 2,
        },
        annotations: {
          yaxis: [
            {
              y: 70, // Upper limit
              borderColor: '#FF0000',
              strokeDashArray: 0, // Solid line (no dashes)
              label: {
                text: 'Upper Limit 70 (amp)',
                style: {
                  color: '#ffffff',
                  background: '#FF0000',
                  fontSize: '16px',
                  fontWeight: 50,
              },
              },
            },
            {
              y: 30, // Lower limit
              borderColor: '#00FF00',
              strokeDashArray: 0, // Solid line (no dashes)
              label: {
                text: 'Lower Limit 30 (amp)',
                style: {
                  color: '#ffffff',
                  background: '#00FF00',
                  fontSize: '16px',
                  fontWeight: 50,
              },
            }
          }
          ],
        },
        xaxis: {
          type: "datetime",
          title: { text: "Timestamp" },
          min: new Date().setHours(0, 0, 0, 0), // Start of the current day
          max: new Date().getTime(), // Current time
        },
        yaxis: {
          title: { text: "Current (amp)" },
        },
        tooltip: {
          enabled: true, // Enable tooltips globally
          shared: true, // Show tooltips for multiple series together
          intersect: false, // Show tooltip when hovering anywhere on the chart
          y: {
            formatter: function (val) {
              return val; // Customize tooltip text
            },
          },
          x: { format: "dd MMM yyyy HH:mm:ss" },
        },
        colors: ["#3443eb", "#17e8e8"],
      };
    
      useEffect(() => {
        const startOfDay = new Date();
        startOfDay.setHours(0, 0, 0, 0);
        const now = new Date();
        const timestamps = [];
        const robot1Data = [];
        const robot2Data = [];
        
        for (let time = startOfDay.getTime(); time <= now.getTime(); time += 3600000) { // Every hour
          timestamps.push(time);
          robot1Data.push([time, Math.floor(Math.random() * 100) + 1]); // Random speed between 1-5 m/s
          robot2Data.push([time, Math.floor(Math.random() * 100) + 1]); // Random speed between 1-5 m/s
        }
    
        setChartSeries([
          { name: "Robot 1", data: robot1Data },
        ]);
      }, []);
    
  return (
    <div className="w-full max-w-full mx-auto p-8 bg-white shadow-md rounded-lg">
      <Chart options={chartOptions} series={chartSeries} type="line" height={400} />
    </div>
  );
};

export default LineGraph;