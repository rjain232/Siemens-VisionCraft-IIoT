import Chart from "react-apexcharts";
import PropTypes from "prop-types";
import { useMemo } from "react";

const BarGraphHourly = ({data , title}) => {
 // Add this style tag in your component or in your global CSS file
const groupLabelStyle = `
  .apexcharts-xaxis-group-label {
    transform: translateY(15px);  /* ⬅️ increase for more space */
  }
`;
  // Build flat timeRanges, seriesData, and dateGroups from raw data
 const { timeRanges, dateGroups } = useMemo(() => {
  if (!data?.length) return { timeRanges: [], dateGroups: [] };

  const formatDate = (dateStr) => {
    const [yyyy, mm, dd] = dateStr.split("-");
    return `${dd}-${mm}-${yyyy}`;
  };

  const dateMap = {};
  data.forEach((item) => {
    if (!dateMap[item.Date]) dateMap[item.Date] = [];
    dateMap[item.Date].push(item.HourRange);
  });

  const timeRanges = [];
  const dateGroups = [];

  Object.entries(dateMap).forEach(([date, hours]) => {
    dateGroups.push({ title: formatDate(date), cols: hours.length }); // ⬅️ formatted here
    hours.forEach((h) => timeRanges.push(h));
  });

  return { timeRanges, dateGroups };
}, [data]);

  const productionData = data?.map((item) => item.Actual) ?? [];

  const chartOptions = {
    chart: {
      type: "bar",
      height: 400,
       offsetY: 0,
      toolbar: {
        show: true,
        tools: {
          download: false,
          selection: true,
          zoom: true,
          zoomin: true,
          zoomout: true,
          pan: true,
          reset: true,
        },
        autoSelected: "zoom",
      },
      zoom: { enabled: true },
      animations: {
        enabled: true,
        easing: "easeinout",
      },
    },
    plotOptions: {
      bar: {
        distributed: true,
        borderRadius: 2,
        horizontal: false,
        columnWidth: "50%",
        dataLabels: { position: "top" },
      },
    },
    xaxis: {
      categories: timeRanges,
      title: {
        text: "Hour Range",
        style: { fontSize: "12px", color: "#666" },
      },
      labels: {
        rotate: -90,
        rotateAlways: true,
        hideOverlappingLabels: true,
        trim: true,
        style: { fontSize: "10px",fontWeight:700,  colors: "#555" },
      },
      axisBorder: { show: true },
      axisTicks: { show: true },
      group: {
        groups: dateGroups,
        // e.g. [{ title: "2025-06-01", cols: 8 }, { title: "2025-06-02", cols: 8 }]
        style: {
          fontSize: "12px",
          fontWeight: 700,
          colors: ["#333"],
         offsetY: -10,
        },
      },
    },
    yaxis: {
      title: {
        text: "Production Count",
        style: { fontSize: "12px", color: "#666" },
      },
      labels: {
        style: { fontSize: "11px", colors: "#666" },
      },
    },
    dataLabels: {
      enabled: true,
      offsetY: -20,
      hideOverlappingLabels: true,
      textAnchor: "middle",
      style: { fontSize: "11px", colors: ["#000"] },
    },
    colors: ["#00893D"],
    tooltip: {
      theme: "light",
      x: {
        // Show "Date | HourRange" in tooltip header
        formatter: (val, { dataPointIndex }) => {
          const group = dateGroups[Math.floor(dataPointIndex / 8)];
          return group
            ? `${group.title}  |  ${timeRanges[dataPointIndex]}`
            : val;
        },
      },
      y: {
        formatter: (value) => `${value}`,
      },
    },
    legend: { show: false },
    grid: {
      borderColor: "rgba(128,128,128,0.15)",
      strokeDashArray: 4,
      xaxis: { lines: { show: false } },
      yaxis: { lines: { show: true } },
    },
  };

  const chartSeries = [
    {
      name: "Production Count",
      data: productionData,
    },
  ];


  return (
    <div className="bg-white rounded-xl shadow-lg pt-4 px-6 pb-2 w-full">
          <style>{groupLabelStyle}</style>

      <h2 className="text-2xl font-bold text-center mb-4">
       {title}
      </h2>
      {data?.length === 0 ? (
        <div className="flex items-center justify-center h-64">
          <p className="text-gray-500 text-lg">No data available for the selected filters.</p>
        </div>
      ) : (
        <Chart options={chartOptions} series={chartSeries} type="bar" height={400} />
      )}
    </div>
  );
};
BarGraphHourly.propTypes = {
  data: PropTypes.arrayOf(
    PropTypes.shape({
      hour_range: PropTypes.string.isRequired,
      production_count: PropTypes.number.isRequired,
      Shift: PropTypes.string,
    })
  ).isRequired,
};

export default BarGraphHourly;
