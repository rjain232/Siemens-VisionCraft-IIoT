import React from "react";
import Chart from "react-apexcharts";

const ShiftwiseOEEPieChart = () => {
  const series = [85, 78, 72]; // OEE for Shift A, Shift B, and Shift C in percentage

  const options = {
    chart: {
      type: "pie",
    },
    labels: ["Shift A", "Shift B", "Shift C"],
    legend: {
      position: "bottom",
      horizontalAlign: "center",
    },
  
    dataLabels: {
      enabled: true,
      formatter: (val, { seriesIndex }) => `${series[seriesIndex]}%`, // Show actual OEE %
    },
    
    colors:["#00893D" , "#05DF72" , "#94f7c1"], // Different colors for OEE representation
    tooltip: {
      y: {
        formatter: (val, { seriesIndex }) => `OEE: ${series[seriesIndex]}%`, // Tooltip shows OEE %
      },
    },
    
  };

  return <Chart options={options} series={series} type="pie" height={300} />;
};

export default ShiftwiseOEEPieChart;
