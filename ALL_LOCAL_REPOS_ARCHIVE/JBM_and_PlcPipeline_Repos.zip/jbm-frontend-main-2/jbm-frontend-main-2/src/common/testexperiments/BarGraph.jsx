import React from "react";
import Chart from "react-apexcharts";

const obj ={
  1:"Fault A",
  2:"Fault B",
  3:"Fault C",
  4:"Fault D",
  5:"Fault E",
  6:"Fault F",
  7:"Fault G",
  8:"Fault H",
  9:"Fault I",
  10:"Fault J"
}

//   { name: "Fault A", count: 6, time: 12000 },
//   { name: "Fault B", count: 4, time: 9500 },
//   { name: "Fault C", count: 5, time: 8000 },
//   { name: "Fault D", count: 1, time: 7050 },
//   { name: "Fault E", count: 3, time: 6000 },
//   { name: "Fault F", count: 8, time: 5000 },
//   { name: "Fault G", count: 7, time: 4500 },
//   { name: "Fault H", count: 3, time: 4000 },
//   { name: "Fault I", count: 2, time: 3000 },
//   { name: "Fault J", count: 2, time: 2500 },
// ];

function formatTime(value) {
  const hours = Math.floor(value / 3600);
  const minutes = Math.floor((value % 3600) / 60);
  const seconds = value % 60;
  return `${hours.toString().padStart(2, "0")}:${minutes
    .toString()
    .padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`;
}

const BarGraph = ({height, faultData = []}) => {
  const combinedFaultData = faultData;
  const maxTime = Math.max(...combinedFaultData.map(item => item.time || 0));
const roundedMax = Math.ceil(maxTime / 1000) * 1000; // round up to nearest 1000 (optional)
  const chartOptions = {
    chart: {
      type: "bar",
      height: 400,
      toolbar: { show: false },
    },
    plotOptions: {
      bar: {
        distributed: true, // Each column will have its own color
        borderRadius: 2,
        horizontal: false,
        columnWidth: "50%",
        dataLabels: {
          position: 'top', // top, center, bottom
        },
      }, 
    },
    xaxis: {
      categories: combinedFaultData.map(item => item.count),
      title: { text: "Fault Frequency" },
    },
    yaxis: {
      title: { text: "Time (Minutes)" },
      max:roundedMax,
       labels: {
      formatter: function (value) {
        return formatTime(value);
      },
    },
      
    },
    dataLabels: {
      offsetY: -25,
      enabled: true,
      textAnchor: 'middle',
      style: { fontSize: "12px", colors: ["#000"]},
      formatter: function (value) {
        return formatTime(value);
      },
    },
    legend: {
      show: true,
      formatter: function (seriesName, opts) {
        // Get corresponding category name from x-axis
        let faultName = combinedFaultData[opts.seriesIndex].name; 
        let faultValue = opts.w.config.series[0].data[opts.seriesIndex];

        // Format legend text like a data label
        return `${faultName}`;
      },
      itemMargin: {
        horizontal: 5,
        vertical: 15
    },
    },
    colors: [
      "#400000",
      "#800000",
      "#BF0000",
      "#ed0404",
      "#f41f1f",
      "#f93131",
      "#e05353",
      "#f26060",
      "#9e7373",
      "#d19999",
    ],
    tooltip: {
      y: {
        formatter: function (value) {
          return formatTime(value);
        },
      },
    },
    responsive: [
      {
        breakpoint: 600, // Adjusts for smaller screens
        options: {
          legend: {
            position: "bottom", // Moves legend below the chart for small screens
          },
        },
      },
    ],
  };

  const chartSeries = [
    {
      name: "Time",
      data: combinedFaultData.map(item => item.time), // Time for each fault
    },
  ];

  return (
   
      <Chart
        options={chartOptions}
        series={chartSeries}
        type="bar"
        height={height}
      />
   
  );
};

export default BarGraph;
