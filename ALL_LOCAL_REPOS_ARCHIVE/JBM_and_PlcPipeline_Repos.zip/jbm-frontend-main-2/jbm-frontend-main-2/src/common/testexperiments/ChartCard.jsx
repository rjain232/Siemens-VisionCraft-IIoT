const   ChartCard = ({ title, shadow , children,bgColor ,border}) => (
    <div className={`bg-white  p-4 rounded-lg h-full ${shadow && 'shadow-lg hover:shadow-xl'} ${bgColor} ${border}`}>
      {title && <h2 className="text-lg font-semibold mb-4 text-center text-gray-700">{title}</h2>}
      {children}
    </div>    
  );

  export default ChartCard;