import React from "react";
import Chart from "react-apexcharts";

const GaugeChart = ({ title, value }) => {
  const chartOptions = {
    chart: {
      type: "radialBar",
    },
    plotOptions: {
      radialBar: {
        hollow: {
          size: "70%",
        },
        track: {
          background: "#e0e0e0",
        },
        dataLabels: {
          show: true,
          name: {
            offsetY: -10,
            color: "#333",
            fontSize: "16px",
          },
          value: {
            fontSize: "22px",
            color: "#333",
            fontWeight: "bold",
          },
        },
      },
    },
    colors: value >= 85 ? ["#00893D"] : value >= 75 ? ["#FFA500"] : ["#A12E2D"], // Green, Orange, Red
    labels: [title],
  };

  return (
    <div className="bg-white rounded-xl shadow-xl p-4 flex flex-col items-center border-t-4 border-gray-400 transform hover:scale-105 transition-transform duration-300">
      <Chart options={chartOptions} series={[value]} type="radialBar" width={250} />
    </div>
  );
};

export default GaugeChart;
