import { useState,useEffect } from "react";
import PropTypes from "prop-types";
import Robo from "./Robo";
import ModalHOC from "../../hoc/ModalHOC";
import { motion } from "framer-motion";
import { Cpu, Globe, HardDrive } from "lucide-react";
import Button from "../components/Button";
import useAxios from "../../hooks/useAxios";
import { Loader } from "../components/Loader";
const topMargin = "top-[20px]";
const positionAndScale = "absolute scale-75"
const secondRowTopMargin ="top-[155px]"
const RFHMTopMargin = "top-[320px]"

const arr = [
  {
    id:2,
    name: "Robot 2",
    className :`${positionAndScale} ${topMargin} -left-[20px]`
  },
  {
    id:4,
    name: "Robot 4",
    className : `${positionAndScale} ${topMargin} left-[140px]`
  },
  {
    id:6,
    name: "Robot 6",
    className : `${positionAndScale} ${topMargin} left-[300px]`
  },
  {
    id:8,
    name: "Robot 8",
    className : `${positionAndScale} ${topMargin} left-[460px]`
  },
  {
    id:10,
    name: "Robot 10",
    className : `${positionAndScale} ${topMargin} left-[620px]`
  },
  {
    id:12,
    name: "Robot 12",
    className : `${positionAndScale} ${topMargin} left-[780px]`
  },
  {
    id:14,
    name: "Robot 14",
     className : `${positionAndScale} ${topMargin} left-[940px]`
  },
  {
    id:18,
    name: "Robot 18",
     className : `${positionAndScale} ${topMargin} left-[1100px]`
  },
  {
    id:20,
    name: "Robot 20",
    className : `${positionAndScale} ${topMargin} left-[1260px]`
  },
  {
    id:1,
    name: "Robot 1",
    className : `${positionAndScale} ${secondRowTopMargin} -left-[20px]`
  },
  {
    id:3,
    name: "Robot 3",
    className : `${positionAndScale} ${secondRowTopMargin} left-[140px]`
  },
  {
    id:5,
    name: "Robot 5",
    className : `${positionAndScale} ${secondRowTopMargin} left-[300px]`
  },
  {
    id:7,
    name: "Robot 7",
    className : `${positionAndScale} ${secondRowTopMargin} left-[460px]`
  },
  {
    id:9,
    name: "Robot 9",
    className : `${positionAndScale} ${secondRowTopMargin} left-[620px]`
  },
  {
    id:11,
    name: "Robot 11",
    className : `${positionAndScale} ${secondRowTopMargin} left-[780px]`
  },
  {
    id:13,
    name: "Robot 13",
    className : `${positionAndScale} ${secondRowTopMargin} left-[940px]`
  },
  {
    id:17,
    name: "Robot 17",
    className : `${positionAndScale} ${secondRowTopMargin} left-[1100px]`
  },
  {
    id:19,
    name: "Robot 19",
    className : `${positionAndScale} ${secondRowTopMargin} left-[1260px]`
  },
  {
   id:15,
    name: "Robot 15",
    className : `${positionAndScale} ${RFHMTopMargin} left-[620px]`
  },
  {
   id:16,
    name: "Robot 16",
    className : `${positionAndScale} ${RFHMTopMargin} left-[940px]`
  },
];



const RobotLayout = ({robotSelect,visibilityChange}) => {

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedRobot, setSelectedRobot] = useState(null);

  //const [params, setParams] = useState({ parameter: null }); // API parameters
  const {
    data: RobotHealthdata=[],
    loading: RobotHealthloading,
    error:RobotHealthError,
    refetch:refetchRobotHealth
  } = useAxios("/robothealth", { method: "GET"}, true);

  const [mergedArrayRobotHealthdata, setMergedArray] = useState(arr);

  useEffect(() => {
    if (RobotHealthdata && RobotHealthdata.length > 0) {
      const filteredData = RobotHealthdata.filter(item => item.status != 'Battery')
      const merged = arr.map(staticRobot => {
        const apiRobot = filteredData.find(r => Number(r.id) === staticRobot.id);
        return {
          ...staticRobot,
          ...apiRobot
        };
      });
      setMergedArray(merged);
    }
  }, [RobotHealthdata]);
  
  useEffect(() => {
    const interval = setInterval(() => {
      refetchRobotHealth(); // update data
    }, 5000);

    return () => clearInterval(interval); // clear on unmount
  }, [refetchRobotHealth]);
  
// if(RobotHealthloading){
//   return <div>Loading ...</div>;
// }
if(RobotHealthError){
  return <div>Error in fetching data ...</div>;
}
  return (
    // !RobotHealthloading &&
  (<div>
      <div className="relative mt-4">
        
      {mergedArrayRobotHealthdata?.map((item, index) => (
            <div
              key={index}
              onClick={() => {
                setIsModalOpen(true);
                setSelectedRobot(item);
              }}
              className={item.className}
            >
              {" "}
              <Robo
                name={item.name}
                status={item.status}
                battery={RobotHealthdata?.filter(item => item.status == 'Battery')?.find(r => Number(r.id) === item.id)?.battery}
              />
              </div>
      ))}
           <div className="absolute w-0.5 h-72 border-l-2 border-dashed border-gray-400 mx-auto left-[305px]"></div>
           <div className="absolute w-0.5 h-72 border-l-2 border-dashed border-gray-400 mx-auto left-[625px]"></div>
           <div className="absolute w-0.5 h-72 border-l-2 border-dashed border-gray-400 mx-auto left-[785px]"></div>
           <div className="absolute w-0.5 h-72 border-l-2 border-dashed border-gray-400 mx-auto left-[1105px]"></div>
           <div className="absolute w-0.5 h-36 border-l-2 border-dashed border-gray-400 mx-auto left-[870px] top-[300px]"></div>

        <h7 className="absolute top-[125px] left-[115px] p-2 bg-slate-200 text-slate-800 font-bold rounded-md text-sm">
            ML-10
        </h7>
         <h7 className="absolute top-[125px] left-[435px] p-2  bg-slate-200 text-slate-800 font-bold rounded-md text-sm">
          {" "}
          ML-20
        </h7>
        <h7 className="absolute top-[125px] left-[675px] p-2  bg-slate-200 text-slate-800 font-bold rounded-md text-sm">
          {" "}
          ML-30
        </h7>
       <h7 className="absolute top-[125px] left-[915px] p-2  bg-slate-200 text-slate-800 font-bold rounded-md text-sm">
          {" "}
          ML-40
        </h7>
        <h7 className="absolute top-[125px] left-[1235px] p-2  bg-slate-200 text-slate-800 font-bold rounded-md text-sm">
          {" "}
          ML-50
        </h7>
       <h7 className="absolute top-[430px] left-[675px] p-2  bg-slate-200 text-slate-800 font-bold rounded-md text-sm">
          {" "}
          RF-10
        </h7>
         <h7 className="absolute  top-[430px] left-[973px] p-2  bg-slate-200 text-slate-800 font-bold rounded-md text-sm">
          {" "}
          Hemming Cell
        </h7>
         </div>

      {isModalOpen && selectedRobot && (
        <ModalHOC isOpen={isModalOpen} onClose={() => setIsModalOpen(false)}>
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
          >
            <h3 className="text-xl font-bold text-gray-800 mb-4 text-center">
              Robot Details
            </h3>
            <div className="space-y-4 mt-6">
              <div className="grid grid-cols-[34px_130px_auto] items-center text-gray-700">
                <Cpu className="w-6 h-6 text-blue-600" />
                <span className="font-medium">Name</span>
                <span className="font-semibold text-right">
                  {selectedRobot.name}
                </span>
              </div>
              <div className="grid grid-cols-[34px_130px_auto] items-center text-gray-700">
                <HardDrive className="w-6 h-6 text-green-600" />
                <span className="font-medium">Make</span>
                <span className="font-semibold text-right">
                  {selectedRobot.make}
                </span>
              </div>
              <div className="grid grid-cols-[34px_130px_auto] items-center text-gray-700">
                <Globe className="w-6 h-6 text-red-600" />
                <span className="font-medium">IP Address</span>
                <span className="font-semibold text-right">
                  {selectedRobot.ip}
                </span>
              </div>
            </div>
            <div className="flex justify-center space-x-3 mt-6">
              <Button label="View Events" onClick={()=>{
                robotSelect(selectedRobot);
                visibilityChange("Robot Events")
              }} />
              <Button
                label="Close"
                onClick={() => setIsModalOpen(false)}
                bgColor="bg-white"
                textColor="text-purple-950 border border-purple-950"
              />
            </div>
          </motion.div>
        </ModalHOC>
      )}
    </div>)
  );
};

RobotLayout.propTypes = {
  robotSelect: PropTypes.func.isRequired,
  visibilityChange: PropTypes.func.isRequired,
};

export default RobotLayout;
