import { useRef, useState } from "react";
import Chart from "react-apexcharts";
import ApexCharts from "apexcharts";

const SHIFT_COLORS = {
  A: { base: "#40C4FF", dark: "#1a8fb8", darker: "#0d5c78", light: "#a8e8ff" },
  B: { base: "#FFB07C", dark: "#c97a3a", darker: "#8a4e1e", light: "#ffe0c8" },
  C: { base: "#A6F54F", dark: "#6db81a", darker: "#437a0a", light: "#d8fda0" },
};

const GroupStackedBar = ({ data }) => {
  const [hiddenSeries, setHiddenSeries] = useState({});

  // ── FIX: track series visibility manually and rebuild series with nulls ──
  const toggleSeries = (seriesName) => {
    setHiddenSeries((prev) => ({
      ...prev,
      [seriesName]: !prev[seriesName],
    }));
  };

  if (!Array.isArray(data) || data?.length === 0) {
    return (
      <div className="text-gray-500 text-sm text-center py-6">
        No production data available
      </div>
    );
  }

  const validData = data.filter(
    (item) =>
      item?.Period &&
      item?.Shift &&
      typeof item?.Actual === "number" &&
      typeof item?.Target === "number"
  );

  if (validData.length === 0) {
    return (
      <div className="text-gray-500 text-sm text-center py-6">
        No valid production data found
      </div>
    );
  }

  const dates = [...new Set(validData.map((d) => d.Period))];

  const getValue = (date, shift, key) => {
    const row = validData.find(
      (d) => d.Period === date && d.Shift?.trim() === shift
    );
    return Number(row?.[key]) || 0;
  };

  const seriesDefs = [
    { name: "Shift A Actual", group: "actual", shift: "A", key: "Actual" },
    { name: "Shift B Actual", group: "actual", shift: "B", key: "Actual" },
    { name: "Shift C Actual", group: "actual", shift: "C", key: "Actual" },
    { name: "Shift A Target", group: "target", shift: "A", key: "Target" },
    { name: "Shift B Target", group: "target", shift: "B", key: "Target" },
    { name: "Shift C Target", group: "target", shift: "C", key: "Target" },
  ];

const formatDate = (dateStr) => {
  if (!dateStr) return "—";
  const parts = dateStr.split("-");

  if (parts.length === 2) {
    // yyyy-mm → mm-yyyy
    const [yyyy, mm] = parts;
    return `${mm}-${yyyy}`;
  }

  if (parts.length === 3) {
    // yyyy-mm-dd → dd-mm-yyyy
    const [yyyy, mm, dd] = parts;
    return `${dd}-${mm}-${yyyy}`;
  }

  return dateStr; // fallback — return as-is if unrecognized format
};

  // ── FIX: replace hidden series data with nulls so stacking stays intact ──
  const series = seriesDefs.map((def) => ({
    name: def.name,
    group: def.group,
    data: hiddenSeries[def.name]
      ? dates.map(() => null)
      : dates.map((d) => getValue(d, def.shift, def.key)),
  }));

  const options = {
    chart: {
      id: "target-actual-chart",
      type: "bar",
      stacked: true,
      toolbar: { show: false },
      animations: { enabled: true, easing: "easeinout", speed: 600 },
    },

    plotOptions: {
      bar: {
        horizontal: false,
        borderRadius: 3,
        borderRadiusApplication: "end",
        borderRadiusWhenStacked: "last",
        columnWidth: "40%",
        dataLabels: {
          position: "center", // ⬅️ center inside each stack segment
          hideOverflowingLabels: true,
        },
      },
    },

    colors: [
      SHIFT_COLORS.A.base,
      SHIFT_COLORS.B.base,
      SHIFT_COLORS.C.base,
      SHIFT_COLORS.A.light,
      SHIFT_COLORS.B.light,
      SHIFT_COLORS.C.light,
    ],

    fill: {
      type: "gradient",
      gradient: {
        shade: "light",
        type: "horizontal",
        shadeIntensity: 1,
        inverseColors: false,
        opacityFrom: 1,
        opacityTo: 1,
        colorStops: [
          // Shift A Actual
          [
            { offset: 0,   color: SHIFT_COLORS.A.light,  opacity: 1 },
            { offset: 30,  color: SHIFT_COLORS.A.base,   opacity: 1 },
            { offset: 75,  color: SHIFT_COLORS.A.base,   opacity: 1 },
            { offset: 100, color: SHIFT_COLORS.A.dark,   opacity: 1 },
          ],
          // Shift B Actual
          [
            { offset: 0,   color: SHIFT_COLORS.B.light,  opacity: 1 },
            { offset: 30,  color: SHIFT_COLORS.B.base,   opacity: 1 },
            { offset: 75,  color: SHIFT_COLORS.B.base,   opacity: 1 },
            { offset: 100, color: SHIFT_COLORS.B.dark,   opacity: 1 },
          ],
          // Shift C Actual
          [
            { offset: 0,   color: SHIFT_COLORS.C.light,  opacity: 1 },
            { offset: 30,  color: SHIFT_COLORS.C.base,   opacity: 1 },
            { offset: 75,  color: SHIFT_COLORS.C.base,   opacity: 1 },
            { offset: 100, color: SHIFT_COLORS.C.dark,   opacity: 1 },
          ],
          // Shift A Target
          [
            { offset: 0,   color: SHIFT_COLORS.A.base,   opacity: 1 },
            { offset: 30,  color: SHIFT_COLORS.A.dark,   opacity: 1 },
            { offset: 75,  color: SHIFT_COLORS.A.dark,   opacity: 1 },
            { offset: 100, color: SHIFT_COLORS.A.darker, opacity: 1 },
          ],
          // Shift B Target
          [
            { offset: 0,   color: SHIFT_COLORS.B.base,   opacity: 1 },
            { offset: 30,  color: SHIFT_COLORS.B.dark,   opacity: 1 },
            { offset: 75,  color: SHIFT_COLORS.B.dark,   opacity: 1 },
            { offset: 100, color: SHIFT_COLORS.B.darker, opacity: 1 },
          ],
          // Shift C Target
          [
            { offset: 0,   color: SHIFT_COLORS.C.base,   opacity: 1 },
            { offset: 30,  color: SHIFT_COLORS.C.dark,   opacity: 1 },
            { offset: 75,  color: SHIFT_COLORS.C.dark,   opacity: 1 },
            { offset: 100, color: SHIFT_COLORS.C.darker, opacity: 1 },
          ],
        ],
      },
    },

   stroke: {
      show: true,
      width: [2.5, 2.5, 2.5, 2.5, 2.5, 2.5], // only target bars get a border
      dashArray: [1, 1, 1, 1, 1, 1], // dashed on target
      colors: [
        "transparent",
        "transparent",
        "transparent",
        "transparent",
        "transparent",
        "transparent",
      ],
    },

    // ── DATA LABELS centered inside each stack segment ──
    dataLabels: {
      enabled: true,
      textAnchor: "middle",
      distributed: false,
      offsetY: 0,
      style: {
        fontSize: "11px",
        fontWeight: 600,
        colors: ["#fff"],   // white label works on all gradient shades
      },
      formatter: (val) => (val && val > 0 ? val : ""),
      dropShadow: {
        enabled: true,
        top: 1,
        left: 1,
        blur: 2,
        color: "#0004",
        opacity: 0.6,
      },
    },

    grid: {
      borderColor: "#E5E7EB",
      strokeDashArray: 3,
      padding: { top: 20, bottom: 25, left: 10, right: 10 },
    },

    xaxis: {
       categories: dates.map(formatDate),
      title: {
        text: "Date",
        style: { fontSize: "14px", fontWeight: 600 },
      },
      labels: { style: { fontSize: "12px" } },
      axisBorder: { show: false },
      axisTicks: { show: false },
    },

    yaxis: {
      title: {
        text: "Production Count",
        style: { fontSize: "14px", fontWeight: 600 },
      },
      labels: { style: { fontSize: "12px" } },
    },

    legend: { show: false },

    tooltip: {
  theme: "light",
  style: { fontSize: "12px" },
  shared: true,
  intersect: false,
  custom: ({ series, seriesIndex, dataPointIndex, w }) => {
    const date = w.globals.labels[dataPointIndex]; 
    const shifts = ["A", "B", "C"];

    const rows = shifts.map((shift) => {
      const actualIdx = seriesDefs.findIndex(
        (s) => s.name === `Shift ${shift} Actual`
      );
      const targetIdx = seriesDefs.findIndex(
        (s) => s.name === `Shift ${shift} Target`
      );

      const actual = series[actualIdx]?.[dataPointIndex] ?? 0;
      const target = series[targetIdx]?.[dataPointIndex] ?? 0;

      return `
        <tr>
          <td style="padding:5px 10px 5px 8px; font-weight:600; color:#374151;">
            <span style="
              display:inline-block;
              width:8px; height:8px;
              border-radius:2px;
              background:${SHIFT_COLORS[shift].base};
              margin-right:5px;
              vertical-align:middle;
            "></span>
            Shift ${shift}
          </td>
          <td style="padding:5px 8px; text-align:center; color:#1a8fb8; font-weight:600;">
            ${actual ?? "—"}
          </td>
          <td style="padding:5px 8px; text-align:center; color:#0d5c78; font-weight:600;">
            ${target ?? "—"}
          </td>
         
        </tr>
      `;
    });

    const totalActual = shifts.reduce((sum, shift) => {
      const idx = seriesDefs.findIndex((s) => s.name === `Shift ${shift} Actual`);
      return sum + (series[idx]?.[dataPointIndex] ?? 0);
    }, 0);

    const totalTarget = shifts.reduce((sum, shift) => {
      const idx = seriesDefs.findIndex((s) => s.name === `Shift ${shift} Target`);
      return sum + (series[idx]?.[dataPointIndex] ?? 0);
    }, 0);

   

    return `
      <div style="
        background:#fff;
        border:1px solid #E5E7EB;
        border-radius:8px;
        box-shadow:0 4px 12px rgba(0,0,0,0.1);
        overflow:hidden;
        min-width:240px;
        font-family:inherit;
      ">
        <!-- Header -->
        <div style="
          background:#f9fafb;
          padding:7px 12px;
          border-bottom:1px solid #E5E7EB;
          font-size:12px;
          font-weight:700;
          color:#111827;
        ">
          📅 ${date}
        </div>

        <!-- Table -->
        <table style="width:100%; border-collapse:collapse; font-size:12px;">
          <thead>
            <tr style="background:#f3f4f6;">
              <th style="padding:5px 10px 5px 8px; text-align:left; color:#6B7280; font-weight:600;">Shift</th>
              <th style="padding:5px 8px; text-align:center; color:#1a8fb8; font-weight:600;">Actual</th>
              <th style="padding:5px 8px; text-align:center; color:#0d5c78; font-weight:600;">Target</th>
            </tr>
          </thead>
          <tbody>
            ${rows.join("")}
          </tbody>
          <tfoot>
            <tr style="border-top:2px solid #E5E7EB; background:#f9fafb;">
              <td style="padding:6px 10px 6px 8px; font-weight:700; color:#111827;">Total</td>
              <td style="padding:6px 8px; text-align:center; font-weight:700; color:#1a8fb8;">${totalActual}</td>
              <td style="padding:6px 8px; text-align:center; font-weight:700; color:#0d5c78;">${totalTarget}</td>
            </tr>
          </tfoot>
        </table>
      </div>
    `;
  },
},
  };

  return (
    <div style={{ width: "100%", height: "100%" }}>
      <Chart
        options={options}
        series={series}
        type="bar"
        height="400px"
        width="100%"
      />

      {/* ── CUSTOM LEGEND ── */}
      <div className="flex flex-row justify-center items-center gap-2 mt-2">

        {/* ACTUAL */}
        <div className="flex items-center gap-3">
          <span className="text-xs font-semibold text-gray-600 uppercase tracking-wide">
            Actual
          </span>
          {["A", "B", "C"].map((shift) => (
            <LegendItem
              key={`actual-${shift}`}
              color={SHIFT_COLORS[shift].base}
              label={`Shift ${shift}`}
              inactive={hiddenSeries[`Shift ${shift} Actual`]}
              onClick={() => toggleSeries(`Shift ${shift} Actual`)}
            />
          ))}
        </div>

        <div className="w-px h-6 bg-gray-300 mx-3" />

        {/* TARGET */}
        <div className="flex items-center gap-3">
          <span className="text-xs font-semibold text-gray-600 uppercase tracking-wide">
            Target
          </span>
          {["A", "B", "C"].map((shift) => (
            <LegendItem
              key={`target-${shift}`}
              color={SHIFT_COLORS[shift].dark}
              label={`Shift ${shift}`}
              inactive={hiddenSeries[`Shift ${shift} Target`]}
              onClick={() => toggleSeries(`Shift ${shift} Target`)}
            />
          ))}
        </div>

      </div>
    </div>
  );
};

const LegendItem = ({ color, label, inactive, onClick }) => (
  <div
    onClick={onClick}
    className="flex items-center gap-1 cursor-pointer select-none"
    style={{
      opacity: inactive ? 0.3 : 1,
      filter: inactive ? "grayscale(40%)" : "none",
      transition: "opacity 0.2s, filter 0.2s",
    }}
  >
    <span
      style={{
        width: 12,
        height: 12,
        borderRadius: 2,
        backgroundColor: color,
        display: "inline-block",
      }}
    />
    <span className="text-xs text-gray-700">{label}</span>
  </div>
);

export default GroupStackedBar;