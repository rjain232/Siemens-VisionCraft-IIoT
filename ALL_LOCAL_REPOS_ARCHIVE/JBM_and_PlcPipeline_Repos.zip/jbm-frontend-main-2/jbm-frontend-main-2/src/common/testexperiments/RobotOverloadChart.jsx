import React from "react";
import Chart from "react-apexcharts";

const RobotOverloadChart = () => {
  const options = {
    chart: {
      type: "line",
      height: 400,
      zoom: { enabled: true }
    },
    stroke: {
      width: [2, 2, 2],
      curve: "smooth"
    },
    xaxis: {
      categories: ["10:00", "10:05", "10:10", "10:15", "10:20", "10:25"],
      title: { text: "Time" }
    },
    yaxis: [
      {
        title: { text: "Torque (Nm) & Current (A)" },
        labels: { formatter: (val) => `${val.toFixed(1)}` },
      },
      {
        opposite: true,
        title: { text: "Temperature (°C)" },
        labels: { formatter: (val) => `${val.toFixed(1)}°C` }
      }
    ],
    markers: { size: 5 },
    legend: { position: "top" },
  };

  const series = [
    { name: "Robot 1 Torque", data: [50, 55, 60, 80, 85, 90] },
    { name: "Robot 1 Current", data: [10, 12, 14, 18, 20, 22] },
    { name: "Robot 1 Temperature", data: [35, 36, 38, 40, 42, 45], yAxisIndex: 1 },
    { name: "Robot 2 Torque", data: [40, 45, 50, 65, 70, 75] },
    { name: "Robot 2 Current", data: [8, 9, 11, 13, 15, 16] },
    { name: "Robot 2 Temperature", data: [30, 32, 33, 35, 37, 40], yAxisIndex: 1 },
    { name: "Robot 3 Torque", data: [60, 65, 70, 85, 90, 95] },
    { name: "Robot 3 Current", data: [15, 17, 19, 21, 24, 26] },
    { name: "Robot 3 Temperature", data: [38, 40, 42, 45, 47, 50], yAxisIndex: 1 }
  ];

  return <Chart options={options} series={series} type="line" height={400} />;
};

export default RobotOverloadChart; 
