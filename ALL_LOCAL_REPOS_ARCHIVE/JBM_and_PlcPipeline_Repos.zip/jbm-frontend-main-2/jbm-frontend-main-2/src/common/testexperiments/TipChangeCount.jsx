import withTable from "../../hoc/withTable";
import axiosInstance from "../axioInstance/AxioInstance";
import DataTable from "../components/DataTable";
import DateRangeSelector from "../components/DateRangeSelector ";
import DropdwonTools from "../components/DropdownTools";
import { useEffect, useState } from "react";



  const TipChangeCount = ({tipchangedata}) => {
       // const data = [
      //   {
      //       timestamp: "2025-03-17 10:15:30",
      //       robotid: "R10001",
      //       tipchangecount: "24",
          
      //   },
      //   {
      //       timestamp: "2025-03-17 10:20:40",
      //       robotid: "R10002",
      //       tipchangecount: "26",
         
      //   },
      //   {
      //       timestamp: "2025-03-17 10:35:10",
      //       robotid: "R10003",
      //       tipchangecount: "24",
          
      //   },
      //   {
      //       timestamp: "2025-03-17 11:40:30",
      //       robotid: "R10004",
      //       tipchangecount: "23",
         
      //   },
      //   {
      //       timestamp: "2025-03-17 11:55:40",
      //       robotid: "R10005",
      //       tipchangecount: "26",
          
      //   },
        
      // ];
      
 
      const columns = [
        {
          label: "Timestamp",
          accessor: "timestamp",
        },
        {
          label: "Robot Id",
          accessor: "robotid",
        },
        {
          label: "Tip Change Count",
          accessor: "tipchangecount",
        },
      ];
      
      const EnhancedTable = withTable(DataTable);
      return (
          <div>
              
              <EnhancedTable
                  data={tipchangedata}
                  columns={columns}
                  enableSearch={true}
                  enableFilter={false}
                  enablePagination={true}
              />
          </div>
      );
  };
  
  export default TipChangeCount;