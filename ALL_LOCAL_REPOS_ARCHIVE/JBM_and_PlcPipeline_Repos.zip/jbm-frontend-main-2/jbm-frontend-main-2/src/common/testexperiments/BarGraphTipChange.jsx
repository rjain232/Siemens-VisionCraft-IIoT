import React from "react";
import Chart from "react-apexcharts";

const BarGraphTipChange = ({tipchangedata=[]}) => {
  const tipdata=tipchangedata;
  const chartOptions = {
    chart: {
      type: "bar",
      height: 400,
      toolbar: { show: false },
    },
    plotOptions: {
      bar: {
        distributed: false,
        borderRadius: 2,
        horizontal: false,
        columnWidth: "50%",
        dataLabels: {
          position: "top",
        },
      },
    },
    xaxis: {
      categories: tipdata.map(item=>item.RobotId),
      title: { text: "Robot ID" },
    },
    yaxis: {
      title: { text: "Tip Change Count" },
    },
    dataLabels: {
      offsetY: -20,
      enabled: true,
      textAnchor: "middle",
      style: { fontSize: "12px", colors: ["#000"] },
    },
    colors: ["#40C4FF"],
    // colors: [
    //     "#40C4FF",
    //     "#800000",
    //     "#BF0000",
    //     "#ed0404",
    //     "#f41f1f",
    //     "#f93131",
    //     "#e05353",
    //     "#f26060",
    //     "#9e7373",
    //     "#d19999",
    //   ], 
    tooltip: {
      y: {
        formatter: function (value) {
          return `${value}`;
        },
      },
    },
    legend: { show: false },
//     fill: {
//   type: "gradient",
//   gradient: {
//     type: "horizontal",   // ← changed from "vertical"
//     colorStops: [
//       { offset: 0,   color: "#B3E5FC", opacity: 1 },  // light left edge
//       { offset: 30,  color: "#40C4FF", opacity: 1 },  // your base color
//       { offset: 65,  color: "#0288D1", opacity: 1 },  // mid shadow
//       { offset: 100, color: "#01579B", opacity: 1 },  // dark right edge
//     ],
//   },
// },
  };

  const chartSeries = [
    {
      name: "Tip Change Count",
      data: tipdata.map(item=>item.TipChangeCount),
    },
  ];

  return (
    <div className="bg-white rounded-xl shadow-lg pt-4 px-6 pb-2 w-full">
      <h2 className="text-2xl font-bold text-center mb-4">
      Tip Change Count
      </h2>
      {tipdata.length === 0 ? (
        <div className="flex justify-center items-center h-64">
          <p className="text-gray-500 text-lg">No data available</p>
        </div>
      ) : (
        <Chart options={chartOptions} series={chartSeries} type="bar" height={400} />
      )}
    </div>
  );
};

export default BarGraphTipChange;
