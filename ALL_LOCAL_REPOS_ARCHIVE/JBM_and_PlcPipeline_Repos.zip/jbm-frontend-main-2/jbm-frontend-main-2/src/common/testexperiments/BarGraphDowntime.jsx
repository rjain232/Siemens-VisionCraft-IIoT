import React from "react";
import Chart from "react-apexcharts";

function secondsToHHMMSSS(seconds) {
  let totalMilliseconds = Math.round(seconds * 1000);

  let hours = Math.floor(totalMilliseconds / 3600000);
  let mins = Math.floor((totalMilliseconds % 3600000) / 60000);
  let secs = Math.floor((totalMilliseconds % 60000) / 1000);
  let millis = totalMilliseconds % 1000;

  return (
    String(hours).padStart(2, "0") + ":" +
    String(mins).padStart(2, "0") + ":" +
    String(secs).padStart(2, "0") + "." +
    String(millis).padStart(3, "0")
  );
}

const BarGraphDowntime = ({top10Alarm=[] ,title}) => {
  const downtimeData=top10Alarm;
  const chartOptions = {
    chart: {
      type: "bar",
      height: 400,
      toolbar: { show: false },
    },
    plotOptions: {
      bar: {
        distributed: true,
        borderRadius: 2,
        horizontal: false,
        columnWidth: "50%",
        dataLabels: {
          position: "top",
        },
      },
    },
    xaxis: {
      categories: downtimeData.map(item=>item.date),
      title: { text: "Date" },
    },
    yaxis: {
      title: { text: "Downtime (HH:MM:SS.MS)" },
      labels : {
       formatter: function (value) {
        console.log(value)
          return `${secondsToHHMMSSS(value)} `;
        }
      }
    },
    dataLabels: {
      offsetY: -20,
      enabled: true,
      textAnchor: "middle",
      style: { fontSize: "12px", colors: ["#000"] },
       formatter: function (value) {
         return `${secondsToHHMMSSS(value)} `;

        },
    },
    colors: [
        "#400000",
        "#800000",
        "#BF0000",
        "#ed0404",
        "#f41f1f",
        "#f93131",
        "#e05353",
        "#f26060",
        "#9e7373",
        "#d19999",
      ], 
    tooltip: {
      y: {
        formatter: function (value) {
          return `${secondsToHHMMSSS(value)} `;
        },
      },
    },
    legend: { show: false },
  };

  const chartSeries = [
    {
      name: "Downtime (HH:MM:SS.MS)",
      data: downtimeData.map(item=>(parseFloat(item.downtimeInMinutes).toFixed(2))),
    },
  ];

  return (
    <div className="bg-white rounded-xl shadow-lg pt-4 px-6 pb-2 w-full">
      <h2 className="text-2xl font-bold text-center mb-4">
      {title}
      </h2>
      <div className="w-[99%] justify-center items-center">
        {downtimeData.length === 0 ? (
          <div className="flex justify-center items-center h-64">
            <p className="text-gray-500 text-lg">No data available</p>
          </div>
        ) : (
          <Chart options={chartOptions} series={chartSeries} type="bar" height={400}/>
        )}
      </div>
    </div>
  );
};

export default BarGraphDowntime;
