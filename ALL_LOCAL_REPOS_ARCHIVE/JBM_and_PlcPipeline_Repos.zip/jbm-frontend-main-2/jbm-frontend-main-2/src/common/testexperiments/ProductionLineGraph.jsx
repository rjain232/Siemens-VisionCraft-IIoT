import React from "react";
import Chart from "react-apexcharts";
import { subDays, format } from "date-fns";

const ProductionLineGraph = ({data}) => {
 // console.log("ProductionLineGraph data", data);
  // Generate last 3 days dynamically
  const lastThreeDays = [...Array(3)].map((_, i) =>
    format(subDays(new Date(), i), "yyyy-MM-dd")
  ).reverse();


  const options = {
    chart: {
      type: "line",
      height: 400,
      zoom: { enabled: false },
    },
    stroke: {
      width: 3,
      curve: "straight",
    },
    xaxis: {
      categories: data?.map(item => item.Date),
      title: { text: "Date" },
    },
    yaxis: {
      title: { text: "Production Count" },
      labels: { formatter: (val) => `${val.toFixed(0)}` },
    },
    markers: { size: 5 },
    legend: {
      position: "bottom",
      horizontalAlign: "center",
      offsetY: 10,
    },
    colors:["#00893D"],
    dataLabels: {
      enabled: true,
      formatter: (val) => (val > 0 ? val : ""),
    },
  };

  const series = [
    {
      name: "Production Count",
      data:data?.map(item => Number(item.PartsProduced)), // Sample data for last 3 days
    },
  ];

  return (
    <div className="w-full max-w-full mx-auto px-4 pt-2 ">
      <Chart options={options} series={series} type="line" height={300} />
    </div>
  );
};

export default ProductionLineGraph;
