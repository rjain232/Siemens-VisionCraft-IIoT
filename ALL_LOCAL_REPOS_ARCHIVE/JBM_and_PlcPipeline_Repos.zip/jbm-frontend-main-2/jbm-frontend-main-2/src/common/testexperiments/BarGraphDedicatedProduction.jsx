import React from "react";
import Chart from "react-apexcharts";

const productionReportData = [
  { shift: "Shift A", actual: 90, target: 100 },
  { shift: "Shift B", actual: 95, target: 105 },
  { shift: "Shift C", actual: 100, target: 110 },
];

const BarGraphDedicatedProduction = ({data}) => {
  
  const series = [
    { name: "Actual Production", data: data.map((item) => item.Actual) },
    { name: "Target Production", data: data.map((item) => item.Target) },
  ];

  const options = {
    chart: {
      type: "bar",
      height: 400,
      stacked: false, // Using grouped bars instead of stacked
    },
    xaxis: {
      categories: data.map((item) => [`Shift ${item.Shift}`,item.Period]),
      title: { text: "Shift" },
    },
    yaxis: {
      title: { text: "Production Count" },
    },
    legend: {
      position: "bottom",
      horizontalAlign: "center",
      offsetY: 0,
    },
    dataLabels: { enabled: true },
    plotOptions: {
      bar: {
        horizontal: false,
        borderRadius: 4,
        columnWidth: "50%",
      },
    },
    colors: ["#f2ec3f","#00893D" ], // Green for actual, Red for target
  };

  return (
    <div className="bg-white pt-4 px-6 pb-2 w-full">
      <Chart options={options} series={series} type="bar" height={400} />
    </div>
  );
};

export default BarGraphDedicatedProduction;
