import React from 'react'
import RobotIcon from "../../assets/robotic-arm (1).png"
import MotorIcon from "../../assets/motor.png"

import WarningIcon from "../../assets/warning.png"
import { AlertTriangle, BatteryFull, BatteryLow, BatteryMedium } from 'lucide-react'
import { motion } from 'framer-motion'


const getStatusWiseColor = (status) => {
  switch (status) {
    case "Active":
      return "bg-green-500";
      case "Breakdown":
        return "bg-[#dc3545]";
        case "Idle" : 
        return "bg-[#ffc107]";
        case "Power Off" : 
        return  "bg-[#ff6347]";
    default:
      break;
  }
};

const Robo = ({name , status , battery , className}) => {
   return (
<div className={className}>
  <div className="w-[170px] flex flex-col items-center bg-white shadow-lg rounded-lg p-2">
  {/* Robot Name - Centered */}
  <h2 className="text-lg font-semibold text-center w-full">{name}</h2>

  {/* Content: Robot Icon & Details */}
  <div className="min-w-[165px] flex items-center mt-2 relative">
    {/* Left: Robot Icon */}
    <div className="w-[60px] flex justify-center ps-1 relative">
      <img src={RobotIcon} height={60} width={60} />
      {status === "Breakdown" && (
              <motion.div
                className="absolute top-2 right-4 text-yellow-500"
                animate={{ opacity: [1, 0.2, 1] }}
                transition={{ duration: 0.8, repeat: Infinity }}
              >
                <img src={WarningIcon} height={25} width={25}/>
              </motion.div>
            )}
    </div>

    {/* Right: Robot Details */}
    <div className="w-2/3 ms-4">
      {/* Status with Dynamic Background */}
      <motion.div
              className={`text-white text-sm font-bold py-1 px-2 rounded-md w-fit ${
                getStatusWiseColor(status)
              }`}
              animate={status === "Breakdown" ? { opacity: [1, 0.2, 1] } : {}}
              transition={{ duration: 1, repeat: Infinity }}
            >
              {status}
            </motion.div>

      {/* Battery Status */}
      <div className="mt-2 flex items-center gap-x-1">
        {battery == 1 ? (
          <BatteryFull className="text-green-600 w-6 h-6" />
        ) : 
          <BatteryLow className="text-red-600 w-6 h-6" />
        }
              <img src={MotorIcon} height={24} width={24} />
  
      </div>
    </div>
  </div>
</div>
</div>
  )
}

export default Robo