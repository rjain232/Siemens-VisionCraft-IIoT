import { useState, useEffect } from "react";
import PropTypes from "prop-types";
import Chart from "react-apexcharts";

const SHIFT_COLORS = {
  0: "#40C4FF", // Shift A — blue
  1: "#FFB07C", // Shift B — orange
  2: "#A6F54F", // Shift C — green
};

const getOEEColor = (value) => {
  if (value <= 50) return "#FF4C4C"; // Red   — poor
  if (value <= 75) return "#FFA500"; // Orange — average
  if (value <= 90) return "#f2ec3f"; // Yellow — good
  return "#00893D";                  // Green  — excellent
};

const ShiftEfficiencyPareto = ({ series, labels, height }) => {
  const [centerText, setCenterText]   = useState("OEE");
  const [centerValue, setCenterValue] = useState(series[3] ?? 0);

  useEffect(() => {
    setCenterText("OEE");
    setCenterValue(series[3] ?? 0);
  }, [series]);

  const colors = series.map((value, index) => {
    if (index === 3) return getOEEColor(value);
    return SHIFT_COLORS[index] ?? "#40C4FF";
  });

  const centerColor =
    centerText === "OEE"
      ? getOEEColor(centerValue)
      : colors[labels.indexOf(centerText)] ?? "#333";

  const options = {
    chart: {
      id: "ShiftWiseOEEChart",
      type: "radialBar",
      offsetY: -20,
      events: {
        dataPointMouseEnter: (_event, _ctx, config) => {
          const idx = config.seriesIndex;
          if (idx !== undefined && idx >= 0) {
            setCenterText(labels[idx]);
            setCenterValue(series[idx]);
          }
        },
        dataPointMouseLeave: () => {
          setCenterText("OEE");
          setCenterValue(series[3] ?? 0);
        },
      },
    },

    stroke: { lineCap: "round" },

    plotOptions: {
      radialBar: {
        barSize: "18%",
        offsetY: 0,
        dataLabels: {
          name: {
            fontSize: "13px",
            fontWeight: 600,
            color: "#555",
            offsetY: -4,
          },
          value: {
            fontSize: "22px",
            fontWeight: "bold",
            color: centerColor,
            offsetY: 4,
            formatter: () => `${centerValue}%`,
          },
          total: {
            show: true,
            label: centerText,
            fontSize: "13px",
            fontWeight: 600,
            color: "#555",
            formatter: () => `${centerValue}%`,
          },
        },
        hollow: {
          size: "35%",
          background: "transparent",
        },
        track: {
          strokeWidth: "100%",
          background: "#efefef",
          margin: 4,
        },
      },
    },

    labels,
    colors,
    legend: { show: false },

    tooltip: {
      enabled: true,
      y: { formatter: (val) => `${val}%` },
    },
  };

  return (
    <div style={{ width: "100%", display: "flex", flexDirection: "column" }}>

      {/* ── Radial Chart ── */}
      <Chart
        options={options}
        series={series}
        type="radialBar"
        height={height || 320}
      />

      {/* ── Custom Pill Legend ── */}
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          flexWrap: "wrap",
          gap: "6px 12px",
          padding: "4px 12px",
          marginTop: "-16px",
        }}
      >
        {labels.map((label, idx) => {
          const displayLabel = (String(label).toLowerCase().includes("overall")) ? "Overall" : label;
          const isActive = centerText === displayLabel;
          return (
            <div
              key={`${displayLabel}-${idx}`}
              onMouseEnter={() => {
                setCenterText(displayLabel);
                setCenterValue(series[idx]);
              }}
              onMouseLeave={() => {
                setCenterText("OEE");
                setCenterValue(series[3] ?? 0);
              }}
              onClick={() => {
                const isCurrentlyActive = centerText === displayLabel;
                setCenterText(isCurrentlyActive ? "OEE" : displayLabel);
                setCenterValue(isCurrentlyActive ? series[3] ?? 0 : series[idx]);
              }}
              style={{
                display: "flex",
                alignItems: "center",
                gap: "6px",
                cursor: "pointer",
                padding: "4px 10px",
                borderRadius: "20px",
                border: `1.5px solid ${colors[idx]}`,
                backgroundColor: isActive ? `${colors[idx]}22` : "transparent",
                transition: "all 0.2s",
                fontSize: "12px",
                fontWeight: 500,
                color: "#374151",
                userSelect: "none",
              }}
            >
              <span
                style={{
                  width: 10,
                  height: 10,
                  borderRadius: "50%",
                  backgroundColor: colors[idx],
                  flexShrink: 0,
                }}
              />
              
              {displayLabel}:&nbsp;
              <strong style={{ color: colors[idx] }}>{series[idx]}%</strong>
            </div>
          );
        })}
      </div>
    </div>
  );
};

ShiftEfficiencyPareto.propTypes = {
  series: PropTypes.arrayOf(PropTypes.number).isRequired,
  labels: PropTypes.arrayOf(PropTypes.string).isRequired,
  height: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
};

export default ShiftEfficiencyPareto;