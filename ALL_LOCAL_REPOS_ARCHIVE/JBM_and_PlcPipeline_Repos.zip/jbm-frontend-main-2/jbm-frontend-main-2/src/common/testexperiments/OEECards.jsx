import React, { useEffect, useRef } from "react";
import { RadialGauge } from "canvas-gauges";

const OEECards = ({ title, oee }) => {
  const gaugeRef = useRef(null);

  useEffect(() => {
    if (gaugeRef.current) {
      new RadialGauge({
        renderTo: gaugeRef.current,
        width: 260,
        height: 260,
        units: "%",
        minValue: 0,
        maxValue: 100,
        value: oee,
        majorTicks: ["0", "20", "40", "60", "80", "100"],
        minorTicks: 2,
        highlights: [
          { from: 0, to: 50, color: "#C30000" }, // Red
          { from: 50, to: 75, color: "yellow" }, // Yellow
          { from: 75, to: 100, color: "green" }, // Green
        ],
        colorPlate: "#fff",
        colorMajorTicks: "#000",
        colorMinorTicks: "#666",
        colorNumbers: "#000",
        colorNeedle: "black",
        needleType: "arrow",
        needleWidth: 3,
        animationDuration: 500,
        animationRule: "linear",
        // ✅ FORMAT VALUE TO SHOW "85%" INSTEAD OF "085.00"
        valueInt: 0, // Show only whole numbers
        valueDec: 0, // Remove decimal places
        valueBox: true, // Ensure value is displayed
        valueText: `${oee}%`, // Add "%" symbol
      }).draw();
    }
  }, [oee]);

  return (
    <div
      className="bg-white p-4 flex flex-col items-center transform hover:scale-105 transition-transform duration-300 w-full h-auto"
    >
      {/* <h2 className="text-xl font-semibold text-gray-900 text-center mb-4">
        {title}
      </h2> */}

      {/* Speedometer Gauge */}
      <canvas ref={gaugeRef} className="w-full max-w-[260px]"></canvas>
    </div>
  );
};

export default OEECards;
