import PropTypes from "prop-types";
import PieChart from "../graphs/PieChart";

const ShiftwiseProductionPieChart = ({data}) => {
  const series = data?.map(item => item.PartsProduced);
  return (
    <PieChart
      chartSeries={series}
      colors={["#40C4FF", "#FFB07C", "#A6F54F"]}
      labels={data?.map(item => `Shift ${item.Shift}`)}
      height={300}
      chartType={"ShiftWise Production"}
    />
  );
};
ShiftwiseProductionPieChart.propTypes = {
  data: PropTypes.arrayOf(
    PropTypes.shape({
      PartsProduced: PropTypes.number.isRequired,
    })
  ).isRequired,
};

export default ShiftwiseProductionPieChart;
