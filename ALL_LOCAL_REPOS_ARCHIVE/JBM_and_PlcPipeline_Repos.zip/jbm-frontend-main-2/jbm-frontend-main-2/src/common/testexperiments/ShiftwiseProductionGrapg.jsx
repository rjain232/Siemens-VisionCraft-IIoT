import React from "react";
import Chart from "react-apexcharts";
import { subDays, format } from "date-fns";
import PropTypes from "prop-types";


const getStackedBarColors = (data) => {
    const transposedData = data[0].data.map((_, colIndex) =>
      data.map((row) => row.data[colIndex])
    );
    console.log("transposedData",transposedData);
  
    return transposedData.map((values) => {
      const maxVal = Math.max(...values);
      const minVal = Math.min(...values);
  
      return values.map((value) => {
        if (value === maxVal) return "#00893D"; // Green for Max
        if (value === minVal) return "#94f7c1"; // Yellow for Min
        return "#05DF72"; // Blue for Medium
      });
    }).flat();
  };
  const SHIFT_COLORS = {
  shift1: "#40C4FF", // dark green
  shift2: "#FFB07C", // medium green
  shift3: "#A6F54F", // light green
};

const ShiftwiseProductionGraph = ({data}) => {
  const series = [
        { name: "Shift A", data: data ?  data?.map(item => item.Shift_A) : []  ,   color: SHIFT_COLORS.shift1 },
        { name: "Shift B", data: data ?  data?.map(item => item.Shift_B) : []   , color: SHIFT_COLORS.shift2 },
        { name: "Shift C", data:data ?  data?.map(item => item.Shift_C) : [] ,  color: SHIFT_COLORS.shift3 },
      ];
      const colors = getStackedBarColors(series);

  // Generate last 3 days dynamically using date-fns
  const lastThreeDays = [...Array(3)].map((_, i) =>
    format(subDays(new Date(), i), "yyyy-MM-dd")
  ).reverse();

  const options = {
    chart: {
      type: "bar",
      height: 400,
      stacked: true, // Enable stacked bars
      toolbar: { show: false },
    },
    xaxis: {
      categories: data?.map(item => item.date),
      title: { text: "Date" },
    },
    yaxis: {
      title: { text: "Production Count" },
    },
    legend: {
       position: "bottom",
      horizontalAlign: "center",
      offsetY: 0,
    },
    dataLabels: { enabled: true },
    plotOptions: {
      bar: {
        horizontal: false,
        borderRadius: 4,
        columnWidth: "50%",
      },
    },
    //colors:colors
  };

 

  return <Chart options={options} series={series} type="bar" height={310} />;
};

export default ShiftwiseProductionGraph;

ShiftwiseProductionGraph.propTypes = {
  data: PropTypes.arrayOf(
    PropTypes.shape({
      Shift_A: PropTypes.number,
      Shift_B: PropTypes.number,
      Shift_C: PropTypes.number,
    })
  )
};