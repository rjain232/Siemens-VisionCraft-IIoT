import React, { useMemo } from "react";
import Chart from "react-apexcharts";
import ChartCard from "./ChartCard";
//import "./OverloadChart.css";

const OverloadChart = ({ data = [], title = "Overload Monitor"  , currentLowerLimit, currentUpperLimit }) => {
  // Validate and sanitize data
  const validatedData = useMemo(() => {
    if (!Array.isArray(data) || data.length === 0) return [];
    return data.map((item) => ({
      Timestamp: item?.Timestamp || "N/A",
      Current: typeof item?.Current === "number" ? item.Current : null,
      Torque: typeof item?.Torque === "number" ? item.Torque : null,
      Temperature:
        typeof item?.Temperature === "number" ? item.Temperature : null,
    }));
  }, [data]);

  const options = {
    chart: {
      type: "line",
      height: 400,
      //fontFamily: '"Segoe UI", "Roboto", sans-serif',
      foreColor: "#6B7280",
      zoom: { enabled: true },
      toolbar: {
        show: false,
        tools: {
          download: true,
          selection: false,
          zoom: true,
          zoomin: true,
          zoomout: true,
          pan: false,
          reset: true,
        },
        autoSelected: "zoom",
      },
      animations: {
        enabled: true,
        speed: 800,
        animateGradually: {
          enabled: true,
          delay: 150,
        },
        dynamicAnimation: {
          enabled: true,
          speed: 500,
        },
      },
      sparkline: { enabled: false },
      stacked: false,
    },

    stroke: {
      width: [3, 2.5, 2.5],
      curve: "smooth",
      lineCap: "round",
      lineJoin: "round",
      dashArray: [0, 0, 0],
    },

    fill: {
      type: "solid",
      gradient: {
        shadeIntensity: 0.3,
        opacityFrom: 0.35,
        opacityTo: 0.05,
        stops: [0, 90, 100],
      },
      colors: ["#DC2626", "#D97706", "#7C3AED"],
    },

    markers: {
      size: 4,
      strokeWidth: 2,
      strokeColors: ["#ffffff"],
      radius: 4,
      hover: { size: 6, sizeOffset: 2 },
      shape: "circle",
      discrete: [],
      offsetX: 0,
      offsetY: 0,
      showNullDataPoints: false,
      enablePolling: false,
    },

    xaxis: {
      categories: validatedData.map((item) => item.Timestamp),
      title: {
        text: "Timestamp",
        style: {
          fontSize: "13px",
          fontWeight: 600,
          color: "#374151",
          letterSpacing: "0.5px",
        },
      },
      labels: {
        style: {
          fontSize: "12px",
          fontWeight: 500,
          colors: "#6B7280",
        },
        datetimeFormatter: {
          year: "yyyy",
          month: "MMM",
          day: "dd",
          hour: "HH:mm",
        },
      },
      axisBorder: {
        show: true,
        color: "#E5E7EB",
        height: 2,
        offsetX: 0,
        offsetY: 0,
      },
      axisTicks: {
        show: true,
        color: "#E5E7EB",
        height: 4,
        offsetX: 0,
        offsetY: 0,
      },
      crosshairs: {
        show: true,
        position: "front",
        stroke: {
          color: "#9CA3AF",
          width: 1,
          dashArray: 3,
        },
      },
    },

    yaxis: [
      {
        seriesName: "Current",
        axisTicks: { show: true, color: "#FEE2E2" },
        axisBorder: { show: true, color: "#DC2626", width: 2 },
        title: {
          text: "Current (A)",
          style: {
            fontSize: "13px",
            fontWeight: 600,
            color: "#DC2626",
            letterSpacing: "0.5px",
          },
        },
        labels: {
          formatter: (val) => {
            if (val === null || val === undefined) return "—";
            return `${val.toFixed(1)}A`;
          },
          style: {
            fontSize: "12px",
            fontWeight: 500,
            colors: "#6B7280",
          },
        },
        tooltip: { enabled: true },
      },
      {
        seriesName: "Torque",
        opposite: true,
        axisTicks: { show: true, color: "#FEF3C7" },
        axisBorder: { show: true, color: "#D97706", width: 2 },
        title: {
          text: "Torque (N)",
          style: {
            fontSize: "13px",
            fontWeight: 600,
            color: "#D97706",
            letterSpacing: "0.5px",
          },
        },
        labels: {
          formatter: (val) => {
            if (val === null || val === undefined) return "—";
            return `${val.toFixed(1)}`;
          },
          style: {
            fontSize: "12px",
            fontWeight: 500,
            colors: "#6B7280",
          },
        },
        tooltip: { enabled: true },
      },
      {
        seriesName: "Temperature",
        opposite: true,
        axisTicks: { show: true, color: "#EDE9FE" },
        axisBorder: { show: true, color: "#7C3AED", width: 2 },
        title: {
          text: "Temperature (°C)",
          style: {
            fontSize: "13px",
            fontWeight: 600,
            color: "#7C3AED",
            letterSpacing: "0.5px",
          },
        },
        labels: {
          formatter: (val) => {
            if (val === null || val === undefined) return "—";
            return `${val.toFixed(1)}°`;
          },
          style: {
            fontSize: "12px",
            fontWeight: 500,
            colors: "#6B7280",
          },
        },
        tooltip: { enabled: true },
      },
    ],

    tooltip: {
      enabled: true,
      theme: "light",
      style: {
        fontSize: "12px",
        fontFamily: "inherit",
      },
      y: {
        formatter: (val, { series, seriesIndex, dataPointIndex, w }) => {
          if (val === null || val === undefined) {
            const labels = ["Current (A)", "Torque (N)", "Temperature (°C)"];
            return `<span style="color: #6B7280;">${labels[seriesIndex] || "Data"}: No data</span>`;
          }
          const labels = ["A", "N", "°C"];
          const value = val.toFixed(2);
          return `<span style="color: #DC2626; font-weight: 700;">${value}${labels[seriesIndex] || ""}</span>`;
        },
      },
      marker: {
        show: true,
        fillColor: "#ffffff",
        strokeColor: "#D1D5DB",
        radius: 4,
      },
      custom: ({ series, seriesIndex, dataPointIndex, w }) => {
        const timestamp =
          validatedData[dataPointIndex]?.Timestamp ||
          w.globals.categories?.[dataPointIndex] ||
          `Point ${dataPointIndex}`;
        const current = series[0]?.[dataPointIndex];
        const torque = series[1]?.[dataPointIndex];
        const temperature = series[2]?.[dataPointIndex];

        const formatValue = (val, unit, color) => {
          if (val === null || val === undefined)
            return `<span style="color: #9CA3AF;">${unit}: —</span>`;
          return `<span style="color: ${color}; font-weight: 700;">${unit}: ${val.toFixed(2)}</span>`;
        };

        return `
          <div style="padding: 12px 16px; background: #FFFFFF; border-radius: 8px; border: 2px solid #E5E7EB; box-shadow: 0 10px 25px rgba(0, 0, 0, 0.12); max-width: 280px;">
            <div style="font-weight: 700; color: #1F2937; margin-bottom: 8px; font-size: 12px; border-bottom: 1px solid #E5E7EB; padding-bottom: 8px;">${timestamp}</div>
            <div style="color: #374151; font-size: 11px; line-height: 1.8;">
              <div style="display: flex; align-items: center; gap: 8px;">
                <span style="font-size: 14px;">🔴</span>
                <div>${formatValue(current, "Current", "#DC2626")}</div>
              </div>
              <div style="display: flex; align-items: center; gap: 8px; margin-top: 4px;">
                <span style="font-size: 14px;">🟠</span>
                <div>${formatValue(torque, "Torque", "#D97706")}</div>
              </div>
              <div style="display: flex; align-items: center; gap: 8px; margin-top: 4px;">
                <span style="font-size: 14px;">🟣</span>
                <div>${formatValue(temperature, "Temperature", "#7C3AED")}</div>
              </div>
            </div>
          </div>
        `;
      },
    },

    grid: {
      show: true,
      borderColor: "#E5E7EB",
      strokeDashArray: 3,
      position: "back",
      xaxis: { lines: { show: false } },
      yaxis: { lines: { show: true } },
      padding: { left: 20, right: 40, top: 20, bottom: 20 },
    },

    legend: {
      position: "bottom",
      horizontalAlign: "center",
      floating: false,
      offsetY: 10,
      fontSize: "12px",
      fontWeight: 600,
      markers: {
        width: 12,
        height: 12,
        radius: 2,
        strokeWidth: 1,
        strokeColor: "#ffffff",
        fillColors: ["#DC2626", "#D97706", "#7C3AED"],
        offsetX: 0,
        offsetY: 0,
      },
      itemMargin: { horizontal: 20, vertical: 0 },
      onItemClick: { toggleDataSeries: true },
      onItemHover: { highlightDataSeries: true },
    },

    annotations: {
      yaxis: [
        {
          y: currentUpperLimit,
          yAxisIndex:0,
          borderColor: "#DC2626",
          strokeDashArray: 4,
          opacity: 0.7,
          fillColor: "#FEE2E2",
          label: {
            borderColor: "#DC2626",
            style: {
              color: "#ffffff",
              background: "#DC2626",
              fontSize: "11px",
              fontWeight: 600,
              padding: {
                left: 8,
                right: 8,
                top: 4,
                bottom: 4,
              },
              borderRadius: 4,
            },
            text: `Upper Limit: ${currentUpperLimit}A`,
            position: "left",
            offsetX: 95,
          },
        },
        {
          y: currentLowerLimit,
          yAxisIndex:0,
          borderColor: "#059669",
          strokeDashArray: 4,
          opacity: 0.7,
          fillColor: "#DCFCE7",
          label: {
            borderColor: "#059669",
            style: {
              color: "#ffffff",
              background: "#059669",
              fontSize: "11px",
              fontWeight: 600,
              padding: {
                left: 8,
                right: 8,
                top: 4,
                bottom: 4,
              },
              borderRadius: 4,
            },
            text: `Lower Limit: ${currentLowerLimit}A`,
            position: "left",
            offsetX: 95,
          },
        },
      ],
    },

    colors: ["#DC2626", "#D97706", "#7C3AED"],

    responsive: [
      {
        breakpoint: 1024,
        options: {
          chart: { height: 350 },
          stroke: { width: [2.5, 2, 2] },
          markers: { size: 3 },
        },
      },
      {
        breakpoint: 768,
        options: {
          chart: { height: 300 },
          stroke: { width: [2, 1.5, 1.5] },
          markers: { size: 2 },
          yaxis: [
            { title: { style: { fontSize: "11px" } } },
            { title: { style: { fontSize: "11px" } } },
            { title: { style: { fontSize: "11px" } } },
          ],
          legend: {
            fontSize: "10px",
            itemMargin: { horizontal: 12, vertical: 0 },
          },
          tooltip: { style: { fontSize: "10px" } },
        },
      },
      {
        breakpoint: 480,
        options: {
          chart: { height: 250 },
          stroke: { width: [1.5, 1, 1] },
          markers: { size: 1.5 },
          xaxis: { labels: { style: { fontSize: "9px" } } },
          yaxis: [
            {
              title: { style: { fontSize: "9px" } },
              labels: { style: { fontSize: "9px" } },
            },
            {
              title: { style: { fontSize: "9px" } },
              labels: { style: { fontSize: "9px" } },
            },
            {
              title: { style: { fontSize: "9px" } },
              labels: { style: { fontSize: "9px" } },
            },
          ],
          legend: {
            fontSize: "9px",
            itemMargin: { horizontal: 8, vertical: 0 },
          },
        },
      },
    ],
  };

  const series = [
    {
      name: "Current",
      data: validatedData.map((item) => item.Current),
      yAxisIndex: 0,
    },
    {
      name: "Torque",
      data: validatedData.map((item) => item.Torque),
      yAxisIndex: 1,
    },
    {
      name: "Temperature",
      data: validatedData.map((item) => item.Temperature),
      yAxisIndex: 2,
    },
  ];

  if (validatedData.length === 0) {
    return (
      <ChartCard title={title}>
          <div className="flex justify-center  items-center mb-4  gap-4">
          <svg
            width="48"
            height="48"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
          >
            <polyline points="12 3 20 7.5 20 16.5 12 21 4 16.5 4 7.5 12 3"></polyline>
            <polyline points="12 12 20 7.5"></polyline>
            <polyline points="12 12 12 21"></polyline>
            <polyline points="12 12 4 7.5"></polyline>
          </svg>
          <p>No data available to display</p>
          <span>Please provide valid chart data</span>
        </div>
      </ChartCard>
    );
  }

  return (
    <ChartCard title={title}>
      <Chart options={options} series={series} type="line" height={400} />
    </ChartCard>
  );
};

export default OverloadChart;
