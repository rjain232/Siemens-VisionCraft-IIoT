import React, { useState, useEffect } from "react";
import Chart from "react-apexcharts";

const getArcColor = (value) => {
  if (value > 0 && value <= 25) return "#7D0000";
  if (value > 25 && value <= 50) return "#FDD400";
  return "#0D580F";
};

const getHollowBackground = (value) => {
  if (value > 0 && value <= 25) return "#fce6e3";
  if (value > 25 && value <= 50) return "#faf2bb";
  return "#eaf7b2";
};

const OverallOEEPareto = ({ height, label, value }) => {
  const [fontSize, setFontSize] = useState("18px");
  const [offsetY, setOffsetY] = useState(-10); // Adjust label positioning

  useEffect(() => {
    const updateStyles = () => {
      if (window.innerWidth < 640) {
        setFontSize("12px");
        setOffsetY(-5); // Adjust for smaller screens
      } else if (window.innerWidth < 1024) {
        setFontSize("14px");
        setOffsetY(-8);
      } else {
        setFontSize("14px");
        setOffsetY(-10); // Standard for large screens
      }
    };

    updateStyles();
    window.addEventListener("resize", updateStyles);
    return () => window.removeEventListener("resize", updateStyles);
  }, []);

  const series = [value];
  const colors = [getArcColor(value)];
  const options = {
    chart: {
      type: "radialBar",
    },
    colors: colors,
    plotOptions: {
      radialBar: {
        hollow: {
          margin: 2,
          size: "65%", // Reduce size so text stays inside
          background: getHollowBackground(value),
        },
        track: {
          dropShadow: {
            enabled: false,
            top: 2,
            left: 0,
            blur: 4,
            opacity: 0.15,
          },
        },
        dataLabels: {
          name: {
            offsetY: offsetY, // Adjust dynamically
            color: "#000",
            fontSize: fontSize,
          },
          value: {
            color: "#000",
            fontSize: fontSize,
            show: true,
          },
        },
      },
    },
    stroke: {
      lineCap: "round",
    },
    labels: [label],
  };

  return <Chart options={options} series={series} type="radialBar" height={height || "auto"} />;
};

export default OverallOEEPareto;
