import React, { useState, useEffect } from "react";
import PropTypes from "prop-types";
import Chart from "react-apexcharts";

const StackedColumnChart = ({OEEData}) => {
  //console.log("OEEData", OEEData);
  const [chartData, setChartData] = useState({
    series: [
      {
        name: "Shift A",
        data: [],
      },
      {
        name: "Shift B",
        data: [],
      },
      {
        name: "Shift C",
        data: [],
      },
    ],
    categories: [],
  });

   // Update chart data dynamically
  useEffect(() => {
    setChartData({
      series: [
        { name: "Shift A", data: OEEData?.map(item => item.Shift_A || null)},
        { name: "Shift B", data: OEEData?.map(item => item.Shift_B || null)  },
        { name: "Shift C", data: OEEData?.map(item => item.Shift_C || null) },
      ],
      categories: OEEData?.map(item => item.date),
    });
  }, [OEEData]);

  const options = {
    chart: { type: "bar", stacked: true, toolbar: { show: false } },
    plotOptions: {
      bar: {
        horizontal: false,
        borderRadius: 5,
        columnWidth: "40%", // Decrease this value to reduce bar width
      },
    },
    colors: ["#145D76", "#09B59A", "#32EBB6"], // Custom colors
    dataLabels: { enabled: true },
    xaxis: { categories: chartData.categories },
    yaxis: { title: { text: "OEE (%)" } },
    legend: { position: "bottom" },
    fill: { opacity: 1 },
    tooltip: { shared: true, intersect: false },
  };

  return (
    <Chart
      options={options}
      series={chartData.series}
      type="bar"
      height={322}
    />
  );
};
StackedColumnChart.propTypes = {
  OEEData: PropTypes.arrayOf(
    PropTypes.shape({
      date: PropTypes.string,
      Shift_A: PropTypes.number,
      Shift_B: PropTypes.number,
      Shift_C: PropTypes.number,
    })
  ),
};
export default StackedColumnChart;
