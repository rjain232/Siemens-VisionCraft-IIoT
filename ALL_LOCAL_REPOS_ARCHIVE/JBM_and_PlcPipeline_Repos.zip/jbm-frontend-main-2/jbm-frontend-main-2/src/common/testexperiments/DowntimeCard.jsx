import React from "react";
import Chart from "react-apexcharts";

const DowntimeCard = ({ title, availableTime, downtime }) => {
  const chartOptions = {
    chart: { type: "pie" },
    labels: ["Available Time", "Downtime"],
    colors: ["#00893D", "#A12E2D"], // Same colors as other pie charts
    legend: {
      position: "bottom",
      markers: { radius: 4 },
    },
    dataLabels: {
      enabled: true,
      formatter: (val, opts) => opts.w.config.series[opts.seriesIndex],
    },
    tooltip: {
        theme: "light",
        style: {
          fontSize: "14px",
          backgroundColor: "#ffffff",
          color: "#000000",
        },
      },
  };

  return (
    <div className="bg-white rounded-xl shadow-xl p-4 flex flex-col items-center border-t-4 border-gray-400 transform hover:scale-105 transition-transform duration-300">
      <h2 className="text-xl font-semibold text-gray-800 text-center mb-2">
        {title}
      </h2>
      <div className="flex justify-center">
        <Chart options={chartOptions} series={[availableTime, downtime]} type="pie" width={300} />
      </div>
    </div>
  );
};

export default DowntimeCard;
