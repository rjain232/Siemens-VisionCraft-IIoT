import { FilterIcon } from "lucide-react";
import { useState } from "react";


const ProductHeader = () => {
  const [filterIconVisible , setFilterIconVisible] = useState(false)
  return (
    <div className="flex flex-col  border-b bg-white pb-4">
      <div className="flex justify-between items-center space-x-4">
        <div>
            <input
              type="text"
              placeholder="Search..."
              className="p-2 border rounded-md shadow-sm focus:ring focus:ring-blue-300"
            />
            </div>
            <div>
        
        {/* Filters */}
        <FilterIcon onClick={()=>{setFilterIconVisible(!filterIconVisible)}}/>
        {!filterIconVisible && <div className="flex space-x-2 items-center flex-grow">
          <select
            className="border rounded-lg px-3 py-2 bg-white text-gray-700"
            defaultValue="Samsung"
          >
            <option value="Samsung">Samsung</option>
            <option value="Apple">Apple</option>
            <option value="OnePlus">OnePlus</option>
          </select>
          <select
            className="border rounded-lg px-3 py-2 bg-white text-gray-700"
            defaultValue="$1-100"
          >
            <option value="$1-100">$1-100</option>
            <option value="$101-500">$101-500</option>
            <option value="$501+">$501+</option>
          </select>
          <select
            className="border rounded-lg px-3 py-2 bg-white text-gray-700"
            defaultValue="Phone"
          >
            <option value="Phone">Phone</option>
            <option value="Laptop">Laptop</option>
            <option value="Accessories">Accessories</option>
          </select>
          <select
            className="border rounded-lg px-3 py-2 bg-white text-gray-700"
            defaultValue="Pink"
          >
            <option value="Pink">Pink</option>
            <option value="Blue">Blue</option>
            <option value="Black">Black</option>
          </select>
        </div>}
        </div>
      </div>
    </div>
  );
};

export default ProductHeader;
