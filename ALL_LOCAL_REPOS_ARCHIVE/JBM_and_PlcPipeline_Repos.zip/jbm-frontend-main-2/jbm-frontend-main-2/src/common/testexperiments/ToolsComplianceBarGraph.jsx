import React, { useEffect, useState } from "react";
import Chart from "react-apexcharts";

const ToolsComplianceBarGraph = ({ data }) => {
  const chartData = {
    series: [
      {
        name: "Completed Activities",
        data: data?.map((item) => item.ActivitiesPerformed),
      },
      {
        name: "Pending Activities",
        data: data?.map((item) => item.ActivitiesPending),
      },
    ],
    categories: data?.map((item) => item.date),
  };

  const options = {
    chart: { type: "bar", stacked: true, toolbar: { show: false } },
    plotOptions: {
      bar: {
        horizontal: false,
        borderRadius: 5,
        columnWidth: "40%", // Decrease this value to reduce bar width
      },
    },
    colors: ["#00893D", "#A12E2D"], // Custom colors
    dataLabels: { enabled: true },
    xaxis: { categories: chartData.categories },
    yaxis: { title: { text: "No. Of Activities" } },
    legend: { position: "bottom" },
    fill: { opacity: 1 },
    tooltip: { shared: true, intersect: false },
  };
  return (
    <Chart
      options={options}
      series={chartData.series}
      type="bar"
      height={303}
    />
  );
};

export default ToolsComplianceBarGraph;
