import React, { useState } from "react";

const DateTimePicker = ({ onDateChange, label = "Select Date Range" }) => {
  const [startDateTime, setStartDateTime] = useState("");
  const [endDateTime, setEndDateTime] = useState("");

  const handleStartDateChange = (e) => {
    setStartDateTime(e.target.value);
    onDateChange && onDateChange({ startDateTime: e.target.value, endDateTime });
  };

  const handleEndDateChange = (e) => {
    setEndDateTime(e.target.value);
    onDateChange && onDateChange({ startDateTime, endDateTime: e.target.value });
  };

  return (
    <div className="flex flex-col space-y-4 bg-white  rounded-lg my-4">
      <div className="flex flex-col justify-between sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
        {/* Start Date-Time Picker */}
        <div className="flex flex-row gap-4">
        <div className="flex flex-col">
          <label htmlFor="start-date" className="text-sm font-medium text-gray-700">
            Start Date & Time
          </label>
          <input
            type="datetime-local"
            id="start-date"
            value={startDateTime}
            onChange={handleStartDateChange}
            className="mt-1 block w-full border rounded-lg px-3 py-2 text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>
        {/* End Date-Time Picker */}
        <div className="flex flex-col">
          <label htmlFor="end-date" className="text-sm font-medium text-gray-700">
            End Date & Time
          </label>
          <input
            type="datetime-local"
            id="end-date"
            value={endDateTime}
            onChange={handleEndDateChange}
            className="mt-1 block w-full border rounded-lg px-3 py-2 text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>
        </div>
        <div>
        <div className="flex flex-col">
        <label htmlFor="duration" className="text-sm font-medium text-gray-700">
            Select Duration
          </label>
        <select
            className="mt-2 block w-full border rounded-lg px-3 py-2 text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            defaultValue="Samsung"
            id='duration'
          >
            <option value="7">Last 7 days</option>
            <option value="14">Last 2 Weeks</option>
            <option value="21">Last 3 Weeks</option>
          </select>
        </div>
        </div>
        <div>
        <div className="flex flex-col">
          <div/>
       <button className="mt-6 px-4 py-2 bg-indigo-900 text-white rounded-lg">ok</button>
        </div>
        </div>
      </div>
    </div>
  );
};

export default DateTimePicker;
