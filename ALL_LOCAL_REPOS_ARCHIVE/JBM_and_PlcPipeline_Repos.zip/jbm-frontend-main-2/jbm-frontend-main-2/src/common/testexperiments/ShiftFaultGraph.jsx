import React from "react";
import Chart from "react-apexcharts";

const faults = {
  1: "Fault A",
  2: "Fault B",
  3: "Fault C",
  4: "Fault D",
  5: "Fault E",
  6: "Fault F",
  7: "Fault G",
  8: "Fault H",
  9: "Fault I",
  10: "Fault J",
};

const shiftNames = [
  "Shift A", "Shift A", "Shift B", "Shift B", "Shift C", 
  "Shift C", "Shift A", "Shift B", "Shift C", "Shift A"
];

function formatTime(value) {
  const hours = Math.floor(value / 3600);
  const minutes = Math.floor((value % 3600) / 60);
  const seconds = value % 60;
  return `${hours.toString().padStart(2, "0")}:${minutes
    .toString()
    .padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`;
}

const ShiftFaultGraph = () => {
  const faultIndexes = [6, 4, 5, 1, 3, 8, 7, 3, 2, 2];

  const xCategories = faultIndexes.map((fault, index) => {
    return `${shiftNames[index]} - ${faults[fault]}`;
  });

  const chartOptions = {
    chart: {
      type: "bar",
      height: 400,
      toolbar: { show: false },
    },
    plotOptions: {
      bar: {
        distributed: true,
        borderRadius: 2,
        horizontal: false,
        columnWidth: "50%",
        dataLabels: {
          position: 'top',
        },
      },
    },
    xaxis: {
      categories: xCategories,
      title: { text: "Shift - Fault" },
      labels: {
        rotate: -45, 
        style: {
          fontSize: '12px',
          fontWeight: 'bold'
        }
      }
    },
    yaxis: {
      title: { text: "Time (Minutes)" },
      max: 12500,
      labels: {
        formatter: function (value) {
          return formatTime(value);
        },
      },
    },
    dataLabels: {
      offsetY: -25,
      enabled: true,
      textAnchor: 'middle',
      style: { fontSize: "12px", colors: ["#000"] },
      formatter: function (value) {
        return formatTime(value);
      },
    },
    legend: {
      show: false,
    },
    colors: [
      "#400000", "#800000", "#BF0000", "#ed0404", "#f41f1f",
      "#f93131", "#e05353", "#f26060", "#9e7373", "#d19999",
    ],
    tooltip: {
      y: {
        formatter: function (value) {
          return formatTime(value);
        },
      },
    },
  };

  const chartSeries = [
    {
      name: "Time",
      data: [12000, 9500, 8000, 7050, 6000, 5000, 4500, 4000, 3000, 2500],
    },
  ];

  return (
    <div >
      {/* <h2 className="text-2xl font-bold text-center mb-4">Shift-wise Top 10 Faults</h2> */}
      <Chart options={chartOptions} series={chartSeries} type="bar" height={300} />
    </div>
  );
};

export default ShiftFaultGraph;
