import React, { useState } from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { Battery, BatteryCharging, BatteryWarning, Cpu, Globe, HardDrive } from "lucide-react";
import robotIcon from "../../assets/robotic-arm.png";
import errorIcon from "../../assets/warning.png";
import { motion } from "framer-motion";
import ModalHOC from "../../hoc/ModalHOC";
import Button from "../components/Button";

const sections = {
  ML_10: [
    { id: 1, name: "Robot 1", battery: 80, status: "Active" },
    { id: 2, name: "Robot 2", battery: 50, status: "Active" },
    { id: 3, name: "Robot 3", battery: 20, status: "Breakdown" },
    { id: 4, name: "Robot 4", battery: 90, status: "Breakdown" },
  ],
  ML_20: [
    { id: 5, name: "Robot 5", battery: 50, status: "Active" },
    { id: 6, name: "Robot 6", battery: 20, status: "Breakdown" },
    { id: 7, name: "Robot 7", battery: 75, status: "Active" },
    { id: 8, name: "Robot 8", battery: 30, status: "Breakdown" },
  ],
  ML_30: [
    { id: 9, name: "Robot 9", battery: 50, status: "Active" },
    { id: 10, name: "Robot 10", battery: 20, status: "Breakdown" }
  ],
  ML_40: [
    { id: 11, name: "Robot 11", battery: 50, status: "Active" },
    { id: 12, name: "Robot 12", battery: 20, status: "Breakdown" },
    { id: 13, name: "Robot 13", battery: 75, status: "Active" },
    { id: 14, name: "Robot 14", battery: 30, status: "Breakdown" },
  ],
  RF_10: [{ id: 15, name: "Robot 15", battery: 60, status: "Active" }],
  Hemming: [{ id: 16, name: "Robot 16", battery: 25, status: "Breakdown" }],
};

const getBatteryIcon = (battery) => {
  if (battery > 75) return <Battery className="text-green-500 w-7 h-7" fill="#00BC56" />;
  if (battery > 40) return <BatteryCharging className="text-yellow-500 w-6 h-6" />;
  return <BatteryWarning className="text-red-500 w-6 h-6 animate-blink" />;
};

const getStatusColor = (status) => (status === "Active" ? "bg-green-500" : "bg-red-500 animate-blink");

const RobotHealth = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedRobot, setSelectedRobot] = useState(null);

  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: true,
  };

  return (
    <div>
      <h1 className="text-3xl font-bold text-center mb-4 mt-6 w-[90%]">Robot Health</h1>
      {/* <div className="w-[70%] px-1 mx-auto"> */}
      <div className="w-[90%] px-1">
        <Slider {...settings}>
          {Object.entries(sections).map(([sectionName, stations]) => (
            <div key={sectionName} className="relative h-[500px]">
              {/* Section Name - Centered */}
              <h2 className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 text-2xl font-bold bg-purple-950 text-white py-2 px-4 rounded-lg">
                {sectionName}
              </h2>

              {/* Robot Cards - 2x2 Grid */}
              <div className="grid grid-cols-2 grid-rows-2 gap-6 w-full h-full p-6">
                {stations.slice(0, 4).map((station, index) => (
                  <div
                    key={station.id}
                   className="px-6 py-4 w-[400px] h-[180px] border rounded-lg bg-white shadow-lg hover:shadow-xl transition-shadow duration-300 hover:scale-105"
                    style={{
                      justifySelf: index % 2 === 0 ? "start" : "end",
                      alignSelf: index < 2 ? "start" : "end",
                    }}
                    onClick={() => {
                      setSelectedRobot(station);
                      setIsModalOpen(true);
                    }}
                  >
                    <h1 className="w-full text-center text-lg font-bold mb-2">{station.name}</h1>
                    <div className="flex gap-2">
                      <div className="relative flex items-center justify-start">
                        <img src={robotIcon} alt="Robot" className="w-[90px] h-[100px]" />
                        {station.status === "Breakdown" && (
                          <motion.img
                            src={errorIcon}
                            alt="Error"
                            className="absolute top-1/2 left-1/2 w-8 h-8 transform -translate-x-1/2 -translate-y-1/2"
                            animate={{ opacity: [1, 0, 1] }}
                            transition={{ duration: 1, repeat: Infinity, ease: "easeInOut" }}
                          />
                        )}
                      </div>
                      <div className="flex-1">
                        <div className="flex m-4">
                          <div className="mx-4 min-w-14 text-start text-slate-500 font-semibold">Status</div>
                          <div className="flex-1">
                            <p className={`text-md font-semibold text-white py-1 px-2 rounded ${getStatusColor(station.status)}`}>
                              {station.status}
                            </p>
                          </div>
                        </div>
                        <div className="flex m-4">
                          <div className="mx-4 min-w-14 text-slate-500 font-semibold">Battery</div>
                          <div className="flex-1">{getBatteryIcon(station.battery)}</div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </Slider>
      </div>


      {/* Fix: Modal should only open if isModalOpen is true */}
      {isModalOpen && selectedRobot && (
        <ModalHOC isOpen={isModalOpen} onClose={() => setIsModalOpen(false)}>
          <motion.div initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.8 }}>
            <h3 className="text-xl font-bold text-gray-800 mb-4 text-center">Robot Details</h3>
            <div className="space-y-4 mt-6">
              <div className="grid grid-cols-[34px_130px_auto] items-center text-gray-700">
                <Cpu className="w-6 h-6 text-blue-600" />
                <span className="font-medium">Name</span>
                <span className="font-semibold text-right">{selectedRobot.name}</span>
              </div>
              <div className="grid grid-cols-[34px_130px_auto] items-center text-gray-700">
                <HardDrive className="w-6 h-6 text-green-600" />
                <span className="font-medium">Status</span>
                <span className="font-semibold text-right">{selectedRobot.status}</span>
              </div>
              <div className="grid grid-cols-[34px_130px_auto] items-center text-gray-700">
                <Globe className="w-6 h-6 text-red-600" />
                <span className="font-medium">Battery</span>
                <span className="font-semibold text-right">{selectedRobot.battery}%</span>
              </div>
            </div>
            <div className="flex justify-center space-x-3 mt-6">
              <Button label="View Events" onClick={() => {}} />
              <Button
                label="Close"
                onClick={() => setIsModalOpen(false)}
                bgColor="bg-white"
                textColor="text-purple-950 border border-purple-950"
              />
            </div>
          </motion.div>
        </ModalHOC>
      )}
    </div>
  );
};

export default RobotHealth;
