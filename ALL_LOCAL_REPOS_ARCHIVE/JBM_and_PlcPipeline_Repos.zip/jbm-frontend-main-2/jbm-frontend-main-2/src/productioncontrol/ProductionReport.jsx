import withTable from "../hoc/withTable";
import DataTable from "../common/components/DataTable";
import DateRangeSelector from "../common/components/DateRangeSelector ";
import useAxios from "../hooks/useAxios";
import { format, parseISO } from "date-fns";
import { generate_TablePDF } from "../utils/PdfLib";
import {generateExcel} from "../utils/ExcelUtils";

import { useState } from "react";
import Button from "../common/components/Button";
import { PlusIcon } from "lucide-react";
import ModalHOC from "../hoc/ModalHOC";
import AddOkNokForm from "./AddOkNokForm";
import { LineName } from "../utils/constants";


const columns = [
  { label: "Date", accessor: "Date" },
  { label: "Production Count", accessor: "PartsProduced" },
  { label: "OK", accessor: "OK" },
  { label: "NOK", accessor: "NOK" },
  { label: "Within Cycle", accessor: "WithinCycle" },
  { label: "Cycle Exceeded", accessor: "CycleExceeded" },
];
const EnhancedTable = withTable(DataTable);

const ProductionReport = () => {
    const[dateFilter,setDateFilter] = useState({
        startDate: null,
        endDate: null,
        duration: null,
        shift: null,    
    });
    
      const [showModal, setShowModal] = useState(false);

      const handleAddClick = () => {
        setShowModal(true);
      };

      const handleCloseModal = () => {
        setShowModal(false);
        handleSearch(
          dateFilter.startDate,
          dateFilter.endDate,
          dateFilter.duration,
          dateFilter.shift
        ); // Refresh data after closing modal
      };


  const {
    data: ProductionReportData,
    loading: ProductionReportDataLoading,
    error: ProductionReportDataError,
    refetch: refetchProductionReportData,
  } = useAxios("/productionReport", { method: "GET"}, true);

  const [isDownloading, setIsDownloading] = useState(false);

  //Done by Arshiya 

   const formattedData = ProductionReportData?.map((item) => ({
  ...item,
  Date: item?.Date && !isNaN(new Date(item.Date))
    ? format(new Date(item.Date), "dd-MM-yyyy")
    : "-",
}));


  const handleSearch = (
    startDate,
    endDate,
    duration,
    shift,
    dedicatedDuration
  ) => {
    setDateFilter({ 
        startDate,
        endDate, 
        duration,
        shift,
        });
    refetchProductionReportData({
    params : {
      startDate: startDate ? format(startDate, "yyyy-MM-dd HH:mm:ss") : null,
      endDate: endDate ? format(endDate, "yyyy-MM-dd HH:mm:ss") : null,
      duration,
      shift,
      dedicatedDuration,
    }
    });
  };
  

  const handleDownload = async () => {
    setIsDownloading(true);

    // Allow React to render loading state
    await new Promise((resolve) => setTimeout(resolve, 10));

    generate_TablePDF(columns, formattedData, `${LineName} Production Report`, dateFilter);
    generateExcel(columns, formattedData, `${LineName} Production Report`);
    setIsDownloading(false);
  };

  if(ProductionReportDataError){
    return <div>Error loading data</div>;
  }
    if(ProductionReportDataLoading){
        return <div>Loading...</div>;
    }
  return (
    <>
      <div className="flex flex-row">
        <div className="flex me-4">
          <DateRangeSelector
            showDownload={true}
            onDownload={handleDownload}
            onSearch={handleSearch}
            showDate={true}
            activeTab={"Report"}
            selectedStartDate={dateFilter?.startDate}
            selectedEndDate={dateFilter?.endDate}
            selectedDuration={dateFilter?.duration}
            selectedShift={dateFilter?.shift}
            isDownloading={isDownloading}
          />
        </div>
        <div
          style={{ display: "flex", alignItems: "flex-end", marginBottom: 16 }}
        >
          <Button
            onClick={handleAddClick}
            icon={PlusIcon}
            label="Add NOK"
            bgColor="bg-purple-950"
          />
        </div>
      </div>

      {!ProductionReportDataLoading && (
        <EnhancedTable
          data={formattedData}
          columns={columns}
          enableSearch={true}
          enableFilter={false}
          enablePagination={true}
        />
      )}
   
        <ModalHOC isOpen={showModal} onClose={handleCloseModal}>
          <AddOkNokForm onClose={handleCloseModal} />
        </ModalHOC>
   
    </>
  );
};

export default ProductionReport;
