import withTable from "../hoc/withTable";
import DataTable from "../common/components/DataTable";
import useAxios from "../hooks/useAxios";
import DateRangeSelector from "../common/components/DateRangeSelector ";
import { useState } from "react";
import { format } from "date-fns";
import { generate_TablePDF } from "../utils/PdfLib";
import { generateExcel } from "../utils/ExcelUtils";
import { LineName } from "../utils/constants";

const EnhancedTable = withTable(DataTable);
const columns = [
  { label: "Date", accessor: "Date" },
  { label: "Shift", accessor: "Shift" },
  { label: "Station", accessor: "StationName" },
  { label: "Cabin Number", accessor: "CabinNo" },
  { label: "From", accessor: "From_Date" },
  { label: "To", accessor: "To_Date" },
  { label: "Cycle Time", accessor: "Duration" },
];

const CycleTime = () => {
  const [dateFilter, setDateFilter] = useState({
    startDate: null,
    endDate: null,
    duration: null,
    shift: null,
  });
  const {
    data: cycleData,
    loading: cycleDataLoading,
    refetch: refetchCycleData,
    error: cycleDataError,
  } = useAxios("/cycleTimeData", { method: "GET" }, true);

  const formattedData = cycleData?.map((item) => ({
    ...item,
    Date: item.Date ? format(new Date(item.Date), "dd-MM-yyyy") : "",
  }));

  const handleSearch = (
    startDate,
    endDate,
    duration,
    shift,
    dedicatedDuration,
  ) => {
    setDateFilter({
      startDate,
      endDate,
      duration,
      shift,
    });
    refetchCycleData({
      params: {
        startDate: startDate
          ? format(new Date(startDate), "yyyy-MM-dd HH:mm:ss")
          : null,
        endDate: endDate ? format(endDate, "yyyy-MM-dd HH:mm:ss") : null,
        duration,
        shift,
        dedicatedDuration,
      },
    });
  };
  const [downloading, setDownloading] = useState(false);

  const handleDownload = async () => {
    setDownloading(true);
    await new Promise((resolve) => setTimeout(resolve, 10));
    generateExcel(columns, formattedData, `${LineName}_Cycle_Time_Report`);
    generate_TablePDF(
      columns,
      formattedData,
      `${LineName}_Cycle_Time_Report`,
      dateFilter,
    );
    setDownloading(false);
  };

  return (
    !cycleDataLoading &&
    cycleData && (
      <div>
        <DateRangeSelector
          showDownload={true}
          onDownload={handleDownload}
          onSearch={handleSearch}
          showDate={true}
          showShift={true}
          activeTab={"Cycle Time"}
          selectedStartDate={dateFilter?.startDate}
          selectedEndDate={dateFilter?.endDate}
          selectedDuration={dateFilter?.duration}
          selectedShift={dateFilter?.shift}
          isDownloading={downloading}
        />
        <EnhancedTable
          data={formattedData}
          columns={columns}
          enableSearch={true}
          enableFilter={true}
          enablePagination={true}
        />
      </div>
    )
  );
};

export default CycleTime;
