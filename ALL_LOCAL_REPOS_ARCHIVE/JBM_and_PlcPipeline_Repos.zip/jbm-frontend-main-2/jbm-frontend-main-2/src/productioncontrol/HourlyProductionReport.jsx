import BarGraphHourly from "../common/testexperiments/BarGraphHourly";
import withTable from "../hoc/withTable";
import DataTable from "../common/components/DataTable";
import DateRangeSelector from "../common/components/DateRangeSelector ";
import useAxios from "../hooks/useAxios";
import { format } from "date-fns";
import { useState } from "react";
import { generatePDF } from "../utils/PdfLib";
import {generateExcel} from "../utils/ExcelUtils";
import {
  addGlobalStylesForPDF,
  addPageNumber,
  cleanupChartStyles,
  pageFooterFormat,
  pageHeadFormat,
  renderChartToPDF,
  reportFromToShiftHeaders,
} from "../utils/PdfLib";
import { useRef } from "react";
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";
import { LineName } from "../utils/constants";

const columns_HourlyCount = [
  { label: "Date", accessor: "Date" },
  { label: "Hour Range", accessor: "HourRange" },
  { label: "Production Count", accessor: "Actual" },
];
const EnhancedTable = withTable(DataTable);

const getCurrentShift = () => {
  const now = new Date();

  const totalMinutes = now.getHours() * 60 + now.getMinutes();

  if (totalMinutes >= 360 && totalMinutes <= 899) {
    // 06:00 - 14:59
    return "A";
  } else if (totalMinutes >= 900 && totalMinutes <= 1409) {
    // 15:00 - 23:29
    return "B";
  } else {
    // 23:30 - 05:59
    return "C";
  }
}

const HourlyProductionReport = () => {
  const [dateFilter, setDateFilter] = useState({
    startDate: null,
    endDate: null,
    duration: null,
    shift: null,
  });

  const {
    data: HourlyProductionData,
    loading: HourlyProductionDataLoading,
    error: HourlyProductionDataError,
    refetch: refetchHourlyProductionData,
  } = useAxios(
    "/hourly_production_report",
    { method: "GET"},
    true
  );

  //Donr by Arshiya
  
   const formattedData = HourlyProductionData?.map((item) => ({
  ...item,
  Date: item.Date ? format(new Date(item.Date), "dd-MM-yyyy") : "", 
}));
 
// References for your charts
    const chart1Ref = useRef(null);
    // const chart2Ref = useRef(null);
    // const chart3Ref = useRef(null);
    const [downloading, setDownloading] = useState(false);
    
    const exportPdfHourlyProductionReport = async () => {
      const doc = new jsPDF();
      const chartRefs = [chart1Ref];
      reportFromToShiftHeaders(doc, dateFilter);
      addGlobalStylesForPDF();
      chartRefs.forEach((ref) => ref.current?.classList.add("pdf-export"));
      let yOffset = 50;
      await renderChartToPDF(doc, chartRefs,yOffset);
      pageHeadFormat(doc, `${LineName} Hourly Production Report`,false);
      
      doc.addPage();
      generatePDF(doc,columns_HourlyCount,formattedData,`${LineName} Hourly Production Report`);
      cleanupChartStyles(chartRefs);
      doc.save(`${LineName} Hourly Production Report.pdf`);
    };
  const handleDownload = () => {
    try{setDownloading(true);
      generateExcel(columns_HourlyCount, formattedData,`${LineName} Hourly Production Report`);
     
      exportPdfHourlyProductionReport().then(() => {
        setDownloading(false);
      });}
      catch (error) {
        console.log(error);
      }
  };

  const handleSearch = (
      startDate,
      endDate,
      duration,
      shift,
      dedicatedDuration
    ) => {
      setDateFilter({
        startDate,
        endDate,
        duration,
        shift,
      });
      refetchHourlyProductionData({
        params: {
          startDate: startDate
            ? format(new Date(startDate), "yyyy-MM-dd HH:mm:ss")
            : null,
          endDate: endDate ? format(endDate, "yyyy-MM-dd HH:mm:ss") : null,
          duration,
          shift,
          dedicatedDuration,
        },
      });
    };

    if (HourlyProductionDataError) {
      return <div>Error loading data</div>;
    }

  return (
    <>
      <DateRangeSelector
        showDownload={true}
        onDownload={handleDownload}
        onSearch={handleSearch}
        showDate={true}
        showShift={true}
        activeTab={"Hourly Production Report"}
        selectedStartDate={dateFilter?.startDate}
        selectedEndDate={dateFilter?.endDate}  
        selectedDuration={dateFilter?.duration}
        selectedShift={dateFilter?.shift ?? getCurrentShift()} 
        isDownloading={downloading}
        TimeSelection={false}
      />
      {!HourlyProductionDataLoading &&  <div className="pt-2">
        <div  ref={chart1Ref} className="mb-6">
          <BarGraphHourly data={HourlyProductionData} title={`Hourly Production Count Shift ${dateFilter?.shift ?? getCurrentShift()}`}/>
        </div>
        <EnhancedTable
          data={formattedData}
          columns={columns_HourlyCount}
          enableSearch={true}
          enableFilter={false}
          enablePagination={true}
        />
      </div>}
    </>
  );
};

export default HourlyProductionReport;
