import BarGraphDedicatedProduction from "../common/testexperiments/BarGraphDedicatedProduction";
import ChartCard from "../common/testexperiments/ChartCard";
import ShiftEfficiencyPareto from "../common/testexperiments/ShiftEfficiencyPareto";
import withTable from "../hoc/withTable";
import ProductionDataTable from "../common/components/ProductionDataTable";
import DateRangeSelector from "../common/components/DateRangeSelector ";
import { useState } from "react";
import useAxios from "../hooks/useAxios";
import { format } from "date-fns";
import { generatePDF } from "../utils/PdfLib";
import {generateExcel} from "../utils/ExcelUtils";
import {
  addGlobalStylesForPDF,
  addPageNumber,
  cleanupChartStyles,
  pageFooterFormat,
  pageHeadFormat,
  renderChartToPDF,
  reportFromToShiftHeaders,
} from "../utils/PdfLib";
import { useRef } from "react";
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";
import GroupStackedBar from "../common/testexperiments/GroupStackedBar";
import { LineName } from "../utils/constants";

const columns_ProductionReport = [
  { label: "Date", accessor: "Date" },
  { label: "A - Target", accessor: "A_Target" },
  { label: "A - Actual", accessor: "A_Actual" },
  { label: "B - Target", accessor: "B_Target" },
  { label: "B - Actual", accessor: "B_Actual" },
  { label: "C - Target", accessor: "C_Target" },
  { label: "C - Actual", accessor: "C_Actual" },
];

const ProductionEnhancedTable = withTable(ProductionDataTable);
const DetailedProductionReport = () => {
  const [dateFilter, setDateFilter] = useState({
    startDate: null,
    endDate: null,
    duration: null,
    dedicatedDuration: null,
  });

  const {
    data: DetailedProductionData,
    loading: DetailedProductionDataLoading,
    error: DetailedProductionDataError,
    refetch: refetchDetailedProductionData,
  } = useAxios("/detailedProductionReport", { method: "GET" }, true);
//console.log("DetailedProductionData==", DetailedProductionData);
  const groupedData = [];

  const map = new Map();

  DetailedProductionData?.detailedProductionTableAndGraphData?.forEach(
    (item) => {
      const date = item.Period;
      const shift = item.Shift.trim();

      if (!map.has(date)) {
        map.set(date, { Date: date });
      }

      const record = map.get(date);
      record[`${shift}_Target`] = item.Target;
      record[`${shift}_Actual`] = item.Actual;
    }
  );

  for (const value of map.values()) {
    groupedData.push(value);
  }

  //Done by Arshiya 

    const fromattedData = groupedData.map((item)=>({
        ...item,
        Date: item.Date ? format(new Date(item.Date),"dd-MM-yyyy") :"",
      }))

  const handleSearch = (
    startDate,
    endDate,
    duration,
    shift,
    dedicatedDuration
  ) => {
    setDateFilter({
      startDate,
      endDate,
      duration,
      dedicatedDuration
    });
    refetchDetailedProductionData({
      params: {
        startDate: startDate
          ? format(new Date(startDate), "yyyy-MM-dd HH:mm:ss")
          : null,
        endDate: endDate ? format(endDate, "yyyy-MM-dd HH:mm:ss") : null,
        duration,
        dedicatedDuration,
      },
    });
  };
  // References for your charts
      const chart1Ref = useRef(null);
      // const chart2Ref = useRef(null);
      // const chart3Ref = useRef(null);
      const [downloading, setDownloading] = useState(false);
      
      const exportPdfDetailedProductionReport = async () => {
        const doc = new jsPDF();
        const chartRefs = [chart1Ref];
        reportFromToShiftHeaders(doc, dateFilter);
        addGlobalStylesForPDF();
        chartRefs.forEach((ref) => ref.current?.classList.add("pdf-export"));
        let yOffset = 50;
        await renderChartToPDF(doc, chartRefs,yOffset);
        pageHeadFormat(doc, `${LineName} Detailed Production Report`,false);
        
        doc.addPage();
       await generatePDF(doc,columns_ProductionReport, fromattedData ,`${LineName} Detailed Production Report`);
        cleanupChartStyles(chartRefs);
        doc.save(`${LineName}_Detailed_Production_Report.pdf`);
      };

  const handleDownload = () => {
        try{setDownloading(true);
          generateExcel(columns_ProductionReport,  fromattedData ,`${LineName} Detailed Report`);
         
          exportPdfDetailedProductionReport().then(() => {
            setDownloading(false);
          });}
          catch (error) {
            console.log("error at handleDownload"+ error);
          }
}

  return (
    <>
      <DateRangeSelector
        showDownload={true}
        onDownload={handleDownload}
        onSearch={handleSearch}
        showDate={true}
        showShift={true}
        activeTab={"Detail Production Report"}
         selectedStartDate={dateFilter?.startDate}
        selectedEndDate={dateFilter?.endDate}  
        selectedDuration={dateFilter?.duration}
        selectedShift={dateFilter?.shift} 
        isDownloading={downloading}
      />
      {!DetailedProductionDataLoading && (
        <div>
          <div ref={chart1Ref} className="grid grid-cols-12 gap-6 py-2">
            {/* ==== Production Bar Graph Section ==== */}
            <div className="col-span-12 md:col-span-8 bg-white shadow-lg p-4 rounded-lg flex flex-col justify-center h-full">
              <h2 className="text-xl font-semibold text-center mb-2">Production Report</h2>
              <div className="w-full flex justify-center">
                {DetailedProductionData?.detailedProductionTableAndGraphData?.length > 0 ? (
                  // <BarGraphDedicatedProduction
                  //   data={DetailedProductionData?.detailedProductionTableAndGraphData}
                  // />

                   <GroupStackedBar
                    data={DetailedProductionData?.detailedProductionTableAndGraphData}
                  />
                ) : (
                  <div className="text-gray-500 text-sm text-center py-4">
                    No production data available for selected range
                  </div>
                )}
              </div>
            </div>

            {/* ==== Shift OEE Chart Section ==== */}
            <div className="col-span-12 md:col-span-4 bg-white shadow-lg p-4 rounded-lg flex flex-col h-full">
              <h2 className="text-xl font-semibold text-center mb-2">Shift OEE</h2>
              <div className="flex-grow flex items-center justify-center">
                <ChartCard>
                  {DetailedProductionData?.shiftOEEData?.some((item) => item?.OEE !== null) ? (
                    <ShiftEfficiencyPareto
                      labels={DetailedProductionData.shiftOEEData.map((item) => item.shift)}
                      series={DetailedProductionData.shiftOEEData.map((item) =>
                        item.OEE !== null ? item.OEE : 0
                      )}
                      height={340}
                    />
                  ) : (
                    <div className="text-gray-500 text-sm text-center py-4">
                      No OEE data available for selected range
                    </div>
                  )}
                </ChartCard>
              </div>
            </div>
          </div>

          {/* ==== Production Table Section ==== */}
          <div className="mt-4">
            {groupedData.length > 0 ? (
              <ProductionEnhancedTable
                data={ fromattedData }
                columns={columns_ProductionReport}
                enableSearch={true}
                enableFilter={false}
                enablePagination={true}
              />
            ) : (
              <div className="text-gray-500 text-sm text-center py-4">
                No production records found for selected date/shift
              </div>
            )}
          </div>
        </div>
)}

    </>
  );
};

export default DetailedProductionReport;
