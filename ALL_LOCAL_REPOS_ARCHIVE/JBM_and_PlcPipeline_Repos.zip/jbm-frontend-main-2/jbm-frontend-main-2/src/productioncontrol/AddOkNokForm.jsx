import { useState } from "react";
import DateTimePicker from "../common/components/DateTimePicker";
import useAxios from "../hooks/useAxios";
import { format } from "date-fns";
import toast from "react-hot-toast";
import PropTypes from "prop-types";

const shiftOptions = [
  { value: "A", label: "Shift A" },
  { value: "B", label: "Shift B" },
  { value: "C", label: "Shift C" },
];

const AddOkNokForm = ({onClose}) => {
      // Example API endpoint
      const {
    refetch: refetchNokDataUpdate,
  } = useAxios("/updateOkNokCount", { method: "POST" }, false); 

  const [formData, setFormData] = useState({
    date: null,
    shift: "",
    noklhcount: "",
    nokrhcount: "",
  });

  const handleChange = (field) => (event) => {
    setFormData({
      ...formData,
      [field]: event.target.value,
    });
  };

  const handleDateChange = (newDate) => {
    console.log("Selected Date:", newDate);
    setFormData({
      ...formData,
      date: format(newDate, "yyyy-MM-dd"),
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
   
   refetchNokDataUpdate({
      data: {
         ...formData
        },
    }).then((response) => { 
        console.log("Response from API:", response);
        onClose(); // Close the modal after successful submission
    }).catch((error) => {
        toast.error(error?.error || "Failed to update OK/NOK count");
    });


   };

  return (
    <>
    <h4 className="text-lg font-semibold mb-4 text-center">Add NOK Count</h4>
      <form
        onSubmit={handleSubmit}
        style={{
          display: "flex",
          flexDirection: "column",
          gap: 16,
          maxWidth: 400,
        }}
      >
        <DateTimePicker
          selectedDate={formData.date}
          onChange={handleDateChange}
          className="w-full"
          showTime={false}
        />
        <select
          value={formData.shift}
          onChange={handleChange("shift")}
          className="border rounded px-3 py-2 w-full"
          required
        >
          <option value="">Select Shift</option>
          {shiftOptions.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>   
        <input
          type="number"
          placeholder="NOK LH Count"
          value={formData.noklhcount}
          onChange={handleChange("noklhcount")}
          className="border rounded px-3 py-2 w-full"
          min="0"
          required
        />
        <input
          type="number"
          placeholder="NOK RH Count"
          value={formData.nokrhcount}
          onChange={handleChange("nokrhcount")}
          className="border rounded px-3 py-2 w-full"
          min="0"
          required
        />
        <button
          type="submit"
          label="Submit"
          className="w-full bg-purple-950 text-white hover:bg-purple-800 text-center p-2 rounded-lg font-semibold"
        >
          Submit
        </button>
      </form>
    </>
  );
};
AddOkNokForm.propTypes = {
  onClose: PropTypes.func.isRequired,
};

export default AddOkNokForm;
