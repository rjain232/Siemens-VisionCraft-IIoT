import  { useState } from "react";
import ChartCard from "../common/testexperiments/ChartCard";
import ProductionLineGraph from "../common/testexperiments/ProductionLineGraph";
import ShiftwiseProductionGraph from "../common/testexperiments/ShiftwiseProductionGrapg";
import ShiftwiseProductionPieChart from "../common/testexperiments/ShiftwiseProductionPieChart";
import { format, subDays } from "date-fns";
import DateRangeSelector from "../common/components/DateRangeSelector ";
import useAxios from "../hooks/useAxios";
import { generatePDF_Multiple_Tbl } from "../utils/PdfLib";
import {generateExcelWithSheets} from "../utils/ExcelUtils";
import {
  addGlobalStylesForPDF,
  addPageNumber,
  cleanupChartStyles,
  pageFooterFormat,
  pageHeadFormat,
  renderChartToPDF,
  reportFromToShiftHeaders,
} from "../utils/PdfLib";
import { useRef } from "react";
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";
import { LineName } from "../utils/constants";

const columns_OverallProductionTrendData = [
  { label: "Date", accessor: "Date" },
  { label: "Production Count", accessor: "PartsProduced" },
];
const columns_ShiftDetailsProductionData= [
  { label: "Production Count", accessor: "PartsProduced" },
  { label: "Shift", accessor: "Shift" },
];
const columns_ShiftwiseProductionDistributionData= [
  { label: "Date", accessor: "Date" },
  { label: "Shift", accessor: "Shift" },
  { label: "Production Count", accessor: "PartsProduced" },
];
const ProductionOverview = () => {
  const lastThreeDays = [...Array(3)]
    .map((_, i) => format(subDays(new Date(), i), "yyyy-MM-dd"))
    .reverse();

  const [dateFilter, setDateFilter] = useState({
    startDate: null,
    endDate: null,
    duration: null,
    shift: null,
  });

  const {
    data: ProductionOverviewData,
    loading: ProductionOverviewDataLoading,
    error: ProductionOverviewDataError,
    refetch: refetchProductionOverviewData,
  } = useAxios(
    "/productionOverview",
    { method: "GET" },
    true
  );
 // console.log("ProductionOverviewData==", ProductionOverviewData);
  const filteredData =
    ProductionOverviewData?.ShiftwiseProductionDistributionData.filter(
      (item) => item.Date && item.Shift && item.PartsProduced !== undefined
    );

  const formattedData = filteredData?.reduce((acc, curr) => {
    const [year, month, day] = curr.Date.split("-");
    const formattedDate = `${day}-${month}-${year}`;

    let entry = acc.find((item) => item.date === formattedDate);
    if (!entry) {
      entry = { date: formattedDate, Shift_A: 0, Shift_B: 0, Shift_C: 0 };
      acc.push(entry);
    }
    console.log("entry[`Shift_${curr.Shift}`] ",entry[`Shift_${curr.Shift}`] )
    entry[`Shift_${curr.Shift.trim()}`] = curr.PartsProduced;
    return acc;
  }, []);
 

  const handleSearch = (
    startDate,
    endDate,
    duration,
    shift,
    dedicatedDuration
  ) => {
    setDateFilter({
      startDate,
      endDate,
      duration,
      shift,
    });
    refetchProductionOverviewData({
      params: {
        startDate: startDate
          ? format(new Date(startDate), "yyyy-MM-dd HH:mm:ss")
          : null,
        endDate: endDate ? format(endDate, "yyyy-MM-dd HH:mm:ss") : null,
        duration,
        shift,
        dedicatedDuration,
      },
    });
  };
  // References for your charts
  const chart1Ref = useRef(null);
  // const chart2Ref = useRef(null);
  // const chart3Ref = useRef(null);
  const [downloading, setDownloading] = useState(false);

  const exportPdfProduction_Report = async () => {
    const doc = new jsPDF();
    const chartRefs = [chart1Ref];

    addGlobalStylesForPDF();
    chartRefs.forEach((ref) => ref.current?.classList.add("pdf-export"));

    // Page 1: Chart + Heading
    reportFromToShiftHeaders(doc, dateFilter);
    pageHeadFormat(doc, `${LineName} Production Overview`, false);
    await renderChartToPDF(doc, chartRefs, 50);

    // These will start from new pages (handled internally)
    await generatePDF_Multiple_Tbl(
      doc,
      columns_OverallProductionTrendData,
      ProductionOverviewData?.OverallProductionTrendData || [],
      "Overall Production Trend Report",
      dateFilter
    );

    await generatePDF_Multiple_Tbl(
      doc,
      columns_ShiftDetailsProductionData,
      ProductionOverviewData?.ShiftDetailsProductionData || [],
      "Shift Details Report",
      dateFilter
    );

    await generatePDF_Multiple_Tbl(
      doc,
      columns_ShiftwiseProductionDistributionData,
      ProductionOverviewData?.ShiftwiseProductionDistributionData || [],
      "Shift-wise Production Report",
      dateFilter
    );
    addPageNumber(doc);
    cleanupChartStyles(chartRefs);
    doc.save(`${LineName}_Production_Overview.pdf`);
  };

//console.log("DATE===", dateFilter);
  const handleDownload = () => {
    try {
      setDownloading(true);
      const sheets = [
        {
          sheetName: "Overall Production Trend",
          headers: columns_OverallProductionTrendData,
          rows: ProductionOverviewData?.OverallProductionTrendData || [],
        },
        {
          sheetName: "Shift Details",
          headers: columns_ShiftDetailsProductionData,
          rows: ProductionOverviewData?.ShiftDetailsProductionData || [],
        },
        {
          sheetName: "Shift-wise Distribution",
          headers: columns_ShiftwiseProductionDistributionData,
          rows: ProductionOverviewData?.ShiftwiseProductionDistributionData || [],
        },
      ];

      generateExcelWithSheets(sheets, `${LineName} Production Overview`);
      exportPdfProduction_Report().then(() => {
        setDownloading(false);
      });
    }
    catch (error) {
      console.log(error);
    }
  };
  if (ProductionOverviewDataError) {
    return <div>Error loading data</div>;
  }

  return (
    <>
      <DateRangeSelector
        showDownload={true}
        onDownload={handleDownload}
        onSearch={handleSearch}
        showDate={false}
        selectedStartDate={dateFilter?.startDate}
        selectedEndDate={dateFilter?.endDate}
        isDownloading={downloading}
      />
      <div>
        <h1 className="text-lg font-semibold mt-4">
          {dateFilter.startDate && dateFilter.endDate
            ? `Date : ${format(
              new Date(dateFilter.startDate),
              "dd-MM-yyyy"
            )}  To  ${format(new Date(dateFilter.endDate), "dd-MM-yyyy")}`
            : `Date : ${lastThreeDays[0]}  To  ${lastThreeDays[lastThreeDays?.length - 1]
            }`}
        </h1>
        {!ProductionOverviewDataLoading && (
          <div ref={chart1Ref}>
            <div
              className={`grid grid-cols-1 md:grid-cols-1 ${ProductionOverviewData?.OverallProductionTrendData?.length > 5
                ? "lg:grid-cols-1"
                : "lg:grid-cols-3"
                }  gap-4 py-4`}
            >
              <ChartCard title={" Overall Production Trend"} shadow={true}>
                <ProductionLineGraph
                  data={ProductionOverviewData?.OverallProductionTrendData}
                />
              </ChartCard>
              <ChartCard
                title={"Shift-wise Production Distribution"}
                shadow={true}
              >
                <ShiftwiseProductionGraph data={formattedData} />
              </ChartCard>
              <ChartCard title={"Shift Details"} shadow={true}>
                <ShiftwiseProductionPieChart
                  data={ProductionOverviewData?.ShiftDetailsProductionData}
                />
              </ChartCard>
            </div>
          </div>
        )}
      </div>
    </>
  );
};

export default ProductionOverview;
