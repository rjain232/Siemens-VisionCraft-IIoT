import { useState, useEffect } from "react";
import useAxios from "../hooks/useAxios";
import DateRangeSelector from "../common/components/DateRangeSelector ";
import { format } from "date-fns";
import ChartCard from "../common/testexperiments/ChartCard";
import ShiftEfficiencyPareto from "../common/testexperiments/ShiftEfficiencyPareto";
import OverallOEEPareto from "../common/testexperiments/OverallOEEPareto";
import PieChart from "../common/graphs/PieChart";
import StackedColumnChart from "../common/testexperiments/StackedColumnChart";
import { jsPDF } from "jspdf";
import * as XLSX from "xlsx";
import { saveAs } from "file-saver";
import {
  addGlobalStylesForPDF,
  addPageNumber,
  cleanupChartStyles,
  pageFooterFormat,
  pageHeadFormat,
  renderChartToPDF,
  reportFromToShiftHeaders,
} from "../utils/PdfLib";
import { useRef } from "react";
import {LineName} from "../utils/constants";

const OverallOEE = () => {
  const [dateFilter, setDateFilter] = useState({
    startDate: null,
    endDate: null,
    duration: null,
    shift: null,
  });

  const {
    data: OverallOEEData,
    loading: OverallOEELoading,
    error: OverallOEEError,
    refetch: refetchOverallOEEData,
  } = useAxios("/overallOEE", { method: "GET" }, true);

  const [downloading, setDownloading] = useState(false);

  const handleSearch = (
    startDate,
    endDate,
    duration,
    shift,
    dedicatedDuration,
  ) => {
    setDateFilter({
      startDate,
      endDate,
      duration,
      shift,
    });

    refetchOverallOEEData({
      params: {
        startDate: startDate
          ? format(new Date(startDate), "yyyy-MM-dd HH:mm:ss")
          : null,
        endDate: endDate ? format(endDate, "yyyy-MM-dd HH:mm:ss") : null,
        duration,
        shift,
        dedicatedDuration,
      },
    });
  };

  const exportExcelReport = () => {
    const wb = XLSX.utils.book_new();
    const { oeeParameters } = OverallOEEData;
    // === Sheet 1: OEE Factor Table ===
    const oeeSheetData = [
      [
        "OEE Factor",
        `[Shift - ${dateFilter?.shift ? dateFilter?.shift : "All"}] (%)`,
      ],
      ["Availability", oeeParameters[0]["Availability"]],
      ["Performance", oeeParameters[0]["Performance"]],
      ["Quality", oeeParameters[0]["Quality"]],
      ["OEE", oeeParameters[0]["OEE"]],
    ];
 
    const oeeSheet = XLSX.utils.aoa_to_sheet(oeeSheetData);
    XLSX.utils.book_append_sheet(wb, oeeSheet, "Titan OEE Summary");

    // === Sheet 2: Day & Shift Wise OEE ===
    const dayOeeHeader = ["Date", "Shift A", "Shift B", "Shift C", "Overall"];
    const dayOeeData = OverallOEEData.dayAndShiftWiseOEE.map((entry) => [
      entry.date,
      `${entry.Shift_A}`,
      `${entry.Shift_B}`,
      `${entry.Shift_C}`,
      `${entry.OEE}`,
    ]);

    const shiftWiseSheet = XLSX.utils.aoa_to_sheet([
      dayOeeHeader,
      ...dayOeeData,
    ]);
    XLSX.utils.book_append_sheet(wb, shiftWiseSheet, `${LineName} Shiftwise OEE`);

    // Save the workbook
    const excelBuffer = XLSX.write(wb, { bookType: "xlsx", type: "array" });
    const blob = new Blob([excelBuffer], { type: "application/octet-stream" });
    saveAs(blob, `${LineName}_OEE_Report.xlsx`);
  };

  const printTable = async (doc) => {
    // ===== TABLE 1: OEE FACTORS TABLE =====
    const { oeeParameters, shiftWiseOEEDistribution } = OverallOEEData;

    const factorTable = [
      ["Availability", oeeParameters[0]["Availability"]],
      ["Performance", oeeParameters[0]["Performance"]],
      ["Quality", oeeParameters[0]["Quality"]],
      ["OEE", oeeParameters[0]["OEE"]],
    ];

    doc.autoTable({
      startY: 180,
      head: [["OEE Factor", `[Shift - ${dateFilter?.shift ? dateFilter?.shift : "All"}]`]],
      body: factorTable,
      theme: "grid",
      headStyles: {
        fillColor: [0, 170, 160],
        textColor: 255,
        halign: "center",
      },
      styles: {
        halign: "center",
      },
      //  willDrawPage: function () {
      //     pageHeadFormat(doc, "OEE Report" , false);
      //   },
    });

    // ===== TABLE 2: DAILY OEE TABLE =====
    const shiftTableBody = OverallOEEData.dayAndShiftWiseOEE.map((entry) => {
      const row = [
        entry.date,
        `${entry.Shift_A || "-"}`,
        `${entry.Shift_B || "-"}`,
        `${entry.Shift_C || "-"}`,
        `${entry.OEE}`,
      ];
      return row;
    });

    doc.autoTable({
      startY: doc.lastAutoTable.finalY + 10,
      head: [["Date", "Shift A", "Shift B", "Shift C", "Overall"]],
      body: shiftTableBody,
      theme: "grid",
      headStyles: {
        fillColor: [0, 170, 160],
        textColor: 255,
        halign: "center",
      },
      styles: {
        halign: "center",
      },
      didParseCell: (data) => {
        // Highlight if OEE is below a threshold
        const value = data.cell.raw?.replace("%", "");
        if (data.column.index >= 1 && value && parseFloat(value) < 50) {
          data.cell.styles.textColor = [255, 0, 0];
          data.cell.styles.fontStyle = "bold";
        }
      },
      didDrawPage: function (data) {
        pageFooterFormat(doc, data);
      },
    });
    addPageNumber(doc);
    //doc.save("OEE_Report.pdf");
  };

  // References for your charts
  const chart1Ref = useRef(null);
  const chart2Ref = useRef(null);
  const chart3Ref = useRef(null);

  const exportPdfOEEReport = async () => {
    const doc = new jsPDF();
    const chartRefs = [chart1Ref, chart2Ref, chart3Ref];
    reportFromToShiftHeaders(doc, dateFilter);
    addGlobalStylesForPDF();
    chartRefs.forEach((ref) => ref.current?.classList.add("pdf-export"));
    let yOffset = 50;
    await renderChartToPDF(doc, chartRefs, yOffset);
    pageHeadFormat(doc, `${LineName} OEE Report`, false);
    printTable(doc);
    cleanupChartStyles(chartRefs);
    doc.save(`${LineName}_OEE_Report.pdf`);
  };

  const handleDownload = async () => {
    try {
      setDownloading(true);
      exportExcelReport();
      exportPdfOEEReport().then(() => {
        setDownloading(false);
      });
    } catch (error) {
      //console.log(error);
    }
  };

  if (OverallOEEError) {
    return <div> Error in fetching data ... </div>;
  }
  return (
    <>
      <div className="mt-2 px-2 sm:px-4">
        <DateRangeSelector
          onDownload={handleDownload}
          activeTab={"Overall OEE"}
          showShift={true}
          onSearch={handleSearch}
          selectedStartDate={dateFilter?.startDate}
          selectedEndDate={dateFilter?.endDate}
          selectedDuration={dateFilter?.duration}
          selectedShift={dateFilter?.shift}
          isDownloading={downloading}
          TimeSelection={false}
        />
        {!OverallOEELoading && (
          <>
            {OverallOEEData?.oeeParameters?.[0]?.Availability !== null ||
            OverallOEEData?.oeeParameters?.[0]?.Performance !== null ||
            OverallOEEData?.oeeParameters?.[0]?.Quality !== null ||
            (OverallOEEData?.shiftWiseOEEDistribution || []).some(
              (item) => item.OEE !== null,
            ) ||
            (OverallOEEData?.availableVSDowntime || []).length > 0 ||
            (OverallOEEData?.dayAndShiftWiseOEE || []).length > 0 ? (
              <>
                <div
                  ref={chart1Ref}
                  className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 my-4"
                  style={{
                    position: "relative",
                    paddingBottom: "20px",
                    overflow: "visible",
                  }}
                >
                  {/* Shift-wise OEE Distribution */}

                  <div className="w-full">
                    <ChartCard
                      title={`OEE [Shift - ${dateFilter?.shift ? dateFilter?.shift : "All"}]`}
                    >
                      {(OverallOEEData?.shiftWiseOEEDistribution || []).some(
                        (item) => item.OEE !== null,
                      ) ? (
                        <OverallOEEPareto
                          height={280}
                          label={"OEE"}
                          value={OverallOEEData?.oeeParameters?.[0]?.OEE ?? 0}
                        />
                      ) : (
                        //   <ShiftEfficiencyPareto
                        //   height={280}
                        //   labels={OverallOEEData.shiftWiseOEEDistribution.map(item => item.shift)}
                        //   //labels={["Shift A", "Shift B", "Shift C", "OEE"]}
                        //   //series={OverallOEEData.shiftWiseOEEDistribution.map(item => item.OEE ?? 0)}
                        //   series={[OverallOEEData.shiftWiseOEEDistribution.find(item => item.shift === "Shift A")?.OEE ?? 0,
                        //   OverallOEEData.shiftWiseOEEDistribution.find(item => item.shift === "Shift B")?.OEE ?? 0,
                        //   OverallOEEData.shiftWiseOEEDistribution.find(item => item.shift === "Shift C")?.OEE ?? 0,
                        //   OverallOEEData?.oeeParameters?.[0]?.OEE ?? 0]}
                        // />
                        <div className="text-gray-500 text-sm text-center py-4">
                          OEE data not available
                        </div>
                      )}
                    </ChartCard>
                  </div>

                  {/* Overall Equipment Efficiency */}

                  <div className="col-span-1 sm:col-span-2">
                    <ChartCard
                      title={`APQ [Shift - ${dateFilter?.shift ? dateFilter?.shift : "All"}]`}
                    >
                      {" "}
                      {OverallOEEData?.oeeParameters?.[0]?.Availability !==
                        null ||
                      OverallOEEData?.oeeParameters?.[0]?.Performance !==
                        null ||
                      OverallOEEData?.oeeParameters?.[0]?.Quality !== null ? (
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-4">
                          {OverallOEEData?.oeeParameters?.[0]?.Availability !==
                            null && (
                            <OverallOEEPareto
                              height={350}
                              label="Availability"
                              value={
                                OverallOEEData.oeeParameters[0].Availability
                              }
                            />
                          )}
                          {OverallOEEData?.oeeParameters?.[0]?.Performance !==
                            null && (
                            <OverallOEEPareto
                              height={350}
                              label="Performance"
                              value={
                                OverallOEEData.oeeParameters[0].Performance
                              }
                            />
                          )}
                          {OverallOEEData?.oeeParameters?.[0]?.Quality !==
                            null && (
                            <OverallOEEPareto
                              height={350}
                              label="Quality"
                              value={OverallOEEData.oeeParameters[0].Quality}
                            />
                          )}
                        </div>
                      ) : (
                        <div className="text-gray-500 text-sm text-center py-4">
                          APQ data not available
                        </div>
                      )}
                    </ChartCard>
                  </div>

                  {/* Available vs Downtime */}

                  <ChartCard
                    title={`Total Available Time VS Total Downtime [Shift - ${dateFilter?.shift ? dateFilter?.shift : "All"}]`}
                  >
                    {(OverallOEEData?.availableVSDowntime || []).filter(Boolean)
                      .length > 0 ? (
                      <PieChart
                        chartSeries={OverallOEEData.availableVSDowntime}
                        labels={["Available Time", "Downtime"]}
                        colors={["#00893D", "#A12E2D"]}
                        height={230}
                        chartType={"Downtime"}
                      />
                    ) : (
                      <div className="text-gray-500 text-sm text-center py-4">
                        Available vs Downtime data not available
                      </div>
                    )}
                  </ChartCard>
                </div>

                {/* Daywise OEE */}

                <div
                  ref={chart2Ref}
                  style={{
                    position: "relative",
                    paddingBottom: "20px",
                    overflow: "visible",
                  }}
                >
                  <ChartCard title="Daywise OEE Distribution">
                    {(OverallOEEData?.dayAndShiftWiseOEE || []).length > 0 ? (
                      <div id="barcolumn">
                        <StackedColumnChart
                          OEEData={OverallOEEData.dayAndShiftWiseOEE}
                        />
                      </div>
                    ) : (
                      <div className="text-gray-500 text-sm text-center py-4">
                        Daywise OEE data not available
                      </div>
                    )}
                  </ChartCard>
                </div>
              </>
            ) : (
              <div className="text-center text-gray-500 mt-6 text-sm">
                No OEE data available for the selected date and shift range.
              </div>
            )}
          </>
        )}
      </div>
    </>
  );
};

export default OverallOEE;
