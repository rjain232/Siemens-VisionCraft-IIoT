import { useState } from "react";
import useAxios from "../hooks/useAxios";
import { format } from "date-fns";
import DateRangeSelector from "../common/components/DateRangeSelector ";
import ChartCard from "../common/testexperiments/ChartCard";
import ShiftEfficiencyPareto from "../common/testexperiments/ShiftEfficiencyPareto";
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";
import * as XLSX from "xlsx";
import { saveAs } from "file-saver";
import {
  addGlobalStylesForPDF,
  addPageNumber,
  cleanupChartStyles,
  pageFooterFormat,
  pageHeadFormat,
  renderChartToPDF,
  reportFromToShiftHeaders
} from "../utils/PdfLib";
import { useRef } from "react";

const StationWiseOEE = () => {
  const [dateFilter, setDateFilter] = useState({
    startDate: null,
    endDate: null,
    duration: null,
    shift: null,
  });

  const {
    data: StaionwiseOeedata,
    loading: StaionwiseOeeloading,
    error: StationWiseOEEError,
    refetch: refetchStationwiseOee,
  } = useAxios("/stationwiseoee", { method: "GET" }, true);

  const handleSearch = (
    startDate,
    endDate,
    duration,
    shift,
    dedicatedDuration
  ) => {
    setDateFilter({
      startDate,
      endDate,
      duration,
      shift,
    });
    refetchStationwiseOee({
      params: {
        startDate: startDate
          ? format(new Date(startDate), "yyyy-MM-dd HH:mm:ss")
          : null,
        endDate: endDate ? format(endDate, "yyyy-MM-dd HH:mm:ss") : null,
        duration,
        shift,
        dedicatedDuration,
      },
    });
  };

  const exportExcelStationWiseOEEReport = () => {
    const wb = XLSX.utils.book_new();

    StaionwiseOeedata.forEach((station) => {
      const headers = [
        "Shift",
        "Availability",
        "Performance",
        "Quality",
        "OEE",
      ];

      const apqData = {};
      station.apqData.forEach((item) => {
        apqData[item.name] = item.value;
      });

      const shifts = ["Shift A", "Shift B", "Shift C", "OEE"];
      const body = shifts.map((shiftName) => {
        if (shiftName === "OEE") {
          // Overall row
          const overall =
            station.shiftData.find((s) => s.name === "OEE")?.oee || "";
          return [
            "Overall",
            apqData["Availability"] || "",
            apqData["Performance"] || "",
            apqData["Quality"] || "",
            overall,
          ];
        } else {
          const shift = station.shiftData.find((s) => s.name === shiftName);
          return [
            shiftName,
            apqData["Availability"] || "",
            apqData["Performance"] || "",
            apqData["Quality"] || "",
            shift?.oee || "",
          ];
        }
      });

      const sheetData = [headers, ...body];

      const ws = XLSX.utils.aoa_to_sheet(sheetData);
      XLSX.utils.book_append_sheet(wb, ws, station.name);
    });

    const wbout = XLSX.write(wb, { bookType: "xlsx", type: "array" });
    saveAs(
      new Blob([wbout], { type: "application/octet-stream" }),
      "Stations_ShiftWise.xlsx"
    );
  };

  const exportPdfStationWiseOEEReport1 = async (doc) => {
    //const doc = new jsPDF("landscape");

    StaionwiseOeedata.forEach((station, index) => {
      if (index > 0) doc.addPage();

      doc.setFontSize(14);
      doc.text(`Station: ${station.name}`, 14, 15);

      const headers = [
        "Shift",
        "Availability",
        "Performance",
        "Quality",
        "OEE",
      ];

      const apqData = {};
      station.apqData.forEach((item) => {
        apqData[item.name] = item.value;
      });

      const shifts = ["Shift A", "Shift B", "Shift C", "OEE"];
      const body = shifts.map((shiftName) => {
        if (shiftName === "OEE") {
          const overall =
            station.shiftData.find((s) => s.name === "OEE")?.oee || "";
          return [
            "Overall",
            apqData["Availability"] || "",
            apqData["Performance"] || "",
            apqData["Quality"] || "",
            overall,
          ];
        } else {
          const shift = station.shiftData.find((s) => s.name === shiftName);
          return [
            shiftName,
            apqData["Availability"] || "",
            apqData["Performance"] || "",
            apqData["Quality"] || "",
            shift?.oee || "",
          ];
        }
      });

      autoTable(doc, {
        startY: 30,
        margin: { top: 30 },
        head: [headers],
        body: body,
        theme: "grid",
        styles: {
          fontSize: 10,
          cellPadding: 4,
          textColor: [0, 0, 0], // Black text
          halign: "center",
          valign: "middle",
          lineColor: [224, 222, 222],
          lineWidth: 0.1,
        },
        headStyles: {
          fillColor: [62, 201, 177],
          textColor: [255, 255, 255],
          cellPadding: 4,
          fontStyle: "bold",
        },
        didDrawPage: function (data) {
          pageFooterFormat(doc, data);
        },
        willDrawPage: function () {
          pageHeadFormat(doc, "Station wise OEE Report",false);
        },
      });
    });
    addPageNumber(doc);
    //doc.save("Stations_ShiftWise.pdf");
  };
   // References for your charts
    const chart1Ref = useRef(null);
    // const chart2Ref = useRef(null);
    // const chart3Ref = useRef(null);
    const [downloading, setDownloading] = useState(false);
    
    const exportPdfOEEReport = async () => {
      const doc = new jsPDF();
      const chartRefs = [chart1Ref];
      reportFromToShiftHeaders(doc, dateFilter);
      addGlobalStylesForPDF();
      chartRefs.forEach((ref) => ref.current?.classList.add("pdf-export"));
      let yOffset = 50;
      await renderChartToPDF(doc, chartRefs,yOffset);
      pageHeadFormat(doc, "Station wise OEE Report",false);
      //printTable(doc);
      doc.addPage();
     await exportPdfStationWiseOEEReport1(doc);
      cleanupChartStyles(chartRefs);
      doc.save("Station_wise_OEE_Report_With_Charts.pdf");
    };

  const handleDownload = async() => {
    try{setDownloading(true);
    exportExcelStationWiseOEEReport();
   
    exportPdfOEEReport().then(() => {
      setDownloading(false);
    });}
    catch (error) {
      //console.log(error);
    }
  }
 // console.log("StaionwiseOeedata",StaionwiseOeedata);
  if(StationWiseOEEError){
    return <div>Error in fetching data ...</div>
  }

  return (
    <div className="mt-2 px-2 sm:px-4">
      <DateRangeSelector
        onDownload={handleDownload}
        onSearch={handleSearch}
        activeTab={"Station-wise OEE"}
        showShift={false}
        selectedStartDate={dateFilter?.startDate}
        selectedEndDate={dateFilter?.endDate}
        selectedDuration={dateFilter?.duration}
        selectedShift={dateFilter?.shift}
        isDownloading={downloading}
      />
      {!StaionwiseOeeloading && (
        <div ref={chart1Ref} className="grid grid-cols-3 gap-6">
          {StaionwiseOeedata.map((station, index) => (
            <ChartCard
              key={index}
              title={station.name}
              shadow={true}
              border={"border-2 border-solid border-gray-100"}
            >
              <div className="flex justify-between items-center">
                {/* Shift Efficiency Pareto Chart */}
                <div className="w-2/3">
                  <ShiftEfficiencyPareto
                    height={280}
                    labels={station.shiftData.map((shift) => shift.name)}
                    series={station.shiftData.map((shift) => shift.oee)}
                  />
                </div>

                {/* APQ Section - Aligned Right */}
                <div className="w-1/3 flex flex-col space-y-2">
                  {station.apqData.map((item, idx) => (
                    <div
                      key={idx}
                      className="border-2 border-solid border-gray-100 p-2 rounded-lg text-center"
                    >
                      <h4 className="text-sm text-gray-600 ">{item.name}</h4>
                      <p className="text-lg font-bold ">{item.value}%</p>
                    </div>
                  ))}
                </div>
              </div>
            </ChartCard>
          ))}
        </div>
      )}
    </div>
  );
};

export default StationWiseOEE;
