import { useRef, useState } from "react";
import useAxios from "../hooks/useAxios";
import DateRangeSelector from "../common/components/DateRangeSelector ";
import { format } from "date-fns";
import BarGraph from "../common/testexperiments/BarGraph";
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";
import * as XLSX from "xlsx";
import { saveAs } from "file-saver";
import {
  addChartToPDF,
  addGlobalStylesForPDF,
  addPageNumber,
  cleanupChartStyles,
  pageFooterFormat,
  pageHeadFormat,
  reportFromToShiftHeaders,
} from "../utils/PdfLib";

const Top10Faults = () => {
  const [dateFilter, setDateFilter] = useState({
    startDate: null,
    endDate: null,
    duration: null,
    shift: null,
  });

  const {
    data: Top10faults,
    loading: Top10faultsloading,
    error: Top10faultserror,
    refetch: refetchTop10Faults,
  } = useAxios("/top10faults", { method: "GET" }, true);
   const [downloading, setDownloading] = useState(false);

  const handleSearch = (
    startDate,
    endDate,
    duration,
    shift,
    dedicatedDuration
  ) => {
    setDateFilter({
      startDate,
      endDate,
      duration,
      shift,
    });
    refetchTop10Faults({
      params: {
        startDate: startDate
          ? format(new Date(startDate), "yyyy-MM-dd HH:mm:ss")
          : null,
        endDate: endDate ? format(endDate, "yyyy-MM-dd HH:mm:ss") : null,
        duration,
        shift,
        dedicatedDuration,
      },
    });
  };

  const exportExcelTop10Faults = () => {
    if (!Top10faults.length) return;

    const header = ["Sr.No", "Fault Code", "Frequency", "Total Time"];

    // Build rows: convert seconds to HH:MM:SS
    const rows = Top10faults.map((item, index) => {
      const timeInSeconds = item.time || 0;
      const hours = Math.floor(timeInSeconds / 3600)
        .toString()
        .padStart(2, "0");
      const minutes = Math.floor((timeInSeconds % 3600) / 60)
        .toString()
        .padStart(2, "0");
      const seconds = (timeInSeconds % 60).toString().padStart(2, "0");
      const formattedTime = `${hours}:${minutes}:${seconds}`;

      return [index + 1, item.name || "N/A", item.count || 0, formattedTime];
    });

    const aoa = [header, ...rows]; // Final 2D array

    const ws = XLSX.utils.aoa_to_sheet(aoa);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Fault Report");

    const wbout = XLSX.write(wb, { bookType: "xlsx", type: "array" });
    const blob = new Blob([wbout], { type: "application/octet-stream" });
    saveAs(blob, "Fault_Report.xlsx");
  };
 const chart1Ref = useRef(null);
  const exportPdfTop10Faults = async () => {
    try {
      const doc = new jsPDF();
       reportFromToShiftHeaders(doc, dateFilter);
       addGlobalStylesForPDF();
       chart1Ref.current?.classList.add("pdf-export");
       let yOffset = 50;
       await addChartToPDF(doc, chart1Ref, yOffset);
       const header = ["Sr.No", "Fault code", "Frequency", "Total Time"];

      const body = Top10faults.map((item, index) => {
        const timeInSeconds = item.time || 0;
        const hours = Math.floor(timeInSeconds / 3600)
          .toString()
          .padStart(2, "0");
        const minutes = Math.floor((timeInSeconds % 3600) / 60)
          .toString()
          .padStart(2, "0");
        const seconds = (timeInSeconds % 60).toString().padStart(2, "0");
        const formattedTime = `${hours}:${minutes}:${seconds}`;

        return [index + 1, item.name || "N/A", item.count || 0, formattedTime];
      });

      autoTable(doc, {
        head: [header],
        body: body,
        styles: {
          fontSize: 10,
          cellPadding: 4,
          textColor: [0, 0, 0],
          halign: "center",
          valign: "middle",
          lineColor: [224, 222, 222],
          lineWidth: 0.1,
        },
        headStyles: {
          fillColor: [62, 201, 177],
          textColor: [255, 255, 255],
          fontStyle: "bold",
        },
        columnStyles: {
          0: { fontStyle: "bold" },
        },
        theme: "grid",
        startY: 110,
        didDrawPage: function (data) {
          pageFooterFormat(doc, data,);
        },
        willDrawPage: function () {
          pageHeadFormat(doc, "Top 10 Faults",false);
        },
      });

      addPageNumber(doc);
      doc.save("Fault_Report.pdf");
      cleanupChartStyles([chart1Ref])
    } catch (e) {
      //console.log(e);
    }
  };

  const handleDownload = async () => {
    try {
      setDownloading(true)
      exportExcelTop10Faults();
      exportPdfTop10Faults().then(()=>{setDownloading(false)});
    } catch (error) {
      //console.log(error);
    }
  };

  if(Top10faultserror){
    return <div>Error in fetching data ....</div>
  }

  return (
    <>
      <div className="pt-4 px-2 sm:px-4">
        <DateRangeSelector
          onDownload={handleDownload}
          onSearch={handleSearch}
          activeTab={"Top 10 Faults"}
          showShift={true}
          selectedStartDate={dateFilter?.startDate}
          selectedEndDate={dateFilter?.endDate}
          selectedDuration={dateFilter?.duration}
          selectedShift={dateFilter?.shift}
          isDownloading={downloading}
        />

        {!Top10faultsloading && (
          <div
            ref={chart1Ref}
            className="bg-white rounded-xl shadow-lg pt-4 px-6 pb-2w-full"
          >
            <h2 className="text-lg font-semibold mb-4 text-center text-gray-700">
              Top 10 Faults
            </h2>
            <BarGraph height={350} faultData={Top10faults} />
          </div>
        )}
      </div>
    </>
  );
};

export default Top10Faults;
