import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import NetPositiveLogo from "../assets/Netp_Logo_2.10.png";
// import DhruvaLogo from "../assets/DHRUVA-logo(Icon ONLY).png";
import PropTypes from "prop-types";
import useAxios from "../hooks/useAxios";
import { useAuthContext } from "../hooks/AuthContext";
import { useNavigate } from "react-router-dom";
import schaefflerLogo from "../assets/schaeffler.png";


const initialState = { username: "", password: "" };

const validationSchema = Yup.object({
  username: Yup.string()
    .required("Username is required")
    .min(3, "Username must be at least 3 characters"),
  password: Yup.string()
    .required("Password is required")
    .min(6, "Password must be at least 6 characters"),
});

const LoginPage = () => {
  const { login } = useAuthContext()
  const { refetch } = useAxios(
    "/login",
    { method: "POST" },
    false,
  );
  const navigate = useNavigate();
  const handleSubmit = async (values, { setSubmitting, setErrors }) => {
    try {
      const response = await refetch({
        data: { Username: values.username, Password: values.password }
      });

      if (response) {
        login(response.token, navigate);
      } else {
        setErrors({ username: "Invalid credentials", password: "Invalid credentials" });
      }
    } catch (error) {

      setErrors({ username: "Server error, please try again" });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center mt-6">
      <div className="mb-4">
        <div className=" flex items-center justify-center mt-6 p-2">
          <img
            src={NetPositiveLogo}
            width="250"
            height="90%"
            alt="logo"
            className="mx-2 p-2"
          />
        </div>
      </div>
      <h2
        className=" text-center "
        style={{
          letterSpacing: "0.830px",
          lineHeight: "normal",
          fontStyle: "normal",
          fontSize: "18.66px",
          fontWeight: "600",
          color: "#0F0F0F",
          paddingBottom: "22px",
        }}
      >
        LOGIN
      </h2>
      <div className="w-full max-w-md p-8 space-y-6 bg-white shadow-md rounded-lg border-2 border-t-2 border-t-blue-900 border-white">
        <Formik
          initialValues={initialState}
          validationSchema={validationSchema}
          onSubmit={handleSubmit}
        >
          {() => (
            <Form className="space-y-4">
              <div>
                <label
                  htmlFor="username"
                  className="block text-sm font-medium text-blue-950"
                  style={{ fontWeight: "600" }}
                >
                  Username
                </label>
                <Field
                  type="text"
                  id="username"
                  name="username"
                  className="w-full px-4 py-2 mt-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                  placeholder="Enter your username"
                />
                <ErrorMessage
                  name="username"
                  component="div"
                  className="mt-1 text-sm text-red-500"
                />
              </div>
              <div>
                <label
                  htmlFor="password"
                  className="block text-sm font-medium text-blue-950"
                  style={{ fontWeight: "600" }}
                >
                  Password
                </label>
                <Field
                  type="password"
                  id="password"
                  name="password"
                  className="w-full px-4 py-2 mt-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                  placeholder="Enter your password"
                />
                <ErrorMessage
                  name="password"
                  component="div"
                  className="mt-1 text-sm text-red-500"
                />
              </div>
              <div className="flex items-center justify-center pt-2">
                <button
                  type="submit"
                  className="flex items-center justify-center px-4 py-2 text-white  rounded-lg hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-400"
                  style={{ backgroundColor: "#1e3a8a" }}
                >
                  LOGIN
                </button>
              </div>
            </Form>
          )}
        </Formik>
      </div>
      <footer className="mt-6 text-center text-sm text-gray-600 ">
        <p className="flex items-center justify-center">
          Developed by {" "}
          {/* <img
            src={DhruvaLogo}
            alt="Dhruva Logo"
            width="22"
            height="22"
            className="mx-2"
          /> */}
          <img
            src={schaefflerLogo}
            width="100"
            height="100"
            alt="logo"
            className="mx-1 h-auto align-middle"
          />{" "}
          | All rights reserved
        </p>
      </footer>
    </div>
  );
};

LoginPage.propTypes = {
  onLogin: PropTypes.func.isRequired,
};
export default LoginPage;
