// import React from "react";
// import netpLogo from "../Assets/Netp_Logo_2.10.png";
// import SchaefflerLogo from "../assets/schaeffler.png";

// const About = () => {
//   document.body.style.overflow = "hidden";

//   return (
//     <div className="flex flex-col items-center justify-center min-h-screen mt-12">
//       <div
//         className="w-full max-w-2xl mt-12 bg-white shadow-md rounded-md p-6"
//         style={{ borderTop: "4px solid #00893D" }}
//       >
//         <div className="flex flex-col items-center text-center">
//           <img
//             src={netpLogo}
//             width="185"
//             height="60"
//             alt="logo"
//             className="mb-6"
//           />
//           <div className="w-full space-y-4 text-lg">
//             {/* Product Name */}
//             <div className="flex flex-col sm:flex-row sm:items-center">
//               <div className="sm:w-1/3 font-semibold sm:text-right sm:pr-4">
//                 Product Name
//               </div>
//               <div className="hidden sm:block w-[10px]">:</div>
//               <div className="sm:w-2/3 text-left pl-1 sm:pl-0">Net+Ve</div>
//             </div>

//             {/* Developed By */}
//             <div className="flex flex-col sm:flex-row sm:items-start">
//               <div className="sm:w-1/3 font-semibold sm:text-right sm:pr-4">
//                 Developed By
//               </div>
//               <div className="hidden sm:block w-[10px] pt-1">:</div>
//               <div className="sm:w-2/3 text-left">
//                 <img src={SchaefflerLogo} width={150} height={30} />
//                 Dhruva Automation And Control Pvt. Ltd.
//                 <br />
//                 <a
//                   href="https://dacpl.in"
//                   className="text-blue-600 hover:underline text-sm"
//                   target="_blank"
//                   rel="noopener noreferrer"
//                 >
//                   visit website
//                 </a>
//               </div>
//             </div>

//             {/* Licensing */}
//             {/* <div className="flex flex-col sm:flex-row sm:items-center">
//                           <div className="sm:w-1/3 font-semibold sm:text-right sm:pr-4">
//                               Licensing
//                           </div>
//                           <div className="hidden sm:block w-[10px]">:</div>
//                           <div className="sm:w-2/3 text-left">Generated At DACPL</div>
//                       </div> */}
//           </div>
//         </div>
//       </div>

//       {/* Optional Full Height Filler (If you still need it) */}
//       <div className="w-full h-[100vh]"></div>
//     </div>
//   );
// };

// export default About;

import React, { useEffect } from "react";
import netpLogo from "../Assets/Netp_Logo_2.10.png";
import SchaefflerLogo from "../assets/schaeffler.png";

const About = () => {
  useEffect(() => {
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = "auto";
    };
  }, []);

  return (
    <div className="flex items-center justify-center h-[70vh] bg-gray-100 px-4">
      <div className="w-full max-w-3xl bg-white rounded-xl shadow-lg overflow-hidden text-center">
        {/* Top Accent */}
    {/* <div className="h-1.5 bg-[#00893D]" /> */}

        {/* Content */}
        <div className="p-10 space-y-8 border-t-4 border-purple-900">
          {/* Logo */}
          <img
            src={netpLogo}
            alt="Net+Ve Logo"
            className="mx-auto h-14 w-auto"
          />

          {/* Product Name */}
          <div className="space-y-1">
            <p className="text-sm text-gray-500 font-medium">
              Product Name
            </p>
            <p className="text-lg font-semibold text-gray-800">
              Net+Ve
            </p>
          </div>

          {/* Developed By */}
          <div className="space-y-2">
            <p className="text-sm text-gray-500 font-medium">
              Developed By
            </p>

            <img
              src={SchaefflerLogo}
              alt="Schaeffler Logo"
              //height={15}
              //width={150}
              className="mx-auto h-full w-32  object-center"
            />

            <p className="text-base text-gray-800">
              (Formerly : Dhruva Automation And Controls Pvt. Ltd.)
            </p>

            <a
              href="https://dacpl.in"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block text-sm text-blue-600 hover:underline"
            >
              visit website
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;



