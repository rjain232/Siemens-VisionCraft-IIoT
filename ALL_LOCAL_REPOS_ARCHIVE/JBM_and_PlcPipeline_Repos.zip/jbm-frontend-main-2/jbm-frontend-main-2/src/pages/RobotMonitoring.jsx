import {  useState } from "react";
import RobotLayout from "../common/testexperiments/RobotLayout";
import RobotStatus from "../robotmonitoring/RobotStatus";
import RobotEvents from "../robotmonitoring/RobotEvents";
import SpotAccuracy from "../robotmonitoring/SpotAccuracy";
import RobotOverloadHistory from "../robotmonitoring/RobotOverloadHistory";


const RobotMonitoring = () => {
  const [activeTab, setActiveTab] = useState("Robot Health");
  const [selectedRobot, setSelectedRobot] = useState(1);
  const handleRobotChange = (robot) => {
    //console.log("Selected Robot:", robot);
    setSelectedRobot(robot.id);
  };

  const handleActiveTabChange = (value) => {
    setActiveTab(value);
  };

  return (
    <div>
      <div className="border-b flex space-x-6">
        <div
          onClick={() => setActiveTab("Robot Health")}
          className={`cursor-pointer py-2 pe-4 ${
            activeTab === "Robot Health"
              ? "border-b-2 border-purple-500 text-purple-500 font-semibold bg-white rounded-sm ps-4 "
              : "text-gray-500 hover:text-gray-700"
          }`}
        >
          Robot Health
        </div>
        <div
          onClick={() => setActiveTab("Robot Status")}
          className={`cursor-pointer py-2 px-4 ${
            activeTab === "Robot Status"
              ? "border-b-2 border-purple-500 text-purple-500 font-semibold bg-white  rounded-sm"
              : "text-gray-500 hover:text-gray-700"
          }`}
        >
          Robot Status
        </div>
        <div
          onClick={() => setActiveTab("Robot History Trend")}
          className={`cursor-pointer py-2 px-4 ${
            activeTab === "Robot History Trend"
              ? "border-b-2 border-purple-500 text-purple-500 font-semibold bg-white  rounded-sm"
              : "text-gray-500 hover:text-gray-700"
          }`}
        >
          Overload history
        </div>
        <div
          onClick={() => setActiveTab("Robot Events")}
          className={`cursor-pointer py-2 px-4 ${
            activeTab === "Robot Events"
              ? "border-b-2 border-purple-500 text-purple-500 font-semibold bg-white  rounded-sm"
              : "text-gray-500 hover:text-gray-700"
          }`}
        >
          Robot Events
        </div>
        <div
          onClick={() => setActiveTab("Spot Accuracy")}
          className={`cursor-pointer py-2 px-4 ${
            activeTab === "Spot Accuracy"
              ? "border-b-2 border-purple-500 text-purple-500 font-semibold bg-white  rounded-sm"
              : "text-gray-500 hover:text-gray-700"
          }`}
        >
          Spot Accuracy
        </div>
      </div>

      <div className="mt-2">
        {activeTab === "Robot Health" && (
          <div>
            <RobotLayout
              robotSelect={handleRobotChange}
              visibilityChange={handleActiveTabChange}
            />
          </div>
        )}
        {activeTab === "Robot Status" && <RobotStatus />}
        {activeTab === "Robot History Trend" && <RobotOverloadHistory />}
        {activeTab === "Robot Events" && <RobotEvents robot={selectedRobot} />}
        {activeTab === "Spot Accuracy" && <SpotAccuracy />}
      </div>
    </div>
  );
};

export default RobotMonitoring;
