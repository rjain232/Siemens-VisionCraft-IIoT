import { FaCheckCircle, FaIndustry, FaTimesCircle } from "react-icons/fa";
import ProductionCard from "../common/testexperiments/ProductionCard";
import OEECards from "../common/testexperiments/OEECards";
import DowntimeCard from "../common/testexperiments/DowntimeCard";
import ShiftFaultGraph from "../common/testexperiments/ShiftFaultGraph";
import GaugeChart from "../common/testexperiments/GaugeChart";

const StatCard = ({ icon, title, count }) => {
  return (
    <div
      className={`bg-white  shadow-xl rounded-2xl p-6 flex items-center space-x-4 border-t-4 border-gray-400 transform  hover:scale-105 transition-transform duration-300`}
    >
      <div className="text-5xl text-white">{icon}</div>
      <div>
        <h3 className="text-lg font-semibold text-black uppercase">{title}</h3>
        <p className="text-3xl font-bold text-black">{count}</p>
      </div>
    </div>
  );
};

const Summary = () => {
  return (
    <div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 pb-4">
        <StatCard icon={<FaIndustry fill="#3B0764" />} title="Total Production" count={100} />
        <StatCard icon={<FaCheckCircle fill="#3B0764" />} title="Total OK" count={80} />
        <StatCard icon={<FaTimesCircle fill="#3B0764" />} title="Total NOK" count={20} />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 pt-6 pb-4">
        <ProductionCard title="Shift A" okCount={40} nokCount={5} />
        <ProductionCard title="Shift B" okCount={25} nokCount={12} />
        <ProductionCard title="Shift C" okCount={15} nokCount={3} />
      </div>
      {/* OEE Gauges */}
      {/* <h2 className="text-2xl font-bold text-gray-800 text-center pt-8 pb-4">Overall Equipment Effectiveness</h2>
      <div className="grid grid-cols-1 md:grid-cols-4 gap-8 pt-4">
        <GaugeChart title="OEE" value={76} />
        <GaugeChart title="Availability" value={84} />
        <GaugeChart title="Performance" value={93} />
        <GaugeChart title="Quality" value={96} />
      </div> */}

      {/* Shift-wise OEE Section */}
      <h2 className="text-2xl font-bold text-gray-800 text-center pt-8 pb-4">
        Shift-wise OEE
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 pt-4">
        <OEECards title="Shift A OEE" oee={85} />
        <OEECards title="Shift B OEE" oee={78} />
        <OEECards title="Shift C OEE" oee={90} />
      </div>

      {/* Downtime Shift-wise */}
      <h2 className="text-2xl font-bold text-gray-800 text-center pt-8 pb-4">
        Shift-wise Downtime
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 pt-4">
        <DowntimeCard title="Shift A Downtime" availableTime={300} downtime={60} />
        <DowntimeCard title="Shift B Downtime" availableTime={280} downtime={80} />
        <DowntimeCard title="Shift C Downtime" availableTime={320} downtime={40} />
      </div>

      {/* Shift-wise Top 10 Faults */}
      <h2 className="text-2xl font-bold text-gray-800 text-center pt-8 pb-4">
        Shift-wise Top 10 Faults
      </h2>
      <ShiftFaultGraph />

    </div>
  );
};

export default Summary;
