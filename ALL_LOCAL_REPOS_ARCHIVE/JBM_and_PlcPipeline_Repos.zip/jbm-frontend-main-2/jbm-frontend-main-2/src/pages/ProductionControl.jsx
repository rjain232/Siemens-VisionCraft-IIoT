import { useState } from "react";
import CycleTime from "../productioncontrol/CycleTime";
import ProductionOverview from "../productioncontrol/ProductionOverview";
import ProductionReport from "../productioncontrol/ProductionReport";
import HourlyProductionReport from "../productioncontrol/HourlyProductionReport";
import DetailedProductionReport from "../productioncontrol/DetailedProductionReport";


const ProductionControl = () => {
  const [activeTab, setActiveTab] = useState("Overview");

  // const downloadReport = () => {
  //   switch (activeTab) {
  //     case "Overview": {
  //       //generatePDF()
  //       return;
  //     }
  //     case "Hourly Production Report": {
  //       generatePDF(
  //         columns_HourlyCount,
  //         hourlyProductionData,
  //         "Hourly Production Report"
  //       );
  //       generateExcel(
  //         columns_HourlyCount,
  //         hourlyProductionData,
  //         "Hourly Production Report"
  //       );
  //       return;
  //     }
  //     case "Detail Production Report": {
  //       generatePDF(
  //         columns_ProductionReport,
  //         productionReportData,
  //         "Detailed Production Report"
  //       );
  //       generateExcel(
  //         columns_ProductionReport,
  //         productionReportData,
  //         "Detailed Production Report"
  //       );
  //       return;
  //     }
  //     case "Cycle Time": {
  //       generatePDF(cycleTimeDataColumns, cycleData, "Cycle Time Report");
  //       generateExcel(cycleTimeDataColumns, cycleData, "Cycle Time Report");
  //       return;
  //     }
  //     default:
  //       return;
  //   }
  // };

  return (
    <div>
      <div className="border-b flex space-x-6">
        {/* Overview */}
        <div
          onClick={() => setActiveTab("Overview")}
          className={`cursor-pointer py-2 pe-4 ${
            activeTab === "Overview"
              ? "border-b-2 border-purple-500 text-purple-500 font-semibold bg-white  rounded-sm ps-4 "
              : "text-gray-500 hover:text-gray-700"
          }`}
        >
          Production Overview
        </div>

        {/* Report */}
        <div
          onClick={() => setActiveTab("Report")}
          className={`cursor-pointer py-2 px-4 ${
            activeTab === "Report"
              ? "border-b-2 border-purple-500 text-purple-500 font-semibold bg-white  rounded-sm"
              : "text-gray-500 hover:text-gray-700"
          }`}
        >
          Report
        </div>

        {/* Hourly Production Report */}
        <div
          onClick={() => setActiveTab("Hourly Production Report")}
          className={`cursor-pointer py-2 px-4 ${
            activeTab === "Hourly Production Report"
              ? "border-b-2 border-purple-500 text-purple-500 font-semibold bg-white  rounded-sm"
              : "text-gray-500 hover:text-gray-700"
          }`}
        >
          Hourly Production Report
        </div>

        {/* Dedicated Production Report */}
        <div
          onClick={() => setActiveTab("Detail Production Report")}
          className={`cursor-pointer py-2 px-4 ${
            activeTab === "Detail Production Report"
              ? "border-b-2 border-purple-500 text-purple-500 font-semibold bg-white  rounded-sm"
              : "text-gray-500 hover:text-gray-700"
          }`}
        >
          Detailed Production Report
        </div>
        <div
          onClick={() => setActiveTab("Cycle Time")}
          className={`cursor-pointer py-2 px-4 ${
            activeTab === "Cycle Time"
              ? "border-b-2 border-purple-500 text-purple-500 font-semibold bg-white  rounded-sm"
              : "text-gray-500 hover:text-gray-700"
          }`}
        >
          Cycle Time
        </div>
      </div>
      <div className="mt-2">
        
        {activeTab === "Overview" && <ProductionOverview />}

        {/* Report */}
        {activeTab === "Report" && <ProductionReport />}

        {/* Hourly Production Report */}
        {activeTab === "Hourly Production Report" && <HourlyProductionReport />}

        {activeTab === "Detail Production Report" && (
          <DetailedProductionReport />
        )}

        {activeTab === "Cycle Time" && <CycleTime />}
      </div>
    </div>
  );
};
export default ProductionControl;
