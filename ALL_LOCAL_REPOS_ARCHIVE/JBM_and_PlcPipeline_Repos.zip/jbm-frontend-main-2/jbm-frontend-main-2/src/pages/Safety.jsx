import DataTable from "../common/components/DataTable";
import withTable from "../hoc/withTable";
import DateRangeSelector from "../common/components/DateRangeSelector ";
import useAxios from "../hooks/useAxios";
import { Loader } from "../common/components/Loader";
import { generatePDF } from "../utils/PdfLib";
import {generateExcel} from "../utils/ExcelUtils";
import Dropdown from "../common/components/Dropdown";
import { useState } from "react";
import BarGraph from "../common/testexperiments/BarGraph";
import BarGraphSafetyAlarm from "../common/testexperiments/BarGraphSafetyAlarm";
import lineLayoutSvg from "../assets/LineLayout3.svg";
import robotImage from "../assets/robotic-arm (1).png"
import WarningIcon from "../assets/warning.png"
import { motion } from "framer-motion";
import SVGAlert from "../common/components/SVGAlert";
import StationLayout from "../common/components/StationLayout";
import RF10Layout from "../common/components/RF10Layout";
import HemmingLayout from "../common/components/HemmingLayout";
import Pro2000Layout from "../common/components/Pro2000Layout";

const Safety = () => {
  const [activeTab, setActiveTab] = useState("Line Layout");
  

  const { data, loading } = useAxios(
    "/safetyalarms",
    { method: "GET" },
    true,
  );
  //console.log("data",data)
  const [filter, setFilter] = useState({ key: '', value: [] });

  const columns = [
    { label: "Date", accessor: "Date" },
    { label: "Time", accessor: "Time" },
    { label: "Alarm Reason", accessor: "AlarmReason" },
    { label: "Downtime (mins)", accessor: "DownTime" },
  ];
 
  const downloadPDF = () => {
    generatePDF(columns, data, "Alarm Log");
    generateExcel(columns, data, "Alarm Log")
  }

  const EnhancedTable = withTable(DataTable);

  const onFilter = (value) => {
    //console.log("filter", filter);
   // console.log("value", value)
    const filtered = data?.filter(item => item.Type === value)
    //console.log("data , filtered", data, filtered)
    setFilter({ ...filter, key: value, value: filtered });

  }

  return (
    <>
      {/* <div className="border-b flex space-x-6">
        <div
          onClick={() => setActiveTab("Top 10 Alarms")}
          className={`cursor-pointer py-2  ${
            activeTab === "Top 10 Alarms"
              ? "border-b-2 border-purple-500 text-purple-500 font-semibold bg-white  rounded-sm px-4"
              : "text-gray-500 hover:text-gray-700 "
          }`}
        >
          Top 10 Alarms
        </div>

        <div
          onClick={() => setActiveTab("Line Layout")}
          className={`cursor-pointer py-2 px-4 ${
            activeTab === "Line Layout"
              ? "border-b-2 border-purple-500 text-purple-500 font-semibold bg-white  rounded-sm"
              : "text-gray-500 hover:text-gray-700"
          }`}
        >
          Line Layout
        </div>
      </div> */}
      {loading && <Loader />}
      {activeTab === "Top 10 Alarms" && (
        <div className="pt-4">
          <DateRangeSelector onDownload={downloadPDF} />
          <BarGraphSafetyAlarm />
        </div>
      )}

      {activeTab === "Line Layout" && (
       <>
         <div className="relative p-2 m-2 bg-[#f5f5f5] h-[570px] overflow-auto flex justify-center items-center border-2 border-dashed border-gray-500">
            <StationLayout />


          </div>
         {/* <div className="relative p-2 m-2 bg-[#f5f5f5] h-[570px] overflow-auto flex justify-center items-center border-2 border-dashed border-gray-500">
      
         <Pro2000Layout/>  */}
         {/* <HemmingLayout/>
         <RF10Layout/> */}
       {/* </div> */}
       </>
      )}
    </>
  );
};

export default Safety;
