import React , { useEffect,useState } from "react";
import Dropdown from "../common/components/Dropdown";

import { SVG } from "@svgdotjs/svg.js";
import { motion } from "framer-motion";
import HemmingLayout from "../common/testexperiments/HemmingLayout";

const initialNodes = [
  { id: "1", position: { x: 100, y: 100 }, data: { label: "PLC" }, type: "input" },
  { id: "2", position: { x: 300, y: 100 }, data: { label: "Robot Arm" } },
  { id: "3", position: { x: 500, y: 100 }, data: { label: "Conveyor" }, type: "output" },
];

const initialEdges = [
  { id: "e1-2", source: "1", target: "2" },
  { id: "e2-3", source: "2", target: "3" },
];


const IndustrialAutomationSVG = () => {
  return (
    <svg width="800" height="400" viewBox="0 0 800 400">
    {/* Conveyor Belt */}
    <motion.rect 
      x="50" y="150" width="700" height="20" fill="gray"
      animate={{ x: [0, 10, 0] }}
      transition={{ duration: 0.5, repeat: Infinity, repeatType: "reverse" }}
    />
    
    {/* Robot Arm (Rotating) */}
    <motion.g 
      initial={{ rotate: 0 }} 
      animate={{ rotate: [0, 20, 0] }} 
      transition={{ duration: 1, repeat: Infinity, repeatType: "reverse" }}
    >
      <circle cx="200" cy="100" r="30" fill="orange" />
      <rect x="180" y="130" width="40" height="50" fill="black" />
      
    </motion.g>

    {/* PLC Controller */}
    <rect x="600" y="50" width="80" height="50" fill="blue" />
    <text x="610" y="80" fill="white">PLC</text>

    {/* Blinking Sensor */}
    <motion.circle 
      cx="500" cy="160" r="10" fill="red"
      animate={{ opacity: [1, 0, 1] }}
      transition={{ duration: 1, repeat: Infinity }}
    />
    <text x="485" y="190" fill="black">Sensor</text>
  </svg>
  );
};

const LineStatusold = () => {
  const [selected, setSelected] = useState("");

  const handleChange = (value) => {
    setSelected(value);
  };
  const options = [
    { value: "option1", label: "option1" },
    { value: "option2", label: "option2" },
    { value: "option3", label: "option3" },
  ];

  return (
    <div>
        <HemmingLayout/>
    </div>
    
  );
};
export default LineStatusold;