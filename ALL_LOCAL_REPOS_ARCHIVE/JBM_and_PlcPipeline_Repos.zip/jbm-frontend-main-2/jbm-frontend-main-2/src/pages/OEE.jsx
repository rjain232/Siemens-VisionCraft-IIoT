import OverallOEE from "../oee/OverallOEE";
import StationWiseOEE from "../oee/StationWiseOEE";
import TabWrapper from "../common/components/TabWrapper";


const OEE = () => {
  return (
    <>
     <TabWrapper
      defaultTab="Overall OEE"
      tabs={[
        { label: "Overall OEE", key: "Overall OEE", component: <OverallOEE /> },
        // { label: "Top 10 Faults", key: "Top 10 Faults", component: <Top10Faults /> },
        // { label: "Station-wise OEE", key: "Station-wise OEE", component: <StationWiseOEE /> },
      ]}
    />
    </>
  );
};

export default OEE;


