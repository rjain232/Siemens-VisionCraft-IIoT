import {  useState } from "react";
import withTable from "../hoc/withTable";
import DataTable from "../common/components/DataTable";
import DateRangeSelector from "../common/components/DateRangeSelector ";
import { generatePDF,generate_TablePDF } from "../utils/PdfLib";
import {generateExcel} from "../utils/ExcelUtils";
import useAxios from "../hooks/useAxios";
import { format } from "date-fns";
import { Loader } from "../common/components/Loader";

const MACHINE_SETUP_DATA_COLUMNS = [
  { label: "Date", accessor: "Timestamp" },
  { label: "Shift", accessor: "Shift" },
  { label: "Line Name", accessor: "LineName" },
  { label: "Setup Begin", accessor: "SetupBegin" },
  { label: "Setup Complete", accessor: "SetupComplete" },
  { label: "Duration", accessor: "Duration" },
];

const EnhancedTable = withTable(DataTable);

const MachinSetup = () => {
  const [params, setParams] = useState({ parameter: null });
  const {
    data: machineSetupData,
    loading: isMachineSetupDataLoading,
    error: isMachineSetupDataError,
    refetch: refetchMachineSetupData,
  } = useAxios("/setupData", { method: "GET", params }, true);

  //console.log("Machine Setup Data", machineSetupData);

  const handleSearch = (startDate, endDate, duration, shift, dedicatedDuration) => {
    setParams({
      startDate: format(startDate, "yyyy-MM-dd HH:mm:ss"),
      endDate: endDate && format(endDate, "yyyy-MM-dd HH:mm:ss"),
      duration,
      shift,
      dedicatedDuration,
    });
    refetchMachineSetupData({
      params: {
        startDate: format(startDate, "yyyy-MM-dd HH:mm:ss"),
        endDate: endDate && format(endDate, "yyyy-MM-dd HH:mm:ss"),
        duration,
        shift,
        dedicatedDuration,
      },
    });
  };
 
 
 const [downloading, setDownloading] = useState(false);
  // const downloadReport = async() =>{
  //    setDownloading(true);
  //    generateExcel(MACHINE_SETUP_DATA_COLUMNS, machineSetupData, "Machine Setup Report")
     
  //    exportPdfMachineSetupReport().than(()=>{
  //     setDownloading(false);
  //    });
     
  // }
  const downloadReport = async () => {
    setDownloading(true);
    generateExcel(MACHINE_SETUP_DATA_COLUMNS, machineSetupData, "Machine Setup Report");
  
    generate_TablePDF(MACHINE_SETUP_DATA_COLUMNS, machineSetupData, "Machine Setup Report",params);
    setDownloading(false);
  };
  
  if (isMachineSetupDataError) {
    //console.error("Error fetching machine setup data:", isMachineSetupDataError);
    return <div className="text-red-600">Error fetching machine setup data</div>;
  }

  return (
    <div>
      <DateRangeSelector 
      showDownload={true} 
      onDownload={downloadReport}  
      onSearch={handleSearch}
      selectedStartDate={params?.startDate}
      selectedEndDate={params?.endDate}
      isDownloading={downloading}
      />
     {isMachineSetupDataLoading ? <Loader/>: <EnhancedTable
        data={machineSetupData}
        columns={MACHINE_SETUP_DATA_COLUMNS}
        enableSearch={true}
        enableFilter={true}
        enablePagination={true}
      />}
    </div>
  );
};
export default MachinSetup;
