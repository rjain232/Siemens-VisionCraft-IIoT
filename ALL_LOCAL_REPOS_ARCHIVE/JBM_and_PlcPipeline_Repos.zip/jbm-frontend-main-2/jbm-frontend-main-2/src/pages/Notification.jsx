import { useNavigate } from 'react-router-dom';
import { BiArrowBack } from 'react-icons/bi';
import useAxios from "../hooks/useAxios";
const notifications = [
    { id: 1, message: "Machine A encountered an error", time: "10 mins ago" },
    { id: 2, message: "Routine maintenance required for Machine B", time: "1 hour ago" },
    { id: 3, message: "Production line C resumed operation", time: "3 hours ago" },
    { id: 4, message: "New software update available", time: "Yesterday" }
];

const Notification = () => {
    const navigate = useNavigate();
    const {
        data: pending_activityData,
        loading: isActivityDataLoading,
        error: isActivityDataError,
        refetch: refetchActivities,
    } = useAxios(
        "/notification",
        { method: "GET" },
        true
    );
    //console.log("pending_activityData", pending_activityData);

    const handlePendingToolSelected = (tool) => {
       // console.log("handlePendingToolSelected", tool);
      
        navigate("/maintenance", {
          state: {
            activeTab: "TDM Tools",
            toolSelected: {
              value: tool.ToolId,
              text: tool.ToolName,
            },
          },
        });
      };
      
    
    return (
        <></>
        // <div className="p-6 bg-gray-100 min-h-screen">
        //     <div className="flex items-center mb-6">
        //         <BiArrowBack
        //             className="text-2xl cursor-pointer hover:scale-110 transition-transform duration-300"
        //             onClick={() => navigate(-1)}
        //         />
        //         <h2 className="text-xl font-semibold ml-4">Back</h2>
        //     </div>
        //     <div className="bg-white p-4 rounded-lg shadow-md">
        //         {isActivityDataLoading ? (
        //             <p className="text-center text-gray-500">Loading...</p>
        //         ) : Array.isArray(pending_activityData.notification) && pending_activityData.notification.length > 0 ? (
        //             <ul className="divide-y divide-gray-300">
        //                 {pending_activityData.notification.map((notification) => (
        //                     <li
        //                         key={notification.ToolId}
        //                         className="py-4 cursor-pointer hover:bg-gray-100 px-4 rounded"
        //                         onClick={() => handlePendingToolSelected(notification)}
        //                     >
        //                         <p className="text-lg font-medium">{notification.Message}</p>
        //                         <p className="text-sm text-gray-500">{new Date(notification.Upto_Schedule).toLocaleString()}</p>
        //                     </li>
        //                 ))}
        //             </ul>
        //         ) : (
        //             <p className="text-center text-gray-500">No notifications available</p>
        //         )}

        //     </div>
        // </div>
    );
};

export default Notification;
