import { useState, useEffect } from "react";
import { TargetIcon, Gauge, Boxes, ChartColumnIncreasing } from "lucide-react";
import ShiftEfficiencyPareto from "../common/testexperiments/ShiftEfficiencyPareto";
import ChartCard from "../common/testexperiments/ChartCard";
import OverallOEEPareto from "../common/testexperiments/OverallOEEPareto";
import Dropdown from "../common/components/Dropdown";
import PieChart from "../common/graphs/PieChart";
import { useNavigate } from "react-router-dom";
import useAxios from "../hooks/useAxios";
import { format, startOfDay, startOfWeek, endOfWeek, startOfMonth, endOfMonth, startOfQuarter, endOfQuarter, startOfYear, endOfYear, subDays, subMonths, subQuarters } from "date-fns";
import { enIN } from "date-fns/locale";

const Dashboard2 = () => {
  const navigate = useNavigate();
  const [selectedValue, setSelectedValue] = useState("1"); // Default to "Current Day"
  const [duration, setDuration] = useState("");
  const {
    data: dashboardData,
    loading,
    error,
  } = useAxios("/dashboard", { method: "GET", params: { durationFlag: selectedValue } }, true);

  const handleRedirect = () => {
    navigate("/maintenance", { state: { activeTab: "Downtime Report" } });
  };
 // console.log("dashboardData--", dashboardData);

  // Function to calculate the duration based on selected value
  const calculateDuration = (selectedValue) => {
    const today = new Date();
    const formatDate = (date) => format(date, "dd-MM-yyyy", { locale: enIN });

    const ranges = {
      1: { start: startOfDay(today) },
      2: { start: startOfDay(subDays(today, 1)) },
      3: { start: startOfWeek(today, { locale: enIN }), end: endOfWeek(today, { locale: enIN }) },
      4: { start: startOfWeek(subDays(today, 7), { locale: enIN }), end: endOfWeek(subDays(today, 7), { locale: enIN }) },
      5: { start: startOfMonth(today), end: endOfMonth(today) },
      6: { start: startOfMonth(subMonths(today, 1)), end: endOfMonth(subMonths(today, 1)) },
      7: { start: startOfQuarter(today), end: endOfQuarter(today) },
      8: { start: startOfQuarter(subQuarters(today, 1)), end: endOfQuarter(subQuarters(today, 1)) },
      9: { start: startOfYear(today), end: endOfYear(today) },
    };

    const { start, end } = ranges[selectedValue] || {};
    return start && end
      ? `${formatDate(start)} To ${formatDate(end)}`
      : start
        ? formatDate(start)
        : "";
  };

  useEffect(() => {
    setDuration(calculateDuration(Number(selectedValue)));
    //console.log("Dropdown value", selectedValue);
  }, [selectedValue]);

  if (error) {
    return <div>Error: {error.message}</div>;
  }

  return (
    !loading && (
      <div className="bg-gray-100 p-4">
        {/* Top Section - Dropdown & Date */}
        <div className="flex flex-col sm:flex-row justify-between items-center mb-4 mt-2">
          <Dropdown
            options={[
              { value: 1, label: "Current Day" },
              { value: 2, label: "Yesterday" },
              { value: 3, label: "Current Week" },
              { value: 4, label: "Last Week" },
              { value: 5, label: "Current Month" },
            ]}
            selectedValue={selectedValue}
            placeholder={"Select Duration"}
            onChange={setSelectedValue}
          />
          <h1 className="text-lg font-semibold text-slate-500 self-center">
            {duration}
          </h1>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
          <StatCard
            title="Daily Target"
            value={dashboardData?.productionData?.target ?? "--"}
            icon={TargetIcon}
          />
          <StatCard
            title="Actual Production"
            value={dashboardData?.productionData?.actual ?? "--"}
            icon={Boxes}
          />
          <StatCard
            title="LHD | RHD Split"
            value={`${dashboardData?.productionData?.LHD ?? "--"} | ${dashboardData?.productionData?.RHD ?? "--"}`}
            icon={Gauge}
          />
          <StatCard
            title="Monthly Target"
            value={
              dashboardData?.MonthlyData
                ? `${dashboardData.MonthlyData.MonthlyActual ?? "--"} / ${dashboardData.MonthlyData.MonthlyTarget ?? "--"}`
                : "--"
            }
            icon={ChartColumnIncreasing}
          />

        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="mb-6" onClick={handleRedirect}>
            <ChartCard title="Total Available Vs Total Downtime" shadow={true}>
              <PieChart
                chartSeries={Array.isArray(dashboardData?.chartSeries) ? dashboardData.chartSeries : [0, 0]}
                labels={["Total Available Time", "Total Downtime"]}
                colors={["#00893D", "#A12E2D"]}
                height={300}
                chartType="Downtime"
              />
            </ChartCard>
          </div>

          <div className="mb-6 ">
            <ChartCard title={"Overall Equipment Efficiency"} shadow={true}>
              <ShiftEfficiencyPareto
                labels={
                  Array.isArray(dashboardData?.shiftOEEData)
                    ? dashboardData.shiftOEEData.map((item) => item.Shift)
                    : ["Shift A", "Shift B", "Shift C", "Overall"]
                }
                series={
                  Array.isArray(dashboardData?.shiftOEEData)
                    ? dashboardData.shiftOEEData.map((item) => parseFloat(item.OEE.toFixed(2)))
                    : [0,0,0,0]
                }
                height={270}
              />
            </ChartCard>
          </div>
          <div className="col-span-2">
            <div className="grid grid-cols-2 md:grid-cols-3 gap-x-6 gap-y-[42px]">
              <div className="col-span-3 border-b-6 border-slate-200 rounded-xl">
                {" "}
                <ChartCard shadow={true}>
                  {" "}
                  <h2 className="text-lg py-2 font-semibold text-center text-gray-700">
                    OEE Parameters
                  </h2>
                </ChartCard>
              </div>
              <ChartCard shadow={true}>
                <OverallOEEPareto
                  label="Availability"
                  value={dashboardData?.OEEParameter?.Availability ?? 0}
                  height={350}
                />
              </ChartCard>
              <ChartCard shadow={true}>
                <OverallOEEPareto
                  label="Performance"
                  value={dashboardData?.OEEParameter?.Performance ?? 0}
                  height={350}
                />
              </ChartCard>
              <ChartCard shadow={true}>
                <OverallOEEPareto
                  label="Quality"
                  value={dashboardData?.OEEParameter?.Quality ?? 0}
                  height={350}
                />
              </ChartCard>
            </div>
          </div>
        </div>
      </div>
    )
  );
};

// Reusable Stat Card
const StatCard = ({ title, value, icon: Icon }) => (
  <div className="bg-white py-2 px-6 border-t-4 border-slate-400 rounded-xl shadow-md flex items-center space-x-4 hover:shadow-lg transition-shadow duration-300">
    <div className="bg-purple-100 p-3 rounded-full">
      <Icon className="text-purple-950 w-8 h-8" />
    </div>
    <div className="w-full">
      <h2 className="text-md font-semibold text-gray-700 mb-1">{title}</h2>
      <p className="text-xl font-bold text-gray-500">{value}</p>
    </div>
  </div>
);

export default Dashboard2;
