import { Boxes, Zap } from "lucide-react";
import Chart from "react-apexcharts";
import ChartCard from "../common/testexperiments/ChartCard";
import DateRangeSelector from "../common/components/DateRangeSelector ";
import useAxios from "../hooks/useAxios";
import { format } from "date-fns";
import jsPDF from "jspdf";
import * as XLSX from "xlsx";
import autoTable from "jspdf-autotable";
import {
  addGlobalStylesForPDF,
  addPageNumber,
  cleanupChartStyles,
  pageFooterFormat,
  pageHeadFormat,
  renderChartToPDF,
  reportFromToShiftHeaders,
} from "../utils/PdfLib";
import { useRef } from "react";
import { useCallback, useState } from "react";


const PowerConsumption = () => {
  const { data, loading, error, refetch } = useAxios(
    "/powerConsumptionDetails",
    { method: "GET" },
    true
  );
 const { powerConsumptionData, daywisePowerConsumptionData, shiftWiseCount } = data ?? {};
//console.log("Power Consumption Data:", powerConsumptionData);
 const [dateFilter, setDateFilter] = useState({
  startDate: null,
  endDate: null,
  // duration: null,
  // shift: null,
});

//#region PDF and Excel
 const exportToPDF = (doc) => {
   //const doc = new jsPDF();

    doc.setFontSize(16);
    //doc.text("Power Consumption Report", 14, 15);

    // Overall Summary Table
    autoTable(doc, {
      startY: 30,
      head: [["Title", "Value"]],
      body: powerConsumptionData.map(item => [item.title, item.value]),
      theme: "grid",
       styles:{
        valign:"middle",
        halign:"center"
      },
       willDrawPage: function () {
            pageHeadFormat(doc, "Power Consumption Report" , false);
          },
    });

      // Shift-wise Table
    autoTable(doc, {
      startY: doc.lastAutoTable.finalY + 10,
      head: [["Shift", "Power Consumption (kWh)", "Cabins Produced", "Avg Power/Cabin (kWh)"]],
      body: shiftWiseCount.map(item => [
        item.Shift,
        item.PowerConsumption,
        item.CabinProduced,
        item.AvgPowerPerCabin,
      ]),
      styles:{
        valign:"middle",
        halign:"center"
      },
      theme: "grid",
    });


    // Daywise Table
    autoTable(doc, {
      startY: doc.lastAutoTable.finalY + 10,
      head: [["Date", "Power Consumption (kWh)"]],
      body: daywisePowerConsumptionData.map(item => [item.date, item.powerConsumption]),
      theme: "grid",
       styles:{
        valign:"middle",
        halign:"center"
      },
       didDrawPage: function (data) {
            pageFooterFormat(doc, data);
          },
         
    });

    addPageNumber(doc)
   // doc.save("power_consumption_report.pdf");
  };

  const exportToExcel = () => {
    const wb = XLSX.utils.book_new();

    const ws1 = XLSX.utils.json_to_sheet(powerConsumptionData);
    XLSX.utils.book_append_sheet(wb, ws1, "Summary");

    const ws2 = XLSX.utils.json_to_sheet(daywisePowerConsumptionData);
    XLSX.utils.book_append_sheet(wb, ws2, "Daywise");

    const ws3 = XLSX.utils.json_to_sheet(shiftWiseCount);
    XLSX.utils.book_append_sheet(wb, ws3, "ShiftWise");

    XLSX.writeFile(wb, "Power_consumption_report.xlsx");
  };
//#endregion



  const chartOptions = {
    chart: {
      type: "bar",
      toolbar: { show: false },
    },
    plotOptions: {
      bar: {
        horizontal: false,
        columnWidth: "50%",
      },
    },
    dataLabels: {
      enabled: false,
    },
    xaxis: {
      categories: data?.shiftWiseCount?.map((item) => item?.Shift),
    },
    colors: ["#EF4444", "#22C55E", "#EDAD1F"],
  };

  const chartSeries = [
    {
      name: "Power Consumption (kWh)",
      data: data?.shiftWiseCount?.map((item) => item?.PowerConsumption),
    },
    {
      name: "Cabin Production",
      data: data?.shiftWiseCount?.map((item) => item?.CabinProduced),
    },
    {
      name: "Avg Power per Cabin (kWh)",
      data: data?.shiftWiseCount?.map((item) => item?.AvgPowerPerCabin),
    },
  ];

  const areaChartOptions = {
    chart: {
      type: "area",
      toolbar: { show: false },
    },
    dataLabels: {
      enabled: false,
    },
    stroke: {
      curve: "smooth",
      width: 2,
    },
    xaxis: {
      categories: data?.daywisePowerConsumptionData?.map((item) => item?.date),
    },
    colors: ["#FF5733"],
  };

  const areaChartSeries = [
    {
      name: "Power Consumption (kWh)",
      data: data?.daywisePowerConsumptionData?.map(
        (item) => item?.powerConsumption
      ),
    },
  ];

  const icons = [Zap, Boxes, Zap];

  const handleSearch = (startDate, endDate) => {
    setDateFilter({
      startDate,
      endDate,

    });
    refetch({
      params: {
        startDate: startDate
          ? format(new Date(startDate), "yyyy-MM-dd HH:mm:ss")
          : null,
        endDate: endDate
          ? format(new Date(endDate), "yyyy-MM-dd HH:mm:ss")
          : null,
      },
    });
  };
// References for your charts
  const chart1Ref = useRef(null);
  // const chart2Ref = useRef(null);
  // const chart3Ref = useRef(null);
  const [downloading, setDownloading] = useState(false);

  const exportPdfPowerConsumptionReport = async () => {
    const doc = new jsPDF();
    const chartRefs = [chart1Ref];
    reportFromToShiftHeaders(doc, dateFilter);
    addGlobalStylesForPDF();
    chartRefs.forEach((ref) => ref.current?.classList.add("pdf-export"));
    let yOffset = 50;
    await renderChartToPDF(doc, chartRefs, yOffset);
    pageHeadFormat(doc, "Power Consumption Report", false);

    doc.addPage();
    await exportToPDF(doc);
    cleanupChartStyles(chartRefs);
    doc.save("Power_Consumption_Report_With_Charts.pdf");
  };
  const handleDownload = () => {
    try {
      setDownloading(true);
      exportToExcel();

      exportPdfPowerConsumptionReport().then(() => {
        setDownloading(false);
      });
    }
    catch (error) {
      //console.log(error);
    };
  }


  if (error) {
    return <div>Error in fetching data ...</div>;
  }

  return (
    <>
      <DateRangeSelector 
      onDownload={handleDownload}
       onSearch={handleSearch}
       selectedStartDate={dateFilter?.startDate}
        selectedEndDate={dateFilter?.endDate}  
       isDownloading={downloading} />
      {!loading && (
        <>
          <div className="grid grid-cols-3 gap-4 mb-6">
            {data?.powerConsumptionData?.map((stat, index) => (
              <StatCard
                key={index}
                title={stat.title}
                value={stat.value}
                icon={icons[index]}
              />
            ))}
          </div>
          <div ref={chart1Ref} className="flex flex-row gap-6">
            <div className="flex-1">
              <ChartCard title={"Shift-wise Power Consumption Distribution"}>
                <Chart
                  options={chartOptions}
                  series={chartSeries}
                  type="bar"
                  height={290}
                />
              </ChartCard>
            </div>
            <div className="flex-1">
              <ChartCard title={"Day-wise Power Consumption Distribution "}>
                <Chart
                  options={areaChartOptions}
                  series={areaChartSeries}
                  type="area"
                  height={290}
                />
              </ChartCard>
            </div>
          </div>
        </>
      )}
    </>
  );
};

export default PowerConsumption;

const StatCard = ({ title, value, icon: Icon }) => (
  <div className="bg-white py-4 px-6 border-t-4 border-slate-400 rounded-xl flex items-center space-x-4 hover:shadow-lg transition-shadow duration-300">
    <div className="bg-purple-100 p-3 rounded-full">
      <Icon className="text-purple-950 w-8 h-8" />
    </div>
    <div className="w-full">
      <h2 className="text-xl font-semibold text-gray-500 mb-1">{title}</h2>
      <p className="text-xl font-bold text-gray-700">{value}</p>
    </div>
  </div>
);
