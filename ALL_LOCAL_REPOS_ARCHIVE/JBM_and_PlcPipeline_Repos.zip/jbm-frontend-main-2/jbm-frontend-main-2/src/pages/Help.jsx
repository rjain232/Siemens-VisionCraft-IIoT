import React from "react";

const Help = () => {
    return (
        <div className="h-screen flex items-start justify-center bg-gray-100">
            <div
                className="w-full max-w-2xl bg-white shadow-md rounded-md p-6 border-t-4 border-purple-950"
                style={{ marginTop: "100px" }}
            >

                <div className="text-center mb-6 px-4">
                    <strong className="text-[22px] text-purple-950">
                        {/* Contact us via Phone or Email for any queries you may have: */}
                        Contact us via Phone or Email 
                    </strong>
                </div>

                {/* Phone Row */}
                <div className="grid grid-cols-12 items-center mb-4 text-[18px] px-2">
                    <div className="col-span-5 text-purple-950 text-center font-semibold">
                        Phone
                    </div>
                    <div className="col-span-1 text-center font-bold">:</div>
                    <div className="col-span-6 text-center font-semibold">
                        9765000543
                    </div>
                </div>

                {/* Email Row */}
                <div className="grid grid-cols-12 items-center mb-4 text-[18px] px-2">
                    <div className="col-span-5 text-purple-950 text-center font-semibold">
                        Email
                    </div>
                    <div className="col-span-1 text-center font-bold">:</div>
                    <div className="col-span-6 text-center font-semibold">
                        gandhar@dacpl.in
                    </div>
                </div>
                {/* Address Row */}
                <div className="grid grid-cols-12 items-center mb-4 text-[18px] px-2">
                    <div className="col-span-5 text-purple-950 text-center font-semibold">
                        Address
                    </div>
                    <div className="col-span-1 text-center font-bold">:</div>
                    <div className="col-span-6 text-center font-semibold">

                        1111-1114, Nandan ProBiz, Baner, Pune, Maharashtra 411045 IN
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Help;
