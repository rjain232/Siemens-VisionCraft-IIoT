import React from "react";
import ReactSpeedometer from "react-d3-speedometer";
import { FaBullseye, FaCheckCircle, FaTrophy } from "react-icons/fa";
import Chart from "react-apexcharts";
import ShiftFaultGraph from "../common/testexperiments/ShiftFaultGraph";
import OEECards from "../common/testexperiments/OEECards";

const getIcon = (type) => {
  switch (type) {
    case "target":
      return <FaBullseye className="text-purple-950" size={24} />;
    case "actual":
      return <FaCheckCircle className="text-purple-950" size={24} />;
    case "achieved":
      return <FaTrophy className="text-purple-950" size={24} />;
    default:
      return null;
  }
};
const Dashboard = () => {
  const productionData = {
    target: 10000,
    actual: 8500,
    achieved: 85, // in percentage
  };
  return (
    <div className="grid grid-cols-4 gap-4">
        <div className="bg-white row-span-3 col-span-2 rounded-lg shadow-sm">
        <h2 className="font-bold text-xl p-4 mx-4 border-b-2 ">OEE</h2>
        <div className="grid grid-cols-2 gap-4 pb-10">
        <OEECards title="Shift A OEE" oee={85} />
        <OEECards title="Shift B OEE" oee={78} />
        <OEECards title="Shift C OEE" oee={90} />
        <OEECards title="Shift A OEE" oee={75} />
        
          {/* <Meter   value={40} color={"#66f2a5"}/>
          <Meter  value={60} color={"#07db66"}/>
          <Meter  value={80} color={"#00893D"} /> */}
        </div>
      </div>
      <div className="col-span-2 bg-white rounded-lg shadow-sm">
        <h2 className="font-bold text-xl p-4 mx-4 border-b-2 ">
          Production Overview
        </h2>
        <div className="grid grid-cols-3 gap-x-4">
          <div>
            <StatCard
              title="Target"
              value={productionData.target}
              type={"target"}
            />
          </div>
          <div>
      <StatCard
              title="Actual"
              value={productionData.actual}
              type={"actual"}
            />
          </div>
          <div>
          <StatCard
              title="Achieved"
              value={productionData.achieved}
              type={"achieved"}
            />
          </div>
        </div>
      </div>
      <div className="col-span-2 row-span-2 bg-white rounded-lg shadow-sm">
      <h2 className="font-bold text-xl p-4 mx-4 border-b-2 ">Top 10 Faults</h2>
      <ShiftFaultGraph/>
      </div>
    </div>
  );
};

export default Dashboard;

const StatCard = ({ title, value, type }) => (
  <div className=" p-4 flex items-start space-x-4">
    <div className="flex-shrink-0 mt-1">{getIcon(type)}</div>
    <div className="text-left">
      <h2 className="text-lg font-semibold">{title}</h2>
      <p className="text-2xl font-bold text-slate-600">{value}</p>
    </div>
  </div>
);

const OEECard = ({value , color}) => {
  const chartOptions = {
    chart: {
      type: "radialBar",
    },
    plotOptions: {
      radialBar: {
        startAngle: -90, // Controls the start position
        endAngle: 90, // Controls the end position
        track: {
          background: "#e7e7e7", // Background color of the track
          strokeWidth: "90%", // Thickness of the track
        },
        dataLabels: {
          name: {
            show: false, // Hide the name label
          },
          value: {
            fontSize: "14px", // Customize the value size
            color: "#333", // Customize the value color
            formatter: function (val) {
              return val + "%"; // Append % to value
            },
          },
        },
      },
    },
    fill: {
      colors: [color], // Customize the gauge color
    },
    stroke: {
      lineCap: "round", // Makes the ends rounded
    },
    labels: ["Performance"],
  };

  return (
      <Chart
        options={chartOptions}
        series={[value]}
        type="radialBar"
        height={300}
      />
  );
};

const Meter = ({value , color}) =>{
  return <div style={{
    width: "300px",
    height: "200px",
   
  }}>
    <ReactSpeedometer
       fluidWidth={true}
       minValue={0}
       maxValue={100}
       value={value}
       needleColor="steelblue"
       needleTransition="easeElastic"
       needleHeightRatio={0.7} // Adjust needle size
       ringWidth={40} // Increase ring width for thicker appearance
       segmentColors={["#ff4d4d", "#ff944d", "#ffd700", "#2ecc71"]} // Gradient-like effect
       textColor="#FFF"
    />
    
  </div>
}
