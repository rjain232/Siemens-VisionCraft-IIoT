import { useEffect, useState } from "react";
import ATCInterruption from "../maintenance/ATCInterruption"
import MiscellaneousAlarms from "../maintenance/MiscellaneousAlarms";
import { useLocation } from "react-router-dom";
import TDMTools from "../maintenance/TDMTools";
import DowntimeReport from "../maintenance/DowntimeReport";
import AlarmReport from "../maintenance/AlarmReport";
import Top10Alarms from "../maintenance/Top10Alarms";
import TipChange from "../maintenance/TipChange";
import Compliance from "../maintenance/Compliance";

const PredictiveAnalysis = () => {
  const [activeTab, setActiveTab] = useState("Downtime Report");
  const [tool, setTool] = useState({ value: "", text: "" });
   
  const location = useLocation();

  useEffect(() => {
    if (location.state?.activeTab) {
      setActiveTab(location.state.activeTab);
    }
    if (location.state?.toolSelected) {
      //console.log("location.state?.toolSelected",location.state?.toolSelected);
      setTool({
        value: location.state.toolSelected.value,
        text: location.state.toolSelected.text,
      });
    }
  }, [location.state]);

  const handleToolChanged = (tool) =>{
     setTool({
      value : tool.value,
      text:tool.text
    })
  }

  const handleActiveTabChange = (tab) =>{
     setActiveTab(tab)
  }

  return (
    <>
      <div className="border-b flex space-x-6 ">
        {/* <div
          onClick={() => setActiveTab("Compliance")}
          className={`cursor-pointer py-2 px-2 ${
            activeTab === "Compliance"
              ? "border-b-2 border-purple-500 text-purple-500 font-semibold bg-white rounded-sm ps-4"
              : "text-gray-500 hover:text-gray-700"
          }`}
        >
          Compliance
        </div>
        <div
          onClick={() => {setTool({ value: "", text: "" }) ;setActiveTab("TDM Tools")}}
          className={`cursor-pointer py-2 px-2 ${
            activeTab === "TDM Tools"
              ? "border-b-2 border-purple-500 text-purple-500 font-semibold bg-white  rounded-sm px-4"
              : "text-gray-500 hover:text-gray-700 "
          }`}
        >
          TDM Tools
        </div> */}
        <div
          onClick={() => setActiveTab("Downtime Report")}
          className={`cursor-pointer py-2 px-2 ${
            activeTab === "Downtime Report"
              ? "border-b-2 border-purple-500 text-purple-500 font-semibold bg-white  rounded-sm"
              : "text-gray-500 hover:text-gray-700"
          }`}
        >
          Downtime Report
        </div>
        <div
          onClick={() => setActiveTab("Alarm Report")}
          className={`cursor-pointer py-2 px-2 ${activeTab === "Alarm Report"
              ? "border-b-2 border-purple-500 text-purple-500 font-semibold bg-white  rounded-sm"
              : "text-gray-500 hover:text-gray-700"
            }`}
        >
          Alarm Report
        </div>
        <div
          onClick={() => setActiveTab("Top 10 Alarms")}
          className={`cursor-pointer py-2 px-2 ${
            activeTab === "Top 10 Alarms"
              ? "border-b-2 border-purple-500 text-purple-500 font-semibold bg-white  rounded-sm px-4"
              : "text-gray-500 hover:text-gray-700 "
          }`}
        >
          Top 10 Alarms
        </div>
        <div
          onClick={() => setActiveTab("ATC Interruption")}
          className={`cursor-pointer py-2 px-2 ${
            activeTab === "ATC Interruption"
              ? "border-b-2 border-purple-500 text-purple-500 font-semibold bg-white  rounded-sm px-4"
              : "text-gray-500 hover:text-gray-700 "
          }`}
        >
          ATC Interruption
        </div>
        <div
          onClick={() => setActiveTab("Miscellaneous Alarms")}
          className={`cursor-pointer py-2 px-2 ${activeTab === "Miscellaneous Alarms"
              ? "border-b-2 border-purple-500 text-purple-500 font-semibold bg-white  rounded-sm"
              : "text-gray-500 hover:text-gray-700"
            }`}
        >
          Miscellaneous Alarm
        </div>
        <div
          onClick={() => setActiveTab("Tipchangecount")}
          className={`cursor-pointer py-2 px-2 ${activeTab === "Tipchangecount"
              ? "border-b-2 border-purple-500 text-purple-500 font-semibold bg-white  rounded-sm"
              : "text-gray-500 hover:text-gray-700"
            }`}
        >
          Tip Change Count
        </div>
      </div>

      <div className="pt-2">
        {/* {activeTab === "Compliance" && (
        <Compliance changeTool={handleToolChanged} changeTab={handleActiveTabChange} selectedTool={tool}/>
        )}
        {activeTab === "TDM Tools" && (
        <TDMTools toolSelected={tool} changeTool={handleToolChanged}/>
        )} */}
        {activeTab === "Downtime Report" && (
         <DowntimeReport/>
        )}
        {activeTab === "Alarm Report" &&
          <AlarmReport />
        }

        {activeTab === "Top 10 Alarms" && (
        <Top10Alarms/>
        )}

        {activeTab === "ATC Interruption" && (
          <ATCInterruption/>
        )}
        {activeTab === "Miscellaneous Alarms" && (
          <MiscellaneousAlarms/>
        )}
        {activeTab === "Tipchangecount" && (
           <TipChange/>
        )}
      </div>
      
    </>
  );
};
export default PredictiveAnalysis;