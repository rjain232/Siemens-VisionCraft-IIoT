// export function validateDateRange(startDate, endDate,duration) {
//   console.log(startDate,endDate,duration);
//   console.log((!startDate || !endDate) && duration!=undefined);
//   if ((!startDate || !endDate) && duration!=undefined) {
//     return {
//       error: true,
//       errorMsg: "Start date and end date are required for search",
//     };
//   }

//   if (startDate && endDate){
//      if (startDate.getTime() > endDate.getTime()) {
//     return { error: true, errorMsg: "Start date cannot be after end date" };
//   }

//   if (startDate.getTime() === endDate.getTime()) {
//     return {
//       error: true,
//       errorMsg: "Start date and end date cannot be the same",
//     };
//   }
// }

//   const now = new Date();
//   if (startDate > now) {
//     return { error: true, errorMsg: "Start date cannot be a future date." };
//   }

//   return { error: false, errorMsg: "" };
// }


export function validateDateRange(startDate, endDate, duration) {
  // Normalize inputs
  const sd = startDate ? new Date(startDate) : null;
  const ed = endDate ? new Date(endDate) : null;
  const hasDuration = duration !== null || duration !== undefined || duration !== "";

  // --- 1️⃣ Check valid input combinations ---
  // Case 1: Only duration provided
  console.log("duration" , duration)
  if (!sd && !ed && hasDuration) {
   
    return { error: false, errorMsg: "" };
  }

  // Case 2: Start & End provided (valid if duration not provided)
  if (sd && ed && !hasDuration) {
         if (startDate.getTime() > endDate.getTime()) {
    return { error: true, errorMsg: "Start date cannot be after end date" };
  }

  if (startDate.getTime() === endDate.getTime()) {
    return {
      error: true,
      errorMsg: "Start date and end date cannot be the same",
    };
  }

  }
  // Case 4: Incomplete date range
  else if ((sd && !ed) || (!sd && ed)) {
    return { error: true, errorMsg: "Both start date and end date are required." };
  }

  // Case 5: Nothing provided
  else if (!sd && !ed && !hasDuration) {
    return { error: true, errorMsg: "Please select start & end date or provide duration." };
  }

  // --- 2️⃣ Date range checks ---
  if (sd && ed) {
    if (isNaN(sd) || isNaN(ed)) {
      return { error: true, errorMsg: "Invalid date(s) provided." };
    }

    if (sd.getTime() > ed.getTime()) {
      return { error: true, errorMsg: "Start date cannot be after end date." };
    }

    // if (sd.getTime() === ed.getTime()) {
    //   return { error: true, errorMsg: "Start date and end date cannot be the same." };
    // }

    const now = new Date();
    if (sd.getTime() > now.getTime()) {
      return { error: true, errorMsg: "Start date cannot be a future date." };
    }

     }

  // --- 3️⃣ Success ---
  return { error: false, errorMsg: "" };
}
