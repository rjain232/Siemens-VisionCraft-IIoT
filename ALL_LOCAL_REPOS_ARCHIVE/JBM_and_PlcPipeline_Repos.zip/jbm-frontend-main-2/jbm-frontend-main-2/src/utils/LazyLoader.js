import { lazy } from "react";

const componentsMap = {
  OEE: lazy(() => import("../pages/OEE")),
  LineStatus: lazy(() => import("../pages/LineStatusold")),
  RobotMonitoring: lazy(() => import("../pages/RobotMonitoring")),
  MachineSetup: lazy(() => import("../pages/MachineSetup")),
  ProductionControl: lazy(() => import("../pages/ProductionControl")),
  PredictiveAnalysis: lazy(() => import("../pages/PredictiveAnalysis")),
  LoginPage: lazy(() => import("../login/LoginPage")),
  Layout: lazy(() => import("../common/layout/Layout")),
  Notification : lazy(()=>import("../pages/Notification")),
  Safety : lazy(()=>import("../pages/Safety")),
  PowerConsumption : lazy(()=>import("../pages/PowerConsumption")),
  About: lazy(() => import("../pages/About")),
  Help:lazy(() => import("../pages/Help")),
};

const LazyLoader = (componentName) => {
  if (!componentsMap[componentName]) {
    throw new Error(`Component ${componentName} not found in componentsMap`);
  }
  return componentsMap[componentName];
};

export default LazyLoader;
