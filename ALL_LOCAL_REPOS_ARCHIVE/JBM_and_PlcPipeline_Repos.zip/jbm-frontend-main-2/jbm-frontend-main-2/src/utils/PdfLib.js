import { format } from "date-fns";
import jsPDF from "jspdf";
import "jspdf-autotable";
import netPositiveLogo from "./../assets/Netp_Logo_2.10.png";
import jbmLogo from "./../assets/jbm_logo.png";
import schaefflerLogo from "./../assets/schaeffler.png";
import { formatDate } from "./Formatters";
import html2canvas from "html2canvas";

const netPositiveLogoImg = new Image();
netPositiveLogoImg.src = netPositiveLogo;

const jbmLogoImage = new Image();
jbmLogoImage.src = jbmLogo;

const schaefflerLogoImage = new Image();
schaefflerLogoImage.src = schaefflerLogo;

export const pageHeadFormat = (pdf, label, isLandscape = true) => {
  pdf.autoTable({
    styles: {
      fillColor: [255, 255, 255],
      fontStyle: "bold",
      textColor: [11, 39, 51],
      fontSize: 14,
    },
    columnStyles: {
      0: {
        valign: "middle",
        halign: "center",
        minCellHeight: 15,
        cellWidth: isLandscape ? 47 : 40,
        fillColor: [255, 255, 255],
      },
      1: {
        valign: "middle",
        halign: "center",
        cellWidth: isLandscape ? 174 : 100,
        fillColor: [255, 255, 255],
        fontSize: isLandscape ? 18 : 16,
        textColor: "#000",
      },
      2: {
        valign: "middle",
        halign: "center",
        cellWidth: isLandscape ? 40 : 30,
        fillColor: [255, 255, 255],
      },
    }, // Cells in first column centered and green
    margin: { top: 10, right: 10 },
    body: [[" ", label, " "]],
    didDrawCell: function (data) {
      if (data.column.index === 2 && data.cell.section === "body") {
        pdf.addImage(
          netPositiveLogoImg,
          "PNG",
          data.cell.x + 1,
          data.cell.y + 1,
          isLandscape ? 45 : 40,
          13
        );
      }
      if (data.column.index === 0 && data.cell.section === "body") {
        pdf.addImage(
          jbmLogoImage,
          "PNG",
          data.cell.x + 1,
          data.cell.y + 1,
          isLandscape ? 45 : 35,
          13
        );
      }
    },
  });
};

export const pageFooterFormat = async (pdf, data) => {
  let timeStamp = `Printed on : ${format(new Date(), "dd-MM-yyyy HH:mm:ss")}`;
  pdf.setFontSize(10);
  pdf.setFont("Helvetica", "bold");
  // jsPDF 1.4+ uses getWidth, <1.4 uses .width
  var pageSize = pdf.internal.pageSize;
  var pageHeight = pageSize.height ? pageSize.height : pageSize.getHeight();
  var pageWidth = pageSize.Width ? pageSize.width : pageSize.getWidth();
  pdf.setTextColor(40);
  pdf.text(timeStamp, data.settings.margin.left, pageHeight - 5);
  //pdf.text("Developed by", pageWidth - 67, pageHeight - 5);
  pdf.addImage(schaefflerLogoImage, "PNG", pageWidth - 45, pageHeight - 15, 35, 18);
};

export const addPageNumber = (pdf) => {
  pdf.setFontSize(10);
  pdf.setFont("Helvetica", "bold");

  const totalPages = pdf.internal.getNumberOfPages();
  const pageWidth = pdf.internal.pageSize.getWidth();
  const pageHeight = pdf.internal.pageSize.getHeight();

  pdf.setTextColor(40);

  for (let i = 1; i <= totalPages; i++) {
    pdf.setPage(i);
    const pageText = `Page No. ${i} / ${totalPages}`;
    
    // Get text width and center it manually
    const textWidth = pdf.getTextWidth(pageText);
    const x = (pageWidth - textWidth) / 2; // CENTER

    pdf.text(pageText, x, pageHeight - 5);
  }
};


export const generatePDF = (doc, headers, rows, title, dateFilter) => {
  // const doc = new jsPDF("landscape")
  // Format table data for autoTable
  const tableHeaders = headers.map((header) => header.label);
  const tableRows = rows.map((row) =>
    headers.map((header) => row[header.accessor] || "")
  );

  //reportFromToShiftHeaders(doc, dateFilter);
  // Generate the table with custom styles
  doc.autoTable({
    startY: 40,
    margin: { top: 30 },
    head: [tableHeaders], // Table header
    body: tableRows, // Table data
    theme: "grid", // Structured grid format
    styles: {
      fontSize: 10,
      cellPadding: 4,
      textColor: [0, 0, 0], // Black text
      halign: "center",
      valign: "middle",
      lineColor: [224, 222, 222],
      lineWidth: 0.1,
    },
    headStyles: {
      fillColor: [62, 201, 177],
      textColor: [255, 255, 255],
      cellPadding: 4,
    },
    alternateRowStyles: {
      fillColor: [240, 240, 240], // Light gray for alternate rows
    },
    columnStyles: {
      0: { cellWidth: "auto" },
      1: { cellWidth: "auto" },
    },
    didDrawPage: function (data) {
      pageFooterFormat(doc, data);
    },
    willDrawPage: function () {
      pageHeadFormat(doc, title, false);
    },
  });

  addPageNumber(doc);

  // Save the PDF
  //doc.save(`${title.replace(/\s+/g, "_")}.pdf`);
};
export const generatePDF_Multiple_Tbl = (doc, headers, rows, title, dateFilter) => {
  const tableHeaders = headers.map((header) => header.label);
  const tableRows = rows.map((row) =>
    headers.map((header) => row[header.accessor] || "")
  );

  // Start each table on a new page
  doc.addPage();

  doc.autoTable({
    margin: { top: 30 },
    head: [tableHeaders],
    body: tableRows,
    theme: "grid",
    styles: {
      fontSize: 10,
      cellPadding: 4,
      textColor: [0, 0, 0],
      halign: "center",
      valign: "middle",
      lineColor: [224, 222, 222],
      lineWidth: 0.1,
    },
    headStyles: {
      fillColor: [62, 201, 177],
      textColor: [255, 255, 255],
      cellPadding: 4,
    },
    alternateRowStyles: {
      fillColor: [240, 240, 240],
    },
    columnStyles: {
      0: { cellWidth: "auto" },
      1: { cellWidth: "auto" },
    },
    didDrawPage: function (data) {
      pageFooterFormat(doc, data);
    },
    willDrawPage: function () {
      pageHeadFormat(doc, title, false);
    },
  });

 
};

export const generate_TablePDF = (headers, rows, title, dateFilter) => {
  const doc = new jsPDF();
  //Format table data for autoTable
  const tableHeaders = headers.map((header) => header.label);
  const tableRows = rows.map((row) =>
    headers.map((header) => row[header.accessor] || "")
  );

  reportFromToShiftHeaders(doc, dateFilter);
  // Generate the table with custom styles
  doc.autoTable({
    startY: 40,
    margin: { top: 30 },
    head: [tableHeaders], // Table header
    body: tableRows, // Table data
    theme: "grid", // Structured grid format
    styles: {
      fontSize: 10,
      cellPadding: 4,
      textColor: [0, 0, 0], // Black text
      halign: "center",
      valign: "middle",
      lineColor: [224, 222, 222],
      lineWidth: 0.1,
    },
    headStyles: {
      fillColor: [62, 201, 177],
      textColor: [255, 255, 255],
      cellPadding: 4,
    },
    alternateRowStyles: {
      fillColor: [240, 240, 240], // Light gray for alternate rows
    },
    columnStyles: {
      0: { cellWidth: "auto" },
      1: { cellWidth: "auto" },
    },
    didDrawPage: function (data) {
      pageFooterFormat(doc, data);
    },
    willDrawPage: function () {
      pageHeadFormat(doc, title, false);
    },
  });

  addPageNumber(doc);

  // Save the PDF
  doc.save(`${title.replace(/\s+/g, "_")}.pdf`);
};


export const reportFromToShiftHeaders = (doc, dateFilter) => {
  const { startDate, endDate, duration, shift } = dateFilter; // your object

  // Metadata section
  doc.setFontSize(12);
  doc.setFont("helvetica", "bold");
  const metaY = 35;
  doc.text(`Report duration:`, 14, metaY);
  //doc.text(`Shift:`, 14, metaY + 8);
  doc.setFont("helvetica", "normal");
  doc.text(
    startDate && endDate
      ? `${formatDate(startDate)} To ${formatDate(endDate)}`
      : `${formatDate(new Date())}`,
    50,
    metaY
  );
  //console.log("dateFilter==", dateFilter);
  if (shift) {
    doc.setFont("helvetica", "bold");
    doc.text(`Shift:`, 14, metaY + 8);
    doc.setFont("helvetica", "normal");
    /// doc.text(`${shift}`, 50, metaY + 8);
    doc.text(shift ? `${shift}` : `A,B,C`, 25, metaY + 8);
  }
};

// 1. Add temporary ApexCharts style tweaks
export const addGlobalStylesForPDF = () => {
  const style = document.createElement("style");
  style.id = "pdf-export-style";
  style.innerHTML = `
    .apexcharts-legend-text {
      margin-top: -3px !important;
    }
    .apexcharts-legend-marker {
      margin-top: 10px !important;
    }
  `;
  document.head.appendChild(style);
};

// 2. Cleanup styles
export const cleanupChartStyles = (chartRefs) => {
  const style = document.getElementById("pdf-export-style");
  if (style) style.remove();

  chartRefs.forEach((ref) => {
    if (ref.current) ref.current.classList.remove("pdf-export");
  });
};

// 3. Add chart to PDF
export const addChartToPDF = async (doc, ref, yOffset, margin = 10) => {
  if (!ref.current) return yOffset;

  // Ensure chart is rendered properly before capture
  await new Promise((resolve) => setTimeout(resolve, 300));

  const canvas = await html2canvas(ref.current, {
    scale: 1.5,
    scrollY: -window.scrollY,
    useCORS: true,
    backgroundColor: null,
  });

  const imgData = canvas.toDataURL("image/png");
  const imgProps = doc.getImageProperties(imgData);
  const pdfWidth = doc.internal.pageSize.getWidth() - 2 * margin;
  const imgHeight = (imgProps.height * pdfWidth) / imgProps.width;
  const pageHeight = doc.internal.pageSize.getHeight();

  // Add a new page if the image doesn't fit on the current page
  if (yOffset + imgHeight > pageHeight - margin) {
    doc.addPage();
    yOffset = margin;
  }

  doc.addImage(imgData, "PNG", margin, yOffset, pdfWidth, imgHeight);
  return yOffset + imgHeight + 10; // Add spacing after chart
};

// 4. Render individual chart refs to PDF
export const renderChartToPDF = async (doc, chartRefs, options = {}) => {
  const { margin = 10, spacing = 10, initialYOffset = 50 } = options;

  let yOffset = initialYOffset;

  for (const ref of chartRefs) {
    yOffset = await addChartToPDF(doc, ref, yOffset, margin, spacing);
  }

  return yOffset;
};

export const generateTableFromData = (
  doc,
  data,
  columns,
  startY = 30,
  title,
  isLandscape
) => {
  try {
    const tableHeaders = columns.map((header) => header.label);
    const tableRows = data.map((row) =>
      columns.map((header) => row[header.accessor] || "")
    );

    doc.autoTable({
      startY: startY,
      margin: { top: 30 },
      head: [tableHeaders], // Table header
      body: tableRows, // Table data
      theme: "grid", // Structured grid format
      styles: {
        fontSize: 10,
        cellPadding: 4,
        textColor: [0, 0, 0], // Black text
        halign: "center",
        valign: "middle",
        lineColor: [224, 222, 222],
        lineWidth: 0.1,
      },
      headStyles: {
        fillColor: [62, 201, 177],
        textColor: [255, 255, 255],
        cellPadding: 4,
      },
      alternateRowStyles: {
        fillColor: [240, 240, 240], // Light gray for alternate rows
      },
      columnStyles: {
        0: { cellWidth: "auto" },
        1: { cellWidth: "auto" },
      },
      didDrawPage: function (data) {
        pageFooterFormat(doc, data);
      },
      willDrawPage: function () {
        pageHeadFormat(doc, title, isLandscape);
      },
    });
  } catch (e) {
    console.error("Error generating table from data:", e);
  }
};
