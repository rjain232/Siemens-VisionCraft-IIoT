import { format, parseISO } from "date-fns";
import DataTable from "../common/components/DataTable";
import DateRangeSelector from "../common/components/DateRangeSelector ";
import withTable from "../hoc/withTable";
import useAxios from "../hooks/useAxios";
import {generateExcel} from "../utils/ExcelUtils";
import { generate_TablePDF} from "../utils/PdfLib";
import { useState } from "react";
import { LineName } from "../utils/constants";
import { Loader } from "../common/components/Loader";

const ROBOT_STATUS_COLUMNS = [
  { label: "Robot ID", accessor: "RobotID" },
  { label: "Timestamp", accessor: "Timestamp" },
  { label: "Status", accessor: "Status" },
];

const EnhancedTable = withTable(DataTable);

const RobotStatus = () => {
  const [params, setParams] = useState({ parameter: null }); // API parameters
  const [isDownloading, setIsDownloading] = useState(false);
  const {
    data: robotStatusData,
    loading: isrobotStatusDataLoading,
    error: isrobotStatusDataError,
    refetch: refetchRobotStatusData,
  } = useAxios("/robotLogs", { method: "GET" }, true);

  //Done by Arshiya 
  const formattedData = robotStatusData?.map(item =>({
    ...item,
    Timestamp: format(parseISO(item.Timestamp),"dd-MM-yyyy HH:mm:ss")
  }))


const download = async () => {
  setIsDownloading(true);

  // Allow React to render loading state
  await new Promise((resolve) => setTimeout(resolve, 0));

  generate_TablePDF(
    ROBOT_STATUS_COLUMNS,
    formattedData,
    `${LineName} Robot Status`,
    {
      startDate: params.startDate,
      endDate: params.endDate,
    }
  );

  generateExcel(
    ROBOT_STATUS_COLUMNS,
    formattedData,
    `${LineName} Robot Status`
  );

  setIsDownloading(false);
};
  const handleSearch = (startDate, endDate, duration, shift, dedicatedDuration) => {
      setParams({
        startDate: format(startDate, "yyyy-MM-dd HH:mm:ss"),
        endDate: format(endDate, "yyyy-MM-dd HH:mm:ss"),
        duration,
        shift,
        dedicatedDuration,
      });
      refetchRobotStatusData({
        params: {
          startDate: format(startDate, "yyyy-MM-dd HH:mm:ss"),
          endDate: format(endDate, "yyyy-MM-dd HH:mm:ss"),
          duration,
          shift,
          dedicatedDuration,
        },
      });
    }
    if(isrobotStatusDataError){
      return <div>Error in fetching data ...</div>;
    }
  return (
    <>
      <DateRangeSelector
        showDownload={true}
        onDownload={download}
        onSearch={handleSearch}
        isDownloading={isDownloading}
      />
       { isrobotStatusDataLoading && (
       <div><Loader/></div>
      )}
     { !isrobotStatusDataLoading &&
      <EnhancedTable
        data={robotStatusData ? formattedData : []}
        columns={ROBOT_STATUS_COLUMNS}
        enableSearch={true}
        enableFilter={true}
        enablePagination={true}
      />}
    </>
  );
};
export default RobotStatus;
