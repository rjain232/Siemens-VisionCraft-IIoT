import React, { useMemo, useRef, useEffect, useCallback } from "react";
import Chart from "react-apexcharts";
import useAxios from "../hooks/useAxios";

const PARAM_CONFIG = {
  Current: {
    min: 20,
    max: 80,
    unit: "A",
    color: "#DC2626",
  },
  Torque: {
    min: 50,
    max: 300,
    unit: "N",
    color: "#D97706",
  },
  Temperature: {
    min: 30,
    max: 90,
    unit: "°C",
    color: "#7C3AED",
  },
};

const pad = (num) => String(num).padStart(2, "0");

// Built from UTC getters, not date-fns — never throws on a missing or
// malformed value, and never depends on a prop that the backend might
// not actually send (which is what caused the prod-only crash).
const formatUTC = (ts) => {
  const date = new Date(ts);
  if (Number.isNaN(date.getTime())) return "—";
  return (
    `${pad(date.getUTCDate())}-${pad(date.getUTCMonth() + 1)}-${date.getUTCFullYear()} ` +
    `${pad(date.getUTCHours())}:${pad(date.getUTCMinutes())}:${pad(date.getUTCSeconds())}`
  );
};

export default function TrendChartWithBrush({
  mainData = [],
  brushData = [],
  parameter,
  onZoomRange,
  onResetZoom,
  isRawLoading = false,
  // True once the user has zoomed/selected a window at least once in the
  // current context — distinct from mainData being empty, which can mean
  // either "haven't zoomed yet" (fall back to overview) or "zoomed, but
  // the API returned nothing for that range" (show a real empty state).
  hasZoomed = false,
  resetToken = 0,
  debounceMs = 600,
}) {
  const { data: paramConfigData } = useAxios("param-config");

  const config = useMemo(() => {
    const apiConfig = paramConfigData?.[parameter];
    if (apiConfig && typeof apiConfig === "object") {
      return apiConfig;
    }
    return (
      PARAM_CONFIG[parameter] ?? {
        min: 0,
        max: 0,
        unit: "",
        color: "#111827",
      }
    );
  }, [parameter, paramConfigData]);

  const chartRef = useRef(null);
  const zoomDebounceRef = useRef(null);
  const lastSentRangeRef = useRef({ start: null, end: null });

  // Keep refs pointing at the latest callbacks. This lets the chart's
  // event handlers (registered once, inside memoized options) always
  // call the current onZoomRange/onResetZoom — without mainOptions or
  // brushOptions needing to be rebuilt just because the parent
  // re-rendered and handed down a new function reference. Rebuilding
  // those options mid-gesture was what wiped out the brush's visible
  // selection box and occasionally swallowed the event entirely.
  const onZoomRangeRef = useRef(onZoomRange);
  const onResetZoomRef = useRef(onResetZoom);
  useEffect(() => {
    onZoomRangeRef.current = onZoomRange;
    onResetZoomRef.current = onResetZoom;
  }, [onZoomRange, onResetZoom]);

  // Clear any pending debounce on unmount.
  useEffect(() => {
    return () => {
      if (zoomDebounceRef.current) clearTimeout(zoomDebounceRef.current);
    };
  }, []);

  // When the parent signals that the underlying sampled dataset changed
  // (new robot/axis/parameter/date-range), force the chart's own zoom
  // state back to default so it doesn't stay visually zoomed into a
  // window that belongs to the previous context.
  useEffect(() => {
    if (resetToken > 0) {
      chartRef.current?.chart?.resetSeries();
    }
  }, [resetToken]);

  const handleResetZoom = useCallback(() => {
    chartRef.current?.chart?.resetSeries();
    lastSentRangeRef.current = { start: null, end: null };
    onResetZoomRef.current?.();
  }, []);

  // Shared by both the main chart's "zoomed" event (drag-zoom or toolbar
  // zoom directly on the main chart) and the brush chart's "selection"
  // event (dragging the mini-chart's selection window) — so either
  // interaction debounces, dedupes, and reports range the same way.
  // Stable across re-renders (only depends on debounceMs) so it never
  // forces mainOptions/brushOptions to be rebuilt.
  const handleZoomChange = useCallback(
    (xaxis) => {
      if (!onZoomRangeRef.current) return;

      const start = xaxis?.min;
      const end = xaxis?.max;

      // ApexCharts can occasionally fire "selection"/"zoomed" with an
      // incomplete range (e.g. during initial brush mount or while data
      // is mid-swap) — forwarding that on would send an unparseable
      // date to the API. Drop it instead of debouncing/sending it.
      if (!Number.isFinite(start) || !Number.isFinite(end)) {
        return;
      }

      if (zoomDebounceRef.current) {
        clearTimeout(zoomDebounceRef.current);
      }

      zoomDebounceRef.current = setTimeout(() => {
        const prev = lastSentRangeRef.current;
        if (prev.start === start && prev.end === end) {
          return;
        }
        lastSentRangeRef.current = { start, end };
        onZoomRangeRef.current({ start, end });
      }, debounceMs);
    },
    [debounceMs],
  );

  // Brush always reflects the sampled (overview) data.
  const brushSeries = useMemo(() => {
    return [
      {
        name: parameter,
        data: brushData.map((item) => ({
          x: item["TimeBucket"],
          y: item["Value"],
        })),
      },
    ];
  }, [brushData, parameter]);

  // isRawView: are we actually showing the zoomed-in raw slice right now?
  // Only true once a zoom has happened AND it came back with data.
  // isEmptyZoomResult: the user zoomed, the request finished, and there's
  // genuinely nothing for that window — distinct from "haven't zoomed
  // yet", which instead falls back to the sampled overview below.
  const isRawView = hasZoomed && mainData?.length > 0;
  const isEmptyZoomResult =
    hasZoomed && !isRawLoading && (!mainData || mainData.length === 0);

  const mainSeries = useMemo(() => {
    if (isEmptyZoomResult) {
      return [{ name: parameter, data: [] }];
    }
    const source = isRawView ? mainData : brushData;
    return [
      {
        name: parameter,
        data: (source || []).map((item) => ({
          x: item["TimeBucket"],
          y: item["Value"],
        })),
      },
    ];
  }, [mainData, brushData, parameter, isRawView, isEmptyZoomResult]);

  // Compute y-axis limits so MIN/MAX annotations remain visible even
  // when raw data exceeds configured bounds. Adds a small padding.
  const yLimits = useMemo(() => {
    const source = isRawView ? mainData : brushData;
    const cfgMin = Number.isFinite(config?.min) ? Number(config.min) : null;
    const cfgMax = Number.isFinite(config?.max) ? Number(config.max) : null;

    if (!source?.length) {
      const min = cfgMin ?? 0;
      const max = cfgMax ?? 0;
      const padAmt = Math.max(1, Math.abs(max - min) || Math.abs(max) * 0.05);
      return { min: min - padAmt, max: max + padAmt };
    }

    const values = source
      .map((d) => Number(d["Value"]))
      .filter((v) => Number.isFinite(v));
    if (!values.length) {
      const min = cfgMin ?? 0;
      const max = cfgMax ?? 0;
      const padAmt = Math.max(1, Math.abs(max - min) || Math.abs(max) * 0.05);
      return { min: min - padAmt, max: max + padAmt };
    }

    const dataMin = Math.min(...values);
    const dataMax = Math.max(...values);
    const min = cfgMin !== null ? Math.min(dataMin, cfgMin) : dataMin;
    const max = cfgMax !== null ? Math.max(dataMax, cfgMax) : dataMax;
    const range = Math.max(1, Math.abs(max - min));
    const padAmt = Math.max(1, range * 0.08);
    return { min: min - padAmt, max: max + padAmt };
  }, [mainData, brushData, isRawView, config]);

  // Drives the "what am I looking at" badge — derived straight from the
  // rendered series so it can never drift out of sync with the chart.
  const viewInfo = useMemo(() => {
    if (isEmptyZoomResult) {
      return {
        label: "No data available for the selected range",
        isRawView: true,
        isEmpty: true,
      };
    }
    const points = isRawView ? mainData : brushData;
    if (!points?.length) {
      return { label: "No data", isRawView };
    }
    const first = points[0]["TimeBucket"];
    const last = points[points.length - 1]["TimeBucket"];
    return {
      label: `${formatUTC(first)} – ${formatUTC(last)}`,
      isRawView,
    };
  }, [mainData, brushData, isRawView, isEmptyZoomResult]);

  const mainOptions = useMemo(
    () => ({
      chart: {
        id: "mainTrend",
        type: "line",
        height: 450,
        fontFamily: "Inter, system-ui, sans-serif",

        zoom: {
          enabled: true,
          type: "x",
          // Disable Apex's auto-scaling so our enforced y-limits keep
          // the configured MIN/MAX annotations visible during zooms.
          autoScaleYaxis: false,
        },

        toolbar: {
          show: false,
          autoSelected: "zoom",
        },

        animations: {
          enabled: false,
        },

        // events: {
        //   zoomed: function (ctx, { xaxis }) {
        //     handleZoomChange(xaxis);
        //   },
        // },
      },

      colors: [config.color],

      stroke: {
        width: 2,
        curve: "smooth",
      },

      markers: {
        size: 0,
        hover: {
          size: 6,
          sizeOffset: 2,
        },
      },

      xaxis: {
        type: "datetime",
        axisBorder: {
          show: true,
          color: "#9ca3af",
          height: 1,
        },
        axisTicks: {
          show: true,
          color: "#9ca3af",
        },
        labels: {
          //datetimeUTC: true,
          style: {
            colors: "#6b7280",
            fontSize: "12px",
            fontWeight: 700,
          },
        },
      },

      yaxis: {
        title: {
          text: `${parameter} (${config.unit})`,
          style: {
            fontSize: "13px",
            fontWeight: 700,
            color: "#374151",
          },
        },
        axisBorder: {
          show: true,
          color: config.color,
          width: 2,
        },
        axisTicks: {
          show: true,
          color: config.color,
        },
        labels: {
          style: {
            colors: "#6b7280",
            fontSize: "12px",
            fontWeight: 700,
          },
          formatter: (val) => `${val.toFixed(1)}`,
        },
        // enforce computed limits so annotations (MIN/MAX) are always visible
        min: yLimits.min,
        max: yLimits.max,
      },

      tooltip: {
        shared: true,
        intersect: false,
        custom: function ({ series, seriesIndex, dataPointIndex, w }) {
          const value = series[seriesIndex][dataPointIndex];
          const timestamp = w.globals.seriesX[seriesIndex][dataPointIndex];
          const date = new Date(timestamp);
          const formattedDate = date.toLocaleString(undefined, {
            year: "numeric",
            month: "short",
            day: "2-digit",
            hour: "2-digit",
            minute: "2-digit",
            second: "2-digit",
            timeZone: "UTC",
          });

          let status = "Normal";
          let statusColor = "#10b981";
          if (value > config.max) {
            status = "Above Max";
            statusColor = "#f44336";
          } else if (value < config.min) {
            status = "Below Min";
            statusColor = "#ff9800";
          }

          return `
            <div style="
              padding: 10px 14px;
              background: #ffffff;
              border: 1px solid #e5e7eb;
              border-radius: 8px;
              box-shadow: 0 4px 12px rgba(0,0,0,0.08);
              font-family: Inter, system-ui, sans-serif;
              min-width: 180px;
            ">
              <div style="font-size: 12px; color: #6b7280; margin-bottom: 6px;">
                ${formattedDate}
              </div>
              <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 4px;">
                <span style="display: flex; align-items: center; font-size: 13px; font-weight: 600; color: #111827;">
                  <span style="width: 9px; height: 9px; border-radius: 50%; background: ${config.color}; display: inline-block; margin-right: 6px;"></span>
                  ${parameter}
                </span>
                <span style="font-size: 14px; font-weight: 700; color: ${config.color};">
                  ${value.toFixed(2)}${config.unit}
                </span>
              </div>
              <div style="display: flex; align-items: center; justify-content: space-between; padding-top: 6px; border-top: 1px dashed #e5e7eb;">
                <span style="font-size: 11px; color: #9ca3af;">
                  Range: ${config.min}–${config.max}${config.unit}
                </span>
                <span style="
                  font-size: 11px;
                  font-weight: 600;
                  color: ${statusColor};
                  background: ${statusColor}1a;
                  padding: 2px 6px;
                  border-radius: 4px;
                ">
                  ${status}
                </span>
              </div>
            </div>
          `;
        },
      },

      annotations: {
        yaxis: [
          {
            y: config.min,
            borderColor: "#ff9800",
            strokeDashArray: 0,
            borderWidth: 4,
            label: {
              text: `MIN ${config.min}${config.unit}`,
              style: {
                background: "#ff9800",
                color: "#fff",
                fontSize: "20px",
                fontWeight: 700,
              },
            },
          },
          {
            y: config.max,
            borderColor: "#f44336",
            strokeDashArray: 0,
            borderWidth: 4,
            label: {
              text: `MAX ${config.max}${config.unit}`,
              style: {
                background: "#f44336",
                color: "#fff",
                fontSize: "20px",
                fontWeight: 700,
              },
            },
          },
        ],
      },

      legend: {
        position: "top",
        fontSize: "13px",
        fontWeight: 500,
        labels: {
          colors: "#374151",
        },
        markers: {
          radius: 12,
        },
      },

      grid: {
        borderColor: "#d1d5db",
        strokeDashArray: 4,
        xaxis: {
          lines: { show: true },
        },
        yaxis: {
          lines: { show: true },
        },
        padding: {
          top: 10,
          right: 10,
          bottom: 0,
          left: 10,
        },
      },
    }),
    [parameter, config, handleZoomChange, yLimits],
  );

  const brushOptions = useMemo(
    () => ({
      chart: {
        id: "brush",
        height: 120,
        type: "area",
        fontFamily: "Inter, system-ui, sans-serif",

        brush: {
          enabled: true,
          target: "mainTrend",
        },

        selection: {
          enabled: true,
          fill: {
            color: config.color,
            opacity: 0.18,
          },
          stroke: {
            width: 1.5,
            color: config.color,
            opacity: 0.6,
            dashArray: 0,
          },
          xaxis: {
            min: brushSeries[0]?.data?.[0]?.x ?? new Date().getTime(),
            max:
              brushSeries[0]?.data?.[
                Math.min(brushSeries[0]?.data?.length - 1, 500)
              ]?.x ?? new Date().getTime(),
          },
        },

        events: {
          // Fires when the user drags, resizes, or moves the brush's
          // selection window — distinct from the main chart's "zoomed"
          // event, which only fires for direct zoom interactions on
          // the main chart itself.
          selection: function (ctx, { xaxis }) {
            handleZoomChange(xaxis);
          },
        },
      },

      colors: [config.color],

      fill: {
        type: "gradient",
        gradient: {
          opacityFrom: 0.4,
          opacityTo: 0.05,
        },
      },

      stroke: {
        width: 1.5,
        curve: "smooth",
      },

      xaxis: {
        type: "datetime",
        axisBorder: {
          show: true,
          color: "#9ca3af",
        },
        labels: {
          datetimeUTC: true,
          style: {
            colors: "#6b7280",
            fontSize: "12px",
            fontWeight: 600,
          },
        },
      },

      yaxis: {
        tickAmount: 2,
        labels: {
          style: {
            colors: "#6b7280",
            fontSize: "12px",
            fontWeight: 600,
          },
        },
        axisBorder: {
          show: true,
          color: "#9ca3af",
        },
      },

      grid: {
        borderColor: "#e5e7eb",
        strokeDashArray: 4,
      },

      tooltip: {
        enabled: false,
      },
    }),
    [parameter, brushSeries, config, handleZoomChange],
  );

  // Always reflects the full sampled overview span (brushData), unlike
  // viewInfo which tracks whatever is currently zoomed/displayed on the
  // main chart — this stays constant regardless of zoom state. Derived
  // directly from brushData's own TimeBucket values (not from
  // startDate/endDate props the backend may not always provide), so it
  // can never throw on a missing/invalid date.
  const parentRangeLabel = useMemo(() => {
    if (!brushData?.length) return "No data";
    const first = brushData[0]["TimeBucket"];
    const last = brushData[brushData.length - 1]["TimeBucket"];
    return `${formatUTC(first)} – ${formatUTC(last)}`;
  }, [brushData]);

  const badgeLabel = isRawLoading
    ? "Loading raw data…"
    : viewInfo.isEmpty
      ? "No Data"
      : viewInfo.isRawView
        ? "Raw Data"
        : "Data Overview";

  const badgeClasses = isRawLoading
    ? "bg-amber-100 text-amber-800"
    : viewInfo.isEmpty
      ? "bg-red-100 text-red-700"
      : viewInfo.isRawView
        ? "bg-blue-100 text-blue-700"
        : "bg-gray-100 text-gray-700";

  return (
    <div className="w-full pr-4">
      <div className="flex items-center gap-2.5 mb-2 font-sans">
        <span
          className={`px-2.5 py-[3px] rounded-full text-xs font-semibold ${badgeClasses}`}
        >
          {badgeLabel}
        </span>
        <span className="text-sm text-gray-500 font-semibold">
          {viewInfo.label}
        </span>
        {viewInfo.isRawView && !isRawLoading && (
          <button
            type="button"
            onClick={handleResetZoom}
            className="ml-auto text-xs font-semibold text-gray-700 bg-gray-100 border border-gray-200 rounded-md py-1 px-2.5 cursor-pointer hover:bg-gray-200 transition-colors"
          >
            Reset to overview
          </button>
        )}
      </div>

      {isEmptyZoomResult ? (
        <div
          className="flex items-center justify-center border border-dashed border-gray-300 rounded-md bg-gray-50 text-gray-500 text-sm font-medium"
          style={{ height: 350 }}
        >
          Data not available for selected range
        </div>
      ) : (
        <Chart
          ref={chartRef}
          options={mainOptions}
          series={mainSeries}
          type="line"
          height={350}
        />
      )}

      <div className="flex items-center gap-2.5 mt-1 mb-1.5 font-sans">
        <span className="px-2.5 py-[3px] rounded-full text-xs font-semibold bg-gray-100 text-gray-700">
          Full Range
        </span>
        <span className="text-sm text-gray-500 font-semibold">
          {parentRangeLabel}
        </span>
      </div>

      <Chart
        options={brushOptions}
        series={brushSeries}
        type="area"
        height={150}
      />
    </div>
  );
}