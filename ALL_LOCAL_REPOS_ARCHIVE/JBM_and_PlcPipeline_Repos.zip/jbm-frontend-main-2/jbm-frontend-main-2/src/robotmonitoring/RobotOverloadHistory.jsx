import useAxios from "../hooks/useAxios";
import DateRangeSelector from "../common/components/DateRangeSelector ";
import { format } from "date-fns";
import Dropdown from "../common/components/Dropdown";
import OverloadChart from "../common/testexperiments/OverloadChart";
import { useEffect, useState, useRef, useCallback } from "react";
import { generateExcel, generateExcelWithSheets } from "../utils/ExcelUtils";
import { generatePDF, generatePDF_Multiple_Tbl } from "../utils/PdfLib";
import {
  addGlobalStylesForPDF,
  addPageNumber,
  cleanupChartStyles,
  pageFooterFormat,
  pageHeadFormat,
  renderChartToPDF,
  reportFromToShiftHeaders,
} from "../utils/PdfLib";
import { jsPDF } from "jspdf";
import { validateDateRange } from "../utils/validators";
import axiosInstance from "../utils/AxiosInstance";
import TrendChartWithBrush from "./TrendChartWithBrush";
import { LineName } from "../utils/constants";

const robotHistoryTableColumn = [
  { label: "RobotId", accessor: "RobotId" },
  { label: "Axis", accessor: "Axis" },
  { label: "Current", accessor: "Value" },
  { label: "Torque", accessor: "Torque" },
  { label: "Temperature", accessor: "Temperature" },
  { label: "Timestamp", accessor: "TimeBucket" },
];

const getRobotHistoryTableColumn = (parameter) => {
  return [
     { label: "Sr. No", accessor: "srno" },
    { label: "Robot ID", accessor: "robotId" },
    { label: "Axis", accessor: "axis" },
    { label: parameter, accessor: "value" },
    { label: "Time", accessor: "time" },
  ];
};

const DEFAULT_ROBOT = "1";
const DEFAULT_AXIS = "Axis1";
const DEFAULT_PARAMETER = "Current";

// date-fns' format() reads a Date object's *local* time components by
// default. The chart's xaxis.min/max are UTC instants (axis is rendered
// with datetimeUTC: true), so formatting them with date-fns would shift
// the value by the browser's local offset before it ever reaches the
// API — exactly the mismatch we saw between the selected window and the
// request params. Build the string from UTC getters instead.
const pad = (num) => String(num).padStart(2, "0");

const formatUTCDateTime = (timestamp) => {
  const date = new Date(timestamp);
  return (
    `${date.getUTCFullYear()}-${pad(date.getUTCMonth() + 1)}-${pad(date.getUTCDate())} ` +
    `${pad(date.getUTCHours())}:${pad(date.getUTCMinutes())}:${pad(date.getUTCSeconds())}`
  );
};

const transformPdfData = (data) => {
  return data.map((item,index) => {
    const tagParts = item.TagName?.split("_") || [];

    return {
      srno:index+1,
      robotId: tagParts[0] || "-",
      axis: tagParts[tagParts.length - 1] || "-",
      value: item.Value,
      time: formatUTCDateTime(item.TimeBucket),
    };
  });
};

const RobotOverloadHistory = () => {
  // ✅ FIX: seed params with the defaults so the first useAxios call
  // already carries selectedRobot and selectedAxis instead of null.
  const [params, setParams] = useState({
    selectedRobot: DEFAULT_ROBOT,
    selectedAxis: DEFAULT_AXIS,
    selectedParameter: DEFAULT_PARAMETER,
  });

  const {
    data: robotList,
    loading: isRobotLoading,
    error: isRobotError,
  } = useAxios("/robotList", { method: "GET" }, true);

  const {
    data: sampledData,
    loading: isRobotHistoryDataLoading,
    error: isRobotHistoryDataError,
  } = useAxios("/robotHistory", { method: "GET", params }, true);

  // ✅ FIX: rawData is the *zoomed-in, raw-resolution* slice. It has no
  // sensible value until the user actually zooms, so start it at null
  // (not sampledData, which isn't loaded yet on mount anyway and was
  // never re-synced afterwards).
  const [rawData, setRawData] = useState(null);
  const [isZoomLoading, setIsZoomLoading] = useState(false);
  const [rawDataReportLabel, setRawDataReportLabel] = useState("");

  // Tracks whether the user has zoomed/selected a window at least once
  // in the current robot/axis/parameter/date-range context. Lets the
  // chart distinguish "haven't zoomed yet" (show the sampled overview)
  // from "zoomed, and the API legitimately returned nothing for that
  // window" (show an explicit "no data" state instead of silently
  // falling back to the overview, which would be misleading).
  const [hasZoomed, setHasZoomed] = useState(false);

  // Bumped whenever the sampled dataset changes, so the chart knows to
  // reset its own internal zoom state back to the overview.
  const [resetToken, setResetToken] = useState(0);

  // Tracks the most recent zoom request so a slow, now-outdated response
  // can't overwrite the data for a range the user has already moved on
  // from (e.g. they zoomed twice quickly and the first call resolves last).
  const zoomRequestIdRef = useRef(0);

  // FIX: whenever a fresh sampled dataset arrives (robot/axis/parameter
  // change, or a new date-range search), any previously zoomed raw slice
  // is now stale and belongs to a different context — clear it so the
  // trend chart falls back to the sampled overview until the user zooms
  // again on the new selection.
  useEffect(() => {
    setRawData(null);
    setHasZoomed(false);
    setResetToken((t) => t + 1);
  }, [sampledData]);

  const [dateFilter, setDateFilter] = useState({
    startDate: null,
    endDate: null,
    duration: null,
  });

  const chart1Ref = useRef(null);
  const [downloading, setDownloading] = useState(false);

  const exportPdfOverloadhistoryReport = async () => {
    const doc = new jsPDF();
    const chartRefs = [chart1Ref];
    reportFromToShiftHeaders(doc, dateFilter);
    if (dateFilter?.duration) {
      doc.setFontSize(10);
      doc.text(`Selected Duration: ${dateFilter.duration}`, 14, 32);
    }
    addGlobalStylesForPDF();
    chartRefs.forEach((ref) => ref.current?.classList.add("pdf-export"));
    let yOffset = 50;
    await renderChartToPDF(doc, chartRefs, yOffset);
    pageHeadFormat(doc, "Overload History", false);

    const columns = getRobotHistoryTableColumn(sampledData?.Parameter);
    const durationLabel = dateFilter?.duration
      ? ` - Duration: ${dateFilter.duration}`
      : "";

    generatePDF_Multiple_Tbl(
      doc,
      columns,
      transformPdfData(sampledData?.data),
      `History data${durationLabel}`,
    );

    if (rawData?.data?.length > 0) {
      const tableHeaders = columns.map((header) => header.label);
      const tableRows = transformPdfData(rawData?.data)?.map((row) =>
        columns.map((header) => row[header.accessor] || ""),
      );
      doc.addPage();
      doc.text(`${rawDataReportLabel}`, 14, 32);

      doc.autoTable({
        margin: { top: 30 },
        startY: 40,
        head: [tableHeaders],
        body: tableRows,
        theme: "grid",
        styles: {
          fontSize: 10,
          cellPadding: 4,
          textColor: [0, 0, 0],
          halign: "center",
          valign: "middle",
          lineColor: [224, 222, 222],
          lineWidth: 0.1,
        },
        headStyles: {
          fillColor: [62, 201, 177],
          textColor: [255, 255, 255],
          cellPadding: 4,
        },
        alternateRowStyles: {
          fillColor: [240, 240, 240],
        },
        columnStyles: {
          0: { cellWidth: "auto" },
          1: { cellWidth: "auto" },
        },
        didDrawPage: function (data) {
          pageFooterFormat(doc, data);
        },
        willDrawPage: function () {
          pageHeadFormat(doc, "Selected window raw report", false);
        },
      });
    }
    addPageNumber(doc);
    cleanupChartStyles(chartRefs);
    doc.save(`${LineName}_Overload_History.pdf`);
  };

  const handleDownload = () => {
    try {
      setDownloading(true);

      const sheets = [
        {
          sheetName: "Master Data",
          headers: getRobotHistoryTableColumn(sampledData?.Parameter),
          rows: transformPdfData(sampledData?.data),
        },
      ];

      if (rawData?.data?.length > 0) {
        sheets.push({
          sheetName: "Raw Data",
          headers: getRobotHistoryTableColumn(sampledData?.Parameter),
          rows: transformPdfData(rawData?.data),
        });
      }

      generateExcelWithSheets(sheets, `${LineName} Overload History`);

      exportPdfOverloadhistoryReport().then(() => {
        setDownloading(false);
      });
    } catch (error) {
      console.log(error);
      alert("Error occurred while downloading the report. Please try again.");
      setDownloading(false);
    }
  };

  const handleSearch = (
    startDate,
    endDate,
    duration,
    shift,
    dedicatedDuration,
  ) => {
    setDateFilter({ startDate, endDate, duration });

    const { error, errorMsg } = validateDateRange(startDate, endDate);
    if (error) {
      alert(errorMsg);
      return;
    }
    setParams((prev) => ({
      ...prev,
      startDate: format(startDate, "yyyy-MM-dd HH:mm:ss"),
      endDate: format(endDate, "yyyy-MM-dd HH:mm:ss"),
      duration,
      dedicatedDuration,
    }));
  };

  if (isRobotError) {
    console.error("Error fetching robot list:", isRobotError);
    return <div className="text-red-600">Error fetching robot list</div>;
  }

  if (isRobotHistoryDataError) {
    console.error(
      "Error fetching robot history data:",
      isRobotHistoryDataError,
    );
    return (
      <div className="text-red-600">
        {isRobotHistoryDataError?.message ??
          "Error fetching robot history data"}
      </div>
    );
  }

  const handleOptionChange = (type, value) => {
    if (type == "robot") {
      setParams((prev) => ({
        ...prev,
        selectedRobot: value,
      }));
    }
    if (type == "axis") {
      setParams((prev) => ({
        ...prev,
        selectedAxis: value,
      }));
    }
    if (type == "parameter") {
      setParams((prev) => ({
        ...prev,
        selectedParameter: value,
      }));
    }
  };

  const handleZoomRange = useCallback(
    async ({ start, end }) => {
      if (!Number.isFinite(start) || !Number.isFinite(end)) {
        console.warn("Ignoring zoom request with invalid range:", {
          start,
          end,
        });
        return;
      }

      const requestId = ++zoomRequestIdRef.current;
      setIsZoomLoading(true);
      // Mark "zoomed" immediately so the chart correctly distinguishes
      // a genuinely empty result for this range from "never zoomed yet",
      // regardless of what the fetch below ends up returning.
      setHasZoomed(true);

      try {
        // ⚠️ TODO: swap this for your new raw-data API call once you share
        // its endpoint/payload/response shape — keeping it isolated here
        // so the rest of the zoom/loading/reset wiring doesn't need to change.
        const response = await axiosInstance({
          url: "/robotHistoryRawData",
          method: "GET",
          params: {
            ...params,
            startDate: formatUTCDateTime(start),
            endDate: formatUTCDateTime(end),
          },
          data: {},
        });

        // Ignore this response if a newer zoom request has been made since.
        if (requestId !== zoomRequestIdRef.current) return;

        setRawData(response?.data);
        setRawDataReportLabel(
          `Raw Data for window selected - ${formatUTCDateTime(start)} - ${formatUTCDateTime(end)}`,
        );
      } catch (error) {
        if (requestId === zoomRequestIdRef.current) {
          console.error("Error fetching raw trend data:", error);
        }
      } finally {
        if (requestId === zoomRequestIdRef.current) {
          setIsZoomLoading(false);
        }
      }
    },
    [params],
  );

  const handleResetZoom = useCallback(() => {
    setRawData(null);
    setHasZoomed(false);
  }, []);

    const axisCount = [7, 8, "7", "8"].includes(params?.selectedRobot) ? 9 : 8;

  return (
    <>
      <DateRangeSelector
        showDownload={true}
        onDownload={handleDownload}
        onSearch={handleSearch}
        selectedStartDate={dateFilter?.startDate}
        selectedEndDate={dateFilter?.endDate}
        isDownloading={downloading}
      />
      <div className="mb-4 flex items-center gap-4">
        {!isRobotLoading && (
          <>
            <Dropdown
              options={robotList?.map((robot) => ({
                value: robot.RobotId,
                label: robot.RobotName,
              }))}
              selectedValue={params.selectedRobot}
              placeholder="Select Robot"
              onChange={(val) => handleOptionChange("robot", val)}
              justify="start"
            />
            <Dropdown
              options={Array.from({ length: axisCount }, (_, i) => ({
                value: `Axis${i + 1}`,
                label: `Axis ${i + 1}`,
              }))}
              placeholder="Select Axis"
              selectedValue={params.selectedAxis}
              onChange={(val) => handleOptionChange("axis", val)}
              justify="start"
            />
            <Dropdown
              options={[
                { value: "Current", label: "Current" },
                { value: "Torque", label: "Torque" },
                { value: "Temperature", label: "Temperature" },
              ]}
              placeholder="Select Parameter"
              selectedValue={params.selectedParameter}
              onChange={(val) => handleOptionChange("parameter", val)}
              justify="start"
            />
          </>
        )}
      </div>

      {isRobotHistoryDataLoading && <div>Loading....</div>}

      {!isRobotHistoryDataLoading &&
        (sampledData?.data?.length > 0 ? (
          <div
            ref={chart1Ref}
            className="p-4 bg-white rounded-md  max-w-[99%] shadow-md border-slate-400"
          >
            <h1 className="text-center font-bold text-gray-600">{`Robot ${sampledData?.Robot} - ${sampledData?.Axis} [${sampledData?.Parameter}]`}</h1>
            <TrendChartWithBrush
              mainData={rawData?.data}
              brushData={sampledData?.data}
              parameter={sampledData?.Parameter}
              onZoomRange={handleZoomRange}
              onResetZoom={handleResetZoom}
              isRawLoading={isZoomLoading}
              hasZoomed={hasZoomed}
              resetToken={resetToken}
            />
          </div>
        ) : (
          <div className="text-red-600">
            No data available for the selected robot
          </div>
        ))}
    </>
  );
};

export default RobotOverloadHistory;