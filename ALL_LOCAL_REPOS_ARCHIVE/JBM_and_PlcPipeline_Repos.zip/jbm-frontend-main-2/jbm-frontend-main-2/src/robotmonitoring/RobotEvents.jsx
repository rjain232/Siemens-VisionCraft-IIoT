import React, { useEffect, useState } from "react";
import PropTypes from "prop-types";
import useAxios from "../hooks/useAxios";
import DateRangeSelector from "../common/components/DateRangeSelector ";
import { format } from "date-fns";
import Dropdown from "../common/components/Dropdown";
import withTable from "../hoc/withTable";
import DataTable from "../common/components/DataTable";
import { generate_TablePDF } from "../utils/PdfLib";
import {generateExcel} from "../utils/ExcelUtils";
import { LineName } from "../utils/constants";

const ROBOT_EVENTS_COLUMNS = [
  { label: "Event Time", accessor: "event_time" },
  { label: "Robot ID", accessor: "robot_name" },
  { label: "Event Type", accessor: "event_type" },
];

const EnhancedTable = withTable(DataTable);

const RobotEvents = ({ robot }) => {
  const [params, setParams] = useState({ parameter: null });
  const [selectedRobot, setSelectedRobot] = useState(
    robot ?? 1
  );
  const [downloading, setDownloading] = useState(false);

  const {
    data: robotEventsData,
    loading: isEventsLoading,
    error: isEventError,
    refetch: refetchRobotEvents,
  } = useAxios("/robotEvents", { method: "GET", params }, true);

  const {
    data: robotList,
    loading: isRobotLoading,
    error: isRobotError,
  } = useAxios("/robotList", { method: "GET" }, true);

  //Done by Arshiya

  const filteredFormattedEvents = robotEventsData
  ?.filter(item => Number(item.robot_id) === Number(selectedRobot))
  .map(item => ({
    ...item,
    event_time: format(new Date(item.event_time), "dd-MM-yyyy HH:mm:ss"),
  })) ?? [];


  const handleDownload = async () => {
     setDownloading(true);
    // Allow React to render loading state
    await new Promise((resolve) => setTimeout(resolve, 0));
    generate_TablePDF(ROBOT_EVENTS_COLUMNS,filteredFormattedEvents, `${LineName} Robot Events`, {startDate: params.startDate, endDate: params.endDate});
    generateExcel(ROBOT_EVENTS_COLUMNS,filteredFormattedEvents, `${LineName} Robot Events`);
    setDownloading(false);
  };

  const handleSearch = (
    startDate,
    endDate,
    duration,
    shift,
    dedicatedDuration
  ) => {
    setParams({
      startDate: format(startDate, "yyyy-MM-dd HH:mm:ss"),
      endDate: format(endDate, "yyyy-MM-dd HH:mm:ss"),
      duration,
      shift,
      dedicatedDuration,
    });
   refetchRobotEvents({
      params: {
        startDate: format(startDate, "yyyy-MM-dd HH:mm:ss"),
        endDate: format(endDate, "yyyy-MM-dd HH:mm:ss"),
        duration,
        shift,
        dedicatedDuration,
      },
    });
  };

   return (
    <>
      <DateRangeSelector
        showDownload={true}
        onDownload={handleDownload}
        onSearch={handleSearch}
        isDownloading={downloading}
      />
      {!isEventsLoading && (
        <div className="mt-4">
          <div className="mb-4">
            <Dropdown
              options={
                isRobotLoading
                  ? []
                  : robotList?.map((item) => ({
                      value: item.RobotId,
                      label: item.RobotName,
                    }))
              }
              selectedValue={selectedRobot}
              placeholder="Select Robot"
              onChange={(val) => {
               // console.log("Selected Robot:", val);
                setSelectedRobot(val);
              }}
              justify="start"
            />
          </div>

          <EnhancedTable
            // data={robotEventsData?.filter(
            //     (item) => Number(item.robot_id) === Number(selectedRobot)
            //   ) ?? []}
              data={filteredFormattedEvents}
            columns={ROBOT_EVENTS_COLUMNS}
            enableSearch={true}
            enableFilter={true}
            enablePagination={true}
          />
        </div>
      )}
    </>
  );
};
RobotEvents.propTypes = {
  robot: PropTypes.number,
};

export default RobotEvents;
