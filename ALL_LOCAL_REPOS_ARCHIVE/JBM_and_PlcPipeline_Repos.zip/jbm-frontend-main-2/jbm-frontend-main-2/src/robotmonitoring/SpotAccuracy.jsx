import React, { useState } from "react";
import DateRangeSelector from "../common/components/DateRangeSelector ";
import MultiSelect from "../common/components/MultiSelect";
import { format, parseISO } from "date-fns";
import ChartCard from "../common/testexperiments/ChartCard";
import PieChart from "../common/graphs/PieChart";
import ColumnWithMarkerChart from "../common/graphs/ColumnGraphWithMarkerChart";
import MultiLineChart from "../common/graphs/MultiLineChart";
import withTable from "../hoc/withTable";
import DataTable from "../common/components/DataTable";
import useAxios from "../hooks/useAxios";
import { Loader } from "../common/components/Loader";
import { generatePDF } from "../utils/PdfLib";
import { generateExcel } from "../utils/ExcelUtils";
import {
  addGlobalStylesForPDF,
  addPageNumber,
  cleanupChartStyles,
  pageFooterFormat,
  pageHeadFormat,
  renderChartToPDF,
  reportFromToShiftHeaders,
} from "../utils/PdfLib";
import { useRef } from "react";
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";
import { LineName } from "../utils/constants";

const spotMissTableColumn = [
  { label: "Date", accessor: "Timestamp" },
  { label: "Cabin No.", accessor: "CabinNo" },
  { label: "Robot Number", accessor: "RobotId" },
  { label: "Spot Target", accessor: "SpotTarget" },
  { label: "Spot Actual", accessor: "SpotActual" },
  { label: "Spot Miss", accessor: "SpotMiss" },
  { label: "Spot Accurracy  (%)", accessor: "SpotAccuracy" },
];

const EnhancedTable = withTable(DataTable);
const SpotAccuracy = () => {
  const [selectedValues, setSelectedValues] = useState([]);
  const [dateFilter, setDateFilter] = useState({
    startDate: null,
    endDate: null,
    duration: null,
    shift: null,
  });


  const {
    data: robotList,
    loading: isRobotLoading,
    error: isRobotError,
  } = useAxios("/robotList", { method: "GET" }, true);

  const {
    data: spotaccuracy,
    loading: isSpotAccuracyLoading,
    error: spotAccuracyError,
    refetch: refetchSpotAccuracy,
  } = useAxios("/spotaccuracy", { method: "GET" }, true);
  //console.log("spotaccuracy", spotaccuracy);

  const filteredData = selectedValues.length > 0 ? spotaccuracy?.AllSpotDataJson?.filter((robot) =>
    selectedValues.includes(Number(robot.RobotId))
  )?.sort((a, b) => new Date(a.Timestamp) - new Date(b.Timestamp)) : spotaccuracy?.AllSpotDataJson;


  // References for your charts
  const chart1Ref = useRef(null);
  const chart2Ref = useRef(null);
  const chart3Ref = useRef(null);
  //Done By Arshiya 

   const formattedData = filteredData?.map((item)=>({
       ...item,          
       Timestamp: format(parseISO(item.Timestamp),"dd-MM-yyyy")
 }))

  const exportPdfSpotAccuracyReport = async () => {
    const doc = new jsPDF();
    const chartRefs = [chart1Ref];
    reportFromToShiftHeaders(doc, dateFilter);
    addGlobalStylesForPDF();
    chartRefs.forEach((ref) => ref.current?.classList.add("pdf-export"));
    let yOffset = 50;
    await renderChartToPDF(doc, chartRefs, yOffset);
    pageHeadFormat(doc, `${LineName} Spot Accuracy Report`, false);
    doc.addPage();
    generatePDF(doc, spotMissTableColumn,formattedData, `${LineName} Spot Accuracy Report`);
    cleanupChartStyles(chartRefs);
    doc.save(`${LineName}_SpotAccuracy_Report.pdf`);
  };
  const [downloading, setDownloading] = useState(false);
  const handleDownload = async () => {
    // generatePDF(spotMissTableColumn , filteredData , "Spot Accuracy Report");
    setDownloading(true);
    await new Promise((resolve) => setTimeout(resolve, 0));
    generateExcel(spotMissTableColumn, formattedData, `${LineName} Spot Accuracy report`);
    exportPdfSpotAccuracyReport().then(() => {
      setDownloading(false);
    });
  };

  const handleSearch = (
    startDate,
    endDate,
    duration,
    shift,
    dedicatedDuration
  ) => {
    setDateFilter({
      startDate,
      endDate,
      duration,
      shift,
    });
    refetchSpotAccuracy({
      params: {
        startDate: startDate
          ? format(new Date(startDate), "yyyy-MM-dd HH:mm:ss")
          : null,
        endDate: endDate ? format(endDate, "yyyy-MM-dd HH:mm:ss") : null,
        duration,
        shift,
        dedicatedDuration,
      },
    });
  };
  if (spotAccuracyError) {
    return <div>Error in fetching spot accuracy details...</div>
  }

  return (
    <>
      <DateRangeSelector
        showDownload={true}
        onDownload={handleDownload}
        onSearch={handleSearch}
        selectedStartDate={dateFilter?.startDate}
        selectedEndDate={dateFilter?.endDate}
        selectedDuration={dateFilter?.duration}
        selectedShift={dateFilter?.shift}
        isDownloading={downloading}
      />

      <>
        <MultiSelect
          options={
            isRobotLoading
              ? []
              : robotList?.map((item) => ({
                value: item.RobotId,
                label: item.RobotName,
              }))
          }
          placeholder="Select Robot"
          onChange={(value) => {
                setSelectedValues(value);
          }}
        />
        {isSpotAccuracyLoading ? (
          <Loader />
        ) : (
          <>
            {/* Handle PieChart: Spot Miss vs Actual */}
            <div ref={chart1Ref} className="flex flex-row gap-4 mt-4">
              <div>
                <ChartCard title="Spot Accuracy">
                  {spotaccuracy?.totalMissedSpots !== null && spotaccuracy?.totalActualSpots !== null ? (
                    <PieChart
                      chartSeries={[
                        spotaccuracy.totalMissedSpots,
                        spotaccuracy.totalActualSpots,
                      ]}
                      colors={["#DC4241", "#00893D"]}
                      labels={["Spot Missed", "Spot Actual"]}
                    />
                  ) : (
                    <div className="text-gray-500 text-sm text-center py-4">
                      Spot Accuracy data not available
                    </div>
                  )}
                </ChartCard>
              </div>

              {/* Handle Line or Column Chart: robotWiseSummary */}
              <div className="flex-1">
                <ChartCard title="Spot Trend">
                  {Array.isArray(spotaccuracy?.robotWiseSummary) &&
                    spotaccuracy?.robotWiseSummary.length > 0 ? (
                    dateFilter.startDate && dateFilter.endDate ? (
                      <MultiLineChart
                        data={
                          selectedValues?.length > 0
                            ? spotaccuracy.robotWiseSummary.filter((robot) =>
                              selectedValues.includes(Number(robot.RobotId))
                            )
                            : spotaccuracy.robotWiseSummary
                        }
                        startDate={dateFilter.startDate}
                        endDate={dateFilter.endDate}
                      />
                    ) : (
                      <ColumnWithMarkerChart
                        data={
                          selectedValues?.length > 0
                            ? spotaccuracy.robotWiseSummary.filter((robot) =>
                              selectedValues.includes(robot.RobotId)
                            )
                            : spotaccuracy.robotWiseSummary
                        }
                      />
                    )
                  ) : (
                    <div className="text-gray-500 text-sm text-center py-4">
                      Spot trend data not available
                    </div>
                  )}
                </ChartCard>
              </div>
            </div>

            {/* Handle Table: filteredData */}
            <div className="mt-4">
              {filteredData?.length > 0 ? (
                <EnhancedTable
                  data={formattedData}
                  columns={spotMissTableColumn}
                  enableSearch={true}
                  enableFilter={true}
                  enablePagination={true}
                />
              ) : (
                <div className="text-gray-500 text-sm text-center py-4">
                  No table records available for selected robot(s)
                </div>
              )}
            </div>
          </>
        )}

      </>
    </>
  );
};

export default SpotAccuracy;
