import useAxios from "../hooks/useAxios";
import DateRangeSelector from "../common/components/DateRangeSelector ";
import { format } from "date-fns";
import Dropdown from "../common/components/Dropdown";
import OverloadChart from "../common/testexperiments/OverloadChart";
import { useEffect, useState } from "react";
import { generateExcel } from "../utils/ExcelUtils";
import { generatePDF } from "../utils/PdfLib";
import {
  addGlobalStylesForPDF,
  cleanupChartStyles,
  pageHeadFormat,
  renderChartToPDF,
  reportFromToShiftHeaders,
} from "../utils/PdfLib";
import { useRef } from "react";
import { jsPDF } from "jspdf";
import { validateDateRange } from "../utils/validators";
import { LineName } from "../utils/constants";

const robotHistoryTableColumn = [
  { label: "RobotId", accessor: "RobotId" },
  { label: "Axis", accessor: "Axis" },
  { label: "Current", accessor: "Current" },
  { label: "Torque", accessor: "Torque" },
  { label: "Temperature", accessor: "Temperature" },
  { label: "Timestamp", accessor: "Timestamp" },
];
const RobotHistoryTrend = () => {
  const [params, setParams] = useState({ parameter: null }); // API parameters
  const [selectedRobot, setSelectedRobot] = useState("01"); // State to manage selected robot
  const [selectedAxis, setSelectedAxis] = useState("Axis1");
  const [downloading, setDownloading] = useState(false);
  const {
    data: robotList,
    loading: isRobotLoading,
    error: isRobotError,
    refetch: refetchRobotList,
  } = useAxios("/robotList", { method: "GET" }, true);

  const {
    data: robotHistoryData,
    loading: isRobotHistoryDataLoading,
    error: isRobotHistoryDataError,
    refetch: refetchRobotHistoryData,
  } = useAxios("/robotHistory", { method: "GET", params }, true);

  const [dateFilter, setDateFilter] = useState({
    startDate: null,
    endDate: null,
    duration: null,
  });

  // const [filteredData , setFilteredData] = useState(robotHistoryData?.data)
  console.log("Selected Robot:", selectedRobot, "Selected Axis:", selectedAxis);
  // useEffect(() => {
  //   const filtered = robotHistoryData?.data?.filter((item) => Number(item.RobotId) === Number(selectedRobot) && item.Axis == selectedAxis);
  //   setFilteredData(filtered);
  // }, [robotHistoryData, selectedRobot, selectedAxis]);

  useEffect(() => {
    setParams((prev) => ({
      ...prev,
      selectedRobot,
      selectedAxis,
    }));
  }, [selectedRobot, selectedAxis]);

  // References for your charts
  const chart1Ref = useRef(null);
  /// const chart2Ref = useRef(null);
  // const chart3Ref = useRef(null);

  const exportPdfOverloadhistoryReport = async () => {
    const doc = new jsPDF();
    const chartRefs = [chart1Ref];
    reportFromToShiftHeaders(doc, dateFilter);
    addGlobalStylesForPDF();
    chartRefs.forEach((ref) => ref.current?.classList.add("pdf-export"));
    let yOffset = 50;
    await renderChartToPDF(doc, chartRefs, yOffset);
    pageHeadFormat(doc, `${LineName} Robot Overload History`, false);
    doc.addPage();
    generatePDF(
      doc,
      robotHistoryTableColumn,
      robotHistoryData?.data,
      `${LineName} Robot Overload History`,
    );
    cleanupChartStyles(chartRefs);
    doc.save(`${LineName}_Robot_Overload_History.pdf`);
  };

  const handleDownload = async () => {
    setDownloading(true);
    // Allow React to render loading state
    await new Promise((resolve) => setTimeout(resolve, 0));
    generateExcel(
      robotHistoryTableColumn,
      robotHistoryData?.data,
      `${LineName} Robot Overload History`,
    );
    exportPdfOverloadhistoryReport().then(() => {
      setDownloading(false);
    });
  };

  const handleSearch = (
    startDate,
    endDate,
    duration,
    dedicatedDuration,
  ) => {
    setDateFilter({
      startDate,
      endDate,
      duration,
    });
    const { error, errorMsg } = validateDateRange(startDate, endDate);
    if (error) {
      alert(errorMsg);
      return;
    }
    setParams({
      startDate: format(startDate, "yyyy-MM-dd HH:mm:ss"),
      endDate: format(endDate, "yyyy-MM-dd HH:mm:ss"),
      duration,
      dedicatedDuration,
      selectedRobot,
      selectedAxis,
    });
  };
  const axisCount = [7, 8, "7", "8"].includes(selectedRobot) ? 9 : 8;

  if (isRobotError) {
    console.error("Error fetching robot list:", isRobotError);
    return <div className="text-red-600">Error fetching robot list</div>;
  }

  if (isRobotHistoryDataError) {
    console.error(
      "Error fetching robot history data:",
      isRobotHistoryDataError,
    );
    return (
      <div className="text-red-600">Error fetching robot history data</div>
    );
  }

  return (
    <>
      <DateRangeSelector
        showDownload={true}
        onDownload={handleDownload}
        onSearch={handleSearch}
        selectedStartDate={dateFilter?.startDate}
        selectedEndDate={dateFilter?.endDate}
        isDownloading={downloading}
      />
      <div className="mb-4 flex items-center gap-4">
        {!isRobotLoading && (
          <>
            <Dropdown
              options={
                isRobotLoading
                  ? []
                  : robotList?.map((robot) => ({
                      value: robot.RobotId,
                      label: robot.RobotName,
                    }))
              }
              selectedValue={selectedRobot}
              placeholder="Select Robot"
              onChange={(val) => {
                //console.log("Selected Robot:", val);
                setSelectedRobot(val);
              }}
              justify="start"
            />
            <Dropdown
              options={Array.from({length: axisCount }, (_, i) => ({
                value: `Axis${i + 1}`,
                label: `Axis ${i + 1}`,
              }))}
              placeholder="Select Axis"
              selectedValue={selectedAxis}
              onChange={(val) => {
                setSelectedAxis(val);
                console.log("Selected Axis", val);
              }}
              justify="start"
            />
          </>
        )}
      </div>
      {isRobotHistoryDataLoading && <div>Loading....</div>}

      {!isRobotHistoryDataLoading &&
        (robotHistoryData?.data?.filter(
          (item) => Number(item.RobotId) === Number(selectedRobot),
        ).length > 0 ? (
          <div ref={chart1Ref}>
            <OverloadChart
              //data={filteredData}
              data={robotHistoryData?.data}
              title={`Robot ${robotHistoryData?.Robot} - ${robotHistoryData?.Axis}`}
              currentLowerLimit={robotHistoryData?.currentLowerLimit ?? 0.5}
              currentUpperLimit={robotHistoryData?.currentUpperLimit ?? 1.5}
            />
          </div>
        ) : (
          <div className="text-red-600">
            No data available for the selected robot
          </div>
        ))}
    </>
  );
};

export default RobotHistoryTrend;
