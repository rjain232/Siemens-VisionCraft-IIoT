const express = require("express");
const router = express.Router();
const multer = require("multer");
const path = require("path");
const userController = require("../controllers/User.Controller");
const DashboardController = require("../controllers/Dashboard.Controller");
const DowntimeLog = require("../controllers/DowntimeLog.Controller");
const RobotHistoryController = require("../controllers/RobotHistory.Controller");
const MachineSetUpData = require("../controllers/MachinesetUpTime.Controller");
const CycletimeData = require("../controllers/CycleTimeData.Controller");
const Maintenance=require("../controllers/Maintenance.Controller");
const Safety =require("../controllers/Safety.Controller");
const sendEmail=require("../middlewares/SendEmail");
const stationwiseoee=require("../controllers/OEE.controller");
const RobotMonitoring=require("../controllers/RobotMonitoring.controller")
const Production =require("../controllers/Production.Controller");
const PowerConsumption =require("../controllers/PowerConsumption.Controller");
const StationLayout = require("../controllers/StationLayout.Controller");
const Notification =require("../controllers/Notification.Controller")
const { verifyToken } = require("../middlewares/Auth");
const { verifyLicense } = require("../middlewares/VerifyLicense");



// Use the same storage config as above
const storage = multer.diskStorage({
  destination: "uploads/",
  filename: (req, file, cb) => {
    cb(null, Date.now() + "-" + file.originalname);
  },
});
const upload = multer({ storage });

router.get("/license/status" , (req, res) => {
  try {
    const license = verifyLicense();
    console.log("License" ,license)
    res.json({
      valid: true,
      customer: license.customer,
      expiryDate: license.expiryDate,
    });
  } catch (err) {
    res.status(403).json({
      valid: false,
      message: err.message,
    });
  }
})

router.post("/login", userController.login);
router.get("/dashboard", DashboardController.getDashboardData);


router.get("/safetyalarms", Safety.getSafetyAlarms);
router.get("/robotEditLogs", RobotMonitoring.getRobotEditLogs);
router.get("/robotLogs", RobotMonitoring.getRobotLogs);
router.get("/setupData", MachineSetUpData.getMachineSetUpData);

router.get("/user-profile" , verifyToken , userController.getUserProfile);
router.post("/sendEmail", upload.array("files"),sendEmail.sendEmail);

//#region Maintenance API 
 router.get("/complianceData" , Maintenance.getComplianceData ) ;
 router.get("/getTools" , Maintenance.getTools);
 router.get("/getActivities" , Maintenance.getActivities);
router.get("/toolactivity",Maintenance.getToolActivity);
router.get("/alarms", Maintenance.Downtime_Report);
router.get("/alarmreport",Maintenance.AlarmReport);
router.get("/top10alarms",Maintenance.Top10Alarm);
router.get("/atcinterruption",Maintenance.ATCInterruption);
router.get("/miscellaneousAlarms",Maintenance.MiscellaneousAlarms);
router.get("/tipchangecount",Maintenance.TipChangeCount);
router.post("/updateTool_Maintenance",Maintenance.updateTool_Maintenance); 
router.post("/upload" ,upload.single('file'), Maintenance.uploadActivities)
router.get("/stations" , Maintenance.getStations);
 // //#endregion

//#region OEE API 
router.get("/stationwiseoee",stationwiseoee.stationwiseOEE);
router.get("/top10faults",stationwiseoee.top10faults);
router.get("/overallOEE",stationwiseoee.overallOEE);
//#endregion

//#region RobotMonitoring API 
router.get("/robothealth",RobotMonitoring.RobotHealth);
router.get("/robotEvents",RobotMonitoring.getRobotEventLogs);
router.get("/robotList",RobotMonitoring.getRobotList);
router.get("/spotaccuracy",RobotMonitoring.getSpotAccuracy);
router.get("/robotHistory", RobotMonitoring.getRobotOverloadHistoryTrendData)
router.get("/robotHistoryRawData", RobotMonitoring.getRobotOverloadHistoryRawData)
router.get("/param-config", RobotMonitoring.getParamConfig);
//#endregion

//#region Production API 
router.get("/productionOverview",Production.ProductionOverview);
router.get("/productionReport",Production.ProductionReport);
router.get("/hourly_production_report",Production.Hourly_Production_Report);
router.get("/detailedProductionReport",Production.DetailedProductionReport);
router.get("/cycleTimeData", Production.CycleTimeData);
router.post("/updateOkNokCount", Production.updateOkNokCount);
 // //#endregion

 //#region Power Consumption APIS
 router.get("/powerConsumptionDetails" , PowerConsumption.getPowerConsumption)
 //#endregiom

 //#region Safety component details
 router.get("/getComponentStatus" , StationLayout.getSafetyComponentsStatus)
 //#endregion

  //#region SNotification
  router.get("/notification",Notification.getNotification_PendingToolActivity);
   //#endregion


module.exports = router;
