//#region dummydata 
const dummydata_DowntimeRport=[
    {
      Id : 1,
      Date: "30-01-2025",
      Time: "10:30:00",
      AlarmCode: "A123",
      AlarmReason : "Robot Collision",
      Type : "Alarm",
      DownTime: "15",
      Remark:""
    },
    {
      Id : 2,
      Date: "30-01-2025",
      Time: "11:45:00",
      AlarmCode: "B456",
      Type:"Warning",
      AlarmReason:"Weight Exceeded",
      DownTime: "30",
        Remark:""
    },
    {
      Id : 3,
      Date: "30-01-2025",
      Time: "13:15:00",
      AlarmCode: "C789",
      Type : "Alarm",
      AlarmReason : "Emergency stop activated",
      DownTime: "10",
        Remark:""
    },
    {
      Id : 4,
      Date: "30-01-2025",
      Time: "13:15:00",
      AlarmCode: "C789",
      Type:"Warning",
      AlarmReason:"Safety gate opened",
      DownTime: "10",
        Remark:""
    },
    {
      Id : 5,
      Date: "30-01-2025",
      Time: "13:15:00",
      AlarmCode: "C789",
      Type : "Alarm",
      AlarmReason:"Collision detected",
      DownTime: "10",
        Remark:""
    },
    {
      Id : 6,
      Date: "30-01-2025",
      Time: "13:15:00",
      AlarmCode: "C789",
      Type : "Alarm",
      AlarmReason:"Workcell safety sensor triggered",
      DownTime: "10",
        Remark:""
    },
  ];
const downtimeData=
[
  { date: "2025-01-30", downtimeInMinutes: 75 },
  { date: "2025-01-31", downtimeInMinutes: 45 },
  { date: "2025-02-01", downtimeInMinutes: 20 },
  { date: "2025-02-02", downtimeInMinutes: 60 },
  { date: "2025-02-03", downtimeInMinutes: 25 },
  { date: "2025-02-04", downtimeInMinutes: 40 },
  { date: "2025-02-05", downtimeInMinutes: 50 },
  { date: "2025-02-06", downtimeInMinutes: 42 },
  { date: "2025-02-07", downtimeInMinutes: 28 },
  { date: "2025-02-08", downtimeInMinutes: 58 },
];
const Top10alarmData = [
  { count: 6, Code: "Alarm A", time: 7050 },
  { count: 2, Code: "Alarm B", time: 2500 },
  { count: 8, Code: "Alarm C", time: 8000 },
  { count: 4, Code: "Alarm D", time: 4500 },
  { count: 5, Code: "Alarm E", time: 5000 },
  { count: 3, Code: "Alarm F", time: 3000 },
  { count: 7, Code: "Alarm G", time: 6500 },
  { count: 5, Code: "Alarm H", time: 5000 },
  { count: 9, Code: "Alarm I", time: 9500 },
  { count: 10, Code: "Alarm J", time: 12000 },
];
const AlarmsReport = [
  {
      Date: "30-01-2025",
      Time: "10:30:00",
      AlarmCode: "LSE12",
      AlarmReason: "Limit switch error",
      Type: "Alarm",
      DownTime: "15",
  },
  {
      Date: "30-01-2025",
      Time: "11:45:00",
      AlarmCode: "WE456",
      Type: "Warning",
      AlarmReason: "Weld error",
      DownTime: "30",
  },
  {
      Date: "30-01-2025",
      Time: "13:15:00",
      AlarmCode: "SCA89",
      Type: "Alarm",
      AlarmReason: "Spot count error",
      DownTime: "10",
  },
  {
      Date: "30-01-2025",
      Time: "13:15:00",
      AlarmCode: "C789",
      Type: "Warning",
      AlarmReason: "Profinet communication error",
      DownTime: "10",
  },
  {
      Date: "30-01-2025",
      Time: "13:15:00",
      AlarmCode: "TP789",
      Type: "Alarm",
      AlarmReason: "Tackle not in home position",
      DownTime: "10",
  },
  {
      Date: "30-01-2025",
      Time: "13:15:00",
      AlarmCode: "TCE78",
      Type: "Alarm",
      AlarmReason: "Torque control error",
      DownTime: "10",
  },
];
const ATCInterruption_data = [
  {
    date: "20-02-2025",
    time: "08:15:30",
    faultCode: "E101",
    deviceId: "D001",
  },
  {
    date: "20-02-2025",
    time: "09:30:45",
    faultCode: "E202",
    deviceId: "D002",
  },
  {
    date: "20-02-2025",
    time: "10:05:12",
    faultCode: "E303",
    deviceId: "D003",
  },
  {
    date: "20-02-2025",
    time: "11:20:50",
    faultCode: "E404",
    deviceId: "D004",
  },
  {
    date: "20-02-2025",
    time: "12:45:35",
    faultCode: "E505",
    deviceId: "D005",
  },
  {
    date: "20-02-2025",
    time: "14:10:20",
    faultCode: "E606",
    deviceId: "D006",
  },
  {
    date: "20-02-2025",
    time: "15:25:55",
    faultCode: "E707",
    deviceId: "D007",
  },
  {
    date: "20-02-2025",
    time: "16:40:10",
    faultCode: "E808",
    deviceId: "D008",
  },
  {
    date: "20-02-2025",
    time: "17:55:05",
    faultCode: "E909",
    deviceId: "D009",
  },
  {
    date: "20-02-2025",
    time: "19:15:40",
    faultCode: "E010",
    deviceId: "D010",
  },
];
const MiscellaneousAlarms_data = [
  {
      timestamp: "2025-03-17 10:15:30",
      alarmname: "Tip Dress",
      alarmdescription: "Robot 1 Tip Dress Required",
    
  },
  {
      timestamp: "2025-03-17 10:20:40",
      alarmname: "Tip Change",
      alarmdescription: "Robot 2 Tip Change Required",
   
  },
  {
      timestamp: "2025-03-17 10:35:10",
      alarmname: "Tip Dress Sensor Malfunction",
      alarmdescription: "Robot 3 Tip Dress Sensor Malfunction",
    
  },
  {
      timestamp: "2025-03-17 11:40:30",
      alarmname: "Tip Not Seated Properly",
      alarmdescription: "Robot 4 Tip Not Seated Properly",
   
  },
  {
      timestamp: "2025-03-17 11:55:40",
      alarmname: "Tip Life Exceeded",
      alarmdescription: "Robot 5 Tip Life Exceeded",
    
  },
  
];
const tipchange_Bardata =
[
    { RobotId: 'R10001', TipChangeCount: 24 },
    { RobotId: 'R10002', TipChangeCount: 26 },
    { RobotId: 'R10003', TipChangeCount: 24 },
    { RobotId: 'R10004', TipChangeCount: 23 },
    { RobotId: 'R10005', TipChangeCount: 26 },
    { RobotId: 'R10006', TipChangeCount: 23 },
    { RobotId: 'R10007', TipChangeCount: 29 },
    { RobotId: 'R10008', TipChangeCount: 24 },
    { RobotId: 'R10009', TipChangeCount: 19 },
    { RobotId: 'R100010', TipChangeCount: 24 }
]
const tipchangeTable_data = [
{
    timestamp: "2025-03-17 10:15:30",
    robotid: "R10001",
    tipchangecount: "24",

},
{
    timestamp: "2025-03-17 10:20:40",
    robotid: "R10002",
    tipchangecount: "26",

},
{
    timestamp: "2025-03-17 10:35:10",
    robotid: "R10003",
    tipchangecount: "24",

},
{
    timestamp: "2025-03-17 11:40:30",
    robotid: "R10004",
    tipchangecount: "23",

},
{
    timestamp: "2025-03-17 11:55:40",
    robotid: "R10005",
    tipchangecount: "26",

},

];
//#endregion