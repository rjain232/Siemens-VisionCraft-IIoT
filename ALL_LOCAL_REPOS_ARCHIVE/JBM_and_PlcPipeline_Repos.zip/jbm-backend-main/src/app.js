const express = require("express");
const cors = require("cors");
const path = require("path");
const route = require("./routes/route.js");
const { localSequelize } = require("./db/connection.js");
const bodyParser = require("body-parser");
require("dotenv").config();
const uploadsPath = path.join(__dirname, "uploads");
const fs = require("fs");
const { verifyLicense } = require("../src/middlewares/VerifyLicense.js")

// console.log("JWT_SECRET_KEY:", process.env.JWT_SECRET_KEY);
// console.log("JWT_TOKEN_EXPIRY:", process.env.JWT_TOKEN_EXPIRY);
// Create uploads folder if it doesn't exist

if (!fs.existsSync(uploadsPath)) {
  fs.mkdirSync(uploadsPath, { recursive: true });
  console.log("Uploads folder created.");
}

const app = express();
const port = process.env.PORT || 9000;

app.use(cors()); // 👈 This enables CORS for all origins


// Middleware
app.use(
  cors({ origin: "*", allowedHeaders: ["Content-Type", "authorization"] })
);
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Static Files
const filePath = path.join(__dirname, "public", "files");
app.use(express.static(filePath));

// Serve Uploaded Files
app.use("/uploads", express.static(uploadsPath));
// Database Connection
localSequelize
  .sync()
  .then(() => {
    console.log("Database connected successfully.");
  })
  .catch((error) => {
    console.error("Unable to connect to the database:", error);
  });

// app.use((req, res, next) => {
//   try {
//     verifyLicense();
//     next();
//   } catch (err) {
//     return res.status(403).json({
//       success: false,
//       message: err.message,
//     });
//   }
// });

// API Routes
app.use("/api", route);

// 404 Handler
app.use((req, res, next) => {
  res.status(404).json({ error: "Route not found" });
});

// Global Error Handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: "Internal Server Error" });
});

// Start Server
app.listen(port, () => {
  console.log("Express app running on port " + port);
});
