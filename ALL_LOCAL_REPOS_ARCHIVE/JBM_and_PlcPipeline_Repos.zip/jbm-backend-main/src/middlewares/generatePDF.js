const fs = require("fs");
const path = require("path");
const { format } = require("date-fns");
const PdfPrinter = require("pdfmake");

// Load fonts for pdfmake
const fonts = {
  Roboto: {
    normal: path.join(__dirname, "../fonts/Roboto-Regular.ttf"),
    bold: path.join(__dirname, "../fonts/Roboto-Medium.ttf"),
    italics: path.join(__dirname, "../fonts/Roboto-Italic.ttf"),
    bolditalics: path.join(__dirname, "../fonts/Roboto-MediumItalic.ttf"),
  },
};

const printer = new PdfPrinter(fonts);

// Load and convert logos to base64
const netPositiveLogo = fs.readFileSync(path.join(__dirname, "../assets/Netp_Logo_2.10.png")).toString("base64");
const jbmLogo = fs.readFileSync(path.join(__dirname, "../assets/jbm_logo.png")).toString("base64");
const dhruvaLogo = fs.readFileSync(path.join(__dirname, "../assets/DhruvaLogo.png")).toString("base64");

const generatePDF = (headers, rows, title, filePath) => {
   return new Promise((resolve, reject) => {
  const tableBody = [
    headers.map((h) => ({ text: h.label, style: "tableHeader" })),
    ...rows.map((row) =>
      headers.map((h) => ({
        text: row[h.accessor] ? String(row[h.accessor]) : "",
        style: "tableCell",
      }))
    ),
  ];

  const docDefinition = {
    pageOrientation: "portrait",
    content: [
      {
        columns: [
          { image: `data:image/png;base64,${jbmLogo}`, width: 100 },
          { text: title, alignment: "center", style: "title", margin: [0, 25, 0, 0] },
          { image: `data:image/png;base64,${netPositiveLogo}`, width: 100, alignment: "right" },
        ],
        margin: [0, 0, 0, 10],
      },
      {
        table: {
          headerRows: 1,
          widths: Array(headers.length).fill("auto"),
          body: tableBody,
        },
        layout: {
          fillColor: (rowIndex) => (rowIndex === 0 ? "#3ec9b1" : rowIndex % 2 === 0 ? "#f0f0f0" : null),
        },
      },
    ],
    footer: (currentPage, pageCount) => {
      return {
        margin: [40, 10],
        columns: [
          {
            width: '*',
            text: `Printed on: ${format(new Date(), "dd-MM-yyyy HH:mm:ss")}`,
            alignment: 'left',
            fontSize: 8
          },
          {
            width: 'auto',
            text: `Page ${currentPage} of ${pageCount}`,
            alignment: 'center',
            fontSize: 8
          },
          {
            width: '*',
            margin: [0, 0, 10, 0], // Optional margin for entire stack
            stack: [
              {
                text: "Developed by",
                fontSize: 8,
                alignment: "right",         // Apply right alignment here
                margin: [0, 0, 50, 2]        // Move text to left by adding RIGHT margin
              },
              {
                image: `data:image/png;base64,${dhruvaLogo}`,
                width: 50,
                alignment: "right",         // Align image right
                margin: [0, -17, 0, 0]        // Move image slightly upward
              }
            ]
          }


        ]
      };
    },

    styles: {
      title: { fontSize: 18, bold: true },
      tableHeader: { bold: true, fontSize: 12, color: "white", fillColor: "#3ec9b1", alignment: "center" },
      tableCell: { fontSize: 10, alignment: "center", margin: [0, 4] },
    },
    defaultStyle: {
      font: "Roboto",
    },
  };

  const pdfDoc = printer.createPdfKitDocument(docDefinition);
  const writeStream = fs.createWriteStream(filePath);
  pdfDoc.pipe(writeStream);
  pdfDoc.end();

   // 🔥 This ensures zip only happens *after* file is written
    writeStream.on("finish", () => resolve());
    writeStream.on("error", (err) => reject(err));
     });
};

module.exports = { generatePDF };
