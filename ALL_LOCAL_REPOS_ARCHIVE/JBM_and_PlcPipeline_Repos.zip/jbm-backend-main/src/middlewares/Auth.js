const jwt = require("jsonwebtoken");
require("dotenv").config();
const SECRET_KEY = process.env.JWT_SECRET_KEY;
const TOKEN_EXPIRY = process.env.JWT_TOKEN_EXPIRY;

const verifyToken = (req, res, next) => {
    const token = req.headers["authorization"].split(" ")[1];
    console.log("token" , token);
    if (!token) return res.status(403).json({ message: "No token provided" });

    
  
    jwt.verify(token, SECRET_KEY, { algorithms: ["HS512"] }, (err, decoded) => {
      if (err) return res.status(401).json({ message: "Unauthorized" });
      req.user = decoded; // Attach user payload from token
      next();
    });
  };

module.exports = {verifyToken};
