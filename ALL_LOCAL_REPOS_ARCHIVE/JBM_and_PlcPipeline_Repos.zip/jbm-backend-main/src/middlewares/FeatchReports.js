const axios = require("axios");
const {getAlramsData}=require("../controllers/DowntimeLog.Controller");

async function FeatchReports() {
//   try {
//     // Call your own API to get alarm data
//    const response = await axios.get("http://localhost:9000/api/alarms"); 
   
//     if (response.data.success) {
//       return response.data.data; // Extract alarms data
//     } else {
//       console.error("Failed to fetch alarms:", response.data.message);
//       return [];
//     }
//   } catch (error) {
//     console.error("Error fetching alarms:", error.message);
//     return [];
//   }
try {
    const data = getAlramsData(); // direct function call
    return data;
  } catch (error) {
    console.error("Error fetching alarms:", error.message);
    return [];
  }
}
module.exports={FeatchReports};