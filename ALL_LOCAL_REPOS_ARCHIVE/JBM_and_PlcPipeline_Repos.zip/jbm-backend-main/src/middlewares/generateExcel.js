const XLSX = require("xlsx");
const fs = require("fs");
const PDFDocument = require("pdfkit");
const ExcelJS = require("exceljs");

const generateExcel = async (data, filePath) => {
    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet("Reports");
  
    sheet.columns = Object.keys(data[0] || {}).map((key) => ({ header: key, key, width: 20 }));
  
    data.forEach((entry) => sheet.addRow(entry));
    await workbook.xlsx.writeFile(filePath);
};

const generatePDF = (data, filePath) => {
    const doc = new PDFDocument();
    doc.pipe(fs.createWriteStream(filePath));
  
    doc.fontSize(16).text("Scheduled Report", { align: "center" }).moveDown();
    data.forEach((entry, index) => {
      doc.text(`${index + 1}. ${JSON.stringify(entry)}`).moveDown();
    });
  
    doc.end();
};

module.exports = { generateExcel };
