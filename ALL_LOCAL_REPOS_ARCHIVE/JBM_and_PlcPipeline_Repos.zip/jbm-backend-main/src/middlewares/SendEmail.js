const nodemailer = require("nodemailer");
const { getToolActivity } = require("../controllers/Maintenance.Controller");
const { getAlarms, getAlarmsData } = require("../controllers/DowntimeLog.Controller");
const cron = require("node-cron");
const axios = require("axios");
const path = require("path"); 
const { generateExcel }=require("../middlewares/generateExcel");
const{FeatchReports}=require("../middlewares/FeatchReports");
const {generatePDF}=require("../middlewares/generatePDF");
const fs = require("fs");
const archiver = require("archiver");
// Nodemailer Transporter
// const transporter = nodemailer.createTransport({
//   service: "gmail", // Change to your email service
//   auth: {
//     user: process.env.EMAIL_USER, // Your Gmail
//     pass: process.env.EMAIL_PASS, // App password (2FA enabled)
//   },
// });
const transporter = nodemailer.createTransport({
  host: "smtpout.asia.secureserver.net",         // Replace with actual SMTP server
  port: 465,                     // Use 587 for TLS or 465 for SSL
  secure: true,                 // false for TLS (587), true for SSL (465)
  auth: {
    user: process.env.EMAIL_USER, // "akash.lad@dacpl.in"
    pass: process.env.EMAIL_PASS  // Your official email password or app password #Dhruva2024#
  },
});
transporter.verify((error, success) => {
  if (error) {
    console.error("SMTP connection error:", error);
  } else {
    console.log("SMTP server is ready to send messages");
  }
});


// async function FeatchReports() {
//   try {
//     // Call your own API to get alarm data
//     const response = await axios.get("http://localhost:9000/api/alarms"); 
//    // const response =await getAlarmsData();
//     if (response.data.success) {
//       return response.data.data; // Extract alarms data
//     } else {
//       console.error("Failed to fetch alarms:", response.data.message);
//       return [];
//     }
//   } catch (error) {
//     console.error("Error fetching alarms:", error.message);
//     return [];
//   }
// }

// Email Sending Function
const sendEmail = async (req, res) => {
  try {
    // if (!req.files || req.files.length === 0) {
    //   return res.status(400).json({ success: false, error: "No files were uploaded." });
    // }

    // const { subject, body, recipient } = req.body;

    // if (!subject || !body || !recipient) {
    //   return res.status(400).json({ success: false, error: "Subject, body, and recipient are required." });
    // }
   // Fetch report data
   const reports = await FeatchReports();

   if (!reports || reports.length === 0) {
     return res.status(400).json({ success: false, error: "No reports available to send." });
   }
   const columnKeys = reports && reports.length > 0 ? Object.keys(reports[0]) : [];
   const headers = columnKeys.map(key => ({
    label: key.charAt(0).toUpperCase() + key.slice(1), // Capitalize first letter
    accessor: key
  }));
   // Define file paths
    const pdfPath = path.join(__dirname, "reports.pdf");
    const excelPath = path.join(__dirname, "reports.xlsx");
    const zipPath = path.join(__dirname, "reports.zip");
   // Generate Reports
   await generatePDF(headers,reports,"Alarm Report", pdfPath);
   await generateExcel(reports, excelPath);

    // Create ZIP file
    const output = fs.createWriteStream(zipPath);
    const archive = archiver("zip", { zlib: { level: 9 } });
     // Handle stream events
    output.on("close", async () => {
      console.log(`Zip created: ${zipPath} (${archive.pointer()} total bytes)`);

      // Prepare mail with ZIP attachment
      const mailOptions = {
        from: process.env.EMAIL_USER,
        to: "akash.lad@dacpl.in",
        subject: "Scheduled Report",
        text: "Please find the zipped report attached.",
        attachments: [{ filename: "reports.zip", path: zipPath }],
      };

      await transporter.sendMail(mailOptions);

      // Cleanup
      fs.unlinkSync(pdfPath);
      fs.unlinkSync(excelPath);
      fs.unlinkSync(zipPath);

      if (res) {
        return res.json({ success: true, message: "Email with zip sent successfully!" });
      } else {
        console.log("Email sent successfully with zip!");
      }
    });

    archive.on("error", err => {
      throw err;
    });

    // Pipe archive to the file
    archive.pipe(output);

    // Append files
    archive.file(pdfPath, { name: "reports.pdf" });
    archive.file(excelPath, { name: "reports.xlsx" });

    // Finalize the archive
    await archive.finalize();

  } catch (error) {
    console.error("Error sending email:", error);
    res.status(500).json({ success: false, error: error.message });
  }
};

// Schedule email at 9 AM daily
cron.schedule("27 11 * * *", async () => {
  console.log("Fetching reports and sending email...");
  
 // await sendEmail();
});
module.exports = { sendEmail };
