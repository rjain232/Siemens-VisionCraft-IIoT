const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const rootDir = path.resolve(__dirname, "../..");
const publicKeyPath = path.join(rootDir, "public.pem");
const licensePath = path.join(rootDir, "license.json");

const verifyLicense = (req, res, next) => {
  if (!fs.existsSync(publicKeyPath) || !fs.existsSync(licensePath)) {
    return {
      customer: "local-dev",
      expiryDate: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString(),
    };
  }

  const publicKey = fs.readFileSync(publicKeyPath);
  const license = JSON.parse(fs.readFileSync(licensePath));

  const verify = crypto.createVerify("SHA256");

  verify.update(JSON.stringify(license.data));
  verify.end();

  const valid = verify.verify(publicKey, license.signature, "base64");

  if (!valid) {
    throw new Error("Invalid license");
  }

  const expiry = new Date(license.data.expiryDate);

  if (new Date() > expiry) {
    throw new Error("License expired");
  }

  return license.data;
};

module.exports = { verifyLicense };
