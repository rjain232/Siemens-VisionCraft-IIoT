const ToolActivity = [
    {
        Id: "1",
        ActivityName: "Cleaning",
        ToolId: "Tool 1",
        Remark:""

    },
    {
        Id: "2",
        ActivityName: "Check Alignment",
        ToolId: "Tool 1",
        Remark:""
    }, {
        Id: "3",
        ActivityName: "Check Air Pressure",
        ToolId: "Tool 1",
        Remark:""
    },
    {
        Id: "4",
        ActivityName: "Cleaning",
        ToolId: "Tool 2",
        Remark:""

    },
    {
        Id: "5",
        ActivityName: "Check Alignment",
        ToolId: "Tool 2",
        Remark:""
    }, {
        Id: "6",
        ActivityName: "Check Air Pressure",
        ToolId: "Tool 2",
        Remark:""
    }
];
module.exports=ToolActivity;