const {localSequelize: sequelize} = require('../db/connection.js');
const getProductionSummaryByRange = async (rangeKey) => {
  try {
    const result = await sequelize.query(
      'EXEC dbo.sp_GetProductionSummaryByRange @RangeKey = :rangeKey',
      {
        replacements: { rangeKey },
        type: sequelize.QueryTypes.SELECT
      }
    );

    console.log('Summary:', result);
    return result;
  } catch (error) {
    console.error('Error executing SP:', error);
    throw error;
  }
};

// Example call
//getProductionSummaryByRange(5); // Get summary for current month
module.exports = {
  getProductionSummaryByRange,
};