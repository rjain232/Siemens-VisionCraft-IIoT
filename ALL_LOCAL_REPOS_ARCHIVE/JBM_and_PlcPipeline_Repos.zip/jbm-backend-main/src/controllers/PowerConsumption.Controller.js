const { localSequelize } = require("../db/connection");
const {
  executeStoredProc,
  executeStoredProcWithDateFilter,
  executeQuery,
} = require("../utils/StoredProcedureExecutor");

const getPowerConsumption = async (req, res) => {
  try {
    const { startDate, endDate, shift } = req.query;
    console.log(startDate, endDate, "startDate , endDate");
    let result;
    const daywisePowerConsumptionData = await executeQuery(
      localSequelize,
      "EXEC SP_CurrentWeek_Power_Consumption_Distribution @StartDate = :startDate, @EndDate = :endDate",
      { startDate: startDate || null, endDate: endDate || null }
    );
    const powerConsumption = await executeQuery(
      localSequelize,
      "EXEC SP_Card_Power_Consumption_Distribution @StartDate = :startDate, @EndDate = :endDate",
      { startDate: startDate || null, endDate: endDate || null }
    );
    const shiftWiseCount = await executeQuery(
      localSequelize,
      "EXEC SP_Shiftwise_Power_Consumption_Distribution @StartDate = :startDate, @EndDate = :endDate",
      { startDate: startDate || null, endDate: endDate || null }
    );
    const powerData = powerConsumption?.[0] || {};


    console.log("powerConsumption", powerConsumption);
    console.log("daywisePowerConsumptionData", daywisePowerConsumptionData);
    console.log("shiftWiseCount", shiftWiseCount);

    if (!powerConsumption || powerConsumption.length === 0) {
      return res.status(200).json({ data : [] ,error: "No power consumption data found" });
    }
    const powerConsumptionData = [
      {
        title: "Total Power Used",
        value: powerData.powerConsumption != null
          ? `${powerData.powerConsumption.toFixed(2)} kWh`
          : 0,
      },
      {
        title: "Total Cabins Produced",
        value: powerData.CabinProduced != null
          ? `${powerData.CabinProduced}`
          : 0,
      },
      {
        title: "Avg Power Per Cabin",
        value: powerData.AvgPowerPerCabin != null
          ? `${powerData.AvgPowerPerCabin.toFixed(2)} kWh`
          : 0,
      },
    ];

    result = {
      powerConsumptionData,
      daywisePowerConsumptionData,
      shiftWiseCount,
    };
    console.log("result", result);
    res.status(200).json({ data: result });
  } catch (error) {
    console.error("Error fetching data:", error);
    res.status(500).json({ error: "Internal Server Error at overallOEE" });
  }
};

module.exports = {
  getPowerConsumption,
};
