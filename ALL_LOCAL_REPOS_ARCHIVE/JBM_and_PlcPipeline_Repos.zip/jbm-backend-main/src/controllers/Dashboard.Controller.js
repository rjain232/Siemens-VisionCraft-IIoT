const { format, startOfDay,  startOfWeek, endOfWeek, startOfMonth, endOfMonth, startOfQuarter, endOfQuarter, startOfYear, endOfYear, subDays, subMonths, subQuarters  } = require('date-fns');
const { enIN } = require('date-fns/locale');
const { localSequelize: sequelize } = require("../db/connection.js");
const { getProductionSummaryByRange } = require('../Data/DashboardUtils');
const {
  executeStoredProc,
  executeStoredProcWithDateFilter,
  executeQuery
} = require("../utils/StoredProcedureExecutor.js");

const today = new Date();
const ranges = {
    1: { start: startOfDay(today)},
    2: { start: startOfDay(subDays(today, 1))},
    3: { start: startOfWeek(today, { locale: enIN }), end: endOfWeek(today, { locale: enIN }) },
    4: { start: startOfWeek(subDays(today, 7), { locale: enIN }), end: endOfWeek(subDays(today, 7), { locale: enIN }) },
    5: { start: startOfMonth(today), end: endOfMonth(today) },
    6: { start: startOfMonth(subMonths(today, 1)), end: endOfMonth(subMonths(today, 1)) },
    7: { start: startOfQuarter(today), end: endOfQuarter(today) },
    8: { start: startOfQuarter(subQuarters(today, 1)), end: endOfQuarter(subQuarters(today, 1)) },
    9: { start: startOfYear(today), end: endOfYear(today) },
  };
// API to fetch dashboard data
const getDashboardData = async (req, res) => {
  try{
  const { startDate, endDate,  dedicatedDuration , duration, shift ,durationFlag } = req.query;
  console.log("durationFlag",durationFlag)
  if (!durationFlag) {
    return res.status(400).json({ error: "Request parameter is required" });
  }
//#region DummyData
  // const productionData = {
  //   target: 1000,
  //   actual: 850,
  //   achieved: 85, 
  //   LHD: 200,
  //   RHD: 150,
  //   MonthTarget: 3000,
  //   MonthAchieved: 2500,
  // };

  //this is as shift A = 55, shift B = 38, shift C = 92 and OEE = 75
  // const shiftOEEData = {
  //   categories: ["Shift A", "Shift B", "Shift C", "OEE"],
  //   values: [55, 38, 92, 75],
  // };

  // const OEEParameter = {
  //   availability: 67,
  //   performance: 85,
  //   quality: 95,
  // };
//#endregion
  //here 0th index is for Total Available Time and 1st index is for Total Downtime 
  
  // const chartSeries = [24, 10];

  let result;
  result = await executeStoredProcWithDateFilter(
    sequelize,
    "APP_SP_Dashboard_ProductionSummaryByRange",
    startDate || null,
    endDate || null,              
    shift || null,
    dedicatedDuration || null,
    duration || null,
    durationFlag|| null,
    
  );

  console.log("Data----", result);

  const OEEDistribution = await executeQuery(
  sequelize,
  "EXEC APP_SP_Dashboard_OEE_Data @RangeKey = :durationFlag",
  { durationFlag }
);

console.log("OEEDistribution" , OEEDistribution)
  // Step 1: Extract and parse the stored procedure result
const rawData = result[0]?.DashboardProductionSummary;

if (!rawData) {
  return res.status(500).json({ error: "No data returned from stored procedure" });
}

const parsedData = JSON.parse(rawData);

// Step 2: Parse each nested JSON field
const productionData = JSON.parse(parsedData.RangeData);
// Handle ShiftWiseOEEDistribution — check if it's a string or already an array
let shiftOEEData = [];

shiftOEEData.push({
  Shift: "Shift A",
  OEE: OEEDistribution[0]?.ShiftA_OEE || 0,
});
shiftOEEData.push({
  Shift: "Shift B",
  OEE: OEEDistribution[0]?.ShiftB_OEE || 0,
});
shiftOEEData.push({
  Shift: "Shift C",
  OEE: OEEDistribution[0]?.ShiftC_OEE || 0,
});
shiftOEEData.push({
  Shift: "OEE",
  OEE: OEEDistribution[0]?.AvgOEE || 0,
});



const MonthlyData = JSON.parse(parsedData.MonthlyData);
const OEEParameter = {
  Availability: OEEDistribution[0]?.AvgAvailability || 0,
  Performance: OEEDistribution[0]?.AvgPerformance || 0,
  Quality: OEEDistribution[0]?.AvgQuality || 0,
};

const chartSeries = [
  OEEDistribution[0]?.AvailableTime ?? 0,
  OEEDistribution[0]?.BreakDown ?? 0
];


// Step 3: Return response in expected format
res.status(200).json({
  data: {
    parameter: durationFlag,
    productionData,
    shiftOEEData,
    chartSeries,
    OEEParameter,
    MonthlyData
  },
});

  }
  catch(error)
  {
    console.error("Error fetching data:", error);
    res.status(500).json({ error: "Internal Server Error at getDashboardData" });
  }

};

module.exports = {getDashboardData};