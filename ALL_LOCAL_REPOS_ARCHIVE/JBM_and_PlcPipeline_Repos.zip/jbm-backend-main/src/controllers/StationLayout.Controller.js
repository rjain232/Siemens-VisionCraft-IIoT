const { localSequelize: sequelize } = require("../db/connection.js");
const { executeQuery } = require("../utils/StoredProcedureExecutor.js");
const getSafetyComponentsStatus = async (req, res) => {
  try {
    const componentStatusResult = await executeQuery(
      sequelize,
      `EXEC APP_SP_GetLineStatus`
    );

    const productionDataResult = await executeQuery(
      sequelize,
      `EXEC APP_SP_Dashboard_ProductionSummaryByRange  @RangeKey = :durationFlag`,
      { durationFlag: 1 }
    );

     const cabinDetails = await executeQuery(sequelize, `EXEC APP_SP_Live_Cabin_Status`)

    const rawData = productionDataResult[0]?.DashboardProductionSummary;
    const parsedData = JSON.parse(rawData);
    const MonthlyData = JSON.parse(parsedData.MonthlyData);
    const productionData = JSON.parse(parsedData.RangeData);

   res.status(200).json({ data: {componentStatusResult , productionData , MonthlyData , cabinDetails} });
  
  } catch (error) {
    console.log("error", error);
    res.status(500).json({ error: "Error in fetching data" });
  }
};

module.exports = { getSafetyComponentsStatus };
