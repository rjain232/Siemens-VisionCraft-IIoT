//const { el } = require("date-fns/locale");
const {
  executeStoredProcWithDateFilter,
  executeStoredProc,
} = require("../utils/StoredProcedureExecutor");
const { Sequelize } = require("sequelize");
const { localSequelize } = require("../db/connection");
const { Op } = require("sequelize");
const { subDays, subMonths, startOfMonth, format } = require('date-fns');

function getStartDateEndDateFromDuration(duration) {
  const today = new Date();
  let startDate, endDate;

  switch (duration) {
    case "Last10Days":
      endDate = today;
      startDate = subDays(today, 10);
      break;

    case "CurrentMonth":
      endDate = today;
      startDate = startOfMonth(today);
      break;

    case "Last3Months":
      endDate = today;
      startDate = startOfMonth(subMonths(today, 3)); 
      // 1st day of 3 months ago
      break;

    case "Last6Months":
      endDate = today;
      startDate = startOfMonth(subMonths(today, 6)); 
      // 1st day of 6 months ago
      break;

    default:
      return [null, null];
  }

  return [
    format(startDate, 'yyyy-MM-dd'),
    format(endDate, 'yyyy-MM-dd')
  ];
}

const ProductionReport = async (req, res) => {
  try {
    let { startDate, endDate, duration, shift } = req.query;
    console.log("Received query params:", startDate, endDate, duration, shift);
    if(duration){
      ([startDate, endDate] = getStartDateEndDateFromDuration(duration));
    }
        console.log("Received query params:", startDate, endDate, duration, shift);

    let result;
    if ((startDate && endDate) || shift) {
      console.log(startDate, endDate);
      result = await executeStoredProcWithDateFilter(
        localSequelize,
        "APP_SP_GetProductionReport",
        startDate || null,
        endDate || null
      );
    } else {
      result = await executeStoredProc(
        localSequelize,
        "APP_SP_GetProductionReport"
      );
    }
    res.status(200).json({
      status: true,
      data: result,
    });
  } catch (error) {
    console.error("Error fetching data:", error);
    res
      .status(500)
      .json({ error: "Internal Server Error at ProductionReport" });
  }
};

const ProductionOverview = async (req, res) => {
  try {
    const { startDate, endDate, duration, shift } = req.query;
    let result;
   
    if ((startDate && endDate) || shift) {
      
      const OverallProductionTrendData = await executeStoredProcWithDateFilter(
        localSequelize,
        "APP_SP_GetOverall_Production_Trend",
        startDate || null,
        endDate || null
      );
      const ShiftwiseProductionDistributionData =
        await executeStoredProcWithDateFilter(
          localSequelize,
          "APP_SP_GetShiftwise_Production_Distribution",
          startDate || null,
          endDate || null
        );
      const ShiftDetailsProductionData = await executeStoredProcWithDateFilter(
        localSequelize,
        "APP_SP_GetShift_Details_Production",
        startDate || null,
        endDate || null
      );
      result = {
        OverallProductionTrendData,
        ShiftwiseProductionDistributionData,
        ShiftDetailsProductionData,
      };
    } else {
      const OverallProductionTrendData = await executeStoredProc(
        localSequelize,
        "APP_SP_GetOverall_Production_Trend"
      );
      const ShiftwiseProductionDistributionData = await executeStoredProc(
        localSequelize,
        "APP_SP_GetShiftwise_Production_Distribution"
      );
      const ShiftDetailsProductionData = await executeStoredProc(
        localSequelize,
        "APP_SP_GetShift_Details_Production"
      );

      result = {
        OverallProductionTrendData,
        ShiftwiseProductionDistributionData,
        ShiftDetailsProductionData,
      };
    }

    res.status(200).json({
      status: true,
      data: result,
    });
  } catch (error) {
    console.error("Error fetching data:", error);
    res
      .status(500)
      .json({ error: "Internal Server Error at ProductionReport" });
  }
};

const Hourly_Production_Report = async (req, res) => {
  try {
    console.log("Received query params:", req.query);
    const { startDate, endDate, duration, shift } = req.query;
    let result;
    if ((startDate && endDate) || shift) {
      console.log(startDate, endDate);
      result = await executeStoredProcWithDateFilter(
        localSequelize,
        "APP_SP_Hourly_Production_Report",
        startDate || null,
        endDate || null,
        shift || null
      );
    } else {
      result = await executeStoredProc(
        localSequelize,
        "APP_SP_Hourly_Production_Report"
      );
    }
    console.log("Hourly Production Report result:", result);
    res.status(200).json({
      status: true,
      data: result,
    });
  } catch (error) {
    console.error("Error fetching data:", error);
    res
      .status(500)
      .json({ error: "Internal Server Error at ProductionReport" });
  }
};

const DetailedProductionReport = async (req, res) => {
  try {
    const { startDate, endDate, dedicatedDuration, duration, shift } =
      req.query;
    let result;
    if ((startDate && endDate) || shift) {
      console.log(startDate, endDate);
      const detailedProductionTableAndGraphData =
        await executeStoredProcWithDateFilter(
          localSequelize,
          "APP_SP_Detailed_Production_Report",
          startDate || null,
          endDate || null,
          shift || null,
          dedicatedDuration || null,
          duration || null
        );
      let shiftOEEData = await executeStoredProcWithDateFilter(
        localSequelize,
        "APP_SP_ShiftWise_OEE_Distribution",
        startDate || null,
        endDate || null,
        shift || null,
        dedicatedDuration || null,
        duration || null
      );
      console.log("Shift OEE Data before processing:", shiftOEEData);
      if (shiftOEEData.length != 0) {
        shiftOEEData = shiftOEEData?.map((item) => ({
          ...item,
          shift: `Shift ${item?.shift?.trim()}`,
        }));

        // const totalOEE = shiftOEEData?.reduce((sum, item) => sum + item.OEE, 0);
        // const avgOEE = totalOEE / shiftOEEData?.length;

        // Add overall objec
        // shiftOEEData?.push({
        //   OEE: parseFloat(avgOEE.toFixed(2)),
        //   shift: "Overall",
        // });
      }

      result = {
        detailedProductionTableAndGraphData,
        shiftOEEData,
      };
    } else {
      const detailedProductionTableAndGraphData = await executeStoredProc(
        localSequelize,
        "APP_SP_Detailed_Production_Report"
      );
      let shiftOEEData = await executeStoredProc(
        localSequelize,
        "APP_SP_ShiftWise_OEE_Distribution"
      );
      shiftOEEData = shiftOEEData?.map((item) => ({
        ...item,
        shift: `Shift ${item.shift.trim()}`,
      }));

      // const totalOEE = shiftOEEData?.reduce((sum, item) => sum + item.OEE, 0);
      // const avgOEE = totalOEE / shiftOEEData?.length;

      // // Add overall objec
      // shiftOEEData?.push({
      //   OEE: parseFloat(avgOEE.toFixed(2)),
      //   shift: "Overall",
      // });

      result = {
        detailedProductionTableAndGraphData,
        shiftOEEData,
      };
    }
    res.status(200).json({
      status: true,
      data: result,
    });
  } catch (error) {
    console.error("Error fetching data:", error);
    res
      .status(500)
      .json({ error: "Internal Server Error at ProductionReport" });
  }
};

const CycleTimeData = async (req, res) => {
  try {
    const { startDate, endDate, duration, shift } = req.query;
    let result;
    if ((startDate && endDate) || shift) {
      console.log(startDate, endDate);
      result = await executeStoredProcWithDateFilter(
        localSequelize,
        "APP_SP_Cycle_Time",
        startDate || null,
        endDate || null
      );
    } else {
      result = await executeStoredProc(localSequelize, "APP_SP_Cycle_Time");
    }
    res.status(200).json({
      status: true,
      data: result,
    });
  } catch (error) {
    console.error("Error fetching data:", error);
    res
      .status(500)
      .json({ error: "Internal Server Error at ProductionReport" });
  }
};

const updateOkNokCount = async (req, res) => {
  try {
    const { date, shift, noklhcount,  nokrhcount } = req.body;
    console.log("Received data:", req.body);
    if (!date || !shift) {
      return res.status(400).json({ error: "date and shift are required" });
    }

  const [results] = await localSequelize.query(
  "EXEC APP_SP_UpdateOkNokCount @date = :date, @shift = :shift, @noklhcount = :noklhcount, @nokrhcount = :nokrhcount",
  {
    replacements: { date, shift, noklhcount, nokrhcount },
    type: Sequelize.QueryTypes.SELECT,
  }
);
  console.log("Update results:", results);
    res.status(200).json({
      status: true,
      message: "Entry updated successfully",
      data: results,
    });
  } catch (error) {
    res.status(500).json({ error: error?.message || "Internal Server Error at updateOkNokCount" });
  }
};
module.exports = {
  ProductionReport,
  Hourly_Production_Report,
  ProductionOverview,
  DetailedProductionReport,
  CycleTimeData,
  updateOkNokCount
};
