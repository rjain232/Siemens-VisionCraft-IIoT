const { localSequelize } = require("../db/connection");
const {
  executeStoredProc,
  executeStoredProcWithDateFilter,
} = require("../utils/StoredProcedureExecutor");

function formatDate(dateStr) {
  const [year, month, day] = dateStr.split("-");
  return `${day}-${month}-${year}`;
}
const stationwiseOEE = async (req, res) => {
  try {
    const { startDate, endDate, days } = req.query;
    console.log("StartDate----", startDate, endDate);
    let result;
    //#region API Calls
    if (startDate && endDate) {
      result = await executeStoredProcWithDateFilter(
        localSequelize,
        "APP_SP_GetStationWiseOEEData",
        startDate,
        endDate
        //days
      );
    } else {
      result = await executeStoredProc(
        localSequelize,
        "APP_SP_GetStationWiseOEEData"
      );
    }
    //#endregion

    //#region Format API API Calls
    const formattedResult = {};

    result.forEach((item) => {
      const name = item.StationName; // Already full name from SP

      if (!formattedResult[name]) {
        formattedResult[name] = {
          name,
          shiftData: [],
          apqData: [],
        };
      }

      // Add shift data
      if ("Shift" in item && "OEE" in item) {
        formattedResult[name].shiftData.push({
          name: item.Shift, // Directly using shift name like "Shift A"
          oee: item.OEE,
        });
      }

      // Add APQ data
      if (
        "Availability" in item &&
        "Performance" in item &&
        "Quality" in item
      ) {
        formattedResult[name].apqData = [
          { name: "Availability", value: Number(item.Availability).toFixed(2) },
          { name: "Performance", value: Number(item.Performance).toFixed(2) },
          { name: "Quality", value: Number(item.Quality).toFixed(2) },
        ];
      }
    });

    // Compute OEE average for each station
    Object.values(formattedResult).forEach((station) => {
      const { shiftData } = station;
      const avgOee =
        shiftData.length > 0
          ? shiftData.reduce((sum, s) => sum + s.oee, 0) / shiftData.length
          : 0;
      shiftData.push({ name: "OEE", oee: Number(avgOee.toFixed(2)) });
    });

    // Final output array
    const stations_sp = Object.values(formattedResult);
    //#endregion

    // Respond
    res.status(200).json({
      status: true,
      data: stations_sp,
    });
  } catch (error) {
    console.error("Error fetching data:", error);
    res.status(500).json({ error: "Internal Server Error at stationwiseOEE" });
  }
};
const top10faults = async (req, res) => {
  try {
    const { startDate, endDate, duration, shift, dedicatedDuration } =
      req.query;

    let result;
    //#region API Calls
    if ((startDate && endDate) || shift) {
      console.log(shift);
      result = await executeStoredProcWithDateFilter(
        localSequelize,
        "SP_GetTop10Faults",
        startDate || null, // Pass null if undefined
        endDate || null,
        shift || null
      );
    } else {
      console.log("StartDate----", startDate, endDate, shift);
      result = await executeStoredProc(localSequelize, "SP_GetTop10Faults");
    }
    res.status(200).json({
      status: true,
      data: result,
    });
    // //#endregion
    console.log(result);
  } catch (error) {
    console.error("Error fetching data:", error);
    res.status(500).json({ error: "Internal Server Error at top10faults" });
  }
};

const overallOEE = async (req, res) => {
  try {
    let result;
    const { startDate, endDate, shift } = req.query;    
    let availableVSDowntime = [];
    if (startDate && endDate) {
      const daywiseOEEDistribution = await executeStoredProcWithDateFilter(
        localSequelize,
        "APP_SP_Daywise_OEE_Distribution",
        startDate,
        endDate,
        shift
      );

      const oeeParameters = await executeStoredProcWithDateFilter(
        localSequelize,
        "APP_SP_Overall_Equipment_Efficiency",
        startDate,
        endDate,
        shift
      );

    availableVSDowntime  = [oeeParameters[0]?.AvailableTime, oeeParameters[0]?.BreakDown];

      let shiftWiseOEEDistribution = await executeStoredProcWithDateFilter(
        localSequelize,
        "APP_SP_ShiftWise_OEE_Distribution",
        startDate,
        endDate
      );

      shiftWiseOEEDistribution = shiftWiseOEEDistribution.map((item) => ({
        ...item,
        OEE: parseFloat(item?.OEE?.toFixed(2)),
        shift: `Shift ${item.shift}`,
      }));

      const totalOEE = shiftWiseOEEDistribution.reduce((sum, item) => sum + item.OEE, 0);
      const avgOEE = totalOEE / shiftWiseOEEDistribution.length;

      shiftWiseOEEDistribution.push({
        OEE: oeeParameters[0]?.OEE ? oeeParameters[0].OEE: parseFloat(avgOEE.toFixed(2)),
        shift: "Overall",
      });

      const groupedData = {};

      daywiseOEEDistribution.forEach((item) => {
        const formattedDate = formatDate(item.Date);
        if (!groupedData[formattedDate]) {
          groupedData[formattedDate] = { date: formattedDate };
        }
        groupedData[formattedDate][`Shift_${item.Shift}`] = item.OEE;
      });

      const finalOutput = Object.values(groupedData).map((entry) => {
        const shifts = ["Shift_A", "Shift_B", "Shift_C"];
        const shiftValues = shifts.map((shift) => entry[shift]).filter(Boolean);
        const total = shiftValues.reduce((sum, val) => sum + val, 0);
        const avg = shiftValues.length ? parseFloat((total / shiftValues.length).toFixed(2)) : 0;

        return {
          ...entry,
          OEE: avg,
        };
      });

      result = {
        oeeParameters,
        shiftWiseOEEDistribution,
        availableVSDowntime,
        dayAndShiftWiseOEE: finalOutput,
      };
    } else {
      const daywiseOEEDistribution = await executeStoredProc(localSequelize, "APP_SP_Daywise_OEE_Distribution");
      const oeeParameters = await executeStoredProc(localSequelize, "APP_SP_Overall_Equipment_Efficiency");
      let shiftWiseOEEDistribution = await executeStoredProc(localSequelize, "APP_SP_ShiftWise_OEE_Distribution");
        const availableVSDowntime = [oeeParameters[0]?.AvailableTime, oeeParameters[0]?.BreakDown];

      shiftWiseOEEDistribution = shiftWiseOEEDistribution.map((item) => ({
        ...item,
        shift: `Shift ${item.shift}`,
      }));

      const totalOEE = shiftWiseOEEDistribution.reduce((sum, item) => sum + item.OEE, 0);
      const avgOEE = totalOEE / shiftWiseOEEDistribution.length;

      shiftWiseOEEDistribution.push({
        OEE: oeeParameters[0]?.OEE ? oeeParameters[0].OEE: parseFloat(avgOEE.toFixed(2)),
        shift: "Overall",
      });

      const groupedData = {};

      daywiseOEEDistribution.forEach((item) => {
        const formattedDate = formatDate(item.Date);
        if (!groupedData[formattedDate]) {
          groupedData[formattedDate] = { date: formattedDate };
        }
        groupedData[formattedDate][`Shift_${item.Shift}`] = item.OEE;
      });

      const finalOutput = Object.values(groupedData).map((entry) => {
        const shifts = ["Shift_A", "Shift_B", "Shift_C"];
        const shiftValues = shifts.map((shift) => entry[shift]).filter(Boolean);
        const total = shiftValues.reduce((sum, val) => sum + val, 0);
        const avg = shiftValues.length ? parseFloat((total / shiftValues.length).toFixed(2)) : 0;

        return {
          ...entry,
          OEE: oeeParameters[0]?.OEE ? oeeParameters[0].OEE: parseFloat(avg.toFixed(2)),
        };
      });

      result = {
        oeeParameters,
        shiftWiseOEEDistribution,
        availableVSDowntime,
        dayAndShiftWiseOEE: finalOutput,
      };
    }

    res.status(200).json({ status: true, data: result });
  } catch (error) {
    console.error("Error fetching data:", error);
    res.status(500).json({ error: "Internal Server Error at overallOEE" });
  }
};


module.exports = {
  stationwiseOEE,
  top10faults,
  overallOEE,
};
