const { Sequelize } = require("sequelize");
const { localSequelize: sequelize } = require("../db/connection.js");
const {
  executeStoredProc,
  executeStoredProcWithDateFilter,
  executeQuery,
} = require("../utils/StoredProcedureExecutor.js");
require("dotenv").config();

const RobotHealth = async (req, res) => {
  try {
    let result;
    //result = robothealth;
    result = await executeStoredProc(sequelize, "APP_SP_Robot_Health");
    res.status(200).json({
      status: true,
      data: result,
    });
  } catch (error) {
    console.error("Error fetching robot health:", error);
    res.status(500).json({ success: false, error: error.message });
  }
};


const getRobotEditLogs = async (req, res) => {
  try {
    const dummyData = [
      {
        robotId: "R10001",
        editDate: "30-01-2025",
        editTime: "08:12:34 AM",
      },
      {
        robotId: "R10002",
        editDate: "31-01-2025",
        editTime: "09:20:18 AM",
      },
      {
        robotId: "R10003",
        editDate: "01-02-2025",
        editTime: "10:35:48 AM",
      },
      {
        robotId: "R10004",
        editDate: "02-02-2025",
        editTime: "11:40:59 AM",
      },
      {
        robotId: "R10005",
        editDate: "03-02-2025",
        editTime: "12:45:12 PM",
      },
      {
        robotId: "R10006",
        editDate: "04-02-2025",
        editTime: "01:55:23 PM",
      },
      {
        robotId: "R10007",
        editDate: "05-02-2025",
        editTime: "02:05:34 PM",
      },
      {
        robotId: "R10008",
        editDate: "06-02-2025",
        editTime: "03:15:45 PM",
      },
      {
        robotId: "R10009",
        editDate: "07-02-2025",
        editTime: "04:25:56 PM",
      },
      {
        robotId: "R10010",
        editDate: "08-02-2025",
        editTime: "05:35:07 PM",
      },
    ];

    return res.json({
      success: true,
      message: "Alarms retrieved successfully",
      data: dummyData,
    });
  } catch (error) {
    console.error("Error fetching alarms:", error);
    res.status(500).json({ success: false, error: error.message });
  }
};

const getRobotLogs = async (req, res) => {
  const { startDate, endDate, duration, shift, dedicatedDuration } = req.query;
 // console.log("StartDate----",startDate,endDate, duration,shift,dedicatedDuration);
  let result;
  if (startDate && endDate) {
    result = await executeStoredProcWithDateFilter(
      sequelize,
      "APP_SP_Robot_Status",
      startDate,
      endDate
    );
  }
  // If both dates are provided, call the stored procedure with date filter
  else {
    result = await executeStoredProc(sequelize, "APP_SP_Robot_Status");
  }
  res.status(200).json({
    success: true,
    data: result,
  });
};

const getRobotEventLogs = async (req, res) => {
  try {
   const { startDate, endDate } = req.query;
    let result;

    if (startDate && endDate) {
      result = await executeStoredProcWithDateFilter(
        sequelize,
        "APP_SP_RobotEvent",
        startDate,
        endDate
      );
    }
    // If both dates are provided, call the stored procedure with date filter
    else {
      result = await executeStoredProc(sequelize, "APP_SP_RobotEvent");
    }
    res.status(200).json({
      success: true,
      data: result,
    });
    
  } catch (error) {
    console.error("Error fetching robot logs:", error);
    res.status(500).json({ error: error.message });
  }
};

const getRobotList = async (req, res) => {
  try {
    const result = await executeStoredProc(sequelize, "APP_SP_GetRobotList");
    res.status(200).json({
      success: true,
      data: result,
    });
  } catch (error) {
    console.error("Error fetching robot list:", error);
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
};

const getSpotAccuracy = async (req, res) => {
  const { startDate, endDate } = req.query;
  let result;
  try {
    if (startDate && endDate) {
      const queryResult = await executeStoredProcWithDateFilter(
        sequelize,
        "APP_SP_SpotAccuracyDetails",
        startDate,
        endDate
      );

      const AllSpotDataJson = JSON.parse(queryResult[0].AllSpotDataJson)?.map(
        (item) => {
        
          const spotAccuracy =
            item.SpotActual === 0 ? 0 : (item.SpotActual / item.SpotTarget) * 100;
          return {
            ...item,
            SpotMiss :  item.SpotMiss > 0
          ? `+${item.SpotMiss}`
          : item.SpotMiss < 0
          ? `-${Math.abs(item.SpotMiss)}`
          : "0",
            SpotAccuracy: spotAccuracy.toFixed(2), // rounded to 2 decimal places
          };
        }
      );
      const robotDataMap = new Map();

      AllSpotDataJson?.forEach((item) => {
        const robotId = item.RobotId;
        const date = item.Timestamp.split("T")[0]; // Only the date part
        const spotAccuracy = parseFloat(item.SpotAccuracy);

        if (!robotDataMap.has(robotId)) {
          robotDataMap.set(robotId, new Map());
        }

        const dateMap = robotDataMap.get(robotId);

        if (!dateMap.has(date)) {
          dateMap.set(date, []);
        }

        dateMap.get(date).push(spotAccuracy);
      });

      // Step 2: Transform to desired output format
      const robotWiseSummary = Array.from(robotDataMap.entries()).map(
        ([robotId, dateMap]) => {
          const spotdata = Array.from(dateMap.entries()).map(
            ([date, accuracies]) => {
              const avgAccuracy = (
                accuracies.reduce((sum, acc) => sum + acc, 0) /
                accuracies.length
              ).toFixed(2);
              return {
                date,
                spotaccuracy: parseFloat(avgAccuracy),
              };
            }
          );

          // Sort spotdata by date ascending
          spotdata.sort((a, b) => new Date(a.date) - new Date(b.date));

          return {
            RobotId: robotId,
            RobotName: `Robot ${robotId}`, // You can replace with real names if available
            spotdata,
          };
        }
      );
      const totalActualSpots = queryResult[0].TotalSpotActual;
      const totalMissedSpots = queryResult[0].TotalSpotMissed;
      result = {
        robotWiseSummary,
        AllSpotDataJson,
        totalActualSpots,
        totalMissedSpots,
      };
    } else {
      const queryResult = await executeStoredProc(
        sequelize,
        "APP_SP_SpotAccuracyDetails"
      );
      const robotWiseSummary = JSON.parse(queryResult[0].RobotWiseSummary);
      const AllSpotDataJson = JSON.parse(queryResult[0].AllSpotDataJson)?.map(
        (item) => {
        
          const spotAccuracy =
            item.SpotActual === 0 ? 0 : (item.SpotActual / item.SpotTarget) * 100;
          return {
            ...item,
              SpotMiss :  item.SpotMiss > 0
          ? `+${item.SpotMiss}`
          : item.SpotMiss < 0
          ? `-${Math.abs(item.SpotMiss)}`
          : "0",
            SpotAccuracy: spotAccuracy.toFixed(2), // rounded to 2 decimal places
          };
        }
      );

      const totalActualSpots = queryResult[0].TotalSpotActual;
      const totalMissedSpots = queryResult[0].TotalSpotMissed;
      result = {
        robotWiseSummary,
        AllSpotDataJson,
        totalActualSpots,
        totalMissedSpots,
      };
    }

    //console.log("spot accuracy result", JSON.parse(result[0].RobotWiseSummary));
    if (!result || result.length === 0) {
      return res.status(404).json({
        success: false,
        message: "No data found",
      });
    }
    res.status(200).json({
      success: true,
      data: result,
    });
  } catch (error) {
    console.error("Error fetching spot accuracy:", error);
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
};

const getRobotOverloadHistoryTrendData = async (req, res) => {
  try {
    const {
      startDate,
      endDate,
      selectedRobot,
      selectedAxis,
      selectedParameter,
    } = req.query;

    const robot = selectedRobot.toString().padStart(2, "0");

    const paramMap = {
      Current: "Curr",
      Torque: "Torq",
      Temperature: "Temp",
    };

    const param = paramMap[selectedParameter];

    if (!param) {
      return res.status(400).send("Invalid parameter");
    }

    const tagName = `${robot}_${param}_${selectedAxis}`;
    let result;
    result = await executeQuery(
      sequelize,
      "EXEC APP_SP_GetRobotOverloadHistoryTrendData @StartDate = :startDate, @EndDate = :endDate, @TagName = :TagName",
      {
        startDate: startDate ?? null,
        endDate: endDate ?? null,
        TagName: tagName ?? null
      },
      Sequelize.QueryTypes.SELECT,
    );

    res.status(200).json({
      success: true,
      data: {
        startDate: startDate,
        endDate: endDate,
        Robot: selectedRobot,
        Axis: selectedAxis,
        currentLowerLimit: process.env.currentLowerLimit,
        currentUpperLimit: process.env.currentUpperLimit,
        dataCount: result?.length,
        Parameter: selectedParameter,
        data: result,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: `${error?.code} ${error?.message}` ?? "Internal Server Error",
    });
  }
};


const getRobotOverloadHistoryRawData = async (req, res) => {
  try {
    const { startDate, endDate, selectedRobot, selectedAxis ,selectedParameter } = req.query;
     const robot = selectedRobot.toString().padStart(2, "0");

    const paramMap = {
      Current: "Curr",
      Torque: "Torq",
      Temperature: "Temp",
    };

    const param = paramMap[selectedParameter];

    if (!param) {
      return res.status(400).send("Invalid parameter");
    }

    const tagName = `${robot}_${param}_${selectedAxis}`;
    let result;
    result = await executeQuery(
      sequelize,
      "EXEC APP_SP_GetRobotOverloadHistoryRawData @StartDate = :startDate, @EndDate = :endDate,  @TagName = :TagName",
      {
        startDate: startDate ?? null,
        endDate: endDate ?? null,
        TagName : tagName ?? null
      },
      Sequelize.QueryTypes.SELECT,
    );

    res.status(200).json({
      success: true,
      data: {
        startDate : startDate,
        endDate : endDate,
        Robot : selectedRobot,
        Axis : selectedAxis,
        dataCount : result?.length,
        Parameter : selectedParameter,
        data: result,
      },
    });
  } catch (error) {
    console.error("Error fetching robot overload history trend data:", error);
    res.status(500).json({
      success: false,
      message: error?.message || "Internal Server Error",
    });
  }
};

const getParamConfig = async (req, res) => {
  try {
    const [results] = await sequelize.query(`
      SELECT 
          ParameterName,
          MinValue AS min,
          MaxValue AS max,
          Unit AS unit,
          Color AS color
      FROM ParamConfig
      WHERE IsActive = 1
    `);

    const PARAM_CONFIG = results.reduce((acc, item) => {
      acc[item.ParameterName] = {
        min: item.min,
        max: item.max,
        unit: item.unit,
        color: item.color
      };
      return acc;
    }, {});

    return res.json({
      success: true,
      data: PARAM_CONFIG
    });

  } catch (error) {
    console.error("ParamConfig Error:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to fetch PARAM_CONFIG"
    });
  }
};

module.exports = {
  RobotHealth,
  getRobotEditLogs,
  getRobotLogs,
  getRobotEventLogs,
  getRobotList,
  getSpotAccuracy,
  getRobotOverloadHistoryTrendData,
  getRobotOverloadHistoryRawData,
  getParamConfig
};
