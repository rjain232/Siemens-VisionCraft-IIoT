const getAlramsData=()=>{
return[
  {
    Id : 1,
    Date: "30-01-2025",
    Time: "10:30:00",
    AlarmCode: "A123",
    AlarmReason : "Robot Collision",
    Type : "Alarm",
    DownTime: "15",
    Remark:""
  },
  {
    Id : 2,
    Date: "30-01-2025",
    Time: "11:45:00",
    AlarmCode: "B456",
    Type:"Warning",
    AlarmReason:"Weight Exceeded",
    DownTime: "30",
      Remark:""
  },
  {
    Id : 3,
    Date: "30-01-2025",
    Time: "13:15:00",
    AlarmCode: "C789",
    Type : "Alarm",
    AlarmReason : "Emergency stop activated",
    DownTime: "10",
      Remark:""
  },
  {
    Id : 4,
    Date: "30-01-2025",
    Time: "13:15:00",
    AlarmCode: "C789",
    Type:"Warning",
    AlarmReason:"Safety gate opened",
    DownTime: "10",
      Remark:""
  },
  {
    Id : 5,
    Date: "30-01-2025",
    Time: "13:15:00",
    AlarmCode: "C789",
    Type : "Alarm",
    AlarmReason:"Collision detected",
    DownTime: "10",
      Remark:""
  },
  {
    Id : 6,
    Date: "30-01-2025",
    Time: "13:15:00",
    AlarmCode: "C789",
    Type : "Alarm",
    AlarmReason:"Workcell safety sensor triggered",
    DownTime: "10",
      Remark:""
  },
]
};
const getAlarms = async (req, res) => {
  try {
    // const dummyData = [
    //   {
    //     Id : 1,
    //     Date: "30-01-2025",
    //     Time: "10:30:00",
    //     AlarmCode: "A123",
    //     AlarmReason : "Robot Collision",
    //     Type : "Alarm",
    //     DownTime: "15",
    //     Remark:""
    //   },
    //   {
    //     Id : 2,
    //     Date: "30-01-2025",
    //     Time: "11:45:00",
    //     AlarmCode: "B456",
    //     Type:"Warning",
    //     AlarmReason:"Weight Exceeded",
    //     DownTime: "30",
    //       Remark:""
    //   },
    //   {
    //     Id : 3,
    //     Date: "30-01-2025",
    //     Time: "13:15:00",
    //     AlarmCode: "C789",
    //     Type : "Alarm",
    //     AlarmReason : "Emergency stop activated",
    //     DownTime: "10",
    //       Remark:""
    //   },
    //   {
    //     Id : 4,
    //     Date: "30-01-2025",
    //     Time: "13:15:00",
    //     AlarmCode: "C789",
    //     Type:"Warning",
    //     AlarmReason:"Safety gate opened",
    //     DownTime: "10",
    //       Remark:""
    //   },
    //   {
    //     Id : 5,
    //     Date: "30-01-2025",
    //     Time: "13:15:00",
    //     AlarmCode: "C789",
    //     Type : "Alarm",
    //     AlarmReason:"Collision detected",
    //     DownTime: "10",
    //       Remark:""
    //   },
    //   {
    //     Id : 6,
    //     Date: "30-01-2025",
    //     Time: "13:15:00",
    //     AlarmCode: "C789",
    //     Type : "Alarm",
    //     AlarmReason:"Workcell safety sensor triggered",
    //     DownTime: "10",
    //       Remark:""
    //   },
    // ];  
const dummyData =getAlramsData();
    return res.json({
      success: true,
      message: "Alarms retrieved successfully",
      data: dummyData,
    });
  } catch (error) {
    console.error("Error fetching alarms:", error);
    res.status(500).json({ success: false, error: error.message });
  }
};

module.exports = {
  getAlarms,getAlramsData,
};
