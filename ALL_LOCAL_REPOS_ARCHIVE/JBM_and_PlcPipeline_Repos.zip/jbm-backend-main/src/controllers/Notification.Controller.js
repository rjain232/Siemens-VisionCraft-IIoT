// const {
//   localSequelize: sequelize,
  
// } = require("../db/connection.js");
const { localSequelize } = require("../db/connection");
const {
  executeStoredProc,
  executeStoredProcWithDateFilter,
  executeQuery,
} = require("../utils/StoredProcedureExecutor");

const getNotification = async (req, res) => {
  try {
    const [results] = await localSequelize.query(`
     SELECT * FROM tbl_tool_activity_history
      WHERE DATEDIFF(DAY, [ComplitedOn], GETDATE()) > 2
    `);
    res.status(200).json(data(results));
  } catch (error) {
    console.error('Notification fetch error:', error);
    res.status(500).json({ error: 'Server error' });
  }
};
const getNotification_PendingToolActivity=async (req, res)=>{
  try{
      const notification= await executeQuery(localSequelize,"APP_SP_Notifications_ToolActivities");
      result={
          notification
      };
      res.status(200).json({
          success: true,
          data: result,
        });
  }
  catch(error){
      console.error("Error fetching data:", error);
      res.status(500).json({ error: "Internal Server Error at overallOEE" });
  }
  };

  module.exports={
    getNotification_PendingToolActivity,
    }