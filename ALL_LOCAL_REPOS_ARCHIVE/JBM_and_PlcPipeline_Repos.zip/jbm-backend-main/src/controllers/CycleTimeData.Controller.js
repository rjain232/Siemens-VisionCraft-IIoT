const productionData = require("../Data/cycleTimeData");

const getCycleTimeData = (req, res) => {
  try {
    const CycletimeData = productionData;
    res.status(200).json({
      success: true,
      data: CycletimeData,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      massage: "Internal Server Error",
    });
  }
};

module.exports = {
  getCycleTimeData,
};
