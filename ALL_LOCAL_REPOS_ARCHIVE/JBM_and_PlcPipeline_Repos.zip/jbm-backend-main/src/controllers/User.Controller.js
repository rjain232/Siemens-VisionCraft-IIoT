const Encryption = require("../utils/Encryption");
const userModel = require("../models/User.Model");

const login = async (req, res) => {
  try {
        const data = req.body;
    const user = await userModel.findOne({
      where: {
        Username: data.Username,
      },
    });

    if (!user) {
      return res.status(404).json({ success: false, error: "User not found" });
    }

    if (data.Password !== user.Password) {
      return res
        .status(401)
        .json({ success: false, error: "Invalid credentials" });
    }

    console.log("user on login" , user.dataValues.id)
    const token = Encryption.generateJwtToken({id : user.dataValues.id});

    res.json({data : {
      success: true,
      message: "Login successfully",
      token,
    }});
  } catch (error) {
    console.error("Login error:", error);
    res.status(500).json({ success: false, error: error.message });
  }
};

const getUserProfile = async(req  ,res) =>{
  try {
    const user = await userModel.findOne({ where: { id: req.user.id } });
    if (!user) return res.status(404).json({ message: "User not found" });
    const response = {
      Username :user.dataValues["Username"],
      FirstName :user.dataValues["FirstName"],
      LastName :user.dataValues["LastName"],
      Email :user.dataValues["Email"],
      MobileNumber : user.dataValues["MobileNumber"]
    }
    res.json({data :response});
  } catch (error) {
    console.log("err" , error)
    res.status(500).json({ message: "Server error" });
  }
}

module.exports = {
  login,
  getUserProfile
};
