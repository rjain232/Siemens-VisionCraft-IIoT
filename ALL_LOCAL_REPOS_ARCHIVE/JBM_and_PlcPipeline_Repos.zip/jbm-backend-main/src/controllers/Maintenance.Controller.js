const ToolActivity = require("../Data/ToolActivity");
const { Sequelize } = require("sequelize");
const {
  localSequelize: sequelize,
  localSequelize,
} = require("../db/connection.js");
const XLSX = require("xlsx");
const fs = require("fs");

const {
  executeStoredProc,
  executeStoredProcWithDateFilter,
  executeQuery,
} = require("../utils/StoredProcedureExecutor.js");

const getStations = async (req, res) => {
  try {
    const result = await executeStoredProc(localSequelize, "APP_SP_GetAllStations");
    res.status(200).json({ status: true, data: result });
  } catch (error) {
    console.error("Error fetching data:", error);
    res.status(500).json({ error: "Error fetching data:" });
  }
};

const getToolActivity = (req, res) => {
  try {
    const Tooldata = ToolActivity;
    return res.status(200).json({
      success: true,
      data: Tooldata,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      data: "Internal Server Error",
    });
  }
};
const Downtime_Report = async (req, res) => {
  try {
    const { startDate, endDate , station } = req.query;
    console.log(startDate, endDate , station)
    let result;
    //result = dummydata_DowntimeRport;
    // Check if startDate and endDate are provided
    const Downtime_Table_Report = await executeQuery(
      sequelize,
      "EXEC APP_SP_Downtime_Table_Overview @StartDate = :startDate, @EndDate = :endDate, @Station = :station",
      {
        startDate: startDate ?? null,
        endDate: endDate ?? null,
        station: station ?? null,
      },
      Sequelize.QueryTypes.SELECT,
    );

      const Downtime_Bar_Data = await executeQuery(
      sequelize,
      "EXEC APP_SP_Downtime_Bar_Overview @StartDate = :startDate, @EndDate = :endDate, @Station = :station",
      {
        startDate: startDate ?? null,
        endDate: endDate ?? null,
        station: station ?? null,
      },
      Sequelize.QueryTypes.SELECT,
    );
      
     result = {
        Downtime_Table_Report,
        Downtime_Bar_Data,
        station
      };
    res.status(200).json({
      success: true,
      data: result,
    });
  } catch (error) {
    console.error("Error fetching Downtime_Report:", error);
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
};
const Top10Alarm = async (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    let result;
    // result = Top10alarmData;
    // Check if startDate and endDate are provided
      // If both dates are provided, call the stored procedure with date filter
    if (startDate && endDate) {
      result = await executeStoredProcWithDateFilter(
        sequelize,
        "APP_SP_Top10Critical_Alarms_Bar",
        startDate,
        endDate
      );
    }
    else {
      result = await executeStoredProc(
        sequelize,
        "APP_SP_Top10Critical_Alarms_Bar"
      );
    }

    // console.log("alarmData:", result);
    res.status(200).json({
      success: true,
      data: result,
    });
  } catch (error) {
    console.error("Error fetching Top10Alarm:", error);
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
};
const AlarmReport = async (req, res) => {
  try {
    const { startDate, endDate ,station } = req.query;
    let result;
   result = await executeQuery(
      sequelize,
      "EXEC APP_SP_AlarmReport @StartDate = :startDate, @EndDate = :endDate, @station = :station",
      {
        startDate: startDate ?? null,
        endDate: endDate ?? null,
        station: station ?? null,
      },
      Sequelize.QueryTypes.SELECT,
    );
    res.status(200).json({
      success: true,
      data: result,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
      error: error,
    });
  }
};
const ATCInterruption = async (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    let result;

    if (startDate && endDate) {
      result = await executeStoredProcWithDateFilter(
        sequelize,
        "APP_SP_ATC_Interruption",
        startDate,
        endDate
      );
    }
    // If both dates are provided, call the stored procedure with date filter
    else {
      result = await executeStoredProc(sequelize, "APP_SP_ATC_Interruption");
    }
    console.log("ATC Interruption data:", result);
    res.status(200).json({
      success: true,
      data: result,
    });
  } catch (error) {
    console.error("Error fetching ATCInterruption:", error);
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
      error: error,
    });
  }
};
const MiscellaneousAlarms = async (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    let result;

    if (startDate && endDate) {
      result = await executeStoredProcWithDateFilter(
        sequelize,
        "APP_SP_Miscellaneous_Alarm",
        startDate,
        endDate
      );
    }
    // If both dates are provided, call the stored procedure with date filter
    else {
      result = await executeStoredProc(sequelize, "APP_SP_Miscellaneous_Alarm");
    }

    console.log("MiscellaneousAlarms Data:", result);
    res.status(200).json({
      success: true,
      data: result,
    });
  } catch (error) {
    console.error("Error fetching MiscellaneousAlarms :", error);
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
      error: error,
    });
  }
};
const TipChangeCount = async (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    let result;
    //result = dummydata_DowntimeRport;
    // Check if startDate and endDate are provided
    if (startDate && endDate) {
      const Tip_ChangeCount_Table = await executeStoredProcWithDateFilter(
        sequelize,
        "APP_SP_Tip_ChangeCount_Table",
        startDate,
        endDate
      );
      const Tip_ChangeCount_Bar_Data = await executeStoredProcWithDateFilter(
        sequelize,
        "APP_SP_Tip_ChangeCount_Bar",
        startDate,
        endDate
      );
      result = {
        Tip_ChangeCount_Table,
        Tip_ChangeCount_Bar_Data,
      };
    }
    // If both dates are provided, call the stored procedure with date filter
    else {
      const Tip_ChangeCount_Table = await executeStoredProc(
        sequelize,
        "APP_SP_Tip_ChangeCount_Table"
      );
      const Tip_ChangeCount_Bar_Data = await executeStoredProc(
        sequelize,
        "APP_SP_Tip_ChangeCount_Bar"
      );
      result = {
        Tip_ChangeCount_Table,
        Tip_ChangeCount_Bar_Data,
      };
    }

    res.status(200).json({
      success: true,
      data: result,
    });
  } catch (error) {
    console.error("Error fetching Downtime_Report:", error);
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
};

const getComplianceData = async (req, res) => {
  try {
    
    const pendingActivitiesData = await executeStoredProc(
      localSequelize,
      "APP_SP_GetToolsWithPendingActivities"
    );
    const activitiesCount = await executeQuery(localSequelize , 'EXEC APP_SP_GetActivitiesCount');
    console.log("activitiesCount" , activitiesCount);
    const currentWeekDetails = await executeQuery(localSequelize , 'EXEC APP_SP_CompletedActivitiesCount_CurrentWeek');
    const chartSeries = [activitiesCount[0].ActivitiesPerformed, activitiesCount[0].ActivitiesToBeCompleted];
    const result = {
      chartSeries,
      pendingActivitiesData,
      activitiesCount : activitiesCount[0],
      currentWeekDetails,
    };

    return res.status(200).json({ status: true, data: result });
  } catch (error) {
    console.error("Error fetching data:", error);
    return res.status(500).json({ error: "Error fetching data:" });
  }
};

const getTools = async (req, res) => {
  try {
    const result = await executeStoredProc(localSequelize, "APP_SP_GetAllTools");
    res.status(200).json({ status: true, data: result });
  } catch (error) {
    console.error("Error fetching data:", error);
    res.status(500).json({ error: "Error fetching data:" });
  }
};

const getActivities = async (req, res) => {
  try {
    const { toolId } = req.query;
    if (!toolId || toolId == "") {
      return res
        .status(200)
        .json({ status: true, message: "Tool Id not provided", data: [] });
    }
    const query = `EXEC APP_SP_GetActivityByToolAndAction @ToolId = :toolId, @Action = :action;`;
    const replacements = {
      action: 0,
      toolId: toolId,
    };

    const result = await executeQuery(localSequelize, query, replacements);

    return res.status(200).json({ status: true, data: result });
  } catch (error) {
    console.error("Error fetching data:", error);
    return res.status(500).json({ error: "Error fetching data:" });
  }
};
const updateTool_Maintenance = async (req, res) => {
  try {
    const dataArray = req.body;
    console.log("DATA--", dataArray);

    if (!Array.isArray(dataArray) || dataArray.length === 0) {
      return res
        .status(400)
        .json({ status: false, error: "Invalid data format." });
    }

    for (const item of dataArray) {
      const query = `EXEC APP_SP_UpdateToolMaintenance 
        @toolid = :ToolId, 
        @activity = :Activity, 
        @action = :Action, 
       @remark = :Remark, 
       @complitedBy = :ReportBy`;

      await executeQuery(localSequelize, query, {
        ToolId: item.ToolId,
        Activity: item.Activity,
        Action: item.Action,
        Remark: item.Remark,
        ReportBy: item.reportBy, // note lowercase key
      });
    }

    res
      .status(200)
      .json({
        data: {
          success: true,
          message: "Tool maintenance data updated successfully.",
        },
      });
  } catch (error) {
    console.error("Error fetching data:", error);
    return res.status(500).json({ error: "Error fetching data:" });
  }
};

const uploadActivities = async (req, res) => {
  try {
    const filePath = req.file.path;
    const workbook = XLSX.readFile(filePath);
    const sheetName = workbook.SheetNames[0];
    const sheetData = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName]);
    // Delete uploaded file after reading
    console.log("sheetData", sheetData);
    for (const item of sheetData) {
      const query = `EXEC APP_SP_InsertToolActivity_IfNotExists @ToolId = :ToolId,@Activity = :ActivityName, @Timestamp = NULL;`;

      const replacements = {
        ToolId: item.ToolId,
        ActivityName: item.ActivityName,
      };

      const result = await executeQuery(
        localSequelize,
        query,
        replacements,
        Sequelize.QueryTypes.RAW
      );
      console.log("insert result", result);
    }

    fs.unlinkSync(filePath);
    res.status(200).json({
      data: {
        status: true,
        data: sheetData,
        message: "Data uploaded successfully",
      },
    });
  } catch (error) {
    console.log("error", error);
    res.status(500).json({ error: "Failed to process file" });
  }
};


module.exports = {
  getToolActivity,
  Downtime_Report,
  Top10Alarm,
  AlarmReport,
  ATCInterruption,
  MiscellaneousAlarms,
  TipChangeCount,
  getComplianceData,
  getActivities,
  getTools,
  updateTool_Maintenance,
  uploadActivities,
  getStations
};
