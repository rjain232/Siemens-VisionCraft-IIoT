const {
  executeStoredProc,
  executeStoredProcWithDateFilter,
} = require("../utils/StoredProcedureExecutor.js");
const { localSequelize: sequelize } = require("../db/connection.js"); // Import the sequelize instance
const { format } = require("date-fns");

function formatDateTimeIST(dateStr) {
  return dateStr.split(" ")[1];
}

function formatDateOnlyIST(dateStr) {
  console.log("Input Date:", dateStr);
  return format(new Date(dateStr.split(" ")[0]), "dd-MM-yyyy");
}

function formatDurationFromSeconds(seconds) {
  const hrs = Math.floor(seconds / 3600)
    .toString()
    .padStart(2, "0");
  const mins = Math.floor((seconds % 3600) / 60)
    .toString()
    .padStart(2, "0");
  const secs = (seconds % 60).toString().padStart(2, "0");
  return `${hrs}:${mins}:${secs}`;
}
function formatDurationFromMinutes(minutes) {
  const totalSeconds = minutes * 60;
  const hrs = Math.floor(totalSeconds / 3600)
    .toString()
    .padStart(2, "0");
  const mins = Math.floor((totalSeconds % 3600) / 60)
    .toString()
    .padStart(2, "0");
  const secs = (totalSeconds % 60).toString().padStart(2, "0");
  return `${hrs}:${mins}:${secs}`;
}

const getMachineSetUpData = async (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    let result;
    // Check if startDate and endDate are provided
    if (startDate && endDate) {
      result = await executeStoredProcWithDateFilter(
        sequelize,
        "sp_GetMachineSetupByTimeRange",
        startDate,
        endDate
      );
    }
    // If both dates are provided, call the stored procedure with date filter
    else {
      result = await executeStoredProc(
        sequelize,
        "sp_GetDashboardDefaultMachineSetupData"
      );
    }

    console.log("Machine setup data:", result);
    const formattedData = result.map((item) => ({
      ...item,
      SetupBegin: formatDateTimeIST(item.SetupBegin),
      SetupComplete: formatDateTimeIST(item.SetupComplete),
      Timestamp: formatDateOnlyIST(item.Timestamp),
      Duration: formatDurationFromSeconds(item.Duration),
    }));
    console.log("Formatted Data:", formattedData);
    res.status(200).json({
      success: true,
      data: formattedData,
    });
  } catch (error) {
    console.error("Error fetching machine setup data:", error);
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
};

module.exports = {
  getMachineSetUpData,
};
