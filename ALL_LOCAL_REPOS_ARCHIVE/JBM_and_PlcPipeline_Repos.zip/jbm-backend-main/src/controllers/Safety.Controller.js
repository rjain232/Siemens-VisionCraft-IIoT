const getSafetyAlarms = async (req, res) => {
    try {
      const dummyData = [
        {
          Date: "30-01-2025",
          Time: "10:30:00",
          AlarmCode: "LSE12",
          AlarmReason : "Limit switch error",
          Type : "Alarm",
          DownTime: "15",
        },
        {
          Date: "30-01-2025",
          Time: "11:45:00",
          AlarmCode: "WE456",
          Type:"Warning",
          AlarmReason:"Weld error",
          DownTime: "30",
        },
        {
          Date: "30-01-2025",
          Time: "13:15:00",
          AlarmCode: "SCA89",
          Type : "Alarm",
          AlarmReason : "Spot count error",
          DownTime: "10",
        },
        {
          Date: "30-01-2025",
          Time: "13:15:00",
          AlarmCode: "C789",
          Type:"Warning",
          AlarmReason:"Profinet communication error",
          DownTime: "10",
        },
        {
          Date: "30-01-2025",
          Time: "13:15:00",
          AlarmCode: "TP789",
          Type : "Alarm",
          AlarmReason:"Tackle not in home position",
          DownTime: "10",
        },
        {
          Date: "30-01-2025",
          Time: "13:15:00",
          AlarmCode: "TCE78",
          Type : "Alarm",
          AlarmReason:"Torque control error",
          DownTime: "10",
        },
      ];  
  
      return res.json({
        success: true,
        message: "Alarms retrieved successfully",
        data: dummyData,
      });
    } catch (error) {
      console.error("Error fetching alarms:", error);
      res.status(500).json({ success: false, error: error.message });
    }
  };
  
  module.exports = {
    getSafetyAlarms,
  };