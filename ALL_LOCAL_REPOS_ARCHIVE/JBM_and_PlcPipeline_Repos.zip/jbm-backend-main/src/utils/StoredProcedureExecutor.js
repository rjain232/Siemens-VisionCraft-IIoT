const { Sequelize } = require("sequelize");
const { localSequelize } = require("../db/connection");

const executeStoredProc = async (sequelizeInstance, storedProcName) => {
    try {
        const result = await sequelizeInstance.query(`EXEC ${storedProcName}`, {
            type: Sequelize.QueryTypes.SELECT,
        });
        return result;
    } catch (error) {
        console.error("Error fetching data executeStoredProc :", error);
        throw new Error("Internal Server Error executeStoredProc :", error);
    }
};

const executeStoredProcWithDateFilter = async (
    sequelizeInstance,
    storedProcName,
    startDate,
    endDate,
    shift,
    dedicatedDuration,
    duration,
    durationFlag,
    toolId
  ) => {
    // ({ startDate, endDate } = utils.getDurationStartAndEnd(
    //   //days,
    //   startDate,
    //   endDate
    // ));
   // startDate = startDate.toISOString().split("T")[0];
   // endDate = endDate.toISOString().split("T")[0];
   try {
    let query = `EXEC ${storedProcName} @StartDate = :startDate, @EndDate = :endDate`;
    let replacements = { startDate, endDate ,dedicatedDuration};

    if (shift) {
      query += `, @Shift = :shift`;
      replacements.shift = shift;
    }

    if (dedicatedDuration) {
      query += `, @DedicatedDuration = :dedicatedDuration`;
      replacements.dedicatedDuration = dedicatedDuration;
    }

    if (durationFlag) {
      query += `, @RangeKey = :durationFlag`;
      replacements.durationFlag = durationFlag;
    }

    if(toolId){
       query += `, @ToolId = :toolId , @Action = :action`;
      replacements.toolId = toolId;
      replacements.action = 0;
    }

    const result = await sequelizeInstance.query(query, {
      replacements,
      type: Sequelize.QueryTypes.SELECT,
    });

    return result; 
  } catch (error) {
      console.error("Error fetching data with date filter:", error);
      throw new Error("Internal Server Error");
    }
  };

  const executeQuery = async (sequelizeInstance,query ,  replacements = {} , type) => {
    try {
      
     const result = await sequelizeInstance.query(query, {
      type: type ||Sequelize.QueryTypes.SELECT,
      replacements, // dynamic parameters
    });

      return result;
    } catch (error) {
      console.error("Error:", error);
      throw new Error("Internal Server Error");
    }
  };

  module.exports = {
    executeStoredProc,
    executeStoredProcWithDateFilter,
    executeQuery,
  };