const jwt = require("jsonwebtoken");
require("dotenv").config();
const SECRET_KEY = process.env.JWT_SECRET_KEY;
const TOKEN_EXPIRY = process.env.JWT_TOKEN_EXPIRY;

class Encryption {
  constructor() {
  }
 
  static generateJwtToken(data) {
    return jwt.sign({ ...data }, SECRET_KEY, {
      expiresIn: TOKEN_EXPIRY,
      algorithm: "HS512",
    });
  }

  async verifyJwtToken(token) {
    return new Promise((resolve, reject) => {
      jwt.verify(token, SECRET_KEY, (err, decoded) => {
        if (err) {
          resolve(null);
        } else {
          resolve(decoded);
        }
      });
    });
  }
}

module.exports = Encryption;
