const { DataTypes } = require("sequelize");
const { localSequelize } = require("../db/connection");

const DowntimeLog = localSequelize.define(
  "DowntimeLogs",
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    Date: {
      type: DataTypes.DATEONLY,
      allowNull: false,
    },
    Time: {
      type: DataTypes.TIME,
      allowNull: false,
    },
    AlarmCode: {
      type: DataTypes.STRING(50),
      allowNull: false,
    },
    DownTime: {
      type: DataTypes.STRING(50),
      allowNull: false,
    },
    CreatedAt: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: DataTypes.NOW,
    },
  },
  {
    tableName: "DowntimeLogs",
    timestamps: false,
  }
);

module.exports = DowntimeLog;
