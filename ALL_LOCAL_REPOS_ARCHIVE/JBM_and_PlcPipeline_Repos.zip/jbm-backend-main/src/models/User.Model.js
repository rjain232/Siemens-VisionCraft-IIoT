const { DataTypes } = require("sequelize");
const { localSequelize } = require("../db/connection");

const User = localSequelize.define(
  "Users",
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      field: "UserID", // Match the database column name
    },
    Username: {
      type: DataTypes.STRING(255),
      unique: {
        name: "unique_userName",
        msg: "Username must be unique",
      },
      allowNull: false,
    },
    FirstName: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    LastName: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    Email: {
      type: DataTypes.STRING(255),
      unique: {
        name: "unique_email",
        msg: "Email must be unique",
      },
      allowNull: true,
      validate: {
        isEmail: { msg: "Must be a valid email address" },
      },
    },
    Password: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    MobileNumber: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    CreatedAt: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: DataTypes.NOW,
      field: "CreatedAt", // Database column name
    },
    UpdatedAt: {
      type: DataTypes.DATE,
      allowNull: true,
      field: "UpdatedAt", // Database column name
    },
  },
  {
    tableName: "Users",
    timestamps: false, // Disable Sequelize auto timestamps
  }
);

module.exports = User;
