const { Sequelize } = require("sequelize");
const { localConfig } = require("./config");

const localSequelize = new Sequelize(
  localConfig.database,
  localConfig.username,
  localConfig.password,
  {
    host: localConfig.host,
    dialect: localConfig.dialect,
    port: localConfig.port,
    dialectOptions: localConfig.dialectOptions,
    pool:localConfig.pool
  }
);

localSequelize
  .authenticate()
  .then(() => {
    console.log("Database connection established successfully.");
  })
  .catch((error) => {
    console.error("Unable to connect to the database:", error);
  });

module.exports = { localSequelize };
