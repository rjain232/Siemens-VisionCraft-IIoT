module.exports.localConfig = {
  host: "127.0.0.1",
  username: "rjain",
  password: "rjain123!",
  database: "Titan1301",
  dialect: "mssql",
  port: 1434,
  dialectOptions: {
    options: {
      encrypt: false,
      trustServerCertificate: true,
      enableArithAbort: true,
    },
    requestTimeout: 30000,
  },
};

// module.exports.localConfig = {
//   host: "SRBPL1SCADABIW1\\SQLEXPRESS",
//   username: "sa",
//   database: "JBM",
//   password: "Dacpl@12345678",
//   dialect: "mssql",
//   port: 1433,
//   dialectOptions: {
//     instanceName: "SQLEXPRESS",
//     connectTimeout: 60000,
//     requestTimeout: 60000,
//   },
//   pool: {
//     max: 20,
//     min: 0,
//     acquire: 120000, // important
//     idle: 10000,
//   },

//   logging: false,
// };
